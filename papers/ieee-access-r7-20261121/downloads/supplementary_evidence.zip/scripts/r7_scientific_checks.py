"""Verify immutable scientific content and the current editorial artifacts."""
from collections import Counter
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile
import hashlib
import json
import re
import unicodedata
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT.parent/"revision6_editorial_closeout_20261120"
OUT=ROOT/"final_review_20261120"
def read(path):return json.loads(Path(path).read_text(encoding="utf-8-sig"))
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def norm(s):return re.sub(r"\s+","",unicodedata.normalize("NFKC",s).replace("\u00ad",""))
def pdftext(path):return "\n".join(p.extract_text() for p in PdfReader(path).pages)

def main():
    preserved=read(ROOT/"evidence/G0_R6_protected_inputs.json")
    assert all(sha(r["path"])==r["sha256"] for r in preserved)
    science=[]
    for p in (OLD/"evidence").iterdir():
        if p.is_file() and (re.match(r"^(E[0-9](?:_|\.)|B[1-7](?:_|\.)|C[123])",p.name) or p.name in ["number_registry.json","stable.json","additional.json","mcm.json","diagnostics.json"]):
            assert sha(ROOT/"evidence"/p.name)==sha(p),p.name
            science.append(p.name)
    immutable=["numbers_revision2.tex","architecture_results.tex","references.bib","author_biographies_to_complete.tex",
               "manuscript.bbl","supplement.tex","officehome60_supplement.tex","locoop_complete_supplement.tex"]
    immutable += [p.relative_to(OLD/"source").as_posix() for folder in ["tables","figures"] for p in (OLD/"source"/folder).rglob("*") if p.is_file() and p.suffix in {".tex",".pdf"}]
    for rel in immutable:assert sha(ROOT/"source"/rel)==sha(OLD/"source"/rel),rel
    old=(OLD/"source/body_revision.tex").read_text(encoding="utf-8")
    new=(ROOT/"source/body_revision.tex").read_text(encoding="utf-8")
    formal=r"\\begin\{(equation|align)\}.*?\\end\{\1\}"
    assert [m[0] for m in re.finditer(formal,old,re.S)]==[m[0] for m in re.finditer(formal,new,re.S)]
    methods=lambda s:s[s.index(r"\section{Related Work}"):s.index(r"\section{Results}")]
    assert methods(old)==methods(new),"Related Work/methods/protocol changed"
    total_old="\n".join((OLD/"source"/s).read_text(encoding="utf-8") for s in ["manuscript.tex","body_revision.tex","architecture_results.tex"])
    total_new="\n".join((ROOT/"source"/s).read_text(encoding="utf-8") for s in ["manuscript.tex","body_revision.tex","architecture_results.tex"])
    pattern=r"\\(?:Num[a-z]+|Close[a-z]+|[A-Z][A-Za-z]+)\{\}"
    assert Counter(re.findall(pattern,total_old))==Counter(re.findall(pattern,total_new)),"Result macro use changed"
    clean=pdftext(ROOT/"source/manuscript.pdf")
    highlight=pdftext(ROOT/"source/manuscript_highlighted.pdf")
    assert clean==highlight
    highlight_proof=read(ROOT/"logs/highlight_QA/highlight_verification.json")
    assert highlight_proof["baseline_sha256"]=="38141d5994a65e0fefbfbd85d4184d749ce6c73b6d22f72274e668c6bdba9fc8"
    assert highlight_proof["clean_pdf_sha256"]==sha(ROOT/"source/manuscript.pdf")
    assert highlight_proof["content_streams_unchanged"]
    replies=read(ROOT/"evidence/responses.json")
    old_replies=read(OLD/"evidence/responses.json")
    assert len(replies["records"])==17
    with ZipFile(OUT/"response_to_reviewers.docx") as z:
        xml=ET.fromstring(z.read("word/document.xml"))
    ns={"w":"http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    paragraphs=["".join(p.itertext()) for p in xml.findall("w:body/w:p",ns)]
    word=norm("\n".join(paragraphs))
    reply_text=pdftext(OUT/"response_to_reviewers.pdf")
    for row,previous in zip(replies["records"],old_replies["records"]):
        assert (row["id"],row["concern"])==(previous["id"],previous["concern"])
        for key in ["concern","response","action"]:
            assert norm(row[key]) in word and norm(row[key]) in norm(reply_text),(row["id"],key)
        if row["id"]!="R1.5":
            assert Counter(re.findall(r"\b\d+\.\d+\b",row["response"]))==Counter(re.findall(r"\b\d+\.\d+\b",previous["response"]))
            assert set(re.findall(r"\b\d+\b",previous["response"]))<=set(re.findall(r"\b\d+\b",row["response"])),row["id"]
    assert all(sum(p.startswith(prefix) for p in paragraphs)==17 for prefix in ["Reviewer's concern:","Author response:","Author action:"])
    registry=read(ROOT/"evidence/response_number_registry.json")
    assert registry["compiled_manuscript_sha256"]==sha(ROOT/"source/manuscript.pdf")
    for row in registry["records"]:
        v=read(ROOT/"evidence"/row["file"])
        for key in row["pointer"]:v=v[key]
        assert v==row["value"] and format(v,"."+str(row["decimals"])+"f")==row["display"]
        assert row["display"] in "\n".join(paragraphs)
    labels=replies["labels"]
    old_labels=old_replies["labels"]
    for label,entry in labels.items():
        if label.startswith(("tab:","fig:","eq:")):
            assert entry["number"]==old_labels[label]["number"],label
    assert sorted(int(r["number"]) for k,r in labels.items() if k.startswith("tab:"))==list(range(1,16))
    assert sorted(int(r["number"]) for k,r in labels.items() if k.startswith("fig:"))==list(range(1,9))
    assert labels["sec:discussion"]["number"]=="VI-B" and labels["sec:limits"]["number"]=="VI-C"
    for item in read(ROOT/"evidence/G4_response_reference_bindings.json"):
        for entry in item["main_references"]:assert labels[entry["label"]]==dict(number=entry["number"],page=entry["page"])
    supp=(ROOT/"source/supplement.aux").read_text(encoding="utf-8")
    assert all("\\newlabel{tab:supp-"+str(i)+"}{{S"+str(i)+"}" in supp for i in range(1,20))
    aux=(ROOT/"source/manuscript.aux").read_text(encoding="utf-8")
    cite_order=[]
    for group in re.findall(r"\\citation\{([^}]+)\}",aux):
        for key in group.split(","):
            if key not in cite_order:cite_order.append(key)
    bib={k:int(v) for k,v in re.findall(r"\\bibcite\{([^}]+)\}\{(\d+)\}",aux)}
    assert [bib[k] for k in cite_order]==list(range(1,36)) and bib["codex"]==35
    banned=["AI-assisted","original submission","post-review","authorized","requested","merely","superseded","TBD","AUTHOR REVIEW DRAFT","Not submitted"]
    scans={kind:{s:len(re.findall(re.escape(s),t,re.I)) for s in banned} for kind,t in [("main",clean),("supplement",pdftext(ROOT/"source/supplement.pdf")),("response",reply_text)]}
    assert not any(n for row in scans.values() for n in row.values()),scans
    words=read(ROOT/"evidence/G3_word_counts.json")
    assert words["abstract_words_including_numbers"]<=180 and words["body_ratio"]<=.85
    constraints={
        "Disjoint unknown roles":"Target unknown categories are excluded from all adapter-training and validation inputs.",
        "Validation-only tuning":"All finite-grid choices use validation labels.",
        "Both operands float64":"both interpolation operands are converted before multiplication",
        "Subtractive score equivalence":"strictly increasing in exact-real MSP",
        "Shared images":"PACS and CIFAR-10 test paths recur 15 and 12 times",
        "No IID claim":"Optimization seeds do not create IID population observations.",
        "Failed high recall":"Both reported worst-class recalls remain below 95\\%.",
        "Probability adverse outcome":"Detection-tuned autoMixTemp worsens ECE15, NLL and Brier relative to MSP",
        "Mixing limit":"No consistent mixing benefit appears",
        "Grid sensitivity":"temperature stability is not established",
        "Baseline superiority":"NegLabel and some LoCoOp variants outperform autoMixTemp on CIFAR-10",
        "Different LoCoOp budget":"Training loss, augmentation and budget differ from the adapter control.",
        "External NegLabel information":"NegLabel uses extra vocabulary information",
        "Transfer counterexample":"All mass of an unrestricted future unknown distribution can lie in a nonempty acceptance region",
        "Retrospective disclosure":"Some sensitivity analyses were specified after access to target outcomes and are retrospective."}
    active=new+(ROOT/"source/architecture_results.tex").read_text(encoding="utf-8")
    assert all(sentence in active for sentence in constraints.values()),[k for k,v in constraints.items() if v not in active]
    result=dict(all_checks_pass=True,no_new_experiments=True,research_results_modified=False,
        protected_R6_files_verified=len(preserved),immutable_scientific_evidence_files=len(science),
        immutable_source_files=len(immutable),related_work_methods_protocol_identical=True,
        equation_blocks_identical=True,all_result_macro_occurrences_identical=True,
        main_tables=15,main_figures=8,supplementary_tables=19,references=35,
        first_citation_order_verified=True,clean_highlight_text_exactly_equal=True,
        highlighted_against_actual_initial_submission=True,all_17_full_responses_verified=True,
        literal_reviewer_concerns_unchanged=True,non_editorial_response_decimal_multisets_identical=True,
        current_reference_bindings_verified=True,word_counts=words,forbidden_phrases=scans,
        retained_scientific_constraints=constraints,
        editorial_metadata_only_changes="Abstract/body/page counts and current section/action locations; no experimental statistics changed.",
        semantic_equivalence_note="Scientific constraints and before/after passages were reviewed; automated token/hash checks do not replace scientific judgment.",
        author_approval=False,upload_ready=False)
    (ROOT/"evidence/G5_academic_writing_checks.json").write_text(json.dumps(result,indent=2,ensure_ascii=False),encoding="utf-8")
    print(json.dumps(result,indent=2,ensure_ascii=False))

if __name__=="__main__":main()
