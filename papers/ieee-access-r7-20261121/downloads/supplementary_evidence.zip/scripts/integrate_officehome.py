"""Integrate every complete Office-Home result, without changing any fit/choice."""
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1];PREV=ROOT.parent/"revision3_20261119";SRC=ROOT/"source"
sys.path.insert(0,str(ROOT/"scripts"))
import integrate_results as I

def main():
    audit=I.read(ROOT/"evidence/C1_complete_panel_audit.json")
    assert audit["all_checks_pass"] and audit["n"]==20 and audit["method_unit_records_verified"]==140
    I.main();I.MACROS=[]
    primary=SRC/"tables/primary.tex"
    primary.write_text(primary.read_text().replace("Equal-unit detection means on complete disjoint-unknown panels.","Equal-unit detection means on the primary PACS/CIFAR-10 disjoint-unknown panels."),encoding="ascii")
    rows=[]
    for i,r in enumerate(audit["summary"]):
        label={"Energy-only-T1":"Energy, $T=1$","Energy-T-tuned":"Energy, tuned $T$","Mix-alpha0.5-T-tuned":"Mix, $\\alpha=0.5$","Zero-shot-T-tuned":"Zero-shot, tuned $T$"}.get(r["method"],r["method"])
        rows.append([label]+[I.n("C1_complete_panel_audit",("summary",i,k),6) for k in ["auroc","fpr95","frozen_threshold_test_unknown_tpr","frozen_threshold_test_known_fpr"]])
    I.table("officehome","Separate Office-Home seed0 panel: four domains and five class-role rotations, with all seven prespecified scores. Values are fractions; each unit receives equal weight. The two timing pilots are included, not extra replications. The sampled training/validation budget differs from PACS; these means are not pooled with the main panels.",r"Method & AUROC & FPR@95 & Target unknown recall & Known rejection",rows,"lrrrr")
    aliases={"OHUnits":I.n("C1_complete_panel_audit",("n",),0),
        "OHExcluded":I.n("C1_dedup_v3",("excluded_images",),0),"OHRetained":I.n("C1_dedup_v3",("retained_images",),0),
        "OHUniqueMin":I.n("C1_complete_panel_audit",("unique_unknown_validation_min",),0),
        "OHUniqueMax":I.n("C1_complete_panel_audit",("unique_unknown_validation_max",),0)}
    i=next(i for i,r in enumerate(audit["summary"]) if r["method"]=="autoMixTemp")
    for key,name in [("auroc","OHAUC"),("fpr95","OHFPR"),("frozen_threshold_test_unknown_tpr","OHRecall"),("frozen_threshold_test_known_fpr","OHReject")]:
        aliases[name]=I.n("C1_complete_panel_audit",("summary",i,key),3)
    for comparator,prefix in [("MSP","OHMSP"),("Temp-MSP","OHTemp")]:
        i=next(i for i,r in enumerate(audit["paired_summary"]) if r["comparator"]==comparator)
        for field,tag in [("mean_delta_auroc","AUC"),("mean_delta_fpr95","FPR")]:aliases[prefix+tag]=I.n("C1_complete_panel_audit",("paired_summary",i,field),3,sign=True)
    with (SRC/"numbers_revision2.tex").open("a",encoding="ascii") as f:
        f.write("\n".join(I.MACROS)+"\n"+"\n".join("\\newcommand{\\"+name+"}{"+value+"}" for name,value in aliases.items())+"\n")
    (ROOT/"evidence/number_registry.json").write_text(json.dumps(I.REG,indent=2),encoding="utf-8")
    body=(PREV/"source/body_revision.tex").read_text(encoding="utf-8")
    protocol=r"""\subsection{Separate Office-Home validation panel}\label{sec:officehome-protocol}
Office-Home~\cite{venkateswara2017} contributes four domains and 65 categories. A fixed, sorted category order rotates by 13 positions over five schedules, assigning 35 known, 15 validation-unknown and 15 disjoint target-unknown categories. The next domain supplies validation and the other two supply known-only training. Each source uses ten files per known class; validation uses ten per assigned class: 700 training, 350 known-validation and 150 unknown-validation files. Target evaluation uses all retained files in its assigned known/unknown roles. The resulting \OHUnits{} units use seed0 only and the same adapter, reference grids, prompts and checkpoint rule. This budget is separate from the main panels.

Before fitting, all exact-content groups spanning domains or categories were excluded at the manifest level: \OHExcluded{} files, leaving \OHRetained{}. Raw files were retained. Same-domain/same-category duplicates remain; validation-unknown unique-content counts range from \OHUniqueMin{} to \OHUniqueMax{}, versus 150 nominal files. Threshold estimation therefore uses a small validation pool. Neither the exact-byte audit nor class-role separation excludes near-duplicates or CLIP pretraining exposure.

Only the seven prespecified post-hoc score variants are evaluated on Office-Home; the MCM and NegLabel comparisons remain confined to the primary panels.

"""
    anchor=r"\subsection{Estimands and dependence}\label{sec:dependence}"
    assert body.count(anchor)==1;body=body.replace(anchor,protocol+anchor)
    results=r"""\subsection{Office-Home under a separate sampled budget}\label{sec:officehome-results}
\input{tables/officehome}
\begin{figure*}[t]\centering
\includegraphics[width=.97\textwidth]{figures/officehome_comparison.pdf}
\caption{Complete Office-Home panel, with all seven prespecified scores. Labels are percentages; Table~\ref{tab:officehome} uses fractions. Within each unit, adapter-based scores share one checkpoint. These seed0 results use a sampled training/validation budget and are not pooled with PACS or CIFAR-10.}\label{fig:officehome}
\end{figure*}
AutoMixTemp attains AUROC/FPR@95 of \OHAUC{}/\OHFPR{}. Relative to MSP, its changes are \OHMSPAUC{}/\OHMSPFPR{}; relative to Temp-MSP they are \OHTempAUC{}/\OHTempFPR{}. At the frozen validation-95\% threshold, target unknown recall is \OHRecall{} with known rejection \OHReject{}. The supplement retains every domain/role outcome, source/temperature choice and per-domain summary, including adverse comparisons. This panel broadens dataset coverage without establishing a consistent benefit from interior mixing, multi-seed robustness, or high-recall threshold transfer.

On this panel, Temp-MSP has slightly higher mean AUROC and lower FPR@95 than autoMixTemp. AutoMixTemp's lower transferred known rejection accompanies lower unknown recall, rather than an unconditional improvement at the intended operating point.

"""
    anchor=r"\section{Reproducibility and Limitations}\label{sec:repro}"
    assert body.count(anchor)==1;body=body.replace(anchor,results+anchor)
    body=body.replace("The experiments use disjoint validation and target unknown categories on PACS and CIFAR-10.","The primary experiments use disjoint validation and target unknown categories on PACS and CIFAR-10; Office-Home adds a separate sampled-budget panel.")
    body=body.replace("Disjoint-unknown sample roles. Adapter-based scores share checkpoints; training-free controls use the same samples. Choices use validation data only.",r"Primary PACS/CIFAR-10 sample roles. Adapter-based scores share checkpoints; training-free controls use the same samples. Choices use validation data only. The separate Office-Home roles are specified in Section~\ref{sec:officehome-protocol}.")
    body=body.replace("Complete-panel detection means.","Primary PACS/CIFAR-10 detection means.")
    body=body.replace("relative to MSP on both datasets.","relative to MSP on both primary datasets.")
    body=body.replace(r"\section{Related Work}",r"\Needspace{5\baselineskip}"+"\n"+r"\section{Related Work}")
    body=body.replace(r"\subsection{Realizable high-recall thresholds}",r"\Needspace{12\baselineskip}"+"\n"+r"\subsection{Realizable high-recall thresholds}")
    body=body.replace(r"\section*{Acknowledgment}",r"\clearpage"+"\n"+r"\twocolumn"+"\n"+r"\section*{Acknowledgment}")
    body=body.replace("Two datasets, fixed role schedules and two backbones do not establish broad robustness.","Three datasets, fixed role schedules and two backbones do not establish broad robustness. Office-Home has only one optimization seed and a smaller sampled training/validation budget; its results do not estimate retraining or class-population uncertainty.")
    body=body.replace("these comparisons do not establish universal joint-search superiority.","these comparisons do not establish universal joint-search superiority. Office-Home also favors Temp-MSP on ROC metrics; autoMixTemp's frozen-threshold recall of \\OHRecall{} at known rejection \\OHReject{} is not a deployment guarantee.")
    start=body.index(r"\section{Conclusion}\label{sec:conclusion}")
    end=body.index(r"\clearpage",start)
    conclusion=r"""\section{Conclusion}\label{sec:conclusion}
Stable scoring improves autoMixTemp's mean detection metrics relative to MSP, but simpler scores remain competitive and validation gates do not establish a consistent interior-mixing benefit. Probability and selective-risk diagnostics do not support improved predictive reliability. Conservative validation thresholds trade more known rejection for higher target recall, without guaranteeing 95\% recall. Joint search is an optional, auditable source selector, not a necessary calibration mechanism.

RN50 favors Temp-MSP on FPR@95; full-budget PACS controls show limited checkpoint-selector effects. The NegLabel port is stronger on CIFAR-10 but weaker on PACS. Office-Home also favors Temp-MSP on ROC metrics: autoMixTemp's transferred recall \OHRecall{} with known rejection \OHReject{} does not establish a deployment guarantee.

"""
    body=body[:start]+conclusion+body[end:]
    (SRC/"body_revision.tex").write_text(body,encoding="ascii")
    wrapper=(PREV/"source/manuscript.tex").read_text(encoding="utf-8")
    wrapper=wrapper.replace(r"\pagestyle{headings}",r"\pagestyle{headings}"+"\n"+r"\raggedbottom")
    float_spacing=r"""\makeatletter
\setlength{\@fptop}{0pt}
\setlength{\@fpsep}{16pt}
\setlength{\@fpbot}{0pt plus 1fil}
\setlength{\@dblfptop}{0pt}
\setlength{\@dblfpsep}{16pt}
\setlength{\@dblfpbot}{0pt plus 1fil}
\makeatother
"""
    wrapper=wrapper.replace(r"\begin{document}",float_spacing+r"\begin{document}")
    start=wrapper.index(r"\begin{abstract}")+len(r"\begin{abstract}");end=wrapper.index(r"\end{abstract}")
    abstract=r"""
Stable score arithmetic changes reported discrimination, without establishing predictive reliability or transferable high-recall thresholds. We audit frozen CLIP-Adapter scoring on 84 PACS and 15 CIFAR-10 units with disjoint validation and target unknown categories. Subtractive float32 maximum-softmax scores create boundary ties; float64 log-odds separate arithmetic from validation selection. Stable autoMixTemp changes AUROC/FPR@95 relative to MSP by \AbsPACSAUC{}/\AbsPACSFPR{} on PACS and \AbsCIFARAUC{}/\AbsCIFARFPR{} on CIFAR-10. Frozen validation thresholds attain mean target unknown recall \PACSAutoRecall{} and \CIFARAutoRecall{}. A separate \OHUnits{}-unit Office-Home seed0 panel under a sampled budget yields autoMixTemp AUROC/FPR@95 of \OHAUC{}/\OHFPR{} and transferred recall/known rejection \OHRecall{}/\OHReject{}. Temp-MSP is slightly better on both Office-Home ROC metrics. No panels are pooled. Conservative validation rules trade higher recall for more known rejection. Primary-panel probability and selective-risk diagnostics show no corresponding reliability gain; validation-gated interior mixing is not consistently useful. Controls include 33 RN50 units, \FullBudgetUnits{} full-budget trajectories, and a function-aligned NegLabel port with extra vocabulary information. NegLabel is stronger on CIFAR-10 but weaker on PACS. Dependence-aware summaries remain conditional on fixed fits. The contribution is an auditable score/threshold study, not a new calibration mechanism or deployment guarantee.
"""
    wrapper=wrapper[:start]+abstract+wrapper[end:]
    (SRC/"manuscript.tex").write_text(wrapper,encoding="ascii")
    bib=(PREV/"source/references.bib").read_text(encoding="utf-8")
    bib+=r"""
@inproceedings{venkateswara2017,
 author={Hemanth Venkateswara and Jose Eusebio and Shayok Chakraborty and Sethuraman Panchanathan},
 title={Deep Hashing Network for Unsupervised Domain Adaptation},
 booktitle={Proceedings of the IEEE Conference on Computer Vision and Pattern Recognition},
 year={2017}, pages={5018--5027},
 url={https://openaccess.thecvf.com/content_cvpr_2017/html/Venkateswara_Deep_Hashing_Network_CVPR_2017_paper.html}}
"""
    (SRC/"references.bib").write_text(bib,encoding="ascii")
    print("Complete Office-Home panel integrated; every observed result uses an evidence-bound macro.")

if __name__=="__main__":main()
