"""Human-readable five-part task reports from recorded evidence only."""
from datetime import datetime,timezone
from pathlib import Path
from gap_closure_core import ROOT,read,sha,write


def table(headers,rows):
    return "\n".join(["| "+" | ".join(headers)+" |","| "+" | ".join(["---"]*len(headers))+" |"]+
        ["| "+" | ".join(str(v) for v in r)+" |" for r in rows])


def report(name,sections):
    text="# "+name+"\n\n"+"\n\n".join("## "+title+"\n"+body for title,body in sections)+"\n"
    p=ROOT/"reports"/(name+".md")
    with p.open("x",encoding="utf-8") as f:f.write(text)


def main():
    p=read(ROOT/"evidence/E0_precision.json");geometry=read(ROOT/"evidence/E0_ROC_geometry.json")
    changed=p["changed_observations"]
    report("E0_精度修正与证据保全报告",[
        ("1. 做了什么","明确将混合两侧先转 float64 再乘系数，核对所有已完成面板的选点、ROC及迁移结果；另重算概率/温度和受影响的 CIFAR 条件敏感性。原始缓存和 R4 不改。"),
        ("2. 文件和章节","新增 `evidence/E0_precision.json`、`E0_ROC_geometry.json`、`E0_probability.json`、`E0_temperature.json`、`E0_conditional_reconciliation.json`；正文方法已明确两侧转换。最终数值绑定、图表和回复信尚待新实验整合，不把当前工作稿当终稿。"),
        ("3. 实际数字及 JSON 来源",f"`E0_precision.json` 覆盖 {p['unit_count']} 个单元、{p['method_rows']} 条方法记录；{len(changed)} 条观察存在指标/选择差异。\n\n"+
            table(["数据集/单元","方法","AUROC变化","FPR95变化","选点变化"],[(r["dataset"]+"/"+r["unit"],r["method"],format(r["delta_auroc"],".17g"),r["delta_fpr95"],r["changed_route_or_temperature"]) for r in changed])+
            f"\n\n`E0_ROC_geometry.json`：PACS 所有主面板正负样本对的顺序及并列完全不变={geometry['primary_PACS_all_weighted_ROC_invariant']}。因此原固定权重下的 PACS ROC 敏感性可以按几何等价保留；该证明不适用于概率、风险曲线或阈值数值。CIFAR15单元已按原随机种子重做400次图像权重扫描。"),
        ("4. 有利还是不利","发现并如实纠正一个极小 AUROC 差异，不用显示位数相同掩盖底层差异。不能把数值表示更精确说成模型可靠性提高。"),
        ("5. 需要决定的事","无需新实验授权。历史80单元的修正只放补充材料/回复信，不重新恢复为主结果。")])
    s=read(ROOT/"evidence/E1_search_utility.json")
    report("E1_搜索价值与实际开销报告",[
        ("1. 做了什么","按 adapter/zero-shot/interior 分层；预设验证收益门控全部保留；固定九个 rotation00/seed0 单元对 Temp 与联合搜索做实际 CPU 计时。"),
        ("2. 文件和章节","`E1_search_utility.json` 及逐单元/分层 CSV；对应正文源选择与额外开销讨论，正式表图待统一整合。Office-Home 该文件当前仅20个seed0，不冒称新60个均已完成。"),
        ("3. 实际数字及 JSON 来源",table(["数据集","单元","Temp中位秒","联合中位秒","比值"],[(r["dataset"],r["unit"],format(r["temp_median_seconds"],".6f"),format(r["auto_median_seconds"],".6f"),format(r["auto_to_temp_ratio"],".3f")) for r in s["timing_summary"]])+
            "\n\n每个计时条件一次预热、三次计时，交替顺序；不包含文件加载、模型拟合或编码推理，不是部署吞吐基准。全部逐单元方向和门控结果见 JSON，而不是只选有利组。"),
        ("4. 有利还是不利","搜索增加了可量化开销；验证集内收益不能证明目标场景需要额外搜索。不能把某一有利来源层当作可部署规则。"),
        ("5. 需要决定的事","无需额外 GPU 授权；完整 Office-Home 运行结束并审计后，按预设另汇总60单元。")])
    transfer=read(ROOT/"evidence/E2_transfer_tradeoffs.json")
    rows=[r for r in transfer["summary"] if r["model"]=="ViT-B32" and r["rho"]==.95 and r["policy"]=="pooled"]
    joint=[r for r in transfer["paired_summary"] if r["model"]=="ViT-B32" and r["rho"]==.95 and r["policy"]=="pooled" and r["comparator"]=="Temp-MSP"]
    report("E2_召回与误拒联合结果报告",[
        ("1. 做了什么","四个验证召回目标×两种阈值规则×四个检测器，联合检查目标未知召回、已知误拒、接受已知准确率、污染比例和缺口分位数，并逐单元统计联合改善。"),
        ("2. 文件和章节","`E2_transfer_tradeoffs.json`；对应方法阈值定义、结果阈值迁移、局限。当前 Office-Home 行只代表已经完成的20个seed0；60单元扩展另审计、另生成JSON。"),
        ("3. 实际数字及 JSON 来源",table(["面板","方法","n","目标召回","已知误拒"],[(r["dataset"],r["method"],r["n"],format(r["unknown_recall"],".6f"),format(r["known_rejection"],".6f")) for r in rows])+
            "\n\n以下为 auto 相对 Temp 的逐单元计数，不是独立样本推断：\n\n"+
            table(["面板","n","联合支配","少误拒也少召回","达到95%召回且误拒不更多"],[(r["dataset"],r["n"],r["joint_dominance_count"],r["lower_rejection_lower_recall_count"],r["target_95_with_no_more_rejection_than_comparator_count"]) for r in joint])),
        ("4. 有利还是不利","不能把误拒较少单独认定为改善。表中结果如未达到95%，结论就必须承认不足。验证未知类与目标不同，保守规则也没有无条件召回保证。"),
        ("5. 需要决定的事","不根据目标结果采用某条阈值规则；无需增加授权。待Office-Home60完成后扩展同一组扫描。")])
    dependency=read(ROOT/"evidence/E3_content_dependence.json")
    overlaps=dependency["role_overlap"]
    report("E3_内容依赖诊断报告",[
        ("1. 做了什么","精确内容哈希核对训练、验证和目标角色；用固定哈希优先级把目标内容分给唯一域/角色簇，种子共用子集后先平均，再检查结果。"),
        ("2. 文件和章节","`E3_content_dependence.json`、`E3_content_ownership.json` 及子集计数；对应依赖性方法与局限。原完整样本均值保留，不以诊断子集替换主结果。"),
        ("3. 实际数字及 JSON 来源",table(["检查","单元数/计数"],[("已审查单元",len(overlaps)),("目标/训练有精确内容交叉的单元",sum(r["test_train_shared_hashes"]>0 for r in overlaps)),("目标/验证有精确内容交叉的单元",sum(r["test_validation_shared_hashes"]>0 for r in overlaps)),("训练/验证有精确内容交叉的单元",sum(r["training_validation_shared_hashes"]>0 for r in overlaps))])+
            "\n\n跨簇目标内容不共享的断言已经实际执行；每簇已知/未知保留量及改变后的均值见 JSON。Office-Home 仍是20个seed0范围，新60范围待专门扩展。"),
        ("4. 有利还是不利","这增加依赖诊断透明度，但不能宣布数据独立：训练/验证仍重用，模型已固定，近重复和预训练暴露未排除；子集估计对象也变了。"),
        ("5. 需要决定的事","无需新训练授权，不为制造独立性声明而删换主面板。")])
    print("Four evidence-bound five-part cache reports written.",flush=True)


if __name__=="__main__":main()
