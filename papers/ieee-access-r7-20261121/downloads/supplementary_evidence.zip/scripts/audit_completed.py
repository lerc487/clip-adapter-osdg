"""Verify completed saved scores and all prespecified aggregate results."""
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from sklearn.metrics import roc_auc_score

ROOT=Path(__file__).resolve().parents[1];PREV=ROOT.parent/"revision2_20261118";BASE=ROOT.parent
sys.path.insert(0,str(BASE/"05_new_runs/code"))
from verified_metrics import fpr_at_recall
sys.path.insert(0,str(PREV/"scripts"))
from c3b_scoring import score,branch


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False),encoding="utf-8")


def main():
    spec=read(ROOT/"prespec/integration_20261119.json")
    for name,digest in spec["input_hashes"].items():assert sha(PREV/"evidence"/name)==digest
    c3=read(ROOT/"evidence/C3b.json");assert len(c3["records"])==168 and len(c3["summary"])==6
    units=sorted({r["unit"] for r in c3["records"]});assert len(units)==28
    for uid in units:
        d=PREV/"new_runs/c3b/evaluations"/uid
        result=read(d/"results.json");assert sha(d/"results.json")==read(d/"completed.json")["results_sha256"]
        assert sha(d/"validation_choices_frozen.json")==result["results"][0]["validation_choices_sha256"]
        for r in result["results"]:
            assert sha(Path(r["target_logits_file"]))==r["target_logits_sha256"]
            checkpoint=Path(result["run_input"])/f"epoch_checkpoints/epoch_{r['epoch']:02d}.pt"
            assert sha(checkpoint)==r["checkpoint_sha256"]
            with np.load(r["target_logits_file"],allow_pickle=False) as z:a={k:z[k] for k in z.files}
            s=score(branch(a["tz"],a["ta"],r["selection"]),r["selection"]["T_score"],"energy" if r["method"]=="Energy-T-tuned" else "msp")
            y=(a["ty"]<0).astype(int)
            assert abs(roc_auc_score(y,s)-r["auroc"])<1e-12
            assert abs(fpr_at_recall(s,y)["fpr95"]-r["fpr95"])<1e-12
            assert next(x for x in c3["records"] if (x["unit"],x["selector"],x["method"])==(uid,r["selector"],r["method"]))==r
    for r in c3["summary"]:
        rows=[x for x in c3["records"] if x["selector"]==r["selector"] and x["method"]==r["method"]]
        assert len(rows)==28
        for k in ["auroc","fpr95","frozen_unknown_recall","frozen_known_rejection","known_accuracy"]:assert abs(np.mean([x[k] for x in rows])-r[k])<1e-12
    primary=read(ROOT/"evidence/stable.json")["records"]
    matches=[]
    for method in ["autoMixTemp","Energy-T-tuned"]:
        rows=[]
        for uid in units:
            f=next(r for r in c3["records"] if r["unit"]==uid and r["selector"]=="known_NLL" and r["method"]==method)
            p=next(r for r in primary if r["unit"]==uid and r["dataset"]=="pacs" and r["method"]==method)
            rows.append(dict(unit=uid,delta_auroc=f["auroc"]-p["auroc"],delta_fpr95=f["fpr95"]-p["fpr95"],primary_auroc=p["auroc"],primary_fpr95=p["fpr95"]))
        matches.append(dict(method=method,n=len(rows),exact_equal_metric_pairs=sum(r["delta_auroc"]==0 and r["delta_fpr95"]==0 for r in rows),
            primary_auroc=float(np.mean([r["primary_auroc"] for r in rows])),primary_fpr95=float(np.mean([r["primary_fpr95"] for r in rows])),
            mean_delta_auroc=float(np.mean([r["delta_auroc"] for r in rows])),mean_delta_fpr95=float(np.mean([r["delta_fpr95"] for r in rows])),records=rows))
    neg=read(ROOT/"evidence/C2_NegLabel.json");assert len(neg["records"])==198
    assert read(ROOT/"evidence/C2_NegLabel_alignment.json")["all_checks_pass"] and read(ROOT/"evidence/C2_NegLabel_CUDA_alignment.json")["passed"]
    array_audit=[]
    for r in neg["records"]:
        d=BASE/"05_new_runs"/r["dataset"]/r["unit"]
        sample=read(d/"test_samples.json");y=(np.array([x["label"] for x in sample])<0).astype(int)
        p=PREV/"new_runs/neglabel/unit_results"/r["dataset"]/(r["unit"]+"_"+r["variant"]+".npz")
        with np.load(p,allow_pickle=False) as z:arrays={k:z[k] for k in z.files}
        assert len(arrays["test"])==len(y) and all(np.isfinite(v).all() for v in arrays.values())
        assert abs(roc_auc_score(y,arrays["test"])-r["auroc"])<1e-12
        assert abs(fpr_at_recall(arrays["test"],y)["fpr95"]-r["fpr95"])<1e-12
        v=np.r_[arrays["val_known"],arrays["val_unknown"]]
        vy=np.r_[np.zeros(len(arrays["val_known"]),dtype=int),np.ones(len(arrays["val_unknown"]),dtype=int)]
        threshold=fpr_at_recall(v,vy)["threshold"];assert threshold==r["validation95_threshold"]
        reject=arrays["test"]>=threshold
        assert abs(reject[y==1].mean()-r["frozen_unknown_recall"])<1e-12 and abs(reject[y==0].mean()-r["frozen_known_rejection"])<1e-12
        array_audit.append(dict(dataset=r["dataset"],unit=r["unit"],variant=r["variant"],score_file=str(p),sha256=sha(p),verified=True))
    for r in neg["summary"]:
        rr=[x for x in neg["records"] if x["dataset"]==r["dataset"] and x["variant"]==r["variant"]]
        assert len(rr)==r["n"]
        for k in ["auroc","fpr95","frozen_unknown_recall","frozen_known_rejection"]:assert abs(np.mean([x[k] for x in rr])-r[k])<1e-12
    pilot=read(ROOT/"evidence/C1_pilot_v3_eval64.json")
    assert len(pilot["records"])==2
    for r in pilot["records"]:
        p=PREV/"new_runs/officehome/dedup_v3/pilot_eval64"/(r["unit"]+"_timing.json")
        assert read(p)==r
    measured=dict(unit_minutes=[dict(unit=r["unit"],minutes=r["measured_unit_pipeline_seconds"]/60) for r in pilot["records"]],
        mean_minutes=float(np.mean([r["measured_unit_pipeline_seconds"]/60 for r in pilot["records"]])),
        total_minutes=sum(r["measured_unit_pipeline_seconds"] for r in pilot["records"])/60)
    output=dict(all_checks_pass=True,C3b_units_verified=28,C3b_method_selector_records=168,C3b_target_metrics_recomputed=True,NegLabel_score_arrays_verified=198,
        matched_primary_full20=matches,NegLabel_saved_score_audit=array_audit,OfficeHome_pilot_measured_times=measured,
        no_new_experiments=True,no_target_retuning=True,OfficeHome_complete_stage1_not_yet_included=True)
    dump(ROOT/"evidence/completed_result_audit.json",output)
    print(json.dumps({k:v for k,v in output.items() if k not in ["matched_primary_full20","NegLabel_saved_score_audit"]},indent=2))
    print(json.dumps([{k:v for k,v in r.items() if k!="records"} for r in matches],indent=2))


if __name__=="__main__":main()
