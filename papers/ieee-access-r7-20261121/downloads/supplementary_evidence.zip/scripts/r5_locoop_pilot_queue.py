"""Run exactly two authorized official pilots under the shared GPU lock."""
from datetime import datetime,timezone
import os
from pathlib import Path
import subprocess
import sys
import time
from gap_closure_core import ROOT,BASE,R2,read,sha,write


def state(stage,done,**kw):
    write(ROOT/"evidence/E6_pilot_progress.json",dict(stage=stage,completed=done,total=2,
        pid=os.getpid(),updated_utc=datetime.now(timezone.utc).isoformat(),**kw))


def main():
    spec_path=ROOT/"prespec/E6_locoop_pilot.json";spec=read(spec_path)
    assert sha(spec_path)==read(ROOT/"prespec/E6_locoop_pilot_seal.json")["sha256"]
    assert read(ROOT/"evidence/E6_cpu_fixture_checks.json")["passed"]
    for path,digest in spec["code_hashes"].items():assert sha(path)==digest,path
    lock=R2/"new_runs/GPU_QUEUE.lock"
    with lock.open("x") as f:f.write(str(os.getpid()))
    done=0;records=[]
    try:
        for dataset,unit in spec["pilot_ids"]:
            if any((r/"new_runs/PAUSE_REQUESTED").exists() for r in [ROOT,R2]):
                state("paused_at_unit_boundary",done,next_unit=unit);return
            output=ROOT/"new_runs/locoop_pilot"/dataset/unit
            complete=output/"results.json"
            if output.exists() and not complete.exists():raise RuntimeError("Partial official pilot requires inspection: "+unit)
            if not output.exists():
                log=ROOT/"logs"/("E6_attempt"+str(spec["execution_attempt"])+"_"+dataset+"_"+unit+".log")
                command=[spec["interpreter"],"-B","-s","-u",str(ROOT/"scripts/r5_locoop_pilot_unit.py"),"--dataset",dataset,"--unit",unit]
                state("official_training",done,current=unit,dataset=dataset)
                with log.open("x",encoding="utf-8") as f:
                    subprocess.run(command,cwd=ROOT,env=dict(os.environ,R5_LOCOOP_QUEUE_PID=str(os.getpid()),PYTHONDONTWRITEBYTECODE="1"),
                        stdout=f,stderr=subprocess.STDOUT,check=True)
            result=read(complete)
            assert result["prespec_sha256"]==sha(spec_path) and sha(output/"saved_logits_and_scores.npz")==result["saved_arrays_sha256"]
            assert all(r["passed"] for r in result["official_score_alignment"])
            records.append(result);done+=1;state("pilot_complete",done,current=unit,dataset=dataset)
        write(ROOT/"evidence/E6_pilot_results.json",dict(records=records,prespec_sha256=sha(spec_path),
            independent_cpu_audit_pending=True,requires_user_batch_decision=True,no_extra_batch_started=True),exclusive=True)
        state("complete_requires_audit_and_user_batch_decision",2)
    except Exception as exc:
        state("failed_requires_inspection",done,error=repr(exc));raise
    finally:
        assert lock.read_text().strip()==str(os.getpid())
        lock.unlink()


if __name__=="__main__":main()
