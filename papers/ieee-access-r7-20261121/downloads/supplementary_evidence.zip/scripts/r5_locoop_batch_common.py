"""Fixed batch identities and safe shared validation helpers, without GPU work."""
from collections import defaultdict
from datetime import datetime, timezone
import hashlib
import json
from pathlib import Path
import os
import shutil

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
R2 = BASE / "revision2_20261118"
SPEC = ROOT / "prespec/E6_locoop_batch.json"
INPUTS = ROOT / "evidence/E6_locoop_batch_inputs.json"
METHODS = ["MCM_official", "GLMCM_official", "MCM64", "GLMCM64"]


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value, exclusive=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    if exclusive:
        with path.open("x", encoding="utf-8") as f:
            json.dump(value, f, indent=2, allow_nan=False)
    else:
        temporary = path.with_name(path.name + ".tmp")
        with temporary.open("w", encoding="utf-8") as f:
            json.dump(value, f, indent=2, allow_nan=False)
        temporary.replace(path)


def now():
    return datetime.now(timezone.utc).isoformat()


def pause_requested():
    return any((p / "new_runs/PAUSE_REQUESTED").exists() for p in [ROOT, R2])


def sealed(check_code=True):
    spec = read(SPEC)
    assert sha(SPEC) == read(SPEC.with_name("E6_locoop_batch_seal.json"))["sha256"]
    assert sha(INPUTS) == spec["inputs_sha256"]
    assert sha(ROOT / "evidence/E6_locoop_batch_authorization_20261120.json") == spec["authorization_sha256"]
    if check_code:
        for path, digest in spec["code_hashes"].items():
            assert sha(path) == digest, path
    return spec


def unit_inputs(spec, job):
    item = next(r for r in read(INPUTS)["units"] if (r["dataset"], r["unit"]) == (job["dataset"], job["unit"]))
    original = Path(item["input_run"])
    for name, digest in item["manifest_hashes"].items():
        assert sha(original / name) == digest, (job["fit_id"], name)
    return item


def available_disk():
    return shutil.disk_usage(ROOT).free


def grouped(rows, keys, fields):
    groups = defaultdict(list)
    for row in rows:
        groups[tuple(row[k] for k in keys)].append(row)
    result = []
    for identity, items in sorted(groups.items()):
        value = dict(zip(keys, identity))
        value["n"] = len(items)
        for field in fields:
            values = [r[field] for r in items if r[field] is not None]
            value[field] = sum(values) / len(values) if values else None
        result.append(value)
    return result
