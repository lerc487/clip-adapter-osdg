"""Independent CPU verification of all frozen detector/epoch choices and replay."""
from collections import defaultdict
import sys
import numpy as np
from gap_closure_core import ROOT, read, sha, write, grouped_means
from audit_officehome_complete import select
from r5_independent_audit_helpers import roc, scores, combine, check, fixtures

METHODS=[("MSP","adapter","msp",False),("Temp-MSP","adapter","msp",True),
         ("Energy-T-tuned","adapter","energy",True),("autoMixTemp","auto","msp",True)]


def metric_arrays(a,sel,mode,prefix):
    if prefix=="v":
        return np.r_[scores(combine(a["kz"],a["ka"],sel),sel["T_score"],mode=="energy"),
                     scores(combine(a["uz"],a["ua"],sel),sel["T_score"],mode=="energy")]
    return scores(combine(a["tz"],a["ta"],sel),sel["T_score"],mode=="energy")


def main():
    path=ROOT/"prespec/E4_independent_audit.json";spec=read(path)
    assert sha(path)==read(path.with_name("E4_independent_audit_seal.json"))["sha256"]
    for name,digest in spec["code_hashes"].items():assert sha(name)==digest,name
    fixture=fixtures()
    if "--fixtures" in sys.argv:
        write(ROOT/"evidence/E4_audit_fixtures.json",dict(**fixture,script_sha256=sha(__file__)),exclusive=True)
        print("E4 independent audit synthetic fixtures passed; no target arrays read.",flush=True);return
    assert read(ROOT/"evidence/E4_audit_fixtures.json")["script_sha256"]==sha(__file__)
    frozen_path=ROOT/"evidence/E4_full_validation_plan.json";assert sha(frozen_path)==spec["choices_sha256"]
    own_path=ROOT/"evidence/E4_epoch_validation_selection.json";assert sha(own_path)==spec["epoch_analysis_sha256"]
    parent_path=ROOT/"evidence/E4_target_results.json";parent=read(parent_path)
    assert parent["choices_sha256"]==sha(frozen_path) and len(parent["records"])==264
    assert read(ROOT/"evidence/E4_target_progress.json")["stage"]=="complete_requires_independent_audit"
    frozen=read(frozen_path);own=read(own_path)
    groups=defaultdict(list)
    for r in frozen["records"]:groups[(r["dataset"],r["unit"],r["run"])].append(r)
    assert len(groups)==33 and all(len(v)==8 for v in groups.values())
    selection_audit=[];target_audit=[]
    for (ds,unit,dirname),records in sorted(groups.items()):
        from pathlib import Path
        run=Path(dirname);cfg=read(run/"config.json")["arguments"]
        assert cfg["epochs"]==20 and cfg["seed"]==0 and cfg["model"]=="ViT-B-32"
        grid=[float(x) for x in cfg["temp_candidates"].split(",")]
        alphas=[float(x) for x in cfg["mix_alphas"].split(",")]
        assert alphas==[0.,.25,.5,.75,1.]
        known_labels=[s["label"] for s in read(run/"val_known_samples.json")]
        unknown_labels=[s["label"] for s in read(run/"val_unknown_samples.json")]
        candidates=defaultdict(list);known_nll=[];epoch_arrays={}
        for epoch in range(1,21):
            vp=run/f"epoch_checkpoints/validation_{epoch:02d}.npz"
            trace=next(t for t in own["validation_inputs"] if (t["dataset"],t["unit"],t["epoch"])==(ds,unit,epoch))
            assert sha(vp)==trace["sha256"] and str(vp)==trace["validation_file"]
            with np.load(vp,allow_pickle=False) as z:a={k:z[k] for k in z.files}
            np.testing.assert_array_equal(a["yk"],known_labels);np.testing.assert_array_equal(a["yu"],unknown_labels)
            epoch_arrays[epoch]=a
            x=a["ka"].astype(np.float64);nll=float(np.mean(np.logaddexp.reduce(x,axis=1)-x[np.arange(len(x)),a["yk"]]))
            known_nll.append((nll,epoch))
            for method,route,mode,tune in METHODS:
                selection=select(a,route,mode,tune,grid,alphas)
                recorded=next(r for r in own["per_epoch_records"] if (r["dataset"],r["unit"],r["method"],r["epoch"])==(ds,unit,method,epoch))["selection"]
                for k in ["score_source","alpha","T_score"]:assert selection[k]==recorded[k],(unit,epoch,method,k)
                for k in ["val_fpr95","val_auroc"]:check(selection[k],recorded[k],(unit,epoch,method,k))
                candidates[method].append((selection["val_fpr95"],-selection["val_auroc"],epoch,selection))
        reference_epoch=min(known_nll)[1]
        # All validation choices above are verified before any target arrays are opened.
        for r in records:
            method=r["method"];definition=next(m for m in METHODS if m[0]==method);mode=definition[2]
            expected_epoch=min(candidates[method],key=lambda c:c[:3])[2] if r["selector"]=="detector_validation_FPR95" else reference_epoch
            assert r["selector"] in ["detector_validation_FPR95","known_NLL_reference"] and r["epoch"]==expected_epoch
            sel=next(c[3] for c in candidates[method] if c[2]==r["epoch"])
            for k in ["score_source","alpha","T_score"]:assert sel[k]==r["selection"][k],(unit,method,k)
            assert sha(r["checkpoint"])==r["checkpoint_sha256"]
            rr=next(v for v in parent["records"] if (v["dataset"],v["unit"],v["method"],v["selector"])==(ds,unit,method,r["selector"]))
            assert all(rr[k]==v for k,v in r.items())
            assert sha(rr["target_logits_file"])==rr["target_logits_sha256"]
            with np.load(rr["target_logits_file"],allow_pickle=False) as z:t={k:z[k] for k in z.files}
            np.testing.assert_array_equal(t["ty"],[s["label"] for s in read(run/"test_samples.json")])
            for key in ["tz","ta"]:assert np.isfinite(t[key]).all() and len(t[key])==len(t["ty"])
            a=epoch_arrays[r["epoch"]];vy=np.r_[np.zeros(len(a["ka"]),dtype=int),np.ones(len(a["ua"]),dtype=int)]
            threshold=roc(metric_arrays(a,sel,mode,"v"),vy)["threshold"]
            st=metric_arrays(t,sel,mode,"t");y=(t["ty"]<0).astype(int);known=y==0;reject=st>=threshold
            pred=t["ta"].argmax(1);accepted=known&~reject
            calculated=dict(auroc=roc(st,y)["auroc"],fpr95=roc(st,y)["fpr95"],threshold=threshold,
                recall=float(reject[~known].mean()),rejection=float(reject[known].mean()),known_accuracy=float((pred[known]==t["ty"][known]).mean()),
                accepted_known_accuracy=float((pred[accepted]==t["ty"][accepted]).mean()) if accepted.any() else None)
            for k,v in calculated.items():
                if v is None:assert rr[k] is None
                else:check(v,rr[k],(unit,method,r["selector"],k),1e-11)
            target_audit.append(dict(dataset=ds,unit=unit,selector=r["selector"],method=method,epoch=r["epoch"],**calculated))
            selection_audit.append(dict(dataset=ds,unit=unit,selector=r["selector"],method=method,epoch=r["epoch"],selection=sel,checkpoint_sha256=r["checkpoint_sha256"]))
        print("E4 audited "+ds+" "+unit,flush=True)
    fields=["auroc","fpr95","recall","rejection","known_accuracy","accepted_known_accuracy"]
    summaries=grouped_means(target_audit,["dataset","selector","method"],fields)
    for row in summaries:
        archived=next(v for v in parent["summary"] if all(v[k]==row[k] for k in ["dataset","selector","method"]))
        assert row["n"]==archived["n"]
        for field in fields:
            if row[field] is None:assert archived[field] is None
            else:check(row[field],archived[field],(row["dataset"],row["method"],row["selector"],field),1e-11)
    assert len(target_audit)==264
    write(ROOT/"evidence/E4_independent_audit.json",dict(all_checks_pass=True,unit_count=33,validated_epoch_snapshots=660,
        method_selector_rows_verified=264,records=target_audit,summary=summaries,selection_audit=selection_audit,fixtures=fixture,
        target_result_sha256=sha(parent_path),choices_sha256=sha(frozen_path),audit_prespec_sha256=sha(path),
        no_new_training=True,no_target_retuning=True,no_IID_inference=True,
        interpretation="Independent validation selection and scoring verification on the same full20 training trajectories, not detector-specific loss retraining or independent population sampling."),exclusive=True)
    print("E4 all264 rows and660 validation snapshots independently verified.",flush=True)


if __name__=="__main__":main()
