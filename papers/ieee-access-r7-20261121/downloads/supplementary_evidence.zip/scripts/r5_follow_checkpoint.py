"""A fixed-scope job dependency, not a recurring automation."""
from datetime import datetime,timezone
import os
import subprocess
import sys
import time
from gap_closure_core import ROOT,R2,read,write


def state(stage,**kw):
    write(ROOT/"evidence/E4_schedule_progress.json",dict(stage=stage,pid=os.getpid(),
        updated_utc=datetime.now(timezone.utc).isoformat(),**kw))


def main():
    state("waiting_for_officehome_stage2")
    while True:
        for root in [ROOT,R2]:
            marker=root/"new_runs/PAUSE_REQUESTED"
            if marker.exists():
                try:internal=read(marker).get("purpose")=="controlled_unit_boundary_yield_for_two_official_pilots"
                except Exception:internal=False
                if not internal:
                    state("paused_by_user_no_followup_started");return
        p=read(ROOT/"evidence/E5_officehome_stage2_progress.json")
        if p["stage"]=="failed_requires_inspection":
            state("blocked_on_failed_officehome_unit",error=p.get("error"));return
        if p["stage"]=="training_complete_requires_independent_audit" and not (R2/"new_runs/GPU_QUEUE.lock").exists():break
        time.sleep(30)
    state("running_frozen_checkpoint_target_inference")
    with (ROOT/"logs/E4_target_stdout.log").open("a",encoding="utf-8") as out,(ROOT/"logs/E4_target_stderr.log").open("a",encoding="utf-8") as err:
        result=subprocess.run([sys.executable,"-B","-s","-u",str(ROOT/"scripts/r5_checkpoint_inference.py")],cwd=ROOT,stdout=out,stderr=err).returncode
    state("complete_requires_independent_audit" if result==0 else "failed_requires_inspection",exit_code=result)


if __name__=="__main__":main()
