"""Reconcile probability/grid diagnostics and weighted-ROC geometry explicitly."""
import sys
from gap_closure_core import *
import cache_analyses as original

BASE_PANELS=original.panels
canonical={(r["model"],r["dataset"],r["unit"],r["method"]):r for r in read(ROOT/"evidence/E0_precision.json")["records"]}


def full_choose(a,route,mode,grid,objective):
    return select(route,mode,grid,a["kz"],a["ka"],a["uz"],a["ua"],True,.5,[0.,.25,.5,.75,1.],objective)


def full_branch(a,prefix,selection):
    return branch(a[prefix+"z"],a[prefix+"a"],selection)


def panels():
    for model,ds,unit,d,a,m in BASE_PANELS():
        m={k:dict(v) for k,v in m.items()}
        for method in ["MSP","Temp-MSP","Energy-T-tuned","autoMixTemp"]:
            c=canonical[(model,ds,unit,method)]
            m[method].update(selection=c["selection"],auroc=c["auroc"],fpr95=c["fpr95"])
        grid=[float(t) for t in read(d/"config.json")["arguments"]["temp_candidates"].split(",")]+[10.,20.,50.,100.,1000.]
        selected=full_choose(a,"auto","msp",grid,"fpr95")
        target,_=detection(a,selected)
        from sklearn.metrics import roc_auc_score
        m["autoMixTemp-expanded"]=dict(selection=selected,auroc=float(roc_auc_score(a["ty"]<0,target)),fpr95=fpr_at_recall(target,a["ty"]<0)["fpr95"])
        yield model,ds,unit,d,a,m


def geometry():
    sys.path.insert(0,str(BASE/"tools"))
    from stable_score_audit import branch as old_branch,stable_msp
    records=[]
    for model,ds,unit,d,old in units():
        if ds=="officehome":continue
        a=load_arrays(d);sel=old["autoMixTemp"]["selection"]
        before=stable_msp(old_branch(a,"t",sel),sel["T_score"])
        with np.load(cache_path(model,ds,unit),allow_pickle=False) as z:after=z["autoMixTemp"]
        positive=np.flatnonzero(a["ty"]<0);negative=np.flatnonzero(a["ty"]>=0)
        changed=0
        for start in range(0,len(positive),64):
            ids=positive[start:start+64]
            old_sign=np.sign(before[ids,None]-before[negative][None,:])
            new_sign=np.sign(after[ids,None]-after[negative][None,:])
            changed+=int(np.count_nonzero(old_sign!=new_sign))
        records.append(dict(**tag(model,ds,unit),cross_class_pairs=len(positive)*len(negative),changed_cross_class_order_or_tie_pairs=changed,
            all_positive_weight_ROC_functionals_invariant=changed==0))
    save("E0_ROC_geometry",dict(records=records,
        primary_PACS_all_weighted_ROC_invariant=all(r["all_positive_weight_ROC_functionals_invariant"] for r in records if r["model"]=="ViT-B32" and r["dataset"]=="pacs"),
        rule="Exact comparison of every positive-negative order/tie sign at fixed frozen parameters. If these signs are unchanged, weighted ROC AUC and complete-tie FPR at recall are invariant for arbitrary common positive image weights. Numeric threshold values and probability/risk diagnostics are not covered by this invariance.",
        preservation="Legacy representations and all raw arrays remain unmodified. Any noninvariant panel must not be called exactly unchanged."))


def main():
    task=sys.argv[1]
    if task=="geometry":geometry();return
    original.panels=panels;original.branch=full_branch;original.choose=full_choose
    name={"B3":"E0_probability","B4":"E0_temperature"}[task]
    original.dump=lambda original_task,value:save(name,dict(value,original_analysis_task=original_task,
        precision_amendment="Both interpolation operands are cast to float64 before multiplication; original protocol constants and all variants retained."))
    getattr(original,task)()


if __name__=="__main__":main()
