"""C0/C2 preflight only. Never trains, installs packages or runs new inference."""
import importlib.util
import json
from pathlib import Path
import subprocess
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent
sys.path.insert(0,str(ROOT/"scripts"))
from cache_analyses import read,sha


def main():
    spec=ROOT/"prespec/C0_C2.json"
    assert sha(spec)==read(ROOT/"prespec/sealed_hashes.json")["C0_C2"]
    measured=[]
    for family in ["primary","vitb32_full20","rn50"]:
        for ds in ["pacs","cifar10"]:
            root=BASE/"05_new_runs"/ds if family=="primary" else BASE/"05_new_runs"/family/ds
            elapsed=[read(p)["seconds"] for p in root.glob("*/completed.json")]
            measured.append(dict(family=family,dataset=ds,completed=len(elapsed),mean_seconds=float(np.mean(elapsed)),median_seconds=float(np.median(elapsed)),min_seconds=min(elapsed),max_seconds=max(elapsed)))
    scanned=[];found=[]
    for top in [Path("C:/icip_osr/data"),Path("D:/icip_osr/data"),Path("C:/Users/e/Downloads")]:
        if not top.exists():continue
        scanned.append(str(top));front=[top]
        for depth in range(4):
            nxt=[]
            for d in front:
                for p in d.iterdir():
                    if any(t in p.name.lower().replace("_","").replace("-","") for t in ["officehome","vlcs","domainnet"]):found.append(str(p))
                    if p.is_dir() and depth<3:nxt.append(p)
            front=nxt
    env={name:bool(importlib.util.find_spec(name)) for name in ["dassl","yacs","nltk","open_clip","clip","mmcv"]}
    gpu=subprocess.check_output(["nvidia-smi","--query-gpu=name,memory.total","--format=csv,noheader"],text=True).strip()
    baseline=next(r for r in measured if r["family"]=="vitb32_full20" and r["dataset"]=="pacs")
    projection=dict(remaining_units=24,derivation="24 remaining PACS units times the observed four-unit full20 mean; excludes different role/epoch scoring costs and is a planning projection, not a measured new runtime.",
                    projected_seconds=24*baseline["mean_seconds"])
    evidence=dict(task="C0_C2",prespec_sha256=sha(spec),gpu=gpu,measured_unit_times=measured,searched_roots=scanned,
        search_max_depth=3,dataset_candidates=found,dependencies=env,C3b_projection=projection,
        new_training_performed=False,new_detector_inference_performed=False,
        decisions_required=["Provide/download Office-Home or explicitly select a different dataset", "Authorize isolated NegLabel dependency/official-code pilot and timing", "Authorize official LoCoOp environment/sample-role pilot", "Whether to extend full20 to 28 PACS units", "Whether optional ViT-B/16 is needed"],
        official_sources=["https://github.com/tmlr-group/NegLabel","https://github.com/AtsuMiyai/LoCoOp","https://www.hemanthdv.org/officeHomeDataset.html"],
        static_source_hashes={p.name:sha(p) for p in (ROOT/"vendor_review").iterdir() if p.is_file()},
        limits="Missing dependencies are a preflight finding, not evidence that official code was executed and failed. No substitute implementation is run. No reliable Office-Home/NegLabel/LoCoOp/ViT-B16 runtime is claimed without an authorized pilot.")
    (ROOT/"evidence/C0_C2.json").write_text(json.dumps(evidence,indent=2),encoding="utf-8")
    lines=["# C0 新实验可行性报告", "", "状态：仅做本地资源与官方实现静态检查，尚未启动新训练或 NegLabel 推理，等待用户确认。", "",
        "## 现有资源", f"实测 GPU：{gpu}。PACS 与已整理 CIFAR-10 在本地；在以下目录的限定深度检查内未发现 Office-Home、VLCS 或 DomainNet："+"；".join(scanned)+"。这不等于断言其他磁盘上不存在数据。", "",
        "| 已有完整运行 | 单元数 | 平均耗时 分钟 | 最短 最长 分钟 |", "| --- | ---: | ---: | ---: |"]
    for r in measured:lines.append(f"| {r['family']} {r['dataset']} | {r['completed']} | {r['mean_seconds']/60:.2f} | {r['min_seconds']/60:.2f} 至 {r['max_seconds']/60:.2f} |")
    lines += ["", "## 各新任务与决定", "",
        "- C1：Office-Home 未找到。建议提供数据或批准从官方页面下载。拟议设计为 4 域、5 个固定类别轮换、3 个优化种子；35 已知/15 验证未知/15 目标未知。源域每类取固定 10 张，验证域每类固定 10 张，目标域使用该角色全部图像；若任一必需类不足则停下报告，不静默减样本。类别排序和轮换步长在下载后的图像完整性检查、正式训练前冻结。训练与 checkpoint 规则沿用既有流程，但该 10-shot 数据预算将明确区别于 PACS 全样本训练。60 单元的总时长目前无法可靠估计，必须先批准计时试点。替代选项仅供选择：VLCS 或 DomainNet 子集，未自行替换。",
        "- C2 NegLabel：官方实现基于 MMClassification，使用外部 WordNet 负词表动态选择标签；当前环境缺少若干官方依赖和 OpenAI clip 包。已有 cosine/logit 缓存不能提供任意负词表的图像特征相似度，需要新增特征推理。须批准隔离环境和官方代码计时试点，标准词表与全基准类别名排除词表均预设后才评估。外部词表明确是额外信息预算；不称复现原论文数字。",
        "- C2 LoCoOp：官方实现需 Dassl 与独立提示训练，当前 dassl/yacs 不可用；官方自带数据接入以 ImageNet 为主，不能声称已支持本协议。需批准独立环境与保持精确样本角色的数据接入试点。未运行，不称官方代码失败，也不使用近似实现。",
        f"- C3b：从已完成 4 个 PACS full20 单元扩展至 28 个，还需 24 单元。按同流程现有均值机械外推为 {projection['projected_seconds']/3600:.2f} 小时，仅用于排程，不是实测新任务时长；角色难度、磁盘及后处理会改变耗时。C3a 缓存配对分析已完成，无需重训。",
        "- C4：ViT-B/16 需检查/下载相应权重并做计时试点，尚无该骨干实测耗时，不编造总时长。优先级低于 C1/C2。", "",
        "## 官方来源与下一步", "[Office-Home 官方数据页](https://www.hemanthdv.org/officeHomeDataset.html)；[NegLabel 官方实现](https://github.com/tmlr-group/NegLabel)；[LoCoOp 官方实现](https://github.com/AtsuMiyai/LoCoOp)。", "",
        "请确认是否先授权 NegLabel/LoCoOp 的隔离环境计时试点，以及 Office-Home 数据的位置或下载许可。未确认前，C1、C2、C3b、C4 全部保持未启动。耗时、依赖和检查范围的机器记录在 evidence/C0_C2.json。"]
    (ROOT/"reports/C0_新实验可行性报告.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print("C0/C2 preflight saved; no new training or detector inference started.")


if __name__=="__main__":main()
