"""Add a validation-frozen known-NLL reference before any new target replay."""
from scipy.special import logsumexp
from gap_closure_core import *


def main():
    source=read(ROOT/"evidence/E4_epoch_validation_selection.json")
    own=[dict(r,selector="detector_validation_FPR95") for r in source["records"]]
    references=[];needed=[]
    for ds,unit,runname in sorted({(r["dataset"],r["unit"],r["run"]) for r in own}):
        run=Path(runname);values=[]
        for epoch in range(1,21):
            with np.load(run/f"epoch_checkpoints/validation_{epoch:02d}.npz",allow_pickle=False) as z:
                ka=z["ka"].astype(np.float64);yk=z["yk"]
            values.append((float(np.mean(logsumexp(ka,axis=1)-ka[np.arange(len(ka)),yk])),epoch))
        _,epoch=min(values)
        with np.load(run/f"epoch_checkpoints/validation_{epoch:02d}.npz",allow_pickle=False) as z:
            a={k:z[k] for k in z.files}
        grid=[float(x) for x in read(run/"config.json")["arguments"]["temp_candidates"].split(",")]
        extra=R2/"new_runs/c3b/evaluations"/unit
        for method,route,mode,ts in [("MSP","adapter","msp",[1.]),("Temp-MSP","adapter","msp",grid),
                                   ("Energy-T-tuned","adapter","energy",grid),("autoMixTemp","auto","msp",grid)]:
            sel=choose(a,route,mode,ts)
            possible=[run/f"epoch_checkpoints/selected_test_{epoch:02d}.npz",extra/f"selected_test_{epoch:02d}.npz"]
            cached=next((p for p in possible if p.is_file()),None)
            ck=run/f"epoch_checkpoints/epoch_{epoch:02d}.pt"
            references.append(dict(dataset=ds,unit=unit,method=method,selector="known_NLL_reference",epoch=epoch,selection=sel,
                run=str(run),checkpoint=str(ck),checkpoint_sha256=sha(ck),existing_target_cache=str(cached) if cached else None))
    records=own+references
    assert len(records)==264
    for r in records:
        if r["existing_target_cache"] is None:
            needed.append((r["dataset"],r["unit"],r["epoch"]))
    path=ROOT/"evidence/E4_full_validation_plan.json"
    write(path,dict(records=records,own_selection_sha256=sha(ROOT/"evidence/E4_epoch_validation_selection.json"),
        missing_caches=[dict(dataset=d,unit=u,epoch=e) for d,u,e in sorted(set(needed))],
        no_target_arrays_read=True,no_new_inference=True,
        interpretation="Same full20 training trajectories; detector-specific checkpoint/score selection versus a known-NLL checkpoint followed by the same detector's own score tuning. This is not detector-specific training-loss optimization."),exclusive=True)
    print("Frozen264 method-selector choices; missing target snapshots="+str(len(set(needed))),flush=True)


if __name__=="__main__":main()
