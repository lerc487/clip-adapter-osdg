"""Contact sheets for all current pages, with distinct directories per final render."""
from pathlib import Path
from PIL import Image, ImageDraw
import re
ROOT = Path(__file__).resolve().parents[1]
for kind in ["E12_main_pages", "E12_supp_pages", "E12_highlight_pages", "E12_response_pages"]:
    paths = sorted((ROOT / "logs" / kind).glob("page-*.png"), key=lambda p: int(p.stem.split("-")[-1]))
    for first in range(0, len(paths), 4):
        canvas = Image.new("RGB", (1500, 2060), "#d9d9d9")
        draw = ImageDraw.Draw(canvas)
        for i, path in enumerate(paths[first:first+4]):
            page = Image.open(path).convert("RGB")
            page.thumbnail((720, 990))
            x, y = (i % 2) * 750 + 10, (i // 2) * 1030 + 30
            canvas.paste(page, (x, y))
            draw.text((x, y-22), path.name, fill="black")
        canvas.save(ROOT / "logs" / (kind + "_contact_" + str(first // 4 + 1) + ".png"))
