"""Regression-test the new auditor only on the two already-inspected pilots."""
import json
from pathlib import Path
import numpy as np
from sklearn.metrics import roc_auc_score
import audit_officehome_complete as audit

ROOT=Path(__file__).resolve().parents[1]
WORK=ROOT.parent/"revision2_20261118/new_runs/officehome/dedup_v3/pilot_eval64"

def main():
    checks=[]
    for uid in ["Art_rotation00_seed0","Clipart_rotation00_seed0"]:
        run=WORK/uid;config=audit.read(run/"config.json")["arguments"]
        with np.load(run/"logits.npz",allow_pickle=False) as z:a={k:z[k] for k in z.files}
        saved=audit.read(WORK/(uid+"_stable_evaluation/results.json"))["results"]
        known=a["ty"]>=0;y=(~known).astype(int);pred=a["ta"].argmax(1)
        vy=np.r_[np.zeros(len(a["ka"]),dtype=int),np.ones(len(a["ua"]),dtype=int)]
        with np.load(WORK/(uid+"_stable_evaluation/stable_scores.npz"),allow_pickle=False) as z:original={k:z[k] for k in z.files}
        for name,route,mode,tune in audit.VARIANTS:
            reference=next(r for r in saved if r["method"]==name)
            selection=audit.select(a,route,mode,tune,[float(t) for t in config["temp_candidates"].split(",")],[float(t) for t in config["mix_alphas"].split(",")])
            for key in ["score_source","alpha","T_score"]:assert selection[key]==reference["selection"][key],(uid,name,selection,reference["selection"])
            s=audit.score(audit.mix(a["tz"],a["ta"],selection["score_source"],selection["alpha"]),selection["T_score"],mode)
            v=np.r_[audit.score(audit.mix(a["kz"],a["ka"],selection["score_source"],selection["alpha"]),selection["T_score"],mode),audit.score(audit.mix(a["uz"],a["ua"],selection["score_source"],selection["alpha"]),selection["T_score"],mode)]
            fpr,_=audit.roc_details(s,y);_,threshold=audit.roc_details(v,vy)
            f1=audit.maxf1_threshold(v,vy);classification=pred.copy();classification[s>=f1]=-1;reject=s>=threshold
            metrics=dict(auroc=float(roc_auc_score(y,s)),fpr95=fpr,known_acc=float((pred[known]==a["ty"][known]).mean()),osr_acc=float((classification==a["ty"]).mean()),frozen_threshold_test_unknown_tpr=float(reject[~known].mean()),frozen_threshold_test_known_fpr=float(reject[known].mean()))
            for key,value in metrics.items():audit.numeric_equal(value,reference[key],(uid,name,key))
            error=float(np.max(np.abs(s-original[name])));assert error<1e-10
            checks.append(dict(unit=uid,method=name,metrics_match=True,max_score_error=error))
    out=dict(passed=True,scope="Only the two previously inspected timing pilots; not a completed20-unit panel audit.",checks=checks)
    (ROOT/"evidence/C1_pilot_auditor_regression.json").write_text(json.dumps(out,indent=2),encoding="utf-8")
    print("New auditor matches the two previously-inspected pilots; complete20-unit results not read.")

if __name__=="__main__":main()
