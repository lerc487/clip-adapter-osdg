"""Vector scientific figures; every displayed value comes from saved analyses."""
from collections import defaultdict
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "06_manuscript/revision_20261118/source/figures"
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":9,"axes.spines.top":False,
    "axes.spines.right":False,"axes.labelsize":9,"xtick.labelsize":8,"ytick.labelsize":8,
    "pdf.fonttype":42,"savefig.pad_inches":.08})
COLORS = {"MSP":"#647680","Temp-MSP":"#28688C","autoMixTemp":"#C06232",
          "Energy-only-T1":"#287C70","Energy-T-tuned":"#458F79","MCM-canonical":"#826C4E","MCM-matched-prompts":"#4F7B9D"}


def dataset_label(ds):
    return "PACS" if ds=="pacs" else "CIFAR-10"


def read(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))


def save(fig, name):
    OUT.mkdir(parents=True,exist_ok=True)
    fig.savefig(OUT/(name+".pdf"),bbox_inches="tight")
    fig.savefig(OUT/(name+".png"),dpi=180,bbox_inches="tight")
    plt.close(fig)


def main():
    stable = read(ROOT/"04_analysis/stable_score_audit_20261118.json")
    diag = read(ROOT/"04_analysis/stable_diagnostics_20261118.json")
    mcm = read(ROOT/"04_analysis/mcm_disjoint_ViT_B_32.json")
    legacy = read(ROOT/"04_analysis/new_validation_assessment_20261118.json")
    fig,ax=plt.subplots(figsize=(7.2,2.5));ax.set_axis_off();ax.set(xlim=(0,1),ylim=(0,1))
    boxes=[(.02,.54,.28,.32,"Train adapter","Known source images\nFrozen CLIP encoders"),
           (.36,.54,.28,.32,"Validate choices","Known NLL: checkpoint\nOther unknowns: scores"),
           (.70,.54,.28,.32,"Freeze and test","Disjoint target unknowns\nNo target-based tuning")]
    for x,y,w,h,title,body in boxes:
        ax.add_patch(plt.Rectangle((x,y),w,h,facecolor="#EEF3F4",edgecolor="#A0B1B9",lw=.8))
        ax.text(x+w/2,y+h-.065,title,ha="center",va="center",weight="bold",fontsize=8.5)
        ax.text(x+w/2,y+.11,body,ha="center",va="center",fontsize=8)
    for x in [.31,.65]:ax.annotate("",xy=(x+.04,.7),xytext=(x,.7),arrowprops={"arrowstyle":"->","color":"#173E56"})
    ax.text(.02,.34,"PACS  84 units",weight="bold",color="#173E56")
    ax.text(.02,.20,"4 domains x 7 rotations x 3 seeds\n3 known | 2 validation unknown | 2 target unknown",fontsize=7.1)
    ax.text(.53,.34,"CIFAR-10  15 units",weight="bold",color="#173E56")
    ax.text(.53,.20,"5 rotations x 3 seeds; official train/test roles\n6 known | 2 validation unknown | 2 target unknown",fontsize=7.1)
    ax.text(.5,.025,"Report score ranking, probability reliability, and transferred thresholds separately.",ha="center",fontsize=8,color="#394B55")
    save(fig,"protocol")
    names=["MSP","Temp-MSP","autoMixTemp","Temp-MSP-AUROC","Energy-only-T1","Energy-T-tuned","MCM-canonical","MCM-matched-prompts","Zero-shot-max-cosine"]
    labels=["MSP","Temp-MSP (FPR)","AutoMixTemp","Temp-MSP (AUROC)","Energy (T=1)","Energy (tuned T)","MCM (canonical)","MCM (matched)","Maximum cosine"]
    fig,axs=plt.subplots(2,2,figsize=(7.2,4.9),sharey=True,layout="constrained")
    for row,ds in enumerate(["pacs","cifar10"]):
        for col,metric in enumerate(["auroc","fpr95"]):
            ax=axs[row,col]
            values=[]
            for method in names:
                v=stable["summaries"][ds].get(method) or mcm["summary"][ds][method]
                values.append(v[metric]*100)
            ax.scatter(values,np.arange(len(names)),s=32,c=[COLORS.get(n,"#51606B") for n in names],zorder=3)
            span=max(values)-min(values);pad=max(span*.1,.5)
            ax.set_xlim(min(values)-pad,max(values)+pad*3.4)
            for i,v in enumerate(values):ax.text(v+pad*.18,i,f"{v:.2f}",va="center",fontsize=7.6)
            ax.set_yticks(np.arange(len(names)),labels);ax.invert_yaxis();ax.grid(axis="x",alpha=.18)
            ax.set_title(f"{dataset_label(ds)}  {'AUROC (higher is better)' if col==0 else 'FPR@95 (lower is better)'}",fontsize=9,loc="left")
            ax.set_xlabel("Percent")
    axs[0,0].set_ylim(len(names)-.5,-.5)
    save(fig,"score_comparison")
    fig,axs=plt.subplots(1,2,figsize=(7.2,2.6),layout="constrained")
    for ax,ds in zip(axs,["pacs","cifar10"]):
        for i,method in enumerate(["MSP","Temp-MSP","autoMixTemp"]):
            rs=[r for r in stable["records"] if r["dataset"]==ds and r["method"]==method]
            vals=[np.mean([r["legacy_float32_fpr95"] for r in rs])*100,
                  np.mean([r["stable_fpr95_at_legacy_selection"] for r in rs])*100,
                  stable["summaries"][ds][method]["fpr95"]*100]
            ax.plot([i]*3,vals,color="#A6B3B9",zorder=1)
            for marker,color,v in zip(["x","s","o"],["#647680","#28688C","#C06232"],vals):ax.scatter(i,v,marker=marker,color=color,s=40,zorder=3)
            ax.annotate(f"{vals[0]:.2f} -> {vals[-1]:.2f}",(i,max(vals)),xytext=(0,7),textcoords="offset points",ha="center",fontsize=7.4)
        ax.set_xticks(range(3),["MSP","Temp-MSP","AutoMixTemp"]);ax.set_ylabel("Mean FPR@95 (%)");ax.set_title(dataset_label(ds),loc="left",fontsize=9);ax.margins(x=.22,y=.35);ax.grid(axis="y",alpha=.18)
    fig.legend([plt.Line2D([],[],marker=m,color=c,linestyle="") for m,c in [("x","#647680"),("s","#28688C"),("o","#C06232")]],
               ["Float32","Stable, float32-selected parameters","Stable, validation-retuned"],loc="upper center",bbox_to_anchor=(.5,1.12),ncol=3,fontsize=7)
    save(fig,"precision_audit")
    fig,axs=plt.subplots(1,2,figsize=(7.2,3.05),layout="constrained")
    for ax,ds in zip(axs,["pacs","cifar10"]):
        for method in ["MSP","Temp-MSP","autoMixTemp","Energy-only-T1"]:
            v=stable["summaries"][ds][method];x=v["frozen_known_rejection"]*100;y=v["frozen_unknown_recall"]*100
            ax.scatter(x,y,s=45,color=COLORS[method],label=method)
            positions={"pacs":{"MSP":(14,87),"Temp-MSP":(14,75),"autoMixTemp":(14,81.2),"Energy-only-T1":(27,66)},
                       "cifar10":{"MSP":(31,80),"Temp-MSP":(25,71),"autoMixTemp":(12,80),"Energy-only-T1":(30,88)}}
            ax.annotate({"autoMixTemp":"AutoMixTemp","Energy-only-T1":"Energy"}.get(method,method),(x,y),
                xytext=positions[ds][method],textcoords="data",fontsize=7.5,
                arrowprops={"arrowstyle":"-","color":COLORS[method],"lw":.65})
        ax.axhline(95,color="#A64932",ls="--",lw=1);ax.text(1,95.7,"95% reference, not a guarantee",fontsize=7,color="#A64932")
        ax.set(xlim=(0,40),ylim=(55,100),xlabel="Target known false rejection (%)",ylabel="Target unknown recall (%)")
        ax.set_title(dataset_label(ds),loc="left",fontsize=9);ax.grid(alpha=.15)
    save(fig,"threshold_transfer")
    fig,axs=plt.subplots(1,2,figsize=(7.2,3),layout="constrained")
    for ax,ds in zip(axs,["pacs","cifar10"]):
        ax.plot([0,1],[0,1],ls="--",color="#A9B4B8",lw=.8)
        for method in ["MSP","Temp-MSP","autoMixTemp"]:
            bins=[r for r in diag["datasets"][ds]["reliability_bins"] if r["method"]==method and r["count"]]
            x,y=[],[]
            for b in range(15):
                bb=[r for r in bins if r["bin"]==b]
                if bb:
                    n=sum(r["count"] for r in bb)
                    x.append(sum(r["confidence"]*r["count"] for r in bb)/n)
                    y.append(sum(r["accuracy"]*r["count"] for r in bb)/n)
            ax.plot(x,y,"o-",ms=3,color=COLORS[method],label=method,lw=1.1)
        ax.set(xlim=(0,1),ylim=(0,1.03),xlabel="Detection-branch known-class confidence",ylabel="Observed known-class accuracy")
        ax.set_title(dataset_label(ds),fontsize=9,loc="left");ax.grid(alpha=.15)
    axs[1].legend(loc="lower right",fontsize=7)
    save(fig,"reliability")
    domains=["art_painting","cartoon","photo","sketch"]
    matrices=[]
    for precision in ["legacy","stable"]:
        a=np.zeros((4,7))
        for i,domain in enumerate(domains):
            for j in range(7):
                if precision=="legacy":
                    ee=[r for r in read(ROOT/"04_analysis/revision_panel_20261118.json")["datasets"]["pacs"]["effects"] if r["method"]=="autoMixTemp" and r["domain"]==domain and int(r["rotation"])==j]
                else:ee=[r for r in diag["datasets"]["pacs"]["effects"] if r["method"]=="autoMixTemp" and r["domain"]==domain and int(r["rotation"])==j]
                a[i,j]=100*np.mean([r["delta_fpr95"] for r in ee])
        matrices.append(a)
    lim=max(abs(a).max() for a in matrices)
    fig,axs=plt.subplots(1,2,figsize=(7.2,2.65),layout="constrained")
    for ax,a,title in zip(axs,matrices,["Float32","Stable score, validation-retuned"]):
        im=ax.imshow(a,cmap="RdBu_r",vmin=-lim,vmax=lim,aspect="auto")
        ax.set_xticks(range(7),[f"R{j}" for j in range(7)]);ax.set_yticks(range(4),[d.replace("art_painting","art painting") for d in domains],fontsize=7)
        for i in range(4):
            for j in range(7):ax.text(j,i,f"{a[i,j]:+.1f}",ha="center",va="center",fontsize=6.7,color="white" if abs(a[i,j])>lim*.55 else "#20323B")
        ax.set_title(title,loc="left",fontsize=8.5);ax.set_xlabel("Fixed class-role rotation")
    fig.colorbar(im,ax=axs,shrink=.8,label="AutoMixTemp - MSP FPR@95 (pp)")
    save(fig,"role_effects")
    fig,axs=plt.subplots(1,2,figsize=(7.2,2.5),layout="constrained")
    for ax,ds in zip(axs,["pacs","cifar10"]):
        for i,method in enumerate(["Temp-MSP","autoMixTemp","Energy-only-T1"]):
            r=next(r for r in diag["datasets"][ds]["conditional_image_intervals"] if r["method"]==method and r["metric"]=="delta_fpr95")
            ee=[r for r in diag["datasets"][ds]["effects"] if r["method"]==method]
            mean=np.mean([r["delta_fpr95"] for r in ee])*100
            ax.plot([r["lower"]*100,r["upper"]*100],[i,i],color=COLORS[method],lw=2)
            ax.scatter(mean,i,color=COLORS[method],s=33,zorder=3)
        ax.axvline(0,color="#9CA9AF",ls="--",lw=.8);ax.set_yticks(range(3),["Temp-MSP","AutoMixTemp","Energy (T=1)"])
        ax.set_ylim(2.6,-.6);ax.set_title(dataset_label(ds),loc="left",fontsize=9);ax.set_xlabel("Change in FPR@95 vs MSP (pp)");ax.grid(axis="x",alpha=.15)
    save(fig,"conditional_sensitivity")
    fig,axs=plt.subplots(1,2,figsize=(7.2,2.75),layout="constrained")
    for ax,ds in zip(axs,["pacs","cifar10"]):
        rows=diag["datasets"][ds]["temperature_curves"]
        tt=sorted({r["T"] for r in rows})
        for field,color,label in [("validation_fpr95","#28688C","Validation"),("test_fpr95","#C06232","Target test")]:
            values=[np.mean([r[field] for r in rows if r["T"]==t])*100 for t in tt]
            ax.plot(tt,values,"o-",ms=3,color=color,label=label,lw=1)
        ax.axvline(5,color="#A0ACB1",ls="--",lw=.8);ax.text(5,ax.get_ylim()[1]," reference upper bound",fontsize=6.8,rotation=90,va="top")
        ax.set_xscale("log");ax.set(xlabel="Temperature, logarithmic scale",ylabel="Mean FPR@95 (%)");ax.set_title(dataset_label(ds),loc="left",fontsize=9);ax.grid(alpha=.15)
    axs[1].legend(fontsize=7,loc="best")
    save(fig,"temperature_curves")
    print("Eight vector figures and PNG previews saved to "+str(OUT),flush=True)


if __name__=="__main__":
    main()
