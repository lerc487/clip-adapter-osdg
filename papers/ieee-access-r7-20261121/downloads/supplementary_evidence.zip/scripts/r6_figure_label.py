"""Change one supplementary axis label; keep every saved plotted value identical."""
from pathlib import Path
import hashlib
import json
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT = Path(__file__).resolve().parents[1]
def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8"))
def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def save(fig, name):
    assert name == "acceptance_policy"
    fig.savefig(ROOT / "source/figures" / (name + ".pdf"), bbox_inches="tight", pad_inches=.08)
    plt.close(fig)

code = (ROOT / "scripts/figures.py").read_text(encoding="utf-8")
start = code.index("    fig,axs=plt.subplots(2,2,figsize=(7.2,5.1)")
fragment = code[start:code.index("    # Record exact source arrays")]
import textwrap
fragment = textwrap.dedent(fragment).replace("Requested validation unknown recall", "Validation unknown-recall target")
namespace = dict(plt=plt, save=save, policy=read(ROOT / "evidence/E2_transfer_tradeoffs.json")["summary"],
                 colors={"MSP":"#647680", "Temp-MSP":"#28688C", "autoMixTemp":"#C06232", "Energy-T-tuned":"#287C70"},
                 methods=["MSP", "Temp-MSP", "autoMixTemp", "Energy-T-tuned"], used=[])
plt.rcParams.update({"font.family":"DejaVu Sans", "font.size":8, "pdf.fonttype":42,
                     "axes.spines.top":False, "axes.spines.right":False})
exec(compile(fragment, "unchanged_acceptance_points", "exec"), namespace)
registry = read(ROOT / "evidence/E9_final_figure_registry.json")
old = [x for x in registry["policy_risk_records"] if x["figure"] == "acceptance_policy"]
assert old == namespace["used"]
registry["figure_hashes"]["acceptance_policy.pdf"] = sha(ROOT / "source/figures/acceptance_policy.pdf")
(ROOT / "evidence/E9_final_figure_registry.json").write_text(json.dumps(registry, indent=2), encoding="utf-8")
(ROOT / "evidence/F4_figure_axis_label_check.json").write_text(json.dumps(dict(
    plotted_records_unchanged=True, rows=len(old), old_label="Requested validation unknown recall",
    new_label="Validation unknown-recall target", vector_pdf_sha256=registry["figure_hashes"]["acceptance_policy.pdf"]), indent=2), encoding="utf-8")
print("Supplementary axis label changed; all saved plotted rows unchanged.")
