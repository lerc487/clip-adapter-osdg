"""CPU-only data/config fixtures, with CUDA explicitly unavailable."""
import hashlib
import json
from pathlib import Path
import torch
from dassl.data import DataManager
from r5_locoop_bridge import ROOT,BASE,config_for,read


def main():
    assert not torch.cuda.is_available(),"CPU fixture must run with CUDA_VISIBLE_DEVICES=-1"
    records=[]
    for dataset,unit in [("pacs","art_painting_rotation00_seed0"),("cifar10","cifar10_rotation00_seed0")]:
        cfg=config_for(dataset,unit,ROOT/"logs/locoop_cpu_fixture"/unit,use_cuda=False)
        dm=DataManager(cfg)
        source=BASE/"05_new_runs"/dataset/unit
        config=read(source/"config.json")["arguments"];data=Path(config["data_root"])
        expected=[(str(data/s["path"]),s["label"]) for s in read(source/"train_samples.json")]
        actual=[(s.impath,s.label) for s in dm.dataset.train_x]
        assert actual==expected
        val=[(str(data/s["path"]),s["label"]) for s in read(source/"val_known_samples.json")]
        assert [(s.impath,s.label) for s in dm.dataset.val]==val
        unknown=lambda name:{s["path"].replace("\\","/").split("/")[-2] for s in read(source/(name+"_samples.json")) if s["label"]<0}
        assert not unknown("val_unknown") & unknown("test")
        batch=next(iter(dm.train_loader_x))
        assert batch["img"].shape[1:]==(3,224,224)
        assert tuple(dm.dataset.classnames)==tuple(dm.dataset.lab2cname[i] for i in range(dm.dataset.num_classes))
        records.append(dict(dataset=dataset,unit=unit,train_files=len(expected),val_known_files=len(val),known_classes=dm.dataset.num_classes,
            topk=cfg.topk,lambda_value=cfg.lambda_value,epochs=cfg.OPTIM.MAX_EPOCH,
            literal_train_order_and_labels_match=True,literal_known_validation_match=True,no_target_in_official_training_manager=True,
            config_sha256=hashlib.sha256(cfg.dump().encode("utf-8")).hexdigest()))
    (ROOT/"evidence/E6_cpu_fixture_checks.json").write_text(json.dumps(dict(passed=True,records=records,no_model_built=True,
        no_model_inference=True,no_gpu_available=True),indent=2),encoding="utf-8")
    print("Official LoCoOp literal-role/config CPU fixtures passed for both fixed pilots.")


if __name__=="__main__":main()
