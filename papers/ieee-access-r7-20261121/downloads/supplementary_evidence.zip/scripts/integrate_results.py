"""Generate every result-table cell and new prose number from evidence JSON."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys

import numpy as np

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent;SRC=ROOT/"source"
sys.path.insert(0,str(ROOT/"scripts"))
from cache_analyses import read
REG=[];MACROS=[];DATA={};DERIVED={}


def load(name):
    if name not in DATA:DATA[name]=read(ROOT/"evidence"/(name+".json"))
    return DATA[name]


def ptr(name,*keys):
    v=load(name)
    for key in keys:v=v[key]
    return v


def pick(name,field,**where):
    rows=ptr(name,field)
    matches=[i for i,r in enumerate(rows) if all(r.get(k)==v for k,v in where.items())]
    assert len(matches)==1,(name,field,where,len(matches))
    return (field,matches[0])


def letters(i):
    result=""
    while True:
        result=chr(97+i%26)+result;i=i//26-1
        if i<0:return result


def n(name,keys,d=6,scale=1,sign=False):
    value=ptr(name,*keys)
    if value is None:return "---"
    assert isinstance(value,(int,float)) and not isinstance(value,bool),(name,keys,value)
    display=format(value*scale,("+" if sign else "")+"."+str(d)+"f")
    macro="Num"+letters(len(REG))
    REG.append(dict(macro=macro,file=name+".json",pointer=list(keys),value=value,scale=scale,decimals=d,signed=sign,display=display))
    MACROS.append("\\newcommand{\\"+macro+"}{"+display+"}")
    return "\\"+macro+"{}"


def derived(key,value,d=6,scale=1,sign=False):
    DERIVED[key]=value;DATA["manuscript_values"]=DERIVED
    return n("manuscript_values",[key],d,scale,sign)


def table(name,caption,head,rows,columns=None,label=None):
    columns=columns or "l"+"r"*(len(rows[0])-1)
    text=[r"\begin{table*}[t]\centering\small",r"\caption{"+caption+"}\\label{tab:"+(label or name)+"}",
        r"\begin{tabular}{"+columns+"}\\toprule",head+r"\\\midrule"]
    text += [" & ".join(row)+r"\\" for row in rows]
    text += [r"\bottomrule\end{tabular}\end{table*}"]
    (SRC/"tables"/(name+".tex")).write_text("\n".join(text)+"\n",encoding="ascii")


def main():
    sources={"stable":"stable_score_audit_20261118.json","diagnostics":"stable_diagnostics_20261118.json",
        "mcm":"mcm_disjoint_ViT_B_32.json","additional":"additional_validation_summary_20261118.json"}
    imports=[]
    for alias,filename in sources.items():
        p=BASE/"04_analysis"/filename;q=ROOT/"evidence"/(alias+".json")
        shutil.copy2(p,q);imports.append(dict(file=q.name,source=str(p),sha256=hashlib.sha256(q.read_bytes()).hexdigest()))
    (ROOT/"evidence/imported_result_provenance.json").write_text(json.dumps(imports,indent=2),encoding="utf-8")
    rows=[]
    for ds,label in [("pacs","PACS"),("cifar10","CIFAR-10")]:
        for method in ["MSP","Temp-MSP","autoMixTemp"]:
            rr=[r for r in ptr("stable","records") if r["dataset"]==ds and r["method"]==method]
            vals=[derived("precision_"+ds+method+k,float(np.mean([r[k] for r in rr]))) for k in ["legacy_float32_fpr95","stable_fpr95_at_legacy_selection","fpr95"]]
            rows.append([label,method]+vals)
    table("precision","Arithmetic audit of FPR@95: subtractive float32, stable scores at float32-selected parameters, and stable validation reselection.",r"Dataset & Method & Float32 & Stable fixed & Stable reselected",rows,"llrrr")
    methods=[("MSP","MSP"),("Temp-MSP","Temp-MSP, FPR objective"),("autoMixTemp","autoMixTemp"),("Temp-MSP-AUROC","Temp-MSP, AUROC objective"),("Energy-only-T1","Energy, $T=1$"),("Energy-T-tuned","Energy, tuned $T$"),("MCM-canonical","MCM, canonical prompt"),("MCM-matched-prompts","MCM, matched prompts"),("Zero-shot-max-cosine","Maximum cosine")]
    rows=[]
    for method,label in methods:
        row=[label]
        for ds in ["pacs","cifar10"]:
            f="stable" if method in ptr("stable","summaries",ds) else "mcm"
            path=["summaries" if f=="stable" else "summary",ds,method]
            row += [n(f,path+[k]) for k in ["auroc","fpr95"]]
        rows.append(row)
    for variant,label in [("standard","NegLabel port, standard"),("benchmark_names_excluded","NegLabel port, name-excluded")]:
        row=[label]
        for ds in ["pacs","cifar10"]:
            p=pick("C2_NegLabel","summary",dataset=ds,variant=variant)
            row += [n("C2_NegLabel",p+(k,)) for k in ["auroc","fpr95"]]
        rows.append(row)
    table("primary","Equal-unit detection means on complete disjoint-unknown panels. MCM and NegLabel match sample roles, not published benchmark protocols. NegLabel ports use unadapted CLIP and an extra external WordNet vocabulary; they are not information-budget-matched to the adapter scores.",r"Method & PACS AUROC & PACS FPR@95 & CIFAR AUROC & CIFAR FPR@95",rows,"lrrrr")
    rows=[]
    for ds,label in [("pacs","PACS"),("cifar10","CIFAR-10")]:
        rr=[r for r in ptr("stable","records") if r["dataset"]==ds and r["method"]=="autoMixTemp"]
        counts=[len(rr)]+[sum(r["selection"]["score_source"]==s for r in rr) for s in ["adapter","zeroshot","mix"]]+[sum(r["selection"]["T_score"]==5 for r in rr)]
        rows.append([label]+[derived("selection"+ds+str(i),v,0) for i,v in enumerate(counts)])
    table("selection","Validation-selected source counts and reference-grid upper-bound selections.",r"Dataset & Units & Adapter & Zero-shot & Interior & $T=5$",rows)
    rows=[]
    for ds,label in [("pacs","PACS"),("cifar10","CIFAR-10")]:
        for method in ["MSP","Temp-MSP","autoMixTemp","Energy-T-tuned"]:
            p=pick("B2","summary",model="ViT-B32",dataset=ds,method=method,rho=.95,policy="pooled")
            rows.append([label,method]+[n("B2",p+(k,),2,100) for k in ["known_rejection","unknown_recall","accepted_known_accuracy"]])
    table("transfer","Pooled validation recall target 0.95, frozen before target scoring. Values are percentages; accepted accuracy uses the fixed adapter classifier.",r"Dataset & Score & Known rejection & Unknown recall & Accepted known accuracy",rows,"llrrr")
    rows=[]
    for ds,label in [("pacs","PACS"),("cifar10","CIFAR-10")]:
        for method in ["MSP","Temp-MSP","autoMixTemp","Known-NLL-TS"]:
            p=pick("B3","summary",model="ViT-B32",dataset=ds,method=method)
            rows.append([label,method]+[n("B3",p+(k,)) for k in ["ece15","nll","brier","aurc"]])
    table("probability","Known-target probability metrics and fixed-classifier AURC. Known-NLL-TS fits a single temperature by continuous known-validation NLL minimization. Lower is better.",r"Dataset & Method & ECE15 & NLL & Brier & AURC",rows,"llrrrr")
    rows=[]
    for ds,label in [("pacs","PACS"),("cifar10","CIFAR-10")]:
        for method in ["Temp-MSP","autoMixTemp","Energy-only-T1"]:
            pp=ptr("diagnostics","datasets",ds,"conditional_image_intervals")
            values=[]
            for metric in ["delta_auroc","delta_fpr95"]:
                i=next(i for i,r in enumerate(pp) if r["method"]==method and r["metric"]==metric)
                path=("datasets",ds,"conditional_image_intervals",i)
                values.append("["+n("diagnostics",path+("lower",),sign=True)+", "+n("diagnostics",path+("upper",),sign=True)+"]")
            rows.append([label,method]+values)
    table("conditional","Central 95\% shared-image sensitivity ranges for changes relative to MSP; 400 Poisson draws with fixed fits and validation choices.",r"Dataset & Method & $\Delta$AUROC range & $\Delta$FPR@95 range",rows,"llll")
    rows=[]
    for ds,label in [("pacs","PACS"),("cifar10","CIFAR-10")]:
        for method,grid in [("autoMixTemp","Reference"),("autoMixTemp-expanded","Expanded")]:
            p=("summaries",ds,method)
            rr=[r for r in ptr("stable","records") if r["dataset"]==ds and r["method"]==method]
            upper=5 if grid=="Reference" else 1000
            count=derived("upper"+ds+grid,sum(r["selection"]["T_score"]==upper for r in rr),0)
            rows.append([label,"autoMixTemp",grid,n("stable",p+("auroc",)),n("stable",p+("fpr95",)),count])
        for method in ["Temp-MSP","autoMixTemp"]:
            p=pick("B4","dense_summary",model="ViT-B32",dataset=ds,method=method)
            rows.append([label,method,"Dense",n("B4",p+("auroc",)),n("B4",p+("fpr95",)),n("B4",p+("upper_count",),0)])
        p=pick("B4","summary",model="ViT-B32",dataset=ds,variant="limit",temperature=None)
        rows.append([label,"Adapter limit","Asymptotic",n("B4",p+("auroc",)),n("B4",p+("fpr95",)),"---"])
    table("grid","Fixed search ranges and the adapter limiting score. All finite-grid selections use validation FPR@95; upper-bound counts refer to each grid.",r"Dataset & Score & Grid & AUROC & FPR@95 & Upper count",rows,"lllrrr")
    rows=[]
    for i,r in enumerate(ptr("additional","architecture_summary")):
        family="ViT-B/32" if r["family"].startswith("ViT") else "RN50"
        pretty={"Energy-only-T1":"Energy ($T=1$)","MCM-canonical":"MCM canonical","MCM-matched-prompts":"MCM matched","Zero-shot-max-cosine":"Maximum cosine"}
        rows.append([family,"PACS" if r["dataset"]=="pacs" else "CIFAR-10",pretty.get(r["method"],r["method"]),n("additional",("architecture_summary",i,"n"),0),n("additional",("architecture_summary",i,"auroc")),n("additional",("architecture_summary",i,"fpr95"))])
    table("architecture","Matched seed0 architectural sensitivity on identical sample roles, including training-free scores.",r"Backbone & Dataset & Method & Units & AUROC & FPR@95",rows,"lllrrr")
    architecture=[r"\begin{table*}[!t]\centering\footnotesize\setlength{\tabcolsep}{3pt}",
        r"\caption{Matched seed0 architectural sensitivity on identical sample roles, including training-free scores. Dataset panels are separate, not pooled.}\label{tab:architecture}"]
    for ds in ["PACS","CIFAR-10"]:
        architecture.extend([r"\begin{minipage}[t]{.49\textwidth}\centering\textbf{"+ds+r"}\par\smallskip",
            r"\begin{tabular}{llrrr}\toprule",r"Backbone & Score & $n$ & AUROC & FPR@95\\\midrule"])
        architecture += [" & ".join([row[0]]+row[2:])+r"\\" for row in rows if row[1]==ds]
        architecture.append(r"\bottomrule\end{tabular}\end{minipage}")
        if ds=="PACS":architecture.append(r"\hfill")
    architecture.append(r"\end{table*}")
    (SRC/"tables/architecture.tex").write_text("\n".join(architecture)+"\n",encoding="ascii")
    rows=[]
    for i,r in enumerate(ptr("C3b","summary")):
        sel={"known_NLL":"Known NLL","validation_MSP_AUROC":"MSP AUROC","validation_energy_AUROC":"Energy AUROC"}[r["selector"]]
        rows.append(["PACS","Full20",sel,r["method"],n("C3b",("summary",i,"n"),0),n("C3b",("summary",i,"auroc")),n("C3b",("summary",i,"fpr95"))])
    for i,r in enumerate(ptr("additional","fullbudget_selectors")):
        if r["dataset"]!="cifar10" or r["method"] not in ["autoMixTemp","Energy-T-tuned"]:continue
        sel={"known_NLL":"Known NLL","validation_MSP_AUROC":"MSP AUROC","validation_energy_AUROC":"Energy AUROC"}[r["selector"]]
        rows.append(["PACS" if r["dataset"]=="pacs" else "CIFAR-10","Full20",sel,r["method"],n("additional",("fullbudget_selectors",i,"n"),0),n("additional",("fullbudget_selectors",i,"auroc")),n("additional",("fullbudget_selectors",i,"fpr95"))])
    for i,r in enumerate(ptr("completed_result_audit","matched_primary_full20")):
        rows.append(["PACS","NLL-stop","Known NLL",r["method"],n("completed_result_audit",("matched_primary_full20",i,"n"),0),n("completed_result_audit",("matched_primary_full20",i,"primary_auroc")),n("completed_result_audit",("matched_primary_full20",i,"primary_fpr95"))])
    table("fullbudget","Validation selectors on full20 trajectories: all PACS domain/role combinations at seed0 and five CIFAR-10 roles at seed0. Exact PACS primary-protocol counterparts are listed separately; these are fixed-fit sensitivity panels, not independent replications.",r"Dataset & Budget & Selector & Score & Units & AUROC & FPR@95",rows,"llllrrr")
    compact=[]
    for ds,budget,sel,score,units,auc,fpr in rows:
        compact.append(["CIFAR" if ds=="CIFAR-10" else ds,
            "NLL-stop" if budget=="NLL-stop" else {"Known NLL":"NLL","MSP AUROC":"MSP-AUC","Energy AUROC":"Energy-AUC"}[sel],
            "Auto" if score=="autoMixTemp" else "Energy",units,auc,fpr])
    compact_text=[r"\begin{table*}[!t]\centering\footnotesize\setlength{\tabcolsep}{2.5pt}",
        r"\caption{Validation epoch selectors on full20 trajectories at seed0. NLL-stop rows are exact PACS primary counterparts. Auto denotes autoMixTemp; Energy is temperature-tuned. These fixed-fit controls are not independent replications.}\label{tab:fullbudget}",
        r"\begin{tabular}{lllrrr}\toprule",r"Data & Selector & Score & $n$ & AUROC & FPR@95\\\midrule"]
    compact_text += [" & ".join(row)+r"\\" for row in compact]
    compact_text.append(r"\bottomrule\end{tabular}\end{table*}")
    (SRC/"tables/fullbudget.tex").write_text("\n".join(compact_text)+"\n",encoding="ascii")
    rows=[]
    for i,r in enumerate(ptr("B1","strata")):
        if not r["n"]:continue
        rows.append([r["model"],"PACS" if r["dataset"]=="pacs" else "CIFAR-10",r["choice"],n("B1",("strata",i,"n"),0),n("B1",("strata",i,"validation_fpr_gain"),sign=True),n("B1",("strata",i,"delta_fpr95"),sign=True),"/".join(n("B1",("strata",i,k),0) for k in ["lower","higher","tied"])])
    table("usecases","autoMixTemp versus Temp-MSP by selected source. Validation gain is Temp minus auto; target change is auto minus Temp. L/H/T counts lower/higher/tied target FPR@95.",r"Backbone & Dataset & Source & Units & Validation gain & Target change & L/H/T",rows,"lllrrrl")
    rows=[]
    for i,r in enumerate(ptr("B6","summary")):
        if r["metric"]!="delta_fpr95":continue
        loo="["+n("B6",("summary",i,"leave_one_out_min"),sign=True)+", "+n("B6",("summary",i,"leave_one_out_max"),sign=True)+"]"
        ranges=[]
        for scheme in ["cluster","joint"]:
            if r["dataset"]=="cifar10":ranges.append("---");continue
            p=pick("B6","intervals",dataset="pacs",scheme=scheme,comparator=r["comparator"],metric="delta_fpr95")
            ranges.append("["+n("B6",p+("lower",),sign=True)+", "+n("B6",p+("upper",),sign=True)+"]")
        rows.append(["PACS" if r["dataset"]=="pacs" else "CIFAR-10",r["comparator"],n("B6",("summary",i,"mean"),sign=True),"/".join(n("B6",("summary",i,k),0) for k in ["lower","higher","tied"]),loo]+ranges)
    table("clusters","Cluster-level auto-minus-comparator FPR@95. L/H/T counts use seed-averaged clusters; LOO deletes one cluster. PACS ranges use 10,000 draws per scheme; no cluster interval is reported for five CIFAR-10 clusters.",r"Dataset & Comparator & Mean & L/H/T & LOO range & Cluster range & Joint range",rows,"llrllll")
    rows=[]
    for i,r in enumerate(ptr("B5","associations")):
        if r["group"]=="all":rows.append([r["feature"].replace("_"," "),n("B5",("associations",i,"clusters"),0),n("B5",("associations",i,"spearman"),3,sign=True)])
    table("heterogeneity","PACS cluster-level Spearman associations with stable autoMixTemp-minus-MSP FPR@95. No p-values or causal interpretation.",r"Baseline feature & Clusters & Spearman",rows,"lrr")
    # Named prose macros use the same evidence registry as table values.
    named={}
    for ds,pre in [("pacs","PACS"),("cifar10","CIFAR")]:
        ss=ptr("stable","summaries",ds)
        for metric,field in [("AUC","auroc"),("FPR","fpr95")]:
            named[pre+"Delta"+metric]=derived(pre+"Delta"+metric,ss["autoMixTemp"][field]-ss["MSP"][field],6,sign=True)
            named["Abs"+pre+metric]=derived("Abs"+pre+metric,ss["autoMixTemp"][field]-ss["MSP"][field],3,sign=True)
        for method,label in [("autoMixTemp","Auto"),("MSP","Base")]:
            named[pre+label+"Recall"]=n("stable",("summaries",ds,method,"frozen_unknown_recall"),3)
        for rho,tag in [(.95,"NinetyFive"),(.99,"NinetyNine")]:
            p=pick("B2","summary",model="ViT-B32",dataset=ds,method="autoMixTemp",rho=rho,policy="worst_class")
            for field,word in [("unknown_recall","Recall"),("known_rejection","Reject")]:named[pre+"Worst"+tag+word]=n("B2",p+(field,),3)
        p=pick("B3","summary",model="ViT-B32",dataset=ds,method="Known-NLL-TS")
        named[pre+"NLLTS"]=n("B3",p+("nll",),3)
        p=pick("B1","associations",model="ViT-B32",dataset=ds)
        named[pre+"GainCorr"]=n("B1",p+("spearman",),3)
    named["CellMinimum"]=n("B5",("minimum_cell_pp",),3,sign=True)
    named["CellMaximum"]=n("B5",("maximum_cell_pp",),3,sign=True)
    for i,r in enumerate(ptr("B5","associations")):
        if r["group"]=="all" and r["feature"]=="baseline_fpr95":named["DifficultyCorr"]=n("B5",("associations",i,"spearman"),3)
    for ds,prefix in [("pacs","PACS"),("cifar10","CIFAR")]:
        p=pick("C2_NegLabel","summary",dataset=ds,variant="standard")
        for k,label in [("fpr95","FPR"),("auroc","AUC")]:named["Neg"+prefix+label]=n("C2_NegLabel",p+(k,),3)
    named["FullBudgetUnits"]=derived("FullBudgetUnits",ptr("C3b","summary",0,"n")+next(r["n"] for r in ptr("additional","fullbudget_selectors") if r["dataset"]=="cifar10"),0)
    named["PACSFullUnits"]=n("C3b",("summary",0,"n"),0)
    p=pick("C3b","summary",selector="known_NLL",method="Energy-T-tuned");named["EnergyNLLFullFPR"]=n("C3b",p+("fpr95",),3)
    p=pick("C3b","summary",selector="validation_energy_AUROC",method="Energy-T-tuned");named["EnergyEpochFullFPR"]=n("C3b",p+("fpr95",),3)
    alias=["\\newcommand{\\"+k+"}{"+v+"}" for k,v in named.items()]
    (SRC/"numbers_revision2.tex").write_text("\n".join(MACROS+alias)+"\n",encoding="ascii")
    (ROOT/"evidence/manuscript_values.json").write_text(json.dumps(DERIVED,indent=2),encoding="utf-8")
    (ROOT/"evidence/number_registry.json").write_text(json.dumps(REG,indent=2),encoding="utf-8")
    print("Evidence-linked tables and prose numbers generated:",len(REG))


if __name__=="__main__":main()
