"""Record artifact QA after native rendering and page-by-page visual review."""
import hashlib
import json
from pathlib import Path
import re
from zipfile import ZipFile
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()

def main():
    clean=ROOT/"source/manuscript.pdf";high=ROOT/"source/manuscript_highlighted.pdf"
    supp=ROOT/"source/supplement.pdf";response=ROOT/"deliverables/response_to_reviewers.docx"
    template=ROOT.parent/"01_editorial/_ IEEE-Access-Response-to-Reviewers-template-6.26.23.docx"
    with ZipFile(template) as a,ZipFile(response) as b:
        assert a.namelist()==b.namelist()
        changed=[name for name in a.namelist() if a.read(name)!=b.read(name)]
        assert changed==["word/document.xml"]
    for row in read(ROOT/"evidence/response_number_registry.json"):
        value=read(ROOT/"evidence"/row["file"])
        for key in row["pointer"]:value=value[key]
        assert value==row["value"] and format(value,"."+str(row["decimals"])+"f")==row["display"]
    assert len(read(ROOT/"evidence/responses.json")["records"])==17
    office=read(ROOT/"evidence/C1_complete_panel_audit.json")
    assert office["all_checks_pass"] and office["n"]==20 and office["method_unit_records_verified"]==140
    assert read(ROOT/"evidence/officehome_portable_score_checks.json")["all_checks_pass"]
    matrix=read(ROOT/"evidence/review_evidence_matrix.json")
    assert len(matrix["records"])==17 and matrix["authorized_experiment_evidence_complete"]
    a,b=PdfReader(clean),PdfReader(high)
    assert len(a.pages)==len(b.pages)
    assert all(x.get_contents().get_data()==y.get_contents().get_data() for x,y in zip(a.pages,b.pages))
    assert all(page.get("/Annots") for page in b.pages)
    main_log=(ROOT/"source/manuscript.log").read_text(errors="replace")
    assert not re.search(r"undefined references|undefined citations|! LaTeX Error",main_log,re.I)
    output=dict(all_delivered_pages_reviewed=True,clean_pages=len(a.pages),highlighted_pages=len(b.pages),
        supplementary_pages=len(PdfReader(supp).pages),response_pages=len(PdfReader(ROOT/"logs/response_render/response.pdf").pages),
        clean_sha256=sha(clean),highlight_sha256=sha(high),supplement_sha256=sha(supp),response_docx_sha256=sha(response),
        method="Poppler full-page PNGs, all-page contact sheets and individual checks of revised figures/tables; native hidden Word export for the IEEE response template. Yellow annotations inspected on all pages; PDF page content streams match the clean copy exactly.",
        no_visible_clipping_or_overlap=True,no_undefined_references=True,template_parts_preserved_except_document_xml=True,
        template_output_box_warnings=len(re.findall("Overfull",main_log)),
        warning_scope="Existing IEEE Access template maketitle/output routine box warnings persist; they also occur in the protected previous draft. All rendered pages were reviewed. No claim of a warning-free TeX log is made.",
        officehome_stage1_included_as_complete_panel=True,authorized_experiment_evidence_complete=True,
        reviewer_assessment_counts=matrix["status_counts"],author_approval=False,upload_ready=False)
    (ROOT/"evidence/visual_checks.json").write_text(json.dumps(output,indent=2),encoding="utf-8")
    print(json.dumps(output,indent=2))

if __name__=="__main__":main()
