"""Tighten only the new interpretation/scope wording and qualify the abstract."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
records=json.loads((ROOT/"evidence/G1_manuscript_language_edits.json").read_text(encoding="utf-8"))
def edit(key,file,before,after,why):
    p=ROOT/"source"/file;t=p.read_text(encoding="utf-8");assert before in t
    p.write_text(t.replace(before,after),encoding="utf-8")
    records.append(dict(id=key,file="source/"+file,before=before,after=after,rationale=why,scientific_content_preserved="Scientific scope and findings unchanged; no numerical field modified."))
edit("M17","manuscript.tex","Probability diagnostics show poorer reliability,","AutoMixTemp's probability diagnostics show poorer reliability,",
     "Attribute the adverse probability result to the evaluated method, not all probability variants.")
edit("M18","body_revision.tex",
     "The probability diagnostics show that improved rejection ranking can coexist with poorer known-class reliability. The source gates expose panel-dependent gains, with no consistently transferable interior-mixing benefit. These findings support temperature-only scoring as the simpler reference and joint search as an optional, auditable extension whose operating-point trade-offs must be assessed explicitly.",
     "Improved rejection ranking coexists with poorer known-class reliability and panel-dependent source-selection gains. Probability diagnostics and transferred operating points therefore complement ROC ranking when assessing the added search against temperature-only scoring.",
     "Give the interpretation without repeating the negative mixing finding already reported with its gate evidence.")
edit("M19","body_revision.tex",
     "The estimates describe finite fitted panels. Across units, images, class roles and training/validation data are reused, including test images within a target domain. Image, cluster and joint reweighting condition on fixed fits and validation choices. Neither these ranges nor optimization seeds estimate uncertainty from retraining, recalibration, class-population sampling or unseen domains; IID population inference is therefore excluded.",
     "Finite-panel estimates retain dependence from reused images, class roles and training/validation data, including test images within a target domain. Image, cluster and joint reweighting condition on fixed fits and validation choices rather than estimating retraining, recalibration, class-population or unseen-domain uncertainty. Optimization seeds do not create IID population observations.",
     "Consolidate the fixed-fit/dependence restriction into one precise paragraph.")
edit("M20","body_revision.tex",
     "Different validation and target unknown classes provide no exchangeability basis for a deployment guarantee. Under an unrestricted future unknown distribution, all its probability mass could lie in a nonempty acceptance region. Validation classes alone therefore cannot guarantee unknown recall while retaining useful known acceptance.",
     "Validation/target unknown-class mismatch prevents an exchangeability-based guarantee. All mass of an unrestricted future unknown distribution can lie in a nonempty acceptance region; retaining useful known acceptance therefore cannot guarantee unknown recall.",
     "Preserve the acceptance-region counterexample and lack of exchangeability without three repeated guarantee disclaimers.")
edit("M21","body_revision.tex",
     "The audit separates numerical score fidelity from temperature/source selection. Stable log-odds resolve subtractive-MSP ties, and the analyzed autoMixTemp panels improve mean detection metrics relative to MSP.",
     "Stable log-odds resolve subtractive-MSP ties, separating numerical fidelity from temperature/source selection. The analyzed autoMixTemp panels improve mean detection metrics relative to MSP.",
     "Start the conclusion directly with the finding rather than a prefatory audit description.")
(ROOT/"evidence/G1_manuscript_language_edits.json").write_text(json.dumps(records,indent=2,ensure_ascii=False),encoding="utf-8")
