"""Validate official construction and logging without a forward pass or GPU."""
import json
import torch
from r5_locoop_bridge import ROOT,config_for
from trainers.locoop import LoCoOp


def main():
    assert not torch.cuda.is_available()
    results=[]
    for dataset,unit in [("pacs","art_painting_rotation00_seed0"),("cifar10","cifar10_rotation00_seed0")]:
        cfg=config_for(dataset,unit,ROOT/"logs/locoop_cpu_constructor"/unit,use_cuda=False)
        trainer=LoCoOp(cfg)
        names=[name for name,p in trainer.model.named_parameters() if p.requires_grad]
        assert names and all(name.startswith("prompt_learner.") for name in names)
        trainer.before_train();assert trainer.start_epoch==0;trainer.close_writer()
        results.append(dict(dataset=dataset,unit=unit,backbone=cfg.MODEL.BACKBONE.NAME,
            trainable_parameters=sum(p.numel() for p in trainer.model.parameters() if p.requires_grad),
            only_prompt_trainable=True,summary_writer_initialized=True,torch_version=torch.__version__))
        del trainer
    (ROOT/"evidence/E6_cpu_constructor_checks.json").write_text(json.dumps(dict(passed=True,records=results,
        no_model_forward_performed=True,no_training=True,no_gpu_available=True),indent=2),encoding="utf-8")
    print("Official ViT-B/32 model, optimizer, scheduler and logger construction passed on CPU for both pilots; no forward pass.")


if __name__=="__main__":main()
