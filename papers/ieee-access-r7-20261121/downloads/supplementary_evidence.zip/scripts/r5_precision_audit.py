"""Compare archived interpolation with explicit float64 on both branches."""
import sys
import numpy as np
from sklearn.metrics import roc_auc_score
from gap_closure_core import *


def main():
    rows, differences, inputs = [], [], []
    for model, ds, unit, directory, archived in units():
        a = load_arrays(directory)
        grid = [float(x) for x in read(directory / "config.json")["arguments"]["temp_candidates"].split(",")]
        vy = np.r_[np.zeros(len(a["ka"]), dtype=int), np.ones(len(a["ua"]), dtype=int)]
        specs = [("MSP", "adapter", "msp", [1.]), ("Temp-MSP", "adapter", "msp", grid),
                 ("Energy-T-tuned", "adapter", "energy", grid), ("autoMixTemp", "auto", "msp", grid)]
        choices = {name: choose(a, route, mode, ts) for name, route, mode, ts in specs}
        choice_path = ROOT / "evidence/r5_validation_choices" / model / ds / (unit + ".json")
        write(choice_path, dict(choices=choices, policy="Validation FPR95, then AUROC; deterministic listed order; no target objective."))
        ty = a["ty"]; y = (ty < 0).astype(int); known = ty >= 0
        saved = dict(target_labels=ty, adapter_predictions=a["ta"].argmax(1), validation_labels=vy)
        for name, route, mode, ts in specs:
            sel = choices[name]
            st, sv = detection(a, sel, mode)
            assert np.isfinite(st).all() and np.isfinite(sv).all()
            threshold = fpr_at_recall(sv, vy)["threshold"]
            reject = st >= threshold
            rec = dict(**tag(model, ds, unit), method=name, selection=sel,
                       auroc=float(roc_auc_score(y, st)), fpr95=fpr_at_recall(st, y)["fpr95"],
                       recall=float(reject[~known].mean()), rejection=float(reject[known].mean()),
                       threshold=threshold, choices_sha256=sha(choice_path))
            rows.append(rec); saved[name] = st; saved[name + "_validation"] = sv
            old = archived[name]
            old_recall = old.get("frozen_unknown_recall", old.get("frozen_threshold_test_unknown_tpr"))
            old_reject = old.get("frozen_known_rejection", old.get("frozen_threshold_test_known_fpr"))
            old_sel = old["selection"]
            canonical_at_old, _ = detection(a, old_sel, mode)
            if ds == "officehome":
                old_scores = canonical_at_old
            else:
                sys.path.insert(0, str(BASE / "tools"))
                from stable_score_audit import branch as old_branch, stable_msp, stable_energy
                fn = stable_energy if mode == "energy" else stable_msp
                old_scores = fn(old_branch(a, "t", old_sel), old_sel["T_score"])
            differences.append(dict(**tag(model, ds, unit), method=name,
                changed_route_or_temperature=any(sel[k] != old_sel[k] for k in ["score_source", "alpha", "T_score"]),
                max_score_abs_difference_at_old_parameters=float(np.max(np.abs(canonical_at_old - old_scores))),
                delta_auroc=rec["auroc"]-old["auroc"], delta_fpr95=rec["fpr95"]-old["fpr95"],
                delta_recall=rec["recall"]-old_recall, delta_rejection=rec["rejection"]-old_reject))
        path = cache_path(model, ds, unit); path.parent.mkdir(parents=True, exist_ok=True)
        np.savez_compressed(path, **saved)
        inputs.append(dict(**tag(model, ds, unit), raw_logits=str(directory / "logits.npz"),
                           raw_logits_sha256=sha(directory / "logits.npz"), saved_score_sha256=sha(path)))
        print("E0 " + model + " " + ds + " " + unit, flush=True)
    changed = [r for r in differences if any(abs(r[k]) > 1e-12 for k in ["delta_auroc", "delta_fpr95", "delta_recall", "delta_rejection"]) or r["changed_route_or_temperature"]]
    save("E0_precision", dict(records=rows, differences=differences, changed_observations=changed,
        unit_inputs=inputs, unit_count=len(inputs), method_rows=len(rows),
        maximum_score_difference=max(r["max_score_abs_difference_at_old_parameters"] for r in differences),
        changed_observation_count=len(changed), canonical_mixing="Both branches cast to float64 before either multiplication; stable log-odds/energy; all archives unchanged.",
        integration_gate="Any changed choice or metric requires explicit reconciliation of all affected tables, curves and claims; never silently reuse old numerical bindings."))


if __name__ == "__main__":
    main()
