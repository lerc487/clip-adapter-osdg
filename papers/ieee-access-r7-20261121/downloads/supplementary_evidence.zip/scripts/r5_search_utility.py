"""Quantify search cost and paired value without selecting favorable targets."""
import time
import platform
from scipy.stats import spearmanr
from gap_closure_core import *


def main():
    source = read(ROOT / "evidence/E0_precision.json")
    grouped = defaultdict(dict)
    for r in source["records"]:
        grouped[(r["model"], r["dataset"], r["unit"])][r["method"]] = r
    records, gates = [], []
    for (model, ds, unit), methods in sorted(grouped.items()):
        auto, temp = methods["autoMixTemp"], methods["Temp-MSP"]
        sel = auto["selection"]
        kind = sel["score_source"]
        if kind == "mix" and sel["alpha"] in [0., 1.]:
            kind = "adapter" if sel["alpha"] == 1. else "zeroshot"
        gain = temp["selection"]["val_fpr95"] - sel["val_fpr95"]
        records.append(dict(**tag(model, ds, unit), source=kind, validation_fpr_gain=gain,
            target_fpr_gain=temp["fpr95"]-auto["fpr95"], delta_fpr95=auto["fpr95"]-temp["fpr95"],
            delta_auroc=auto["auroc"]-temp["auroc"], alpha=sel["alpha"], temperature=sel["T_score"]))
        for delta in [0., .01]:
            for gate in ["any_source", "interior_only"]:
                enabled = gain > delta and (gate == "any_source" or kind == "mix")
                chosen = auto if enabled else temp
                gates.append(dict(**tag(model, ds, unit), delta=delta, gate=gate, enabled=enabled,
                    delta_fpr95=chosen["fpr95"]-temp["fpr95"], delta_auroc=chosen["auroc"]-temp["auroc"]))
    strata = grouped_means(records, ["model", "dataset", "source"], ["validation_fpr_gain", "delta_fpr95", "delta_auroc"])
    for row in strata:
        rs = [r for r in records if all(r[k] == row[k] for k in ["model", "dataset", "source"])]
        row.update(lower=sum(r["delta_fpr95"] < 0 for r in rs), higher=sum(r["delta_fpr95"] > 0 for r in rs), tied=sum(r["delta_fpr95"] == 0 for r in rs))
    correlations = []
    for model, ds in sorted({(r["model"], r["dataset"]) for r in records}):
        rs = [r for r in records if r["model"] == model and r["dataset"] == ds]
        x, y = [r["validation_fpr_gain"] for r in rs], [r["target_fpr_gain"] for r in rs]
        correlations.append(dict(model=model, dataset=ds, n=len(rs),
            spearman=float(spearmanr(x, y).statistic) if len(set(x)) > 1 and len(set(y)) > 1 else None))
    timings = []
    for model, ds, unit, directory, old in units():
        if model != "ViT-B32" or not unit.endswith("rotation00_seed0"):
            continue
        a = load_arrays(directory)
        grid = [float(x) for x in read(directory / "config.json")["arguments"]["temp_candidates"].split(",")]
        ka = {k: a[k] for k in ["ka", "kz", "ua", "uz"]}
        for route in ["adapter", "auto"]:
            choose(ka, route, "msp", grid)
        for repeat in range(3):
            for route in (["adapter", "auto"] if repeat % 2 == 0 else ["auto", "adapter"]):
                started = time.perf_counter()
                selection = choose(ka, route, "msp", grid)
                elapsed = time.perf_counter() - started
                expected = grouped[(model, ds, unit)]["autoMixTemp" if route == "auto" else "Temp-MSP"]["selection"]
                assert selection == expected
                timings.append(dict(**tag(model, ds, unit), route=route, repeat=repeat, seconds=elapsed,
                    validation_files=len(a["ka"])+len(a["ua"]), listed_candidates=len(grid)*(7 if route == "auto" else 1)))
        print("E1 timing " + ds + " " + unit, flush=True)
    timing_summary = []
    for key in sorted({(r["dataset"], r["unit"]) for r in timings}):
        rows = {route: [r["seconds"] for r in timings if (r["dataset"], r["unit"], r["route"]) == (*key, route)] for route in ["adapter", "auto"]}
        timing_summary.append(dict(dataset=key[0], unit=key[1], repeats=3,
            temp_median_seconds=float(np.median(rows["adapter"])), auto_median_seconds=float(np.median(rows["auto"])),
            auto_to_temp_ratio=float(np.median(rows["auto"])/np.median(rows["adapter"]))))
    save("E1_search_utility", dict(records=records, strata=strata, correlations=correlations, gate_records=gates,
        gate_summary=grouped_means(gates, ["model", "dataset", "delta", "gate"], ["enabled", "delta_fpr95", "delta_auroc"]),
        timing_records=timings, timing_summary=timing_summary, platform=platform.platform(),
        timing_scope="Nine fixed rotation00/seed0 ViT-B32 units, one per domain/dataset. One warmup and three repetitions per route, alternating execution order. CPU validation-search timing excludes loading, training and encoder inference; it is not a latency benchmark for a deployed system.",
        decision_rule="No gate is adopted on the basis of these target outcomes. Report every prespecified gate. Extra search is not established as necessary by validation fit alone."))


if __name__ == "__main__":
    main()
