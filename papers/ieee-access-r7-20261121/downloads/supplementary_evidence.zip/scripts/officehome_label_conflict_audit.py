"""Quantify a possible label-integrity amendment without applying it."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/"new_runs/officehome"


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def new(p,x):
    with p.open("x",encoding="utf-8") as f:json.dump(x,f,indent=2,allow_nan=False)


def main():
    spec=dict(task="C1_label_conflict_audit",input_inventory_sha256=sha(WORK/"integrity_check.json"),
        v2_audit_sha256=sha(ROOT/"evidence/C1_dedup_v2.json"),script_sha256=sha(Path(__file__)),
        design="Read-only counts of all exact-byte duplicate groups assigned to different categories. Report all existing v2 known/unknown label conflicts and examples. Compute exact remaining sample availability under a proposed global exclusion of all members of groups crossing domains OR categories, without modifying manifests or images.",
        non_authorization="Only the21cross-domain paths have been authorized for exclusion. Any broader rule remains a proposal requiring explicit approval, a new immutable version and no target-performance-based selection.",
        scope="Input metadata only, no Office-Home model outcomes or sampling changes.")
    p=ROOT/"prespec/C1_label_conflict_audit.json";new(p,spec)
    new(ROOT/"prespec/C1_label_conflict_audit_seal.json",dict(task=spec["task"],sha256=sha(p)))
    source=read(WORK/"integrity_check.json");groups=read(ROOT/"evidence/C1_duplicate_audit.json")["groups"]
    v2=read(ROOT/"evidence/C1_dedup_v2.json")
    cross_category=[g for g in groups if not g["category_agreement"]]
    proposed=[g for g in groups if g["cross_domain"] or not g["category_agreement"]]
    all_hashes={g["sha256"] for g in proposed};old_hashes={g["sha256"] for g in groups if g["cross_domain"]}
    additional=[r for r in source["files"] if r["sha256"] in all_hashes-old_hashes]
    remaining=[r for r in source["files"] if r["sha256"] not in all_hashes]
    counts=Counter((r["domain"],r["category"]) for r in remaining)
    assert len(counts)==260
    pilot_examples=[]
    for uid in v2["pilot"]:
        row=next(r for r in v2["label_conflicts"] if r["unit"]==uid)
        pilot_examples.append(dict(unit=uid,split=row["split"],example=row["groups"][0]))
    result=dict(task=spec["task"],prespec_sha256=sha(p),cross_category_duplicate_groups=len(cross_category),
        cross_category_duplicate_group_images=sum(len(g["images"]) for g in cross_category),
        proposed_union_duplicate_groups=len(proposed),proposed_union_excluded_images=len(source["files"])-len(remaining),
        additional_images_beyond_authorized21=len(additional),proposed_remaining_images=len(remaining),
        proposed_min_images_per_domain_category=min(counts.values()),proposed_cells_below10=[dict(domain=d,category=c,n=n) for (d,c),n in sorted(counts.items()) if n<10],
        v2_known_unknown_conflicting_hash_groups=v2["known_unknown_conflicting_hash_groups_across_planned_units"],
        affected_v2_pilot_ids=v2["affected_pilot_ids"],pilot_examples=pilot_examples,
        proposal_groups=proposed,additional_paths=[r["path"] for r in additional],
        no_additional_exclusion_applied=True,no_data_modified=True,no_model_inference=True)
    new(ROOT/"evidence/C1_label_conflict_audit.json",result)
    lines=["# Office Home 已知未知标签冲突与待确认方案","","## 1 做了什么",
        "完成用户已授权的21张跨域重复排除并封存 v2。随后只读复核每个预设运行的图像标签；未进行任何额外排除、重采样或模型计算。","","## 2 文件位置",
        "v2 新清单：new_runs/officehome/dedup_v2/roles_manifest.json；v2 审计：evidence/C1_dedup_v2.json。补充检查：evidence/C1_label_conflict_audit.json；设计与哈希在 prespec/C1_label_conflict_audit.json 及 seal。","","## 3 数字与来源",
        "以下精确计数均来自 evidence/C1_label_conflict_audit.json，原始图像清单与 v2 角色表通过哈希绑定。","",
        f"剩余域内跨类别完全重复有 {len(cross_category)} 组，涉及 {result['cross_category_duplicate_group_images']} 张图像；其中 {result['v2_known_unknown_conflicting_hash_groups']} 个不同图像哈希组在某些预设运行中跨越已知/未知标签边界。两个计时试点均受影响。","","| 试点 | 集合 | 同一图像的已知路径 | 未知路径 |","| --- | --- | --- | --- |"]
    for r in pilot_examples:lines.append("| "+r["unit"]+" | "+r["split"]+" | "+", ".join(r["example"]["left"])+" | "+", ".join(r["example"]["right"])+" |")
    lines += ["","## 4 对结论的影响",
        "这不是算法结果不利，也不是下载损坏。它是原始数据的标签完整性问题：完全相同输入不应同时作为二元检测的已知和未知样本。仅处理跨域重复还不足以消除这一矛盾；因此 GPU 试点尚未激活，C3b 继续运行，NegLabel 仍按既定顺序等待。保留清单内同域同类的重复项仍意味着名义样本数不等于独立图像数，后续应如实报告，不作 IID 推断。","","## 5 待确认的规则",
        "建议新增 v3：统一排除跨域或跨类别的完全重复组的全部成员，避免按类别主观挑选保留哪张。原文件一律保留，旧预设和 v2 清单不变；类别排序、轮换、每类10张采样和阶段规则均不改变。",
        f"按当前清单精确计算，该规则相对 v2 还需排除 {len(additional)} 张，总排除 {result['proposed_union_excluded_images']} 张，剩 {len(remaining)} 张；单域单类最少仍有 {result['proposed_min_images_per_domain_category']} 张，低于10张的单元格为 {len(result['proposed_cells_below10'])}。这只是可用性检查，并未实施该规则。",
        "","请确认是否同意该清单级规则；确认后再建立新预设版本并重新封存，不能覆盖已封存的21张排除规则。"]
    (ROOT/"reports/C1_已知未知标签冲突与待确认方案.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k not in ["proposal_groups","additional_paths"]},indent=2,ensure_ascii=False))


if __name__=="__main__":main()
