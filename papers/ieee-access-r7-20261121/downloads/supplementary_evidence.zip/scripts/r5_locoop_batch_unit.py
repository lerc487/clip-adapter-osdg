"""One frozen official-trainer fit; never choose a configuration on target data."""
import argparse
import os
from pathlib import Path
import sys
import time

import numpy as np
import torch
from torch.utils.data import DataLoader
from scipy.special import logsumexp
from sklearn.metrics import roc_auc_score
from dassl.utils import set_random_seed

from r5_locoop_batch_common import ROOT, BASE, R2, SPEC, METHODS, sealed, unit_inputs, read, write, sha, available_disk
from r5_locoop_bridge import OFFICIAL, config_for
from r5_locoop_pilot_unit import known_nll, stable_scores

sys.path.insert(0, str(ROOT / "new_runs/c3b/code"))
from train_disjoint import MultiDomainFolder
from verified_metrics import fpr_at_recall
from trainers.locoop import LoCoOp
from clip_w_local import clip


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--fit-id", required=True)
    args = parser.parse_args()
    spec = sealed()
    job = next(r for r in spec["jobs"] if r["fit_id"] == args.fit_id)
    assert not job["reused_pilot"]
    owner = os.environ.get("R5_LOCOOP_BATCH_OWNER")
    assert owner and (R2 / "new_runs/GPU_QUEUE.lock").read_text().strip() == owner
    assert read(ROOT / "evidence/E6_locoop_batch_fixtures.json")["all_checks_pass"]
    assert available_disk() >= spec["minimum_free_bytes"]
    inputs = unit_inputs(spec, job)
    output = Path(job["output"])
    assert not output.exists(), "Partial or completed output requires queue inspection"
    cfg = config_for(job["dataset"], job["unit"], output, use_cuda=True)
    cfg.defrost()
    cfg.lambda_value = job["lambda_value"]
    cfg.freeze()
    assert sha_text(cfg.dump()) == job["config_sha256"]
    output.mkdir(parents=True, exist_ok=False)
    write(output / "config.json", dict(yaml=cfg.dump(), fit_id=job["fit_id"], lambda_value=job["lambda_value"],
        batch_prespec_sha256=sha(SPEC), inputs_sha256=spec["inputs_sha256"],
        literal_input_manifest_hashes=inputs["manifest_hashes"], no_target_based_hyperparameters=True,
        queue_lock_owner=owner, observed_parent_pid=os.getppid()), exclusive=True)
    set_random_seed(0)
    torch.backends.cudnn.benchmark = False
    started = time.perf_counter()
    trainer = LoCoOp(cfg)
    trainable = [name for name, p in trainer.model.named_parameters() if p.requires_grad]
    assert trainable and all(name.startswith("prompt_learner.") for name in trainable)
    trainer.before_train()
    assert trainer.start_epoch == 0 and cfg.OPTIM.MAX_EPOCH == 50
    source = Path(inputs["input_run"])
    known_labels = np.array([s["label"] for s in read(source / "val_known_samples.json")], dtype=np.int64)
    validation_dir = output / "known_validation_trace"
    validation_dir.mkdir(exist_ok=False)
    records = []
    best = (float("inf"), None)
    for epoch in range(50):
        trainer.epoch = epoch
        trainer.before_epoch()
        trainer.run_epoch()
        captured = []
        def capture_known(module, data, result):
            captured.append(result[0].detach().cpu().numpy().copy())
        hook = trainer.model.register_forward_hook(capture_known)
        try:
            nll = known_nll(trainer)
        finally:
            hook.remove()
        logits = np.concatenate(captured)
        assert len(logits) == len(known_labels) and np.isfinite(logits).all() and np.isfinite(nll)
        independent_nll = float(np.mean(logsumexp(logits.astype(np.float64), axis=1) - logits[np.arange(len(logits)), known_labels]))
        assert abs(nll - independent_nll) <= 1e-5, (job["fit_id"], epoch, nll, independent_nll)
        trace = validation_dir / ("epoch_%02d.npz" % (epoch + 1))
        np.savez_compressed(trace, global_logits=logits, labels=known_labels,
            batch_sizes=np.array([len(x) for x in captured], dtype=np.int64))
        row = dict(epoch=epoch + 1, known_validation_nll=nll, float64_diagnostic_nll=independent_nll,
            validation_logits_file=str(trace), validation_logits_sha256=sha(trace))
        records.append(row)
        if nll < best[0]:
            best = (nll, epoch + 1)
        trainer.after_epoch()
        checkpoint = output / "prompt_learner" / ("model.pth.tar-" + str(epoch + 1))
        assert checkpoint.is_file()
        row["checkpoint_sha256"] = sha(checkpoint)
        with (output / "epochs.jsonl").open("a", encoding="utf-8") as f:
            import json
            f.write(json.dumps(row) + "\n")
        write(output / "progress.json", dict(stage="official_prompt_training", epoch=epoch + 1, total_epochs=50,
            fit_id=job["fit_id"], lambda_value=job["lambda_value"], validation_nll=nll))
    trainer.after_train()
    chosen = output / "prompt_learner" / ("model.pth.tar-" + str(best[1]))
    choice = dict(epoch=best[1], known_validation_nll=best[0], checkpoint_file=str(chosen), checkpoint_sha256=sha(chosen),
        policy="Earliest minimum recorded official float32 known-validation NLL over all50epochs; no validation unknown or target choice",
        float64_trace_is_diagnostic_not_selection_objective=True, prespec_sha256=sha(SPEC))
    write(output / "checkpoint_choice_frozen.json", choice, exclusive=True)
    trainer.load_model(str(output), epoch=best[1])
    data_root = Path(read(source / "config.json")["arguments"]["data_root"])
    transform = clip._transform(224)
    arrays = {}
    alignment = []
    for role in ["val_known", "val_unknown", "test"]:
        samples = read(source / (role + "_samples.json"))
        loader = DataLoader(MultiDomainFolder([(str(data_root / s["path"]), s["label"]) for s in samples], transform),
            batch_size=64, num_workers=0, shuffle=False)
        captured = []
        def capture_scoring(module, data, result):
            captured.append((result[0].detach().cpu().numpy().copy(), result[1].detach().cpu().numpy().copy()))
        hook = trainer.model.register_forward_hook(capture_scoring)
        try:
            raw_mcm, raw_gl = trainer.test_ood(loader, 1.)
        finally:
            hook.remove()
        g = np.concatenate([x[0] for x in captured])
        l = np.concatenate([x[1] for x in captured])
        assert len(g) == len(samples)
        with torch.no_grad():
            pg = torch.softmax(torch.from_numpy(g) / 100., dim=-1).numpy()
            pl = torch.softmax(torch.from_numpy(l) / 100., dim=-1).numpy()
        err = max(float(np.max(np.abs(raw_mcm + pg.max(1)))),
            float(np.max(np.abs(raw_gl + pg.max(1) + pl.max(axis=(1, 2))))))
        assert err <= 1e-6
        alignment.append(dict(role=role, max_cpu_gpu_score_difference=err, passed=True))
        arrays[role + "_global_logits"] = g
        arrays[role + "_local_logits"] = l
        arrays[role + "_labels"] = np.array([s["label"] for s in samples])
        arrays[role + "_MCM_official"] = raw_mcm
        arrays[role + "_GLMCM_official"] = raw_gl
        for method, value in stable_scores(g, l).items():
            arrays[role + "_" + method] = value
        if role == "val_unknown":
            vy = np.r_[np.zeros(len(arrays["val_known_labels"]), dtype=int), np.ones(len(samples), dtype=int)]
            thresholds = {m: fpr_at_recall(np.r_[arrays["val_known_" + m], arrays["val_unknown_" + m]], vy)["threshold"] for m in METHODS}
            write(output / "validation_thresholds_frozen.json", dict(thresholds=thresholds,
                checkpoint_choice_sha256=sha(output / "checkpoint_choice_frozen.json"), score_temperature=1.,
                no_target_selection=True), exclusive=True)
    ty = arrays["test_labels"]
    y = ty < 0
    known = ~y
    pred = arrays["test_global_logits"].argmax(1)
    results = []
    for method in METHODS:
        st = arrays["test_" + method]
        reject = st >= thresholds[method]
        results.append(dict(method=method, auroc=float(roc_auc_score(y, st)), fpr95=fpr_at_recall(st, y)["fpr95"],
            frozen_unknown_recall=float(reject[y].mean()), frozen_known_rejection=float(reject[known].mean()),
            known_accuracy=float((pred[known] == ty[known]).mean()), validation95_threshold=thresholds[method]))
    saved = output / "saved_logits_and_scores.npz"
    np.savez_compressed(saved, **arrays)
    result = dict(dataset=job["dataset"], unit=job["unit"], fit_id=job["fit_id"], lambda_value=job["lambda_value"],
        results=results, epochs=records, best_epoch=best[1], measured_pipeline_seconds=time.perf_counter() - started,
        official_score_alignment=alignment, saved_arrays_sha256=sha(saved), prespec_sha256=sha(SPEC),
        official_trainer_unchanged=True, metrics_use_unknown_positive_complete_tie_ROC=True,
        not_reproduction_of_published_benchmark_numbers=True, all50_known_validation_logit_traces=True)
    write(output / "results.json", result, exclusive=True)
    write(output / "progress.json", dict(stage="complete_requires_independent_audit", fit_id=job["fit_id"], epochs=50))
    print("Official LoCoOp batch fit complete: " + job["fit_id"], flush=True)


def sha_text(text):
    import hashlib
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


if __name__ == "__main__":
    main()
