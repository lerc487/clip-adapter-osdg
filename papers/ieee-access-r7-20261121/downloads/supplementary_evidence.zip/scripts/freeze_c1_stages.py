"""Freeze stage rules before Office-Home data acceptance or outcomes."""
import hashlib
import json
from pathlib import Path
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parents[1]


def main():
    spec=dict(task="C1_stages",created_utc=datetime.now(timezone.utc).isoformat(),
        stage_status="Authorized staged design; awaiting local dataset path or explicit official-download confirmation.",
        dataset="Office-Home, four domains, 65 common categories; no substitution without user decision.",
        acceptance="Decode and SHA256 every image, verify common 65-category folders across four domains and >=10 valid images per required class/domain. Any corruption or shortage stops and reports; no silent exclusion or sample reduction.",
        class_rule="After integrity acceptance, freeze actual class names sorted by (casefold,name), then five circular rotations with step13. For rotation r: cyclic classes[(i+13*r)%65], first35 known, next15 validation unknown, final15 target unknown. Record all assignments/hashes before training.",
        domain_rule="Actual domain folder names sorted by (casefold,name); target in that order, validation=next cyclic domain, other two source domains. Freeze literal names after acceptance.",
        samples="Within each source domain take exactly10 images per known class; within validation domain exactly10 images per known and validation-unknown class; target all known plus target-unknown images. Rank within class by SHA256(seed|relative_posix_path); ties by path. Training unknowns absent. Validation unknown target roles disjoint.",
        nominal_validation_unknowns=150,validation_caveat="Only150 validation unknown samples in this design, so quantile estimates may be noisy; different10-shot-per-source-domain budget from PACS full training; report separately, never pool with primary PACS panel.",
        seeds={"pilot":[0],"stage1":[0],"stage2":[1,2]},
        pilot="First two target domains in sorted order, rotation00, seed0, at most two units. GPU runs only after C3b completion; report measured per-unit training+evaluation wall times, no quality-based decision.",
        stage1="Four domains x five rotations x seed0 =20 units, pilot two reused. Do not start remaining18 until user reviews measured timing and authorizes stage1. Run all prespecified units regardless of pilot performance.",
        stage2="Seeds1 and2, total40 additional units; later explicit user authorization required, time/resource-based decision only. Report completed stage as fixed, never choose stage by desired outcome.",
        model="ViT-B/32 openai, same adapter/loss/optimizer/prompt settings as existing pipeline; max20epochs, known-validation-NLL early stopping patience3. Stablefloat64 scoring with reference temperature/source grids. Copy accepted sample manifests into each run.",
        metrics=["AUROC","threshold-realizable FPR@95","known accuracy","frozen validation95 target unknown recall","known rejection"],
        interpretation="Equal-unit descriptive means within Office-Home only. Fixed few-shot split, no IID CI, no deployment guarantee or claim to independent images across rotations.",
        no_target_selection=True,report_all_outcomes=True,
        pending="No dataset download, integrity run, class-manifest freeze or GPU pilot has occurred for C1.")
    p=ROOT/"prespec/C1_stages.json"
    with p.open("x",encoding="utf-8") as f:json.dump(spec,f,indent=2)
    seal=ROOT/"prespec/C1_stages_seal.json"
    with seal.open("x",encoding="utf-8") as f:json.dump(dict(task="C1_stages",sha256=hashlib.sha256(p.read_bytes()).hexdigest(),frozen_before_data_acceptance=True),f,indent=2)
    print("Office-Home stage rules frozen; no data or GPU execution.")


if __name__=="__main__":main()
