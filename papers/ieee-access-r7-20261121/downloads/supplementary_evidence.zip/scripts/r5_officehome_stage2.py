"""Serial stage2 queue; original seed0 archives and source remain read-only."""
from datetime import datetime, timezone
import os
from pathlib import Path
import subprocess
import sys
import time
from gap_closure_core import ROOT, R2, read, sha, write

sys.path.insert(0, str(R2 / "scripts"))
from officehome_train import selected_rows
from officehome_pilot import verify_samples
from officehome_pilot_v3_eval64 import verify_exact_labels
from officehome_stable_evaluation import evaluate_stable

WORK = ROOT / "new_runs/officehome/stage2_eval64"


def state(stage, completed, **kw):
    path = ROOT / "evidence/E5_officehome_stage2_progress.json"
    tmp = path.with_suffix(".tmp")
    write(tmp, dict(stage=stage, completed=completed, total=40, pid=os.getpid(),
        updated_utc=datetime.now(timezone.utc).isoformat(), **kw))
    tmp.replace(path)


def verify_spec():
    spec_path = ROOT / "prespec/E5_officehome_stage2.json"
    spec = read(spec_path)
    assert sha(spec_path) == read(ROOT / "prespec/E5_officehome_stage2_seal.json")["sha256"]
    assert sha(Path(spec["manifest"])) == spec["manifest_sha256"]
    assert sha(Path(spec["command_template"])) == spec["command_template_sha256"]
    for path, digest in spec["code_hashes"].items():
        assert sha(Path(path)) == digest, path
    assert sha(ROOT / "evidence/R5_authorization_20261119.json") == spec["authorization_sha256"]
    assert read(ROOT / "evidence/R5_authorization_20261119.json")["officehome_seed1_seed2"]
    plan = read(Path(spec["manifest"]))
    selected = [u for u in plan["units"] if u["unit_id"] in spec["unit_ids"]]
    assert len(selected) == 40 and {u["seed"] for u in selected} == {1,2}
    assert set(spec["unit_ids"]) == set(plan["stage2"])
    fixtures = []
    for u in selected:
        known = set(u["known"]); vu = set(u["validation_unknown"]); tu = set(u["target_unknown"])
        assert len(known) == 35 and len(vu) == 15 and len(tu) == 15
        assert not known & vu and not known & tu and not vu & tu
        role = u["roles"]
        assert len(role["train"]) == 700 and len(role["val_known"]) == 350 and len(role["val_unknown"]) == 150
        for domain in plan["domains"]:
            for names in [u["known"],u["validation_unknown"],u["target_unknown"]]:
                got = selected_rows(u,domain,names)
                expected_roles = ["test"] if domain == u["target"] else ["val_known","val_unknown"] if domain == u["val"] else ["train"]
                expected = [(r["path"],r["category"]) for rname in expected_roles for r in role[rname] if r["domain"] == domain and r["category"] in names]
                assert got == expected
        fixtures.append(dict(unit=u["unit_id"],seed=u["seed"],literal_sampler_matches=True))
    write(ROOT / "evidence/E5_sampler_fixture_checks.json", dict(passed=True,units=fixtures,
        prespec_sha256=sha(spec_path), no_training=True,no_encoder_inference=True))
    return spec, plan


def main():
    spec, plan = verify_spec()
    if "--prepare-only" in sys.argv:
        print("Stage2 sealed: all40 original v3 units, literal sampler checks passed; no GPU used.")
        return
    WORK.mkdir(parents=True, exist_ok=True)
    lock = R2 / "new_runs/GPU_QUEUE.lock"
    with lock.open("x") as f:
        f.write(str(os.getpid()))
    timings = []
    completed = 0
    try:
        for uid in spec["unit_ids"]:
            if any((root / "new_runs/PAUSE_REQUESTED").exists() for root in [ROOT,R2]):
                state("paused_at_unit_boundary", completed, next_unit=uid)
                return
            u = next(x for x in plan["units"] if x["unit_id"] == uid)
            run = WORK / uid; timing = WORK / (uid + "_timing.json")
            if timing.exists():
                result = read(timing)
                assert result["stage2_spec_sha256"] == sha(ROOT / "prespec/E5_officehome_stage2.json")
                for name,digest in read(run / "artifact_hashes.json").items():
                    assert sha(run / name) == digest
                assert sha(WORK / (uid+"_stable_evaluation") / "results.json") == result["stable_results_sha256"]
            else:
                if run.exists():
                    raise RuntimeError("Partial unit requires inspection; no automatic overwrite/retry: " + uid)
                for rows in u["roles"].values():
                    for row in rows:
                        path = Path(plan["data_root"]) / row["path"]
                        assert path.is_file() and sha(path) == row["sha256"], path
                command = list(read(Path(spec["command_template"]))["command"])
                command[0] = sys.executable
                command[4] = str(ROOT / "scripts/r5_officehome_train_stage2.py")
                replacements = {"--seed":str(u["seed"]),"--data_root":plan["data_root"],"--target_domain":u["target"],"--val_domain":u["val"],
                    "--unknown_classes":",".join(u["validation_unknown"]+u["target_unknown"]),
                    "--calibration_unknown_classes":",".join(u["validation_unknown"]),"--target_unknown_classes":",".join(u["target_unknown"])}
                for flag,value in replacements.items():
                    command[command.index(flag)+1] = value
                write(WORK / (uid+"_launch.json"),dict(unit=uid,command=command,stage2_spec_sha256=sha(ROOT / "prespec/E5_officehome_stage2.json")),exclusive=True)
                state("training",completed,current=uid)
                start=time.perf_counter()
                with (WORK/(uid+".log")).open("x",encoding="utf-8") as f:
                    subprocess.run(command,cwd=WORK,env=dict(os.environ,PAPER2_RUN_DIR=str(run),OFFICEHOME_UNIT_ID=uid,PYTHONDONTWRITEBYTECODE="1"),stdout=f,stderr=subprocess.STDOUT,check=True)
                wall=time.perf_counter()-start;start=time.perf_counter()
                verify_samples(run,u,plan["data_root"]);verify_exact_labels(run,u)
                for name,digest in read(run/"artifact_hashes.json").items():
                    assert sha(run/name)==digest
                evaluation=WORK/(uid+"_stable_evaluation")
                results=evaluate_stable(run,evaluation)
                write(evaluation/"stage2_execution_link.json",dict(stage2_spec_sha256=sha(ROOT/"prespec/E5_officehome_stage2.json"),
                    manifest_sha256=spec["manifest_sha256"],parent_scoring_spec_sha256=spec["parent_scoring_spec_sha256"]),exclusive=True)
                post=time.perf_counter()-start
                result=dict(unit=uid,seed=u["seed"],epochs=len((run/"epochs.jsonl").read_text().splitlines()),
                    training_and_primary_evaluation_seconds=wall,additional_postprocessing_seconds=post,
                    measured_unit_pipeline_seconds=wall+post,results=results,
                    stage2_spec_sha256=sha(ROOT/"prespec/E5_officehome_stage2.json"),stable_results_sha256=sha(evaluation/"results.json"),
                    sample_counts={k:len(v) for k,v in u["roles"].items()},unique_content_counts={k:len({r["sha256"] for r in v}) for k,v in u["roles"].items()})
                write(timing,result,exclusive=True)
            timings.append(result);completed+=1
            state("unit_complete",completed,current=uid)
            print("OfficeHome stage2 " + str(completed)+"/40 "+uid,flush=True)
        assert len(timings)==40 and len({r["unit"] for r in timings})==40
        records=[dict(unit=r["unit"],seed=r["seed"],**m) for r in timings for m in r["results"]]
        write(ROOT/"evidence/E5_officehome_stage2_results.json",dict(records=records,timings=timings,
            stage2_spec_sha256=sha(ROOT/"prespec/E5_officehome_stage2.json"),all_variants_retained=True,
            independent_cpu_audit_pending=True,no_IID_inference=True,not_pooled_with_primary=True),exclusive=True)
        state("training_complete_requires_independent_audit",40)
    except Exception as exc:
        state("failed_requires_inspection",completed,error=repr(exc))
        raise
    finally:
        assert lock.read_text().strip()==str(os.getpid())
        lock.unlink()


if __name__=="__main__":
    main()
