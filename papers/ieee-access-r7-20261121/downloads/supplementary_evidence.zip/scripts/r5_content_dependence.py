"""Remove target-content reuse in a fixed-model sensitivity, not an IID trial."""
from sklearn.metrics import roc_auc_score
from gap_closure_core import *


def main():
    inventories = {d: identities(d) for d in ["pacs", "cifar10", "officehome"]}
    entries, overlap = [], []
    eligibility = defaultdict(set)
    for model, ds, unit, directory, old in units():
        lookup = inventories[ds]
        hashes = {r: sample_hashes(directory, r + "_samples.json", lookup) for r in ["train", "val_known", "val_unknown", "test"]}
        test = set(hashes["test"]); train = set(hashes["train"])
        val = set(hashes["val_known"] + hashes["val_unknown"])
        overlap.append(dict(**tag(model, ds, unit), train_files=len(hashes["train"]), test_files=len(hashes["test"]),
            train_unique=len(train), test_unique=len(test), test_train_shared_hashes=len(test & train),
            test_validation_shared_hashes=len(test & val), training_validation_shared_hashes=len(train & val)))
        samples = read(directory / "test_samples.json")
        byhash = defaultdict(list)
        for i, h in enumerate(hashes["test"]):
            byhash[h].append(i)
        assert all(len({samples[i]["label"] for i in ids}) == 1 for ids in byhash.values()), (ds, unit, "conflicting labels within a content group")
        cluster = unit.rsplit("_seed", 1)[0]
        excluded = train | val
        for h in byhash:
            if h not in excluded:
                eligibility[(model, ds, h)].add(cluster)
        entries.append((model, ds, unit, directory, cluster, hashes["test"], samples, excluded))
    owners = {}
    for key, candidates in eligibility.items():
        model, ds, h = key
        owners[key] = min(candidates, key=lambda c: hashlib.sha256(("R5-owner-v1|"+model+"|"+ds+"|"+h+"|"+c).encode("utf-8")).hexdigest())
    plan = [dict(model=m, dataset=d, content_sha256=h, owner_cluster=c) for (m,d,h),c in sorted(owners.items())]
    plan_path = ROOT / "evidence/E3_content_ownership.json"
    write(plan_path, dict(rule="Fixed hash priority over eligible clusters; no scores/target metrics used. Seeds share the assigned subset, and are averaged rather than treated as independent.", records=plan))
    rows, counts = [], []
    used_clusters = defaultdict(dict)
    for model, ds, unit, directory, cluster, hashes, samples, excluded in entries:
        kept = []
        seen = set()
        for i in sorted(range(len(samples)), key=lambda j: samples[j]["path"].replace("\\", "/")):
            h = hashes[i]
            if h not in seen and h not in excluded and owners[(model, ds, h)] == cluster:
                kept.append(i); seen.add(h)
        ids = np.array(kept, dtype=int)
        with np.load(cache_path(model, ds, unit), allow_pickle=False) as z:
            a = {k:z[k] for k in z.files}
        y = a["target_labels"][ids] < 0
        assert y.sum() >= 5 and (~y).sum() >= 5, (model, ds, unit, "insufficient prespecified minimum per ROC class")
        for h in seen:
            old_owner = used_clusters[(model, ds)].setdefault(h, cluster)
            assert old_owner == cluster
        counts.append(dict(**tag(model, ds, unit), cluster=cluster, retained_unique=len(ids),
            retained_known=int((~y).sum()), retained_unknown=int(y.sum()), full_test_files=len(samples)))
        for method in ["MSP", "Temp-MSP", "autoMixTemp"]:
            st = a[method][ids]; vy=a["validation_labels"]
            threshold = fpr_at_recall(a[method+"_validation"], vy)["threshold"]
            reject=st >= threshold
            rows.append(dict(**tag(model, ds, unit), cluster=cluster, method=method,
                auroc=float(roc_auc_score(y, st)), fpr95=fpr_at_recall(st, y)["fpr95"],
                recall=float(reject[y].mean()), rejection=float(reject[~y].mean())))
    clusters = grouped_means(rows, ["model", "dataset", "cluster", "method"], ["auroc", "fpr95", "recall", "rejection"])
    summary = grouped_means(clusters, ["model", "dataset", "method"], ["auroc", "fpr95", "recall", "rejection"])
    paired = []
    for auto in [r for r in clusters if r["method"] == "autoMixTemp"]:
        for comparator in ["MSP", "Temp-MSP"]:
            ref = next(r for r in clusters if (r["model"],r["dataset"],r["cluster"],r["method"]) == (auto["model"],auto["dataset"],auto["cluster"],comparator))
            paired.append({k:auto[k] for k in ["model","dataset","cluster"]} | dict(comparator=comparator,
                delta_auroc=auto["auroc"]-ref["auroc"], delta_fpr95=auto["fpr95"]-ref["fpr95"]))
    save("E3_content_dependence", dict(role_overlap=overlap, subset_counts=counts, records=rows, cluster_records=clusters,
        summary=summary, paired_cluster_records=paired,
        paired_summary=grouped_means(paired,["model","dataset","comparator"],["delta_auroc","delta_fpr95"]),
        assignment_sha256=sha(plan_path), no_target_content_shared_between_clusters=True,
        residual="Training and validation contents and fitted models still overlap. This changes the evaluation subset/estimand and is only a fixed-fit sensitivity, not independent pipeline replication or a population CI. It cannot be used to select the main results.",
        original_mean_results_preserved=True))


if __name__ == "__main__":
    main()
