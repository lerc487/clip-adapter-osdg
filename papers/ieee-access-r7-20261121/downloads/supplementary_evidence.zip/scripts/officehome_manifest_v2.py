"""Apply the authorized cross-domain exclusion in a new immutable manifest."""
from collections import Counter,defaultdict
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import time

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/"new_runs/officehome";NEW=OLD/"dedup_v2"


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
    return h.hexdigest()
def write_new(p,obj):
    with p.open("x",encoding="utf-8") as f:json.dump(obj,f,indent=2,allow_nan=False,ensure_ascii=False)
def seal(task,obj):
    p=ROOT/"prespec"/(task+".json");write_new(p,obj)
    write_new(ROOT/"prespec"/(task+"_seal.json"),dict(task=task,sha256=sha(p),sealed_utc=datetime.now(timezone.utc).isoformat()))
    return sha(p)
def state(stage,**kw):
    p=ROOT/"evidence/C1_manifest_v2_progress.json";tmp=p.with_suffix(".tmp")
    tmp.write_text(json.dumps(dict(stage=stage,updated=time.strftime("%Y-%m-%dT%H:%M:%S"),**kw),indent=2),encoding="utf-8");tmp.replace(p)


def collisions(left,right):
    a=defaultdict(list);b=defaultdict(list)
    for row in left:a[row["sha256"]].append(row["path"])
    for row in right:b[row["sha256"]].append(row["path"])
    return [dict(sha256=h,left=a[h],right=b[h]) for h in sorted(a.keys()&b.keys())]


def main():
    NEW.mkdir(parents=True,exist_ok=True)
    original=read(OLD/"integrity_check.json");audit=read(ROOT/"evidence/C1_duplicate_audit.json")
    data=Path(original["data_root"]);files=original["files"]
    assert sha(OLD/"integrity_check.json")==audit["source_sha256"]
    groups=[g for g in audit["groups"] if g["cross_domain"]]
    excluded_hashes={g["sha256"] for g in groups}
    excluded_paths={r["path"] for g in groups for r in g["images"]}
    assert len(groups)==9 and len(excluded_paths)==21
    protected=[ROOT/"prespec"/(name+".json") for name in ["C1_stages","C1_acceptance","C1_pilot","authorized_queue"]]
    protected += [ROOT/"prespec"/(name+"_seal.json") for name in ["C1_stages","C1_acceptance","C1_pilot","authorized_queue"]]
    protected += [ROOT/"scripts"/name for name in ["officehome_accept.py","officehome_train.py","officehome_pilot.py","follow_authorized_stages.py"]]
    protected += [OLD/"integrity_check.json",OLD/"cross_role_duplicate_error.json"]
    before={str(p.relative_to(ROOT)).replace("\\","/"):sha(p) for p in protected}
    authorization=ROOT/"evidence/C1_dedup_v2_authorization.json"
    write_new(authorization,dict(source="Explicit user reply in this conversation on2026-11-19 Asia/Shanghai",
        answer="同意排除跨域重复组，重建并封存新版本清单",scope="Exclude all members of the9cross-domain exact-byte duplicate groups,21paths, in a new manifest only. Keep disk files and all previous specifications unchanged.",
        other_exclusions_authorized=False,new_stage1_remaining18_authorized=False,new_stage2_authorized=False))
    design=dict(task="C1_dedup_v2",created_utc=datetime.now(timezone.utc).isoformat(),
        authorization_sha256=sha(authorization),parent_stage_design_sha256=sha(ROOT/"prespec/C1_stages.json"),
        original_inventory_sha256=sha(OLD/"integrity_check.json"),duplicate_audit_sha256=sha(ROOT/"evidence/C1_duplicate_audit.json"),
        excluded_hashes=sorted(excluded_hashes),excluded_paths=sorted(excluded_paths),
        rule="Remove these21paths from new manifests only. No disk deletion, no other duplicate removal. Verify every original image SHA256 still matches the all-image inventory; original decoding results thus remain applicable.",
        role_rule="Keep original casefold/name ordering, four sorted domains, cyclic next-domain validation, class step13, five rotations; first35known,next15validation-unknown,remaining15target-unknown; SHA256(seed|relativepath) selection10perclass per source/validation domain; target all retained samples of its roles. Freeze seed0/1/2 assignments before any model inference, execute only the two authorized seed0 pilots later.",
        checks="Every domain/category must retain at least10images. Verify path and content separation across train/validation/test. Additionally report exact-byte known-versus-unknown collisions within validation and test, and within-role duplicate counts; do not remove additional images. Block GPU activation if known/unknown label collisions remain, pending user decision.",
        outcomes="Input-metadata audit only; no Office-Home training, scoring or target performance inspected. Protocol amended for input integrity before any Office-Home result. Stage expansion remains time/resource-based, never outcome-based.",
        frozen_script_sha256=sha(Path(__file__)),protected_previous_hashes=before)
    design_hash=seal("C1_dedup_v2",design)
    state("verifying_unchanged_original_images",total=len(files));started=time.perf_counter()
    for i,row in enumerate(files):
        assert sha(data/row["path"])==row["sha256"],row["path"]
        if (i+1)%1000==0:state("verifying_unchanged_original_images",completed=i+1,total=len(files))
    raw_unchanged_seconds=time.perf_counter()-started
    retained=[r for r in files if r["sha256"] not in excluded_hashes]
    assert len(files)-len(retained)==21
    assert {r["path"] for r in files if r["sha256"] in excluded_hashes}==excluded_paths
    domains=sorted({r["domain"] for r in retained},key=lambda s:(s.casefold(),s))
    classes=sorted({r["category"] for r in retained},key=lambda s:(s.casefold(),s))
    assert len(domains)==4 and len(classes)==65
    byclass=defaultdict(list)
    for r in retained:byclass[(r["domain"],r["category"])].append(r)
    assert len(byclass)==260 and min(len(v) for v in byclass.values())>=10
    write_new(NEW/"exclusion_manifest.json",dict(protocol_version="C1_dedup_v2",groups=groups,paths=sorted(excluded_paths),raw_data_changed=False))
    write_new(NEW/"filtered_inventory.json",dict(protocol_version="C1_dedup_v2",data_root=str(data),files=retained,
        raw_inventory_sha256=sha(OLD/"integrity_check.json"),design_sha256=design_hash))
    units=[];label_conflicts=[];checks=[]
    state("building_and_auditing_literal_role_manifests",retained_images=len(retained))
    for rotation in range(5):
        shifted=[classes[(j+13*rotation)%65] for j in range(65)]
        known,vu,tu=shifted[:35],shifted[35:50],shifted[50:]
        assert set(known).isdisjoint(vu) and set(known).isdisjoint(tu) and set(vu).isdisjoint(tu)
        for i,target in enumerate(domains):
            val=domains[(i+1)%4];sources=[d for d in domains if d not in [target,val]]
            for seed in [0,1,2]:
                def take(domain,names,sampled):
                    rows=[]
                    for name in names:
                        entries=byclass[(domain,name)]
                        if sampled:chosen=sorted(entries,key=lambda r:(hashlib.sha256((str(seed)+"|"+r["path"]).encode()).hexdigest(),r["path"]))[:10]
                        else:chosen=sorted(entries,key=lambda r:r["path"])
                        rows += chosen
                    return rows
                train=[r for d in sources for r in take(d,known,True)]
                vk=take(val,known,True);uv=take(val,vu,True)
                tk=take(target,known,False);ut=take(target,tu,False)
                uid=f"{target}_rotation{rotation:02d}_seed{seed}"
                assert len(train)==700 and len(vk)==350 and len(uv)==150
                role_rows=dict(train=train,val_known=vk,val_unknown=uv,test=tk+ut)
                primary=[("train",train),("validation",vk+uv),("test",tk+ut)]
                for ai,(aname,arows) in enumerate(primary):
                    for bname,brows in primary[ai+1:]:assert not collisions(arows,brows),(uid,aname,bname)
                for split,left,right in [("validation",vk,uv),("test",tk,ut)]:
                    conflict=collisions(left,right)
                    if conflict:label_conflicts.append(dict(unit=uid,target=target,rotation=rotation,seed=seed,split=split,groups=conflict))
                checks.append(dict(unit=uid,major_role_content_overlap=0,known_unknown_label_overlap_groups={
                    "validation":len(collisions(vk,uv)),"test":len(collisions(tk,ut))},
                    row_counts={k:len(v) for k,v in role_rows.items()},unique_content_counts={k:len({r["sha256"] for r in v}) for k,v in role_rows.items()}))
                units.append(dict(unit_id=uid,target=target,val=val,seed=seed,rotation=rotation,known=known,validation_unknown=vu,target_unknown=tu,roles=role_rows))
    pilot=[u["unit_id"] for u in units if u["rotation"]==0 and u["seed"]==0][:2]
    eligible=not label_conflicts
    manifest=dict(protocol_version="C1_dedup_v2",data_root=str(data),domains=domains,classes=classes,rotation_step=13,units=units,pilot=pilot,
        stage1=[u["unit_id"] for u in units if u["seed"]==0],stage2=[u["unit_id"] for u in units if u["seed"] in [1,2]],
        stage1_requires_measured_pilot_and_user_decision=True,stage2_requires_later_user_decision=True,
        training_eligible=eligible,exclusion_manifest_sha256=sha(NEW/"exclusion_manifest.json"),design_sha256=design_hash,
        frozen_before_any_officehome_inference=True)
    write_new(NEW/"roles_manifest.json",manifest)
    literal=dict(task="C1_roles_manifest_v2",manifest="new_runs/officehome/dedup_v2/roles_manifest.json",manifest_sha256=sha(NEW/"roles_manifest.json"),
        design_sha256=design_hash,domains=domains,classes=classes,pilot=pilot,training_eligible=eligible)
    literal_hash=seal("C1_roles_manifest_v2",literal)
    remaining_groups=[g for g in read(ROOT/"evidence/C1_duplicate_audit.json")["groups"] if g["sha256"] not in excluded_hashes]
    count_cross_category=sum(not g["category_agreement"] for g in remaining_groups)
    involved={r["sha256"] for row in label_conflicts for r in row["groups"]}
    pilot_conflicts=[r for r in label_conflicts if r["unit"] in pilot]
    summary=dict(task="C1_dedup_v2",design_sha256=design_hash,literal_roles_spec_sha256=literal_hash,roles_manifest_sha256=literal["manifest_sha256"],
        original_images=len(files),excluded_images=len(excluded_paths),excluded_cross_domain_groups=len(groups),retained_images=len(retained),
        domain_counts=dict(sorted(Counter(r["domain"] for r in retained).items())),classes=len(classes),
        minimum_images_per_domain_category=min(len(v) for v in byclass.values()),original_image_files_verified_unchanged=len(files),
        raw_hash_recheck_seconds=raw_unchanged_seconds,original_data_modified=False,previous_specifications_unchanged=all(sha(ROOT/p)==h for p,h in before.items()),
        planned_stage1_units=len(manifest["stage1"]),planned_stage2_units=len(manifest["stage2"]),planned_units_are_not_completed_runs=True,
        training_eligible=eligible,no_officehome_model_results=True,remaining_intra_domain_cross_category_duplicate_groups=count_cross_category,
        known_unknown_conflicting_hash_groups_across_planned_units=len(involved),unit_split_label_conflict_records=len(label_conflicts),
        affected_pilot_ids=sorted({r["unit"] for r in pilot_conflicts}),pilot=pilot,per_unit_checks=checks,label_conflicts=label_conflicts,
        all_remaining_duplicate_groups=remaining_groups)
    write_new(ROOT/"evidence/C1_dedup_v2.json",summary)
    if not eligible:
        # This is an input-label conflict, not a reason to alter the approved exclusion.
        state("frozen_but_label_conflicts_require_user_decision",training_eligible=False,excluded_images=len(excluded_paths),retained_images=len(retained),
            conflicting_hash_groups=len(involved),affected_pilot_ids=summary["affected_pilot_ids"],no_additional_images_excluded=True)
    else:state("accepted_waiting_C3b_then_two_unit_pilot_v2",training_eligible=True,retained_images=len(retained))
    lines=["# Office Home 新版清单排除与封存报告","","## 1 做了什么",
        "按用户授权，仅从新版清单排除所有跨域完全重复组的成员；磁盘原图、ZIP、旧预设及旧失败记录保留。全量重新核对原图 SHA256 后，使用原排序、轮换和确定性采样规则生成并封存新版角色表。没有运行 Office-Home 模型。","","## 2 文件位置",
        "new_runs/officehome/dedup_v2/exclusion_manifest.json、filtered_inventory.json、roles_manifest.json；prespec/C1_dedup_v2.json、C1_roles_manifest_v2.json 及对应 seal。","","## 3 数字与 JSON 来源",
        "以下均来自 evidence/C1_dedup_v2.json。","","| 项目 | 数量 |","| --- | ---: |",
        f"| 原始图像 | {summary['original_images']} |",f"| 授权排除的跨域重复组 | {len(groups)} |",f"| 仅在清单中排除的图像 | {len(excluded_paths)} |",
        f"| 新版保留图像 | {len(retained)} |",f"| 类别 | {len(classes)} |",f"| 单域单类最少图像 | {summary['minimum_images_per_domain_category']} |",
        f"| 重新核对且未变动的原始图像 | {len(files)} |",f"| 剩余域内跨类别完全重复组 | {count_cross_category} |",
        f"| 跨已知/未知标签边界的不同图像哈希组 | {len(involved)} |","","所有预设运行均无训练/验证/测试大角色间的相同字节图像；但域内不同类别可共享同一图像。完整逐运行检查与冲突路径均在 JSON，未按有利结果选行。",
        "","## 4 对结论的影响"]
    if not eligible:
        lines += ["新版解决了已授权的跨域重复，但完整角色复核发现域内跨类别重复：同一图像在部分运行中同时有已知和未知标签。确定性评分无法把完全相同的输入按相反标签区分。受影响的两个计时试点为："+"、".join(summary["affected_pilot_ids"])+"。因此新版已封存但尚不启用 GPU；不会把它写成无标签冲突的独立验证。",
            "","## 5 需要用户决定的事","本轮未删除额外图像，也未修改已授权21张的范围。建议再对跨类别完全重复组作明确清单级规则决策，新增协议版本并封存，之后才恢复试点。Office-Home 及 NegLabel 顺序接续仍保持停止；C3b 继续。"]
    else:lines += ["新版通过图像角色和已知/未知标签检查，可在 C3b 后运行两个计时试点。","","## 5 需要用户决定的事","两个已授权试点完成后汇报实测耗时，再决定剩余18单元。不得依据试点结果方向改变阶段。"]
    (ROOT/"reports/C1_新版清单排除与封存报告.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps({k:v for k,v in summary.items() if k not in ["per_unit_checks","label_conflicts","all_remaining_duplicate_groups"]},indent=2,ensure_ascii=False))


if __name__=="__main__":main()
