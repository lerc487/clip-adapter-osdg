"""Freeze the complete-panel audit before reading uncompleted Office-Home results."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent;PREV=BASE/"revision3_20261119";RUNS=BASE/"revision2_20261118"

def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for block in iter(lambda:f.read(1024*1024),b""):h.update(block)
    return h.hexdigest()
def read(path):return json.loads(path.read_text(encoding="utf-8-sig"))
def new(path,value):
    with path.open("x",encoding="utf-8") as f:json.dump(value,f,indent=2,allow_nan=False)

def main():
    for name in ["scripts","source","prespec","evidence","logs","reports","deliverables"]:(ROOT/name).mkdir(parents=True,exist_ok=True)
    if (ROOT/"prespec/C1_complete_panel_integration.json").exists():raise RuntimeError("Already initialized; never refreeze an observed result")
    protected=[dict(path=str(p),sha256=sha(p)) for folder in ["source","deliverables"] for p in sorted((PREV/folder).rglob("*")) if p.is_file()]
    frozen=RUNS/"prespec/C1_stage1_v3_eval64.json"
    plan=read(frozen)
    progress=read(RUNS/"evidence/C1_stage1_v3_progress.json")
    assert progress["completed"]<20,"Freeze must precede inspection of a complete stage1 result"
    decisions=[
        ("R1.1","partial","B1 does not establish a consistent validation-identifiable need for interior mixing; optional audit reframing, not proof of necessity."),
        ("R1.2","technical_response_completed","Require verified primary disjoint PACS/CIFAR and all20OfficeHome units, plus RN50; disclose fixed/few-shot budgets and OfficeHome seed0 only."),
        ("R1.3","partial","Conditional image/cluster/joint analyses address dependence but do not produce independent refits or population uncertainty."),
        ("R1.4","partial","Recall/rejection tradeoff is quantified; no general95percent target recall at reduced rejection is established."),
        ("R1.5","technical_response_completed","History scan empty; symmetric prose ratio<=0.85; abstract<=200; terminology and non-redundant scope statement checked."),
        ("R2.1","partial","Operations are established and extra source-search necessity is not proven; contribution is empirical audit, not a novel universal detector."),
        ("R2.2","technical_response_completed","ECE15/NLL/Brier and known-NLL temperature control reported, including deterioration."),
        ("R2.3","technical_response_completed","Frozen manifests verify disjoint known, validation-unknown and target-unknown categories; no CLIP pretraining exclusion claim."),
        ("R2.4","technical_response_completed","Reference/expanded/dense grids, upper-bound counts and large-temperature limit/rank diagnostics retained, without a temperature-stability guarantee."),
        ("R2.5","partial","Conservative validation thresholds explored with both target recall and known rejection, but requested joint high-recall/low-rejection benefit is not guaranteed."),
        ("R2.6","technical_response_completed","Additional CIFAR and complete OfficeHome data panels independently checked; disclose that custom class-role protocols are not a full standardized OOD suite."),
        ("R2.7","technical_response_completed","Numerical saturation traces and descriptive domain/role/confidence/difficulty diagnostics added; no causal explanation claimed."),
        ("R2.8","partial","Clusters still share images, fits and validation decisions remain fixed; external data broaden evidence but are not independent population sampling."),
        ("R3.1","technical_response_completed","Same strict unknown-category exclusion verification as R2.3."),
        ("R3.2","technical_response_completed","Reliability, accepted-known accuracy, unknown contamination, risk-coverage and AURC reported with fixed classifier."),
        ("R3.3","technical_response_completed","Original DeepLab and EfficientNet architecture papers cited; no unrelated suggested application DOIs or unrun model results."),
        ("R3.4","partial","MCM/NegLabel, RN50 and all28PACS full20 selector controls complete; LoCoOp and ViT-B16 not run; shared training loss/budget is not full independent detector optimization.")]
    spec=dict(task="C1_complete_panel_integration",created_utc=datetime.now(timezone.utc).isoformat(),
        previous_root=str(PREV),experiment_root=str(RUNS),progress_at_freeze=progress,
        stage1_spec_sha256=sha(frozen),stage1_seal_sha256=sha(RUNS/"prespec/C1_stage1_v3_eval64_seal.json"),
        roles_manifest_sha256=plan["roles_manifest_sha256"],expected_units=plan["unit_ids"],expected_methods=plan["methods"],
        audit="Wait for all20seed0units and final parent JSON; freeze final input digests before recomputation. Check every raw archive hash, sample role against frozen v3manifest and exact class/hash role separation; do not change raw images/models/logits/scores. Recompute stable float64 scores and validation selection for all7methods, target AUROC and empirical threshold FPR, known/OSR accuracy and frozen validation95 recall/rejection. Compare saved choices and score arrays and all140records; equal-unit/domain summaries and paired differences, counts, source choices and timings. No IID intervals, target tuning or new fits.",
        independent_numeric_check="Use logaddexp.reduce for log-sum-exp, sklearn ROC thresholds and every complete tie group with >= threshold. Validate all7 saved scores and fresh validation-only choice enumeration; max score error1e-10, metric error1e-12. Reuse sealed original maxF1 convention for OSR, not a new target-fitted threshold.",
        result_policy="Keep all methods/domains/rotations irrespective of direction; separate OfficeHome budget and seed0 status from PACS/CIFAR. Include complete aggregate and per-domain tables plus per-unit raw JSON/CSV. Do not infer mixing benefits, universal improvement, population independence or deployment guarantees.",
        publication="Update protocol, results, captions, abstract, limitations, conclusion,17template responses and a Chinese17-item evidence/status matrix. Build clean/highlighted PDFs against the actual submitted baseline and source/evidence ZIPs. Author approval and editorial acceptance remain unresolved even after authorized evidence is complete.",
        assessment_definitions=dict(technical_response_completed="The requested technical supplement has been provided and checked, not a claim that the reviewer accepts it or that the scientific limitation vanished.",partial="Evidence and an explicit scope limitation are provided, but the original desired capability or comparison is not fully delivered."),
        review_assessment_rules=[dict(id=i,status=s,reason=r) for i,s,r in decisions],
        retrospective_context="Primary, C3b, NegLabel and two OfficeHome timing pilot outcomes have been inspected. Remaining stage1 outcome directions are not used to choose scope/configurations. This is verification/document integration, not a prospective new detector claim.",
        no_new_training=True,no_stage2_authorization=True,no_target_retuning=True)
    path=ROOT/"prespec/C1_complete_panel_integration.json";new(path,spec)
    new(ROOT/"prespec/C1_complete_panel_integration_seal.json",dict(task=spec["task"],sha256=sha(path)))
    shutil.copytree(PREV/"source",ROOT/"source",dirs_exist_ok=True)
    for folder in ["scripts","prespec","evidence","reports"]:
        for p in (PREV/folder).iterdir():
            if p.is_file() and p.suffix in [".py",".json",".csv",".npz",".md"]:shutil.copy2(p,ROOT/folder/p.name)
    for p in (RUNS/"prespec").glob("C1*.json"):
        if not (ROOT/"prespec"/p.name).exists():shutil.copy2(p,ROOT/"prespec"/p.name)
    shutil.copy2(PREV/"logs/artifact.md",ROOT/"logs/artifact.md")
    new(ROOT/"evidence/officehome_integration_input_manifest.json",dict(previous_source_and_deliverables=protected))
    new(ROOT/"STATUS.json",dict(state="waiting_for_full_OfficeHome_stage1",upload_ready=False,authorized_experiment_evidence_complete=False,
        live_progress_file=str(RUNS/"evidence/C1_stage1_v3_progress.json"),stage2_not_authorized=True))
    print("Complete-panel audit and17-item assessment criteria sealed before full OfficeHome results; previous version preserved.")

if __name__=="__main__":main()
