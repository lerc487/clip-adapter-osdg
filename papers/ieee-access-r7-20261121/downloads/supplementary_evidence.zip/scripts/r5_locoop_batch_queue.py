"""Finite serial queue for the64 newly authorized official LoCoOp fits."""
import os
from pathlib import Path
import subprocess
import sys
import time

from r5_locoop_batch_common import ROOT, R2, SPEC, INPUTS, METHODS, sealed, read, write, sha, now, pause_requested, available_disk
from r5_locoop_batch_audit import audit_unit


def state(stage, done, **extra):
    write(ROOT / "evidence/E6_locoop_batch_progress.json", dict(stage=stage, completed_new=done, total_new=64,
        reused_pilots=2, total_fits=66, completed_fits=done + 2, pid=os.getpid(), updated_utc=now(), **extra))


def main():
    spec = sealed()
    assert read(ROOT / "evidence/E6_locoop_batch_authorization_20261120.json")["new_fits_authorized"] == 64
    assert read(ROOT / "evidence/E6_locoop_batch_fixtures.json")["all_checks_pass"]
    assert available_disk() >= spec["minimum_free_bytes"]
    assert len(spec["jobs"]) == 66 and sum(not r["reused_pilot"] for r in spec["jobs"]) == 64
    lock = R2 / "new_runs/GPU_QUEUE.lock"
    done = 0
    records = []
    audit_root = ROOT / "evidence/E6_locoop_batch_unit_audits"
    audit_root.mkdir(exist_ok=True)
    launch = time.time_ns()
    with lock.open("x") as f:
        f.write(str(os.getpid()))
    completed = False
    try:
        for job in spec["jobs"]:
            if pause_requested():
                state("paused_at_unit_boundary", done, next_fit=job["fit_id"])
                return
            output = Path(job["output"])
            result_path = output / "results.json"
            if not job["reused_pilot"]:
                if output.exists() and not result_path.is_file():
                    raise RuntimeError("Partial batch fit requires inspection, no automatic retry: " + job["fit_id"])
                if not output.exists():
                    assert available_disk() >= spec["minimum_free_bytes"]
                    state("official_prompt_training", done, current=job["fit_id"], lambda_value=job["lambda_value"], dataset=job["dataset"])
                    log = ROOT / "logs" / ("E6_batch_" + str(launch) + "_" + job["fit_id"].replace("/", "__") + ".log")
                    command = [spec["interpreter"], "-B", "-s", "-u", str(ROOT / "scripts/r5_locoop_batch_unit.py"), "--fit-id", job["fit_id"]]
                    with log.open("x", encoding="utf-8") as f:
                        subprocess.run(command, cwd=ROOT,
                            env=dict(os.environ, CUDA_VISIBLE_DEVICES="0", R5_LOCOOP_BATCH_OWNER=str(os.getpid()), PYTHONDONTWRITEBYTECODE="1"),
                            stdout=f, stderr=subprocess.STDOUT, check=True)
            state("independent_cpu_unit_audit", done, current=job["fit_id"])
            audit = audit_unit(spec, job)
            audit_file = audit_root / (job["fit_id"].replace("/", "__") + ".json")
            if audit_file.exists():
                assert read(audit_file) == audit
            else:
                write(audit_file, audit, exclusive=True)
            records.append(dict(fit_id=job["fit_id"], dataset=job["dataset"], unit=job["unit"], lambda_value=job["lambda_value"],
                reused_pilot=job["reused_pilot"], output=str(output), result_sha256=sha(result_path),
                saved_arrays_sha256=audit["saved_arrays_sha256"], unit_audit_sha256=sha(audit_file)))
            if not job["reused_pilot"]:
                done += 1
            state("fit_complete_independently_audited", done, current=job["fit_id"])
        assert done == 64 and len(records) == 66
        destination = ROOT / "evidence/E6_locoop_batch_results.json"
        value = dict(records=records, new_fits=64, reused_pilots=2, total_fits=66, prespec_sha256=sha(SPEC),
            target_based_lambda_selection=False, lambda_panels_not_pooled=True, final_independent_audit_pending=True)
        if destination.exists():
            assert read(destination) == value
        else:
            write(destination, value, exclusive=True)
        state("training_complete_full_independent_audit_pending", done)
        completed = True
    except Exception as exc:
        state("failed_requires_inspection", done, error=repr(exc))
        raise
    finally:
        assert lock.read_text().strip() == str(os.getpid())
        lock.unlink()
    if completed:
        try:
            state("independent_cpu_full_panel_audit", done)
            if not (ROOT / "evidence/E6_locoop_batch_audit.json").exists():
                with (ROOT / "logs" / ("E6_batch_full_audit_" + str(launch) + ".log")).open("x", encoding="utf-8") as f:
                    subprocess.run([sys.executable, "-B", "-s", "-u", str(ROOT / "scripts/r5_locoop_batch_audit.py")],
                        cwd=ROOT, env=dict(os.environ, CUDA_VISIBLE_DEVICES="-1"), stdout=f, stderr=subprocess.STDOUT, check=True)
            assert read(ROOT / "evidence/E6_locoop_batch_audit.json")["all_checks_pass"]
            state("complete_independently_audited_manuscript_integration_pending", 64, upload_ready=False)
        except Exception as exc:
            state("failed_full_audit_requires_inspection", done, error=repr(exc))
            raise


if __name__ == "__main__":
    main()
