"""Stable score selection matching the frozen numerical-audit convention."""
import numpy as np
from scipy.special import logsumexp
from sklearn.metrics import roc_auc_score
from verified_metrics import fpr_at_recall


def score(logits, temperature, mode):
    x=np.asarray(logits,dtype=np.float64)/float(temperature)
    if mode=="energy":
        return -float(temperature)*logsumexp(x,axis=1)
    maximum=x.max(axis=1)
    x=x.copy();x[np.arange(len(x)),x.argmax(axis=1)]=-np.inf
    return logsumexp(x,axis=1)-maximum


def branch(z,a,selection):
    if selection["score_source"]=="adapter":return a
    if selection["score_source"]=="zeroshot":return z
    alpha=selection["alpha"]
    return alpha*np.asarray(a,dtype=np.float64)+(1-alpha)*np.asarray(z,dtype=np.float64)


def select(route,mode,temps,kz,ka,uz,ua,tune,mix_alpha,mix_alphas,objective):
    candidates=[("adapter",None)] if route=="auto" else [(route,mix_alpha if route=="mix" else None)]
    if route=="auto":candidates += [("zeroshot",None)]+[("mix",float(a)) for a in mix_alphas]
    y=np.r_[np.zeros(len(ka),dtype=int),np.ones(len(ua),dtype=int)]
    best=None
    for source,alpha in candidates:
        selection=dict(score_source=source,alpha=alpha)
        k=branch(kz,ka,selection);u=branch(uz,ua,selection)
        for t in (temps if tune else [1.]):
            values=np.r_[score(k,t,mode),score(u,t,mode)]
            auc=float(roc_auc_score(y,values));fpr=fpr_at_recall(values,y)["fpr95"]
            key=(fpr,-auc) if objective=="fpr95" else (-auc,fpr)
            if best is None or key<best[0]:
                best=(key,dict(**selection,T_score=float(t),val_fpr95=fpr,val_auroc=auc))
    return best[1]
