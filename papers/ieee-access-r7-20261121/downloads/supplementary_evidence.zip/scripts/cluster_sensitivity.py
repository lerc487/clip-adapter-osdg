"""Prespecified fixed-model cluster and shared-image conditional sensitivity."""
import json
from pathlib import Path
import sys
import time

import numpy as np

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent
sys.path.insert(0,str(ROOT/"scripts"))
from cache_analyses import read,sha,dump,panels
sys.path.insert(0,str(BASE/"tools"))
from image_resampling_sensitivity import prepared,weighted_metrics


def batch_metrics(item,weights):
    ids,y,ends=item
    w=weights[:,ids].astype(np.float64)
    tp=np.cumsum(w*y,axis=1)[:,ends]
    fp=np.cumsum(w*(1-y),axis=1)[:,ends]
    assert (tp[:,-1]>0).all() and (fp[:,-1]>0).all()
    prev_tp=np.c_[np.zeros(len(w)),tp[:,:-1]]
    delta_fp=np.diff(np.c_[np.zeros(len(w)),fp],axis=1)
    auc=(delta_fp*(tp+prev_tp)*.5).sum(1)/(tp[:,-1]*fp[:,-1])
    at=np.argmax(tp>=.95*tp[:,-1,None],axis=1)
    fpr=fp[np.arange(len(w)),at]/fp[:,-1]
    return np.c_[auc,fpr]


def fixtures():
    scores=np.array([.1,.4,.4,.8,.2,.8]);y=np.array([0,0,1,1,0,1]);ids=np.arange(6)
    item=prepared(scores,y,ids)
    w=np.array([[2,1,1,3,2,2],[1,1,2,1,3,1],[2,3,2,4,1,3]])
    np.testing.assert_allclose(batch_metrics(item,w),np.stack([weighted_metrics(item,a) for a in w]),atol=1e-14)


def main():
    spec=ROOT/"prespec/B6.json"
    assert sha(spec)==read(ROOT/"prespec/sealed_hashes.json")["B6"]
    fixtures()
    cluster_rows=[];summary=[];intervals=[];replicates={}
    for ds in ["pacs","cifar10"]:
        manifest=read(BASE/"02_historical/pacs_same_checkpoint_20260919/data_manifest.json") if ds=="pacs" else read(BASE/"05_new_runs/data/cifar10_manifest.json")
        norm=lambda p:p.replace("\\","/").removeprefix("CIFAR10_folders/")
        hashes={norm(r["path"]):r["sha256"] for r in manifest};hidx={h:i for i,h in enumerate(sorted(set(hashes.values())))}
        units=[];cache=[]
        for model,tag,unit,d,a,m in panels():
            if model!="ViT-B32" or tag!=ds:continue
            ids=np.array([hidx[hashes[norm(s["path"])]] for s in read(d/"test_samples.json")])
            with np.load(BASE/"04_analysis/stable_score_cache/primary"/ds/(unit+".npz"),allow_pickle=False) as z:
                cc={method:prepared(z[method],(a["ty"]<0).astype(int),ids) for method in ["MSP","Temp-MSP","autoMixTemp"]}
            units.append(unit);cache.append(cc)
        labels=[u.rsplit("_seed",1)[0] for u in units]
        clusters=sorted(set(labels));ci=[clusters.index(c) for c in labels]
        counts=np.bincount(ci);assert np.all(counts==3)
        # The fixture and observed calculation use the same exact-tie ROC rule.
        obs=np.stack([np.stack([weighted_metrics(cc[m],np.ones(len(hidx))) for m in ["MSP","Temp-MSP","autoMixTemp"]]) for cc in cache])
        diffs={"MSP":obs[:,2]-obs[:,0],"Temp-MSP":obs[:,2]-obs[:,1]}
        grouped={m:np.stack([v[np.array(ci)==i].mean(0) for i in range(len(clusters))]) for m,v in diffs.items()}
        for comparator,values in grouped.items():
            for i,c in enumerate(clusters):
                cluster_rows.append(dict(dataset=ds,cluster=c,seeds=int(counts[i]),comparator=comparator,
                    delta_auroc=float(values[i,0]),delta_fpr95=float(values[i,1])))
            for j,metric in enumerate(["delta_auroc","delta_fpr95"]):
                v=values[:,j];deleted=(v.sum()-v)/(len(v)-1)
                summary.append(dict(dataset=ds,comparator=comparator,metric=metric,clusters=len(v),mean=float(v.mean()),
                    lower=int((v<0).sum()),higher=int((v>0).sum()),tied=int((v==0).sum()),leave_one_out_min=float(deleted.min()),leave_one_out_max=float(deleted.max())))
        if ds=="cifar10":continue
        rng=np.random.default_rng(2026111806)
        weights=rng.multinomial(len(clusters),np.full(len(clusters),1/len(clusters)),size=10000)
        for comparator,values in grouped.items():
            replicates["cluster_"+comparator]=weights@values/len(clusters)
        rng=np.random.default_rng(2026111807);joint={m:[] for m in grouped};batch=32;started=time.perf_counter()
        for start in range(0,10000,batch):
            b=min(batch,10000-start)
            image_weights=rng.poisson(1,size=(b,len(hidx))).astype(np.uint16)
            cw=rng.multinomial(len(clusters),np.full(len(clusters),1/len(clusters)),size=b)
            selected=np.stack([np.stack([batch_metrics(cc[m],image_weights) for m in ["MSP","Temp-MSP","autoMixTemp"]],axis=1) for cc in cache],axis=1)
            for k,comparator in enumerate(["MSP","Temp-MSP"]):
                dd=selected[:,:,2]-selected[:,:,k]
                gg=np.stack([dd[:,np.array(ci)==i].mean(axis=1) for i in range(len(clusters))],axis=1)
                joint[comparator].append((gg*cw[:,:,None]).sum(axis=1)/len(clusters))
            if start%320==0:
                status=dict(completed_draws=start+b,total_draws=10000,elapsed_seconds=time.perf_counter()-started)
                (ROOT/"logs/B6_progress.json").write_text(json.dumps(status,indent=2),encoding="ascii")
                print("B6 joint "+str(start+b)+"/10000",flush=True)
        for comparator,blocks in joint.items():replicates["joint_"+comparator]=np.concatenate(blocks)
        for name,v in replicates.items():
            scheme,comparator=name.split("_",1)
            for j,metric in enumerate(["delta_auroc","delta_fpr95"]):
                intervals.append(dict(dataset=ds,scheme=scheme,comparator=comparator,metric=metric,draws=len(v),
                    lower=float(np.quantile(v[:,j],.025)),median=float(np.quantile(v[:,j],.5)),upper=float(np.quantile(v[:,j],.975))))
    np.savez_compressed(ROOT/"evidence/B6_replicates.npz",**replicates)
    dump("B6",dict(cluster_records=cluster_rows,summary=summary,intervals=intervals,metric_fixture_pass=True,
        analysis_engine_sha256=sha(Path(__file__)),replicate_file="B6_replicates.npz",
        replicate_sha256=sha(ROOT/"evidence/B6_replicates.npz"),
        remaining_dependence="Clusters in a target domain share test images and all fits/validation selections are fixed; these are not independent cluster samples or population uncertainty intervals."))


if __name__=="__main__":main()
