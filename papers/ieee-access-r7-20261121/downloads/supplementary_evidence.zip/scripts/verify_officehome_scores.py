"""Portable reproduction of all Office-Home metrics from exported scores/labels."""
import hashlib
import json
from pathlib import Path
import numpy as np

ROOT=Path(__file__).resolve().parents[1]

def auc(s,y):
    order=np.argsort(s,kind="stable");ss=s[order];yy=y[order]
    ends=np.r_[np.flatnonzero(ss[1:]!=ss[:-1]),len(ss)-1]
    starts=np.r_[0,ends[:-1]+1]
    known_before=0;favorable=0.
    for lo,hi in zip(starts,ends):
        group=yy[lo:hi+1];positive=int(group.sum());negative=len(group)-positive
        favorable+=positive*(known_before+.5*negative);known_before+=negative
    return favorable/(int(y.sum())*int((y==0).sum()))

def fpr95(s,y):
    order=np.argsort(-s,kind="stable");ss=s[order];yy=y[order]
    ends=np.r_[np.flatnonzero(ss[1:]!=ss[:-1]),len(ss)-1]
    tp=np.cumsum(yy,dtype=np.int64)[ends];fp=ends+1-tp
    index=np.flatnonzero(tp/int(y.sum())>=.95)[0]
    return float(fp[index]/int((y==0).sum()))

def main():
    data=json.loads((ROOT/"evidence/C1_complete_panel_audit.json").read_text(encoding="utf-8"))
    assert data["all_checks_pass"] and data["n"]==20
    checked=[]
    for unit in data["units"]:
        uid=unit["unit"];path=ROOT/"evidence/officehome_saved_scores"/(uid+".npz")
        assert hashlib.sha256(path.read_bytes()).hexdigest()==data["raw_archives"][uid]["portable_scores_and_labels_sha256"]
        with np.load(path,allow_pickle=False) as z:arrays={k:z[k] for k in z.files}
        labels=arrays["target_labels"];pred=arrays["adapter_predictions"];known=labels>=0;y=(~known).astype(int)
        for row in [r for r in data["records"] if r["unit"]==uid]:
            s=arrays[row["method"]];assert len(s)==len(labels) and np.isfinite(s).all()
            reject=s>=row["frozen_val_tpr95_threshold"]
            classification=pred.copy();classification[s>=row["maxf1_validation_threshold"]]=-1
            actual=dict(auroc=float(auc(s,y)),fpr95=float(fpr95(s,y)),known_acc=float((pred[known]==labels[known]).mean()),
                osr_acc=float((classification==labels).mean()),frozen_threshold_test_unknown_tpr=float(reject[~known].mean()),frozen_threshold_test_known_fpr=float(reject[known].mean()))
            for key,value in actual.items():assert abs(value-row[key])<=1e-12,(uid,row["method"],key,value,row[key])
            checked.append(dict(unit=uid,method=row["method"],verified=True))
    assert len(checked)==140
    out=dict(all_checks_pass=True,unit_method_records_verified=len(checked),units=len(data["units"]),
        scope="Saved-score metrics and frozen-threshold target decisions are reproducible from included arrays/labels. This is not an encoder/training rerun or an independent validation-sample model-selection reproduction.")
    (ROOT/"evidence/officehome_portable_score_checks.json").write_text(json.dumps(out,indent=2),encoding="utf-8")
    print(json.dumps(out,indent=2))

if __name__=="__main__":main()
