"""Acquire only the archive linked from the official Office-Home page."""
import hashlib
from html.parser import HTMLParser
import json
from pathlib import Path
import re
import shutil
import stat
import subprocess
import sys
import time
from urllib.parse import urljoin,urlparse
import zipfile
import requests

ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/"new_runs/officehome"
PAGE="https://www.hemanthdv.org/officeHomeDataset.html"
SHARE="https://drive.google.com/file/d/0B81rNlvomiwed0V1YUxQdC1uOTg/view?resourcekey=0-2SNWq0CDAuWOBRRBL7ZZsw&usp=sharing"
DOWNLOAD="https://drive.google.com/uc?export=download&id=0B81rNlvomiwed0V1YUxQdC1uOTg&resourcekey=0-2SNWq0CDAuWOBRRBL7ZZsw"


def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
    return h.hexdigest()


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def dump(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True);temp=p.with_suffix(".tmp")
    temp.write_text(json.dumps(obj,indent=2,allow_nan=False),encoding="utf-8");temp.replace(p)


def state(stage,**kw):dump(ROOT/"evidence/C1_acquisition_progress.json",dict(task="C1",stage=stage,updated=time.strftime("%Y-%m-%dT%H:%M:%S"),**kw))


class Forms(HTMLParser):
    def __init__(self):super().__init__();self.forms=[];self.current=None;self.links=[]
    def handle_starttag(self,tag,attrs):
        attrs=dict(attrs)
        if tag=="form":self.current=dict(action=attrs.get("action",""),method=attrs.get("method","get"),params={});self.forms.append(self.current)
        if tag=="input" and self.current is not None and "name" in attrs:self.current["params"][attrs["name"]]=attrs.get("value","")
        if tag=="a" and "href" in attrs:self.links.append(attrs["href"])
    def handle_endtag(self,tag):
        if tag=="form":self.current=None


def response_for_download(session):
    url=DOWNLOAD;params=None
    for attempt in range(4):
        response=session.get(url,params=params,stream=True,timeout=(30,120));response.raise_for_status()
        if "text/html" not in response.headers.get("Content-Type","").lower():return response
        text=response.text
        (WORK/"acquisition"/f"google_response_{attempt}.html").write_text(text,encoding="utf-8")
        if re.search(r"download quota|too many users|quota exceeded|request access|you need access",text,re.I):
            raise RuntimeError("Official Drive file reports quota/access restrictions; stop, no mirror substitution")
        parser=Forms();parser.feed(text)
        form=next((f for f in parser.forms if "download" in f["action"]),None)
        if form:
            url=urljoin(response.url,form["action"]);params=form["params"]
            if form["method"].lower()!="get":raise RuntimeError("Unexpected official download form method")
        else:
            link=next((x for x in parser.links if "confirm=" in x and ("download" in x or "/uc?" in x)),None)
            if link is None:raise RuntimeError("Official public download did not provide an archive or confirmation link; inspect saved HTML")
            url=urljoin(response.url,link);params=None
        host=urlparse(url).hostname or ""
        if host not in ["drive.google.com","drive.usercontent.google.com"]:raise RuntimeError("Refusing non-official redirect form")
        response.close()
    raise RuntimeError("Official confirmation loop did not yield an archive")


def main():
    dest=WORK/"acquisition";dest.mkdir(parents=True,exist_ok=True)
    specfile=ROOT/"prespec/C1_download.json";sealfile=ROOT/"prespec/C1_download_seal.json"
    spec=dict(task="C1_download",official_page=PAGE,official_share=SHARE,download_endpoint=DOWNLOAD,
        authorization="User explicitly permitted download from the official page on2026-11-19 Asia/Shanghai.",
        policy="Download only the linked official Google Drive archive. No third-party mirrors, authentication bypass or dataset substitution. Stop on quota/access restrictions. Validate ZIP CRC and local SHA256; no official checksum is claimed if none is published.",
        extraction="Reject path traversal and symlink ZIP entries. Extract to a new acquisition subdirectory, never overwrite data. Accept exact Art/Clipart/Product/Real-World four-domain root; run complete image and role checks before any training.",
        stage_design_sha256=sha(ROOT/"prespec/C1_stages.json"),script_sha256=sha(Path(__file__)))
    if specfile.exists():assert read(specfile)==spec
    else:
        with specfile.open("x",encoding="utf-8") as f:json.dump(spec,f,indent=2)
        with sealfile.open("x",encoding="utf-8") as f:json.dump(dict(task="C1_download",sha256=sha(specfile)),f,indent=2)
    dump(ROOT/"evidence/C1_download_authorization_20261119.json",dict(source="Explicit user reply in this conversation",approved_official_download=True,share=SHARE))
    try:
        session=requests.Session();session.headers["User-Agent"]="Mozilla/5.0 (academic dataset acquisition)"
        state("verifying_official_link")
        page=session.get(PAGE,timeout=(30,60));page.raise_for_status();(dest/"official_page.html").write_text(page.text,encoding="utf-8")
        assert "0B81rNlvomiwed0V1YUxQdC1uOTg" in page.text,"Official linked file ID changed; stop for review"
        archive=dest/"OfficeHomeDataset_10072016.zip";partial=archive.with_suffix(".zip.partial")
        if not archive.exists():
            if partial.exists():raise RuntimeError("Partial archive exists; inspect before attempting a new transfer")
            if shutil.disk_usage(dest).free<10*1024**3:raise RuntimeError("Less than10GiB free for download/extraction; stop")
            response=response_for_download(session)
            headers={k:response.headers[k] for k in ["Content-Type","Content-Length","ETag","Last-Modified","Content-Disposition"] if k in response.headers}
            expected=int(headers["Content-Length"]) if "Content-Length" in headers else None
            downloaded=0;last=time.monotonic();started=time.perf_counter()
            with partial.open("xb") as stream:
                for chunk in response.iter_content(chunk_size=1024*1024):
                    if not chunk:continue
                    stream.write(chunk);downloaded+=len(chunk)
                    if time.monotonic()-last>5:
                        state("downloading",bytes_received=downloaded,server_content_length=expected);last=time.monotonic()
            if expected is not None:assert downloaded==expected,(downloaded,expected)
            response.close();assert zipfile.is_zipfile(partial),"Official response is not a ZIP"
            partial.replace(archive)
            dump(dest/"download_manifest.json",dict(official_page=PAGE,official_share=SHARE,headers=headers,bytes=downloaded,
                sha256=sha(archive),seconds=time.perf_counter()-started,official_published_checksum=None,
                verification="Local SHA256 plus server length when available and ZIP CRC; not an independently published official digest."))
        else:assert sha(archive)==read(dest/"download_manifest.json")["sha256"]
        state("checking_archive_CRC",archive_sha256=sha(archive))
        extracted=dest/"extracted"
        if not extracted.exists():
            with zipfile.ZipFile(archive) as z:
                assert z.testzip() is None,"ZIP CRC mismatch"
                for entry in z.infolist():
                    p=(extracted/entry.filename).resolve()
                    assert p.is_relative_to(extracted.resolve()),entry.filename
                    assert not stat.S_ISLNK(entry.external_attr>>16),entry.filename
                extracted.mkdir();z.extractall(extracted)
            dump(dest/"extraction_complete.json",dict(archive_sha256=sha(archive),ZIP_CRC_passed=True))
        elif not (dest/"extraction_complete.json").exists():raise RuntimeError("Partial extraction exists; stop for inspection")
        candidates=[]
        for p in [extracted]+[p for p in extracted.iterdir() if p.is_dir()]:
            normalized={re.sub("[^a-z]","",c.name.casefold()) for c in p.iterdir() if c.is_dir()}
            if normalized=={"art","clipart","product","realworld"}:candidates.append(p)
        assert len(candidates)==1,("Could not identify exact official four-domain root",candidates)
        data=candidates[0];state("validating_all_images_and_freezing_roles",data_root=str(data))
        log=WORK/"acceptance.log"
        with log.open("w",encoding="utf-8") as f:
            subprocess.run([sys.executable,"-B","-s","-u",str(ROOT/"scripts/officehome_accept.py"),"--data-root",str(data)],
                stdout=f,stderr=subprocess.STDOUT,check=True)
        dump(ROOT/"evidence/C1_acquisition.json",dict(data_root=str(data),archive_sha256=sha(archive),
            download_manifest=read(dest/"download_manifest.json"),accepted_roles_sha256=sha(WORK/"accepted_roles.json"),
            accepted=True,new_model_inference=False,download_spec_sha256=sha(specfile)))
        state("accepted_waiting_C3b_then_two_unit_pilot",data_root=str(data),accepted_roles_sha256=sha(WORK/"accepted_roles.json"))
    except Exception as exc:
        state("failed_requires_inspection",error=repr(exc));raise


if __name__=="__main__":main()
