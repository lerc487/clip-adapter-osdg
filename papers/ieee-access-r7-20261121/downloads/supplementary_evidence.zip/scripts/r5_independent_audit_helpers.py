"""Independent exact-tie ROC and float64 score references."""
import numpy as np


def roc(scores,labels,rho=.95):
    s=np.asarray(scores);y=np.asarray(labels,dtype=int)
    assert len(s)==len(y) and np.isfinite(s).all() and set(y)=={0,1}
    order=np.argsort(-s,kind="stable");z=s[order];v=y[order]
    ends=np.r_[np.flatnonzero(z[:-1]!=z[1:]),len(z)-1]
    tp=np.cumsum(v,dtype=np.int64)[ends];fp=ends+1-tp
    tpr=tp/y.sum();fpr=fp/(len(y)-y.sum());i=np.flatnonzero(tpr>=rho)[0]
    auc=float(np.trapz(np.r_[0.,tpr],np.r_[0.,fpr]))
    return dict(auroc=auc,fpr95=float(fpr[i]),threshold=float(z[ends[i]]))


def scores(logits,t,energy=False):
    x=np.asarray(logits,dtype=np.float64)/t
    if energy:return -t*np.logaddexp.reduce(x,axis=1)
    maximum=x.max(1);masked=x.copy();masked[np.arange(len(x)),x.argmax(1)]=-np.inf
    return np.logaddexp.reduce(masked,axis=1)-maximum


def combine(z,a,sel):
    if sel["score_source"]=="adapter":return a
    if sel["score_source"]=="zeroshot":return z
    return sel["alpha"]*np.asarray(a,dtype=np.float64)+(1-sel["alpha"])*np.asarray(z,dtype=np.float64)


def check(value,expected,where,tolerance=1e-12):
    assert np.isfinite(value) and np.isfinite(expected) and abs(value-expected)<=tolerance,(where,value,expected)


def fixtures():
    r=roc(np.array([.8,.8,.4,.2]),np.array([1,0,1,0]))
    assert r==dict(auroc=.625,fpr95=.5,threshold=.4)
    np.testing.assert_array_equal(scores(np.array([[4.,1.],[2.,-1.]]),2.),[-1.5,-1.5])
    return dict(passed=True,synthetic_only=True,complete_tie_ROC=True,binary_logodds_exact=True)
