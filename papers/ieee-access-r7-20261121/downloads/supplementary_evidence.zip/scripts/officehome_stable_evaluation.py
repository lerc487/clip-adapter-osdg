"""Recompute all pilot scores in float64, leaving training archives unchanged."""
import hashlib
import json
from pathlib import Path
import time
import numpy as np
from sklearn.metrics import roc_auc_score
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"new_runs/c3b/code"))
from verified_metrics import fpr_at_recall,threshold_maxf1
from c3b_scoring import score,select,branch


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def new(p,x):
    with p.open("x",encoding="utf-8") as f:json.dump(x,f,indent=2,allow_nan=False)


def numerical_fixtures(root):
    sys.path.insert(0,str(root.parent/"tools"))
    from stable_score_audit import stable_msp,stable_energy,choose
    rng=np.random.default_rng(20261119)
    a={k:rng.normal(size=(n,5)).astype(np.float32)*25 for k,n in [("ka",31),("kz",31),("ua",17),("uz",17)]}
    a["yk"]=np.zeros(31,dtype=int);a["yu"]=np.zeros(17,dtype=int)
    for mode,reference in [("msp",stable_msp),("energy",stable_energy)]:
        for t in [.2,1.,5.]:np.testing.assert_array_equal(score(a["ka"],t,mode),reference(a["ka"],t))
        for route in ["adapter","auto"]:
            ours=select(route,mode,[.2,1.,5.],a["kz"],a["ka"],a["uz"],a["ua"],True,.5,[0.,.25,.5,.75,1.],"fpr95")
            assert ours==choose(a,route,mode,[.2,1.,5.],"fpr95")
    sel=dict(score_source="mix",alpha=.25)
    actual=branch(a["kz"],a["ka"],sel)
    assert actual.dtype==np.float64
    np.testing.assert_array_equal(actual,.25*a["ka"].astype(np.float64)+.75*a["kz"].astype(np.float64))
    (root/"evidence/C1_pilot_v3_eval64_numerical_fixtures.json").write_text(json.dumps(dict(passed=True,synthetic_only=True,
        model_inference=False,mixing_float64=True,stable_score_and_validation_selection_match_primary_audit=True,
        prespec_sha256=sha(root/"prespec/C1_pilot_v3_eval64.json")),indent=2),encoding="utf-8")


def evaluate_stable(run,dest):
    dest.mkdir(parents=True,exist_ok=False)
    config=read(run/"config.json")["arguments"]
    with np.load(run/"logits.npz",allow_pickle=False) as z:a={k:z[k] for k in z.files}
    temps=[float(t) for t in config["temp_candidates"].split(",")];alphas=[float(t) for t in config["mix_alphas"].split(",")]
    variants=[("MSP","adapter","msp",False),("Temp-MSP","adapter","msp",True),
        ("Energy-only-T1","adapter","energy",False),("Mix-alpha0.5-T-tuned","mix","msp",True),
        ("autoMixTemp","auto","msp",True),("Zero-shot-T-tuned","zeroshot","msp",True),
        ("Energy-T-tuned","adapter","energy",True)]
    choices=[]
    for name,route,mode,tune in variants:
        start=time.perf_counter()
        selection=select(route,mode,temps,a["kz"],a["ka"],a["uz"],a["ua"],tune,.5,alphas,"fpr95")
        choices.append(dict(method=name,mode=mode,selection=selection,selection_seconds=time.perf_counter()-start))
    new(dest/"validation_choices_frozen.json",dict(choices=choices,raw_logits_sha256=sha(run/"logits.npz"),
        policy="All choices use validation only and are persisted before target-score computation. Mixing and scoring float64; no target-based configuration changes."))
    fixed_hash=sha(dest/"validation_choices_frozen.json")
    legacy={r["method"]:r for r in read(run/"results.json")};rows=[];arrays={}
    known=a["ty"]>=0;y=(~known).astype(int);pred=a["ta"].argmax(1)
    vy=np.r_[np.zeros(len(a["ka"]),dtype=int),np.ones(len(a["ua"]),dtype=int)]
    for row in choices:
        name,mode,sel=row["method"],row["mode"],row["selection"];t=sel["T_score"]
        sv=np.r_[score(branch(a["kz"],a["ka"],sel),t,mode),score(branch(a["uz"],a["ua"],sel),t,mode)]
        st=score(branch(a["tz"],a["ta"],sel),t,mode);assert np.isfinite(st).all()
        threshold=fpr_at_recall(sv,vy)["threshold"];reject=st>=threshold
        f1=threshold_maxf1(sv,vy)["threshold"];classification=pred.copy();classification[st>=f1]=-1
        details=fpr_at_recall(st,y)
        result=dict(method=name,checkpoint_sha256=sha(run/"best_adapter.pt"),selection=sel,
            auroc=float(roc_auc_score(y,st)),fpr95=details["fpr95"],known_acc=float((pred[known]==a["ty"][known]).mean()),
            osr_acc=float((classification==a["ty"]).mean()),maxf1_validation_threshold=f1,
            frozen_val_tpr95_threshold=threshold,frozen_threshold_test_known_fpr=float(reject[known].mean()),
            frozen_threshold_test_unknown_tpr=float(reject[~known].mean()),test_fpr95_details=details,
            selection_seconds=row["selection_seconds"],arithmetic="float64 mixing and stable scores",
            validation_choices_sha256=fixed_hash)
        if name in legacy:
            result["archived_auroc"]=legacy[name]["auroc"];result["archived_fpr95"]=legacy[name]["fpr95"]
            result["float64_minus_archived_auroc"]=result["auroc"]-legacy[name]["auroc"]
            result["float64_minus_archived_fpr95"]=result["fpr95"]-legacy[name]["fpr95"]
        arrays[name]=st;rows.append(result)
    np.savez_compressed(dest/"stable_scores.npz",**arrays)
    new(dest/"results.json",dict(results=rows,raw_results_sha256=sha(run/"results.json"),raw_logits_sha256=sha(run/"logits.npz"),
        raw_training_archive_modified=False,prespec_sha256=sha(ROOT/"prespec/C1_pilot_v3_eval64.json")))
    return rows
