"""Bind the integrated manuscript to corrected immutable evidence, not old rounding."""
from copy import deepcopy
from pathlib import Path
import re
import sys
import numpy as np
from scipy.special import softmax, logsumexp

from gap_closure_core import ROOT, read, sha, write, branch
import r5_precision_followup as replay


def mean(rows, field):
    assert rows
    return float(np.mean([r[field] for r in rows]))


def one(rows, **where):
    rows = [r for r in rows if all(r.get(k) == v for k, v in where.items())]
    assert len(rows) == 1, (where, len(rows))
    return rows[0]


def main():
    specpath = ROOT / "prespec/E7_numeric_consolidation.json"
    spec = read(specpath)
    assert sha(specpath) == read(specpath.with_name("E7_numeric_consolidation_seal.json"))["sha256"]
    assert sha(__file__) == spec["script_sha256"]
    for name, digest in spec["inputs"].items():
        assert sha(ROOT / "evidence" / name) == digest, name
    original_registry = read(ROOT / "evidence/number_registry.json")
    stable = deepcopy(read(ROOT / "evidence/stable.json"))
    diag = deepcopy(read(ROOT / "evidence/diagnostics.json"))
    corrected = read(ROOT / "evidence/E0_precision.json")["records"]
    fixed = read(ROOT / "evidence/E0_fixed_original_parameters.json")["records"]
    probability = read(ROOT / "evidence/E0_probability.json")
    expanded = []
    for ds in ["pacs", "cifar10"]:
        diag["datasets"][ds]["reliability_bins"] = []
    for model, ds, unit, directory, a, methods in replay.panels():
        ex = methods["autoMixTemp-expanded"]
        expanded.append(dict(model=model, dataset=ds, unit=unit, method="autoMixTemp-expanded", **ex))
        if model != "ViT-B32":
            continue
        for method in ["MSP", "Temp-MSP", "autoMixTemp", "Energy-T-tuned"]:
            r = one(corrected, model=model, dataset=ds, unit=unit, method=method)
            old = one(stable["records"], dataset=ds, unit=unit, method=method)
            old.update(selection=r["selection"], auroc=r["auroc"], fpr95=r["fpr95"],
                frozen_unknown_recall=r["recall"], frozen_known_rejection=r["rejection"])
        old = one(stable["records"], dataset=ds, unit=unit, method="autoMixTemp-expanded")
        old.update(ex)
        known = a["ty"] >= 0
        labels = a["ty"][known]
        for method in ["MSP", "Temp-MSP", "autoMixTemp", "Known-NLL-TS"]:
            expected = one(probability["records"], model=model, dataset=ds, unit=unit, method=method)
            selection = dict(score_source="adapter", alpha=None, T_score=expected["temperature"]) if method == "Known-NLL-TS" else methods[method]["selection"]
            x = branch(a["tz"], a["ta"], selection)[known].astype(np.float64) / selection["T_score"]
            p = softmax(x, axis=1)
            conf = p.max(1)
            correct = p.argmax(1) == labels
            bins = []
            for i in range(15):
                selected = np.minimum((conf * 15).astype(int), 14) == i
                count = int(selected.sum())
                bins.append(dict(unit=unit, method=method, bin=i, count=count,
                    confidence=float(conf[selected].mean()) if count else None,
                    accuracy=float(correct[selected].mean()) if count else None))
            ece = sum(r["count"] * abs(r["confidence"] - r["accuracy"]) for r in bins if r["count"]) / len(labels)
            nll = float(np.mean(logsumexp(x, axis=1) - x[np.arange(len(x)), labels]))
            target = np.eye(p.shape[1])[labels]
            brier = float(np.mean(np.sum((p - target) ** 2, axis=1)))
            for key, value in [("ece15", ece), ("nll", nll), ("brier", brier)]:
                assert abs(value - expected[key]) < 1e-11, (unit, method, key, value, expected[key])
            diag["datasets"][ds]["reliability_bins"].extend(bins)
        print("E7 replay/plot reconciliation " + model + " " + unit, flush=True)
    for ds in ["pacs", "cifar10"]:
        for method in ["MSP", "Temp-MSP", "autoMixTemp", "Energy-T-tuned", "autoMixTemp-expanded"]:
            rows = [r for r in stable["records"] if r["dataset"] == ds and r["method"] == method]
            for field in ["auroc", "fpr95", "frozen_unknown_recall", "frozen_known_rejection"]:
                if all(field in r for r in rows):
                    stable["summaries"][ds][method][field] = mean(rows, field)
        for effect in diag["datasets"][ds]["effects"]:
            if effect["method"] in ["Temp-MSP", "autoMixTemp", "Energy-T-tuned"]:
                r = one(corrected, model="ViT-B32", dataset=ds, unit=effect["unit"], method=effect["method"])
                base = one(corrected, model="ViT-B32", dataset=ds, unit=effect["unit"], method="MSP")
                effect.update(delta_auroc=r["auroc"] - base["auroc"], delta_fpr95=r["fpr95"] - base["fpr95"])
        for r in stable["records"]:
            if r["dataset"] == ds and r["method"] in ["MSP", "Temp-MSP", "autoMixTemp"]:
                f = one(fixed, dataset=ds, unit=r["unit"], method=r["method"])
                r["stable_fpr95_at_legacy_selection"] = f["fpr95"]
    reconciliation = read(ROOT / "evidence/E0_conditional_reconciliation.json")
    for ds in ["pacs", "cifar10"]:
        diag["datasets"][ds]["conditional_image_intervals"] = reconciliation["image_intervals"][ds]
    sources = {r["file"]: read(ROOT / "evidence" / r["file"]) for r in original_registry}
    replacement = {name: read(ROOT / "evidence" / filename) for name, filename in {
        "B2": "E2_transfer_tradeoffs.json", "B3": "E0_probability.json", "B4": "E0_temperature.json", "B7": "E0_legacy80.json"}.items()}
    e1 = read(ROOT / "evidence/E1_search_utility.json")
    values = {}
    origins = {}
    updates = []
    for r in original_registry:
        value = r["value"]
        file = r["file"]
        path = r["pointer"]
        reason = "Unchanged immutable evidence"
        if file == "stable.json":
            value = stable
            for key in path:
                value = value[key]
            reason = "E0 full64 primary scores; E7 same-grid expanded replay"
        elif file == "diagnostics.json":
            value = diag
            for key in path:
                value = value[key]
            reason = "E0 reconciled shared-content intervals"
        elif file[:-5] in replacement:
            old = sources[file]
            new = replacement[file[:-5]]
            field, index, *rest = path
            entry = old[field][index]
            keys = [k for k in ["model", "dataset", "method", "rho", "policy", "variant", "temperature"] if k in entry]
            value = one(new[field], **{k: entry[k] for k in keys})
            for key in rest:
                value = value[key]
            reason = "Corrected immutable " + {"B2": "E2", "B3": "E0_probability", "B4": "E0_temperature", "B7": "E0_legacy80"}[file[:-5]]
        elif file == "B1.json":
            field, index, key = path
            entry = sources[file][field][index]
            if field == "strata":
                value = one(e1["strata"], model=entry["model"], dataset=entry["dataset"], source=entry["choice"])[key]
            elif field == "associations":
                value = one(e1["correlations"], model=entry["model"], dataset=entry["dataset"])[key]
            else:
                updated = one(e1["gate_summary"], model=entry["model"], dataset=entry["dataset"], delta=entry["delta"],
                    gate="any_source" if entry["gate"] == "any_selected_source" else entry["gate"])
                value = int(round(updated["enabled"] * updated["n"])) if key == "enabled" else updated[key]
            reason = "E1 full64 gate/source evidence; enabled fraction converted to integer count"
        elif file == "B6.json":
            field, index, key = path
            entry = sources[file][field][index]
            new = reconciliation["summary"] if field == "summary" else reconciliation["pacs_intervals"]
            keys = [k for k in ["dataset", "comparator", "metric", "scheme"] if k in entry]
            value = one(new, **{k: entry[k] for k in keys})[key]
            reason = "E0 conditional reconciliation; PACS exact ROC geometry proof / CIFAR replay"
        elif file == "additional.json" and path[0] == "architecture_summary":
            entry = sources[file][path[0]][path[1]]
            model = "ViT-B32" if entry["family"].startswith("ViT") else "RN50"
            rows = [x for x in corrected if x["model"] == model and x["dataset"] == entry["dataset"] and x["method"] == entry["method"] and x["unit"].endswith("seed0")]
            if rows:
                value = len(rows) if path[-1] == "n" else mean(rows, path[-1])
                reason = "E0 full64 matched seed0 architecture means"
        elif file == "manuscript_values.json":
            key = path[0]
            match = re.fullmatch(r"precision_(pacs|cifar10)(MSP|Temp-MSP|autoMixTemp)(legacy_float32_fpr95|stable_fpr95_at_legacy_selection|fpr95)", key)
            if match:
                ds, method, variant = match.groups()
                if variant == "fpr95":
                    rows = [x for x in corrected if x["model"] == "ViT-B32" and x["dataset"] == ds and x["method"] == method]
                    value = mean(rows, "fpr95")
                else:
                    rows = [x for x in fixed if x["dataset"] == ds and x["method"] == method]
                    value = mean(rows, "raw_float32_fpr95" if variant == "legacy_float32_fpr95" else "fpr95")
                reason = "E0 original-parameter reconciliation; raw float32 kept read-only"
            elif "Delta" in key or key.startswith("Abs"):
                ds = "pacs" if "PACS" in key else "cifar10"
                metric = "auroc" if key.endswith("AUC") else "fpr95"
                value = stable["summaries"][ds]["autoMixTemp"][metric] - stable["summaries"][ds]["MSP"][metric]
                reason = "E0 full64 auto-minus-MSP difference of equal-unit means"
            elif key.startswith("upper") and key.endswith("Expanded"):
                ds = "pacs" if "pacs" in key else "cifar10"
                value = sum(x["selection"]["T_score"] == 1000 for x in expanded if x["model"] == "ViT-B32" and x["dataset"] == ds)
                reason = "E7 full64 same-expanded-grid selection count"
        assert isinstance(value, (int, float)) and np.isfinite(value), (file, path, value)
        values[r["macro"]] = value
        origins[r["macro"]] = dict(previous_file=file, previous_pointer=path, previous_value=r["value"], derivation=reason)
        new = dict(r, file="E7_final_numeric_evidence.json", pointer=["values_by_macro", r["macro"]], value=value,
            decimals=0 if r["decimals"] == 0 else 3)
        new["display"] = format(value * new["scale"], ("+" if new["signed"] else "") + "." + str(new["decimals"]) + "f")
        updates.append(new)
    result = dict(values_by_macro=values, numeric_origins=origins, stable=stable, diagnostics=diag, expanded_records=expanded,
        source_sha256=spec["inputs"], prespec_sha256=sha(specpath), both_interpolation_operands_float64=True,
        original_archives_modified=False, expanded_grid_is_previously_fixed=True, no_new_training=True,
        no_encoder_inference=True, no_target_hyperparameter_selection=True)
    write(ROOT / "evidence/E7_final_numeric_evidence.json", result, exclusive=True)
    write(ROOT / "evidence/E7_final_number_registry.json", updates, exclusive=True)
    print("Final full64 evidence consolidated; source not yet changed.", flush=True)


if __name__ == "__main__":
    main()
