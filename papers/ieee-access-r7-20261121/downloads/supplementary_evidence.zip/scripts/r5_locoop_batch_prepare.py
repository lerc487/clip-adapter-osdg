"""Freeze all33 sample roles and66 configurations before any new fit."""
import hashlib
from pathlib import Path
import sys

from r5_locoop_batch_common import ROOT, BASE, SPEC, INPUTS, read, write, sha, now, available_disk
from r5_locoop_bridge import config_for


def main():
    assert not SPEC.exists() and not INPUTS.exists(), "Existing freeze must not be overwritten"
    authorization = ROOT / "evidence/E6_locoop_batch_authorization_20261120.json"
    assert read(authorization)["new_fits_authorized"] == 64
    pilot_spec_path = ROOT / "prespec/E6_locoop_pilot.json"
    pilot_spec = read(pilot_spec_path)
    assert sha(pilot_spec_path) == read(pilot_spec_path.with_name("E6_locoop_pilot_seal.json"))["sha256"]
    assert read(ROOT / "evidence/E6_pilot_audit.json")["all_checks_pass"]
    for name, digest in pilot_spec["code_hashes"].items():
        assert sha(name) == digest, name
    identities = [("pacs", f"{domain}_rotation{rotation:02d}_seed0")
        for domain in ["art_painting", "cartoon", "photo", "sketch"] for rotation in range(7)]
    identities += [("cifar10", f"cifar10_rotation{rotation:02d}_seed0") for rotation in range(5)]
    assert len(identities) == 33
    images = {}
    units = []
    jobs = []
    roles = ["train", "val_known", "val_unknown", "test"]
    for dataset, unit in identities:
        original = BASE / "05_new_runs" / dataset / unit
        config = read(original / "config.json")["arguments"]
        root = Path(config["data_root"]).resolve()
        known = read(original / "class_map.json")["known"]
        assert len(known) == (3 if dataset == "pacs" else 6) and config["seed"] == 0
        manifests = {name: read(original / (name + "_samples.json")) for name in roles}
        sets = {}
        unknown_classes = {}
        for role, rows in manifests.items():
            hashes = set()
            classes = set()
            for row in rows:
                relative = row["path"].replace("\\", "/")
                path = (root / relative).resolve()
                assert path.is_relative_to(root) and path.is_file(), path
                cls = Path(relative).parent.name
                if row["label"] >= 0:
                    assert known[row["label"]] == cls, (unit, role, cls, row["label"])
                else:
                    assert role in ["val_unknown", "test"] and cls not in known
                    classes.add(cls)
                key = (dataset, str(path).casefold())
                if key not in images:
                    images[key] = dict(dataset=dataset, absolute_path=str(path), sha256=sha(path))
                hashes.add(images[key]["sha256"])
            sets[role] = hashes
            unknown_classes[role] = sorted(classes)
            if role in ["train", "val_known"]:
                assert all(r["label"] >= 0 for r in rows)
                assert {r["label"] for r in rows} == set(range(len(known)))
            if role == "val_unknown":
                assert all(r["label"] < 0 for r in rows)
        assert len(unknown_classes["val_unknown"]) == len(unknown_classes["test"]) == 2
        assert not set(unknown_classes["val_unknown"]) & set(unknown_classes["test"])
        assert not sets["train"] & (sets["val_known"] | sets["val_unknown"] | sets["test"])
        assert not sets["test"] & (sets["val_known"] | sets["val_unknown"])
        filenames = ["config.json", "class_map.json"] + [role + "_samples.json" for role in roles]
        item = dict(dataset=dataset, unit=unit, input_run=str(original), known_classes=known,
            unknown_classes=unknown_classes, sample_counts={role: len(rows) for role, rows in manifests.items()},
            manifest_hashes={name: sha(original / name) for name in filenames},
            no_within_unit_train_target_or_validation_target_content_overlap=True)
        units.append(item)
        for coefficient, tag in [(.1, "lambda_010"), (.25, "lambda_025")]:
            reused = [dataset, unit] in pilot_spec["pilot_ids"] and coefficient == .1
            output = ROOT / "new_runs" / ("locoop_pilot" if reused else "locoop_batch") / dataset / unit
            if not reused:
                output = output / tag
                assert not output.exists(), output
            cfg = config_for(dataset, unit, output, use_cuda=True)
            cfg.defrost()
            cfg.lambda_value = coefficient
            cfg.freeze()
            config_sha = hashlib.sha256(cfg.dump().encode("utf-8")).hexdigest()
            job = dict(dataset=dataset, unit=unit, lambda_value=coefficient, lambda_tag=tag,
                fit_id=dataset + "/" + unit + "/" + tag, output=str(output), reused_pilot=reused, config_sha256=config_sha)
            if reused:
                assert read(output / "config.json")["yaml"] == cfg.dump(), (unit, "Pilot config must be identical")
                assert read(output / "results.json")["prespec_sha256"] == sha(pilot_spec_path)
                job["pilot_result_sha256"] = sha(output / "results.json")
            jobs.append(job)
        print("Frozen literal roles/configs " + dataset + "/" + unit, flush=True)
    assert len(jobs) == 66 and sum(job["reused_pilot"] for job in jobs) == 2
    assert sum(job["dataset"] == "pacs" and not job["reused_pilot"] for job in jobs) == 55
    assert sum(job["dataset"] == "cifar10" and not job["reused_pilot"] for job in jobs) == 9
    write(INPUTS, dict(units=units, images=list(images.values()), raw_images_read_only=True,
        freeze_utc=now(), class_roles_disjoint=True, no_outcome_based_unit_selection=True), exclusive=True)
    hashes = dict(pilot_spec["code_hashes"])
    for name in ["r5_locoop_batch_common.py", "r5_locoop_batch_prepare.py", "r5_locoop_batch_fixtures.py",
                 "r5_locoop_batch_unit.py", "r5_locoop_batch_queue.py", "r5_locoop_batch_audit.py", "r5_independent_audit_helpers.py"]:
        path = ROOT / "scripts" / name
        hashes[str(path)] = sha(path)
    for name in ["train_disjoint.py", "verified_metrics.py"]:
        path = ROOT / "new_runs/c3b/code" / name
        hashes[str(path)] = sha(path)
    audit_path = ROOT / "evidence/E0_precision.json"
    hashes[str(audit_path)] = sha(audit_path)
    spec = dict(task="E6_official_locoop_complete_seed0_two_lambda_batch", created_utc=now(),
        interpreter=pilot_spec["interpreter"], authorization_sha256=sha(authorization), inputs_sha256=sha(INPUTS),
        pilot_prespec_sha256=sha(pilot_spec_path), pilot_audit_sha256=sha(ROOT / "evidence/E6_pilot_audit.json"),
        jobs=jobs, new_fits=64, reused_pilots=2, total_fits=66, distinct_sample_role_units=33,
        lambda_values=[.1, .25], seed=0, backbone="ViT-B/32", minimum_free_bytes=8 * 1024 ** 3,
        initial_free_bytes=available_disk(), code_hashes=hashes,
        unit_order="PACS domain-major art_painting/cartoon/photo/sketch, rotations0..6, then CIFAR rotations0..4; within each unit lambda0.1 then0.25. Two fixedlambda0.1 pilots reused, not fitted again.",
        training="Unmodified official trainer/loss; generic16-token end prompts; AMP; SGD officiallr.002; batch32;50epochs; official augmentation and drop_last for training; topk=max(1,floor(.2K)); onlylambda differs. Each fit resetsseed0, no warm start between fits. Different loss/augmentation/50epoch prompt budget from the max20epoch adapter.",
        checkpoint="Earliest exact minimum official float32 known-validation NLL over50epochs, separately in every fit. No validation-unknown or target checkpoint selection. New fits save every epoch's known-validation logits for independent diagnostic NLL checks; diagnostic float64 NLL does not replace the recorded selection objective.",
        scores="Official test_ood temperature1 MCM/GL-MCM, plus stablefloat64MCM log-odds and float64GL-MCM; retain all four, all samples. Do not reproduce published benchmark numbers or replace exact official scores.",
        interpretation="Report lambda0.1 and0.25 separately for each dataset; equal-role-unit means within each panel. No target-selected bestlambda, no poolinglambda as independent observations, no IID/population or95recall guarantee. Pair with exactprimaryseed0 sample roles while disclosing separate training budgets/classifiers.",
        arithmetic_audit="Manual complete-tie unknown-positive ROC; independent NumPy officialfloat32 scores tolerance1e-6 andfloat64 scores1e-12. Target labels only enter evaluation. NLL tracescheckedfloat64 vs recordedfloat32 tolerance1e-5. Reused2pilots have recordedepochNLL but no raw perepochknownlogits; disclose this distinction.",
        stopping="One shared GPUlock; pause at fit boundaries. Stop on any failed/partialfit or audit mismatch; no silent retry, omissions, grid changes or replacements. Each fit independently audited before starting the next; afterall66a fresh full CPUaudit, then exit. No automatic manuscript submission.",
        prespec_timing="Lambda candidates were declared before pilot target inspection; full unit coverage authorized after actual pilot timings and frozen now, before64newfits. This is not a pristine prospective study with no earlier target access.",
        upload_ready=False)
    assert spec["initial_free_bytes"] >= spec["minimum_free_bytes"]
    write(SPEC, spec, exclusive=True)
    write(SPEC.with_name("E6_locoop_batch_seal.json"), dict(sha256=sha(SPEC)), exclusive=True)
    print("Sealed66 jobs/64newfits; no training has started.", flush=True)


if __name__ == "__main__":
    main()
