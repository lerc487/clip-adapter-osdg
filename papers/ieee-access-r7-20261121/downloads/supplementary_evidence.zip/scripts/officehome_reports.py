"""Write the completed five-part task report from verified evidence only."""
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];RUNS=ROOT.parent/"revision2_20261118"
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def write(name,text):(ROOT/"reports"/name).write_text(text+"\n",encoding="utf-8")

def main():
    data=read(ROOT/"evidence/C1_complete_panel_audit.json");assert data["all_checks_pass"] and data["n"]==20
    assert read(ROOT/"evidence/officehome_portable_score_checks.json")["all_checks_pass"]
    progress=read(RUNS/"evidence/C1_stage1_v3_progress.json");assert progress["completed"]==20
    (ROOT/"evidence/C1_stage1_status_snapshot.json").write_text(json.dumps(progress,indent=2),encoding="utf-8")
    labels=read(ROOT/"evidence/responses.json")["labels"]
    place=lambda name:labels[name]["number"]
    rows="\n".join(f"| {r['method']} | {r['n']} | {r['auroc']:.6f} | {r['fpr95']:.6f} | {r['frozen_threshold_test_unknown_tpr']:.6f} | {r['frozen_threshold_test_known_fpr']:.6f} |" for r in data["summary"])
    changes="\n".join(f"相对{r['comparator']}：ΔAUROC={r['mean_delta_auroc']:+.6f}，ΔFPR@95={r['mean_delta_fpr95']:+.6f}；FPR下降/上升/相同={r['lower']}/{r['higher']}/{r['tied']}。" for r in data["paired_summary"])
    text=f"""# C1 Office Home 阶段1完成与核验报告

## 1 做了什么
完成四域×五轮换×seed0的全部20单元，复用两个计时试点、补18个新单元，七个预设方法全部报告。未启动seed1/2。CPU独立重算全部140组结果，验证冻结图像/类别角色、raw archive哈希、float64评分、验证集选参、ROC阈值、Known/OSR准确率和冻结阈值迁移指标。
源图像按唯一文件路径重验了{data['unique_raw_image_paths_verified']}个SHA256；分数重算相对保存值的最大绝对差为{data['max_saved_score_absolute_error']:.12g}。

## 2 修改的文件和位置
source/body_revision.tex；source/tables/officehome.tex；source/figures/officehome_comparison.pdf；摘要、结论、Scope and limitations；正文{place('sec:officehome-protocol')}/{place('sec:officehome-results')}，表{place('tab:officehome')}，图{place('fig:officehome')}；补充S15-S18和逐条回复R1.2/R2.6。

## 3 新数字与 JSON 来源
所有数字来自evidence/C1_complete_panel_audit.json；原始完整面板为revision2_20261118/evidence/C1_stage1_v3_eval64.json。下表是各单元等权均值，均为比例而非百分数：

| 方法 | 单元 | AUROC | FPR@95 | 冻结阈值目标召回 | 已知误拒 |
| --- | --- | --- | --- | --- | --- |
{rows}

{changes}

autoMixTemp选择来源计数：{json.dumps(data['selection_source_counts'],ensure_ascii=False)}。
逐单元结果、域均值和配对差见C1_complete_units.csv、C1_complete_domain_summary.csv、C1_complete_paired.csv。保存分数与标签在evidence/officehome_saved_scores，使用verify_officehome_scores.py可独立重算这140组指标；这不是重新训练或重跑编码器。

## 4 对我们有利还是不利
严格按上表与配对差判读，不用结果方向改变预设。补充独立数据集是证据覆盖的改善，但不能将第三个数据集、较低的FPR或某个域的优势直接解释成内部混合必要、普遍最优或目标95%召回保证。
本面板仅seed0，35/15/15类角色；源与验证每类10张，与PACS训练预算不同，不合并均值。验证未知仅150个名义文件，独特内容数范围为{data['unique_unknown_validation_min']}–{data['unique_unknown_validation_max']}。跨域/跨类完全重复组已排除，但同域同类重复保留，近重复和预训练暴露未审计。

## 5 需要作者决定的事
已授权实验已完成，无需为了补齐这批结果再运行seed1/2。作者应审核完整17条证据核对表，特别是部分回应的科学诉求和LoCoOp未运行的比较范围，再决定是否重投。当前不会擅自启动额外实验或代为投稿。
"""
    write("C1_阶段1完成与核验报告.md",text)
    write("C1_阶段1运行说明.md","# C1 阶段1状态更新\n\n全部20单元已完成并核验，完整报告见C1_阶段1完成与核验报告.md。本文件替代本目录先前的运行中快照；先前版本文件未修改。")
    wc=read(ROOT/"evidence/word_counts.json")
    write("A2_报告.md",f"""# A2 精简与完整面板整合报告

## 1 做了什么
保留回应审稿意见所需图表，纳入完整Office-Home面板；题摘、协议、结果、限制与结论同步，避免将三个预算不同的数据集混算。

## 2 文件和章节
source/body_revision.tex、architecture_results.tex、manuscript.tex及所有结果表。当前实际节号、表号和图号见evidence/responses.json和17条证据核对表。

## 3 新数字及 JSON 来源
evidence/word_counts.json：相同计数规则正文{wc['before']}→{wc['after']}词，比例{wc['ratio']:.6f}，摘要{wc['abstract_words']}词。该比例通过不删必要表图的压缩获得。

## 4 有利还是不利
文字与版式改善不等于方法证据更强；概率可靠性、迁移阈值、简单基线及外部词表方法的不利比较仍保留。

## 5 需要作者决定的事
确认题目、贡献定位与元数据；证据收齐不代表17条实质诉求全部实现或能保证录用。
""")
    write("README_本轮报告索引.md","# 本轮报告索引\n\nC1_阶段1完成与核验报告和17条审稿意见证据核对表为当前完整面板报告。C3b、NegLabel、B1–B7及其余已完成分析沿用真实既有报告；历史报告中的早期位置不作为本轮引文依据，实际编号以当前responses.json、CHANGES.md及证据核对表为准。未运行LoCoOp/ViT-B16的限制保留，不将其写成已完成。")
    print("Complete five-part Office-Home task report and current prose-count report generated.")

if __name__=="__main__":main()
