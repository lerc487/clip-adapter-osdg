"""Run exactly the two authorized v3 pilots after the C3b GPU stage."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from officehome_train import selected_rows
from officehome_pilot import verify_samples
from officehome_stable_evaluation import evaluate_stable,numerical_fixtures

ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/"new_runs/officehome/dedup_v3"


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);temp=p.with_suffix(".tmp")
    temp.write_text(json.dumps(x,indent=2,allow_nan=False),encoding="utf-8");temp.replace(p)


def state(stage,**kw):
    obj=dict(stage=stage,protocol_version="C1_dedup_v3",updated=time.strftime("%Y-%m-%dT%H:%M:%S"),**kw)
    dump(ROOT/"evidence/C1_pilot_v3_eval64_progress.json",obj)
    # The already-sealed NegLabel stage reads this metadata alias, not old C1 outcomes.
    dump(ROOT/"evidence/C1_pilot_progress.json",obj)


def freeze():
    literal=read(ROOT/"prespec/C1_roles_manifest_v3.json")
    names=["officehome_train_v3.py","officehome_pilot_v3_eval64.py","officehome_stable_evaluation.py","officehome_train.py","officehome_pilot.py","c3b_scoring.py"]
    files=[ROOT/"scripts"/name for name in names]+sorted((ROOT/"new_runs/c3b/code").glob("*.py"))
    spec=dict(task="C1_pilot_v3_eval64",parent_stage_design_sha256=sha(ROOT/"prespec/C1_stages.json"),
        parent_pilot_spec_sha256=sha(ROOT/"prespec/C1_pilot_v3.json"),
        numerical_amendment="Before any Office-Home fit/outcome, replace use of archive result rows with explicit float64 mixing AND stable scoring from saved logits. All seven validation-only methods are recomputed; archive files are retained unchanged and every archive-versus-float64 difference is recorded. No training, grid, objective, sample or stage change.",
        input_amendment_sha256=sha(ROOT/"prespec/C1_dedup_v3.json"),literal_roles_spec_sha256=sha(ROOT/"prespec/C1_roles_manifest_v3.json"),
        roles_manifest_sha256=literal["manifest_sha256"],pilot_ids=literal["pilot"],
        design="Two fixed v3 rotation00/seed0 units, Art then Clipart. Original known-NLL early stop3/max20epochs, same adapter/loss/optimizer/prompts/stable scoring; only the approved manifest-level input curation changes.",
        samples="35known/15validation-unknown/15target-unknown. Two source domains each10known files/class; validation350known/150unknown nominal files. Target all retained role files. Report unique-content counts as well as nominal counts; same-domain/same-category duplicates remain. No IID or target-recall guarantee.",
        metrics="All six named variants plus validation-FPR-tuned energy, both pilots, including adverse outcomes. Mix, autoMixTemp and all other methods use explicit float64 logit mixing/score arithmetic in the reported post-evaluation. Unit wall time measures process startup, training and primary archive evaluation; postprocessing/hash verification measured separately and combined. Timings are measured, not extrapolated estimates.",
        fixtures="Before GPU use verify all60planned literal sample assignments route exactly through the training sampler, including source-unknown fallback returning empty and validation/target unknown identity separation. No model inference in fixture.",
        gates="Require completed C3b, eligible v3, all source hashes and seals. One global GPU lock. Stop on error, partial output or pause marker; no fallback/resampling. Only two pilots run. Remaining18seed0 and seed1/2 require later approval based on time/resources, never outcome direction.",
        code_hashes={p.relative_to(ROOT).as_posix():sha(p) for p in files})
    p=ROOT/"prespec/C1_pilot_v3_eval64.json"
    if p.exists():assert read(p)==spec
    else:
        with p.open("x",encoding="utf-8") as f:json.dump(spec,f,indent=2)
        with (ROOT/"prespec/C1_pilot_v3_eval64_seal.json").open("x",encoding="utf-8") as f:json.dump(dict(task="C1_pilot_v3_eval64",sha256=sha(p)),f,indent=2)
    return spec,literal


def fixtures(plan):
    exclusions=set(read(WORK/"exclusion_manifest.json")["paths"]);checked=[]
    for unit in plan["units"]:
        known=sorted(unit["known"]);unknown=unit["validation_unknown"]+unit["target_unknown"]
        sources=[d for d in plan["domains"] if d not in [unit["target"],unit["val"]]]
        routed_train=[r for d in sources for r in selected_rows(unit,d,known)]
        routed_vk=selected_rows(unit,unit["val"],known)
        routed_uv=selected_rows(unit,unit["val"],unit["validation_unknown"])
        routed_test=selected_rows(unit,unit["target"],known)+selected_rows(unit,unit["target"],unit["target_unknown"])
        routed=dict(train=routed_train,val_known=routed_vk,val_unknown=routed_uv,test=routed_test)
        for role,rows in routed.items():
            assert rows==[(r["path"],r["category"]) for r in unit["roles"][role]],(unit["unit_id"],role)
            assert not (set(p for p,c in rows)&exclusions)
        assert all(selected_rows(unit,d,unknown)==[] for d in sources)
        assert not selected_rows(unit,unit["val"],unit["target_unknown"])
        assert not selected_rows(unit,unit["target"],unit["validation_unknown"])
        assert len(routed_train)==700 and len(routed_vk)==350 and len(routed_uv)==150
        checked.append(unit["unit_id"])
    dump(ROOT/"evidence/C1_pilot_v3_eval64_fixture_checks.json",dict(passed=True,CPU_only=True,model_inference=False,
        assignments_checked=len(checked),unit_ids=checked,exact_ordered_manifest_routing=True,excluded_paths_absent=True,
        prespec_sha256=sha(ROOT/"prespec/C1_pilot_v3_eval64.json")))


def verify_exact_labels(run,unit):
    labels={c:i for i,c in enumerate(read(run/"class_map.json")["known"])}
    for role,expected in unit["roles"].items():
        actual=read(run/(role+"_samples.json"))
        assert [(r["path"].replace("\\","/"),r["label"]) for r in actual]==[(r["path"],labels.get(r["category"],-1)) for r in expected],role


def report(rows):
    lines=["# Office Home v3 两单元计时试点报告","","## 1 做了什么","完成两个已授权 v3 计时单元，未启动剩余18单元或后续种子。","","## 2 文件位置",
        "evidence/C1_pilot_v3_eval64.json；new_runs/officehome/dedup_v3/pilot_eval64；prespec/C1_pilot_v3_eval64.json。","","## 3 实测数据与 JSON 来源",
        "下表均从 evidence/C1_pilot_v3_eval64.json 读取实际 perf_counter 时间，不是排程估算。所有方法指标均在同一文件保留，不按结果选择是否扩大阶段。","",
        "| 单元 | 实际 epoch | 训练及主评估 秒 | 附加处理 秒 | 合计 秒 |","| --- | ---: | ---: | ---: | ---: |"]
    for row in rows:lines.append(f"| {row['unit']} | {row['epochs']} | {row['training_and_primary_evaluation_seconds']:.2f} | {row['additional_postprocessing_seconds']:.2f} | {row['measured_unit_pipeline_seconds']:.2f} |")
    lines += ["","## 4 对结论的影响","两单元主要用于计时，不代表完整 Office-Home 面板。验证未知150张为名义文件数；唯一内容数逐单元报告。10-shot预算和已去重输入版本与 PACS 主面板不同，不混合推断，不声称部署召回保证。","","## 5 需要用户决定的事",
        "请依据实测耗时和资源决定是否授权阶段1剩余18单元；若执行则完成全部预设20单元，不因试点效果改变范围。seed1/2仍需单独确认。NegLabel 按已授权顺序接续，不替代 Office-Home 阶段决定。"]
    (ROOT/"reports/C1_v3稳定评分计时试点报告.md").write_text("\n".join(lines)+"\n",encoding="utf-8")


def main():
    spec,literal=freeze();manifest=ROOT/literal["manifest"]
    assert sha(manifest)==literal["manifest_sha256"]
    plan=read(manifest);assert plan["training_eligible"]
    for name,h in spec["code_hashes"].items():assert sha(ROOT/name)==h
    fixtures(plan)
    numerical_fixtures(ROOT)
    if "--prepare-only" in sys.argv:print("v3 pilot sealed and exact sampler routing checked; no GPU use.");return
    assert read(ROOT/"evidence/C3b_progress.json")["stage"]=="complete_requires_manuscript_integration"
    assert read(ROOT/"evidence/C1_dedup_v3.json")["training_eligible"]
    lock=ROOT/"new_runs/GPU_QUEUE.lock"
    with lock.open("x") as f:f.write(str(os.getpid()))
    done=0;rows=[]
    try:
        for uid in plan["pilot"]:
            if (ROOT/"new_runs/PAUSE_REQUESTED").exists():state("paused_at_unit_boundary",completed=done,total=2);return
            unit=next(u for u in plan["units"] if u["unit_id"]==uid);run=WORK/"pilot_eval64"/uid
            timing=WORK/"pilot_eval64"/(uid+"_timing.json");log=WORK/"pilot_eval64"/(uid+".log")
            run.parent.mkdir(parents=True,exist_ok=True)
            if run.exists() and not timing.exists():raise RuntimeError("Partial v3 pilot needs inspection: "+uid)
            if not run.exists():
                command=[sys.executable,"-B","-s","-u",str(ROOT/"scripts/officehome_train_v3.py"),"--data_root",plan["data_root"],
                    "--target_domain",unit["target"],"--val_domain",unit["val"],"--unknown_classes",",".join(unit["validation_unknown"]+unit["target_unknown"]),
                    "--calibration_unknown_classes",",".join(unit["validation_unknown"]),"--target_unknown_classes",",".join(unit["target_unknown"]),
                    "--seed","0","--model","ViT-B-32","--epochs","20","--early_stop","3","--early_stop_metric","known_nll",
                    "--batch_size","64","--lr","2e-5","--hidden_ratio","0.0625","--max_scale","0.05","--cos_reg","0.2","--amp",
                    "--num_workers","0","--openclip_cache_dir","C:/icip_osr/.cache/clip","--templates",
                    "a photo of a {}|a sketch of a {}|a cartoon of a {}|a painting of a {}"]
                dump(WORK/"pilot_eval64"/(uid+"_launch.json"),dict(command=command,unit=uid,roles_manifest_sha256=literal["manifest_sha256"],
                    prespec_sha256=sha(ROOT/"prespec/C1_pilot_v3_eval64.json")))
                state("training",completed=done,total=2,current=uid);start=time.perf_counter()
                with log.open("x",encoding="utf-8") as f:
                    subprocess.run(command,cwd=WORK,env=dict(os.environ,PAPER2_RUN_DIR=str(run),OFFICEHOME_UNIT_ID=uid,PYTHONDONTWRITEBYTECODE="1"),
                        stdout=f,stderr=subprocess.STDOUT,check=True)
                wall=time.perf_counter()-start;start=time.perf_counter()
                verify_samples(run,unit,plan["data_root"]);verify_exact_labels(run,unit)
                for name,h in read(run/"artifact_hashes.json").items():assert sha(run/name)==h
                results=evaluate_stable(run,run.parent/(uid+"_stable_evaluation"))
                post=time.perf_counter()-start
                measured=dict(unit=uid,protocol_version="C1_dedup_v3",epochs=len((run/"epochs.jsonl").read_text().splitlines()),
                    training_and_primary_evaluation_seconds=wall,additional_postprocessing_seconds=post,measured_unit_pipeline_seconds=wall+post,
                    sample_counts={k:len(v) for k,v in unit["roles"].items()},
                    unique_content_counts={k:len({r["sha256"] for r in v}) for k,v in unit["roles"].items()},
                    roles_manifest_sha256=literal["manifest_sha256"],results=results)
                dump(timing,measured)
            rows.append(read(timing));done+=1;state("unit_complete",completed=done,total=2,current=uid)
        dump(ROOT/"evidence/C1_pilot_v3_eval64.json",dict(task="C1_pilot_v3_eval64",protocol_version="C1_dedup_v3",records=rows,
            prespec_sha256=sha(ROOT/"prespec/C1_pilot_v3_eval64.json"),roles_manifest_sha256=literal["manifest_sha256"],
            mean_training_and_primary_evaluation_seconds=sum(r["training_and_primary_evaluation_seconds"] for r in rows)/len(rows),
            mean_unit_pipeline_seconds=sum(r["measured_unit_pipeline_seconds"] for r in rows)/len(rows),
            stage1_remaining18_authorized=False,stage2_authorized=False,not_pooled_with_PACS=True,no_IID_inference=True))
        report(rows);state("complete_awaiting_stage1_user_decision",completed=done,total=2,remaining_stage1_units=18)
    except Exception as exc:state("failed_requires_inspection",completed=done,total=2,error=repr(exc));raise
    finally:lock.unlink(missing_ok=True)


if __name__=="__main__":main()

