"""Replay the affected CIFAR conditional statistics; retain invariant PACS draws."""
from collections import defaultdict
from pathlib import Path
import sys
import numpy as np
from gap_closure_core import ROOT,BASE,read,sha,write,identities,sample_hashes,cache_path
sys.path.insert(0,str(BASE/"tools"))
from image_resampling_sensitivity import prepared,weighted_metrics


def main():
    path=ROOT/"prespec/E0_conditional_reconciliation.json";spec=read(path)
    assert sha(path)==read(path.with_name("E0_conditional_reconciliation_seal.json"))["sha256"]
    for name,digest in spec["code_hashes"].items():assert sha(name)==digest,name
    geometry=read(ROOT/"evidence/E0_ROC_geometry.json")
    assert sha(ROOT/"evidence/E0_ROC_geometry.json")==spec["geometry_sha256"]
    assert geometry["primary_PACS_all_weighted_ROC_invariant"]
    old=read(ROOT/"evidence/B6.json");diagnostics=read(ROOT/"evidence/diagnostics.json")
    lookup=identities("cifar10");index={h:i for i,h in enumerate(sorted(set(lookup.values())))}
    units=[];cache=[];clusters=[]
    for uid in sorted({r["unit"] for r in read(ROOT/"evidence/E0_precision.json")["records"] if r["model"]=="ViT-B32" and r["dataset"]=="cifar10"}):
        directory=BASE/"05_new_runs/cifar10"/uid
        ids=np.array([index[h] for h in sample_hashes(directory,"test_samples.json",lookup)])
        with np.load(cache_path("ViT-B32","cifar10",uid),allow_pickle=False) as z:a={k:z[k] for k in z.files}
        with np.load(BASE/"04_analysis/stable_score_cache/primary/cifar10"/(uid+".npz"),allow_pickle=False) as z:
            a["Energy-only-T1"]=z["Energy-only-T1"]
        y=(a["target_labels"]<0).astype(int)
        cc={m:prepared(a[m],y,ids) for m in ["MSP","Temp-MSP","autoMixTemp","Energy-only-T1"]}
        units.append(uid);cache.append(cc);clusters.append(uid.rsplit("_seed",1)[0])
    assert len(units)==15 and len(set(clusters))==5
    observed=[]
    for uid,cluster,cc in zip(units,clusters,cache):
        baseline={m:weighted_metrics(cc[m],np.ones(len(index))) for m in ["MSP","Temp-MSP","autoMixTemp"]}
        for ref in ["MSP","Temp-MSP"]:
            d=baseline["autoMixTemp"]-baseline[ref]
            observed.append(dict(unit=uid,cluster=cluster,comparator=ref,delta_auroc=float(d[0]),delta_fpr95=float(d[1])))
    cluster_rows=[];summary=[]
    for ref in ["MSP","Temp-MSP"]:
        for cluster in sorted(set(clusters)):
            rs=[r for r in observed if r["cluster"]==cluster and r["comparator"]==ref];assert len(rs)==3
            cluster_rows.append(dict(dataset="cifar10",cluster=cluster,seeds=3,comparator=ref,
                delta_auroc=float(np.mean([r["delta_auroc"] for r in rs])),delta_fpr95=float(np.mean([r["delta_fpr95"] for r in rs]))))
        for metric in ["delta_auroc","delta_fpr95"]:
            values=np.array([r[metric] for r in cluster_rows if r["comparator"]==ref])
            deleted=(values.sum()-values)/4
            summary.append(dict(dataset="cifar10",comparator=ref,metric=metric,clusters=5,mean=float(values.mean()),
                lower=int((values<0).sum()),higher=int((values>0).sum()),tied=int((values==0).sum()),
                leave_one_out_min=float(deleted.min()),leave_one_out_max=float(deleted.max())))
    draws=defaultdict(list);rng=np.random.default_rng(20261118)
    for i in range(400):
        weights=rng.poisson(1,len(index));baseline=np.stack([weighted_metrics(cc["MSP"],weights) for cc in cache])
        for method in ["Temp-MSP","autoMixTemp","Energy-only-T1"]:
            draws[method].append((np.stack([weighted_metrics(cc[method],weights) for cc in cache])-baseline).mean(0))
        if i%100==0:print("CIFAR corrected conditional draws "+str(i)+"/400",flush=True)
    intervals=[]
    for method,values in draws.items():
        a=np.array(values)
        for j,metric in enumerate(["delta_auroc","delta_fpr95"]):
            intervals.append(dict(method=method,metric=metric,lower=float(np.quantile(a[:,j],.025)),median=float(np.quantile(a[:,j],.5)),upper=float(np.quantile(a[:,j],.975))))
    output=ROOT/"evidence/E0_conditional_cifar_draws.npz";assert not output.exists()
    np.savez_compressed(output,**{m:np.array(v) for m,v in draws.items()})
    write(ROOT/"evidence/E0_conditional_reconciliation.json",dict(all_checks_pass=True,
        cluster_records=[r for r in old["cluster_records"] if r["dataset"]=="pacs"]+cluster_rows,
        summary=[r for r in old["summary"] if r["dataset"]=="pacs"]+summary,
        pacs_intervals=old["intervals"],
        image_intervals={"pacs":diagnostics["datasets"]["pacs"]["conditional_image_intervals"],"cifar10":intervals},
        pacs_preservation="Every primary PACS positive-negative score order/tie is exactly invariant. Thus the pre-existing common-image weights, cluster and joint ROC functionals are retained. This proof does not cover probabilities or numeric threshold values.",
        cifar_replay="All15 primary units, same complete-tie weighted metric, sorted full-inventory content hashes,400 Poisson1 draws, generator seed20261118. No cluster/population confidence interval on fiveclusters.",
        draw_sha256=sha(output),geometry_sha256=sha(ROOT/"evidence/E0_ROC_geometry.json"),
        original_B6_sha256=sha(ROOT/"evidence/B6.json"),original_diagnostics_sha256=sha(ROOT/"evidence/diagnostics.json"),
        audit_spec_sha256=sha(path),no_training=True,no_encoder_inference=True,no_target_selection=True,
        conditional_on_fixed_fits=True,no_IID_population_inference=True),exclusive=True)
    print("Affected conditional/cluster evidence reconciled; original files preserved.",flush=True)


if __name__=="__main__":main()
