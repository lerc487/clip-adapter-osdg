"""Readable aggregate supplement; complete units remain in JSON/CSV."""
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/"source"
sys.path.insert(0,str(ROOT/"scripts"))
import integrate_results as I


def main():
    I.REG=I.read(ROOT/"evidence/number_registry.json");I.MACROS=[]
    lines=[r"\documentclass[10pt]{article}",r"\usepackage[margin=.7in]{geometry}",r"\usepackage{booktabs,graphicx,longtable,amsmath}",r"\input{numbers_revision2}",r"\renewcommand{\thetable}{S\arabic{table}}",r"\renewcommand{\thefigure}{S\arabic{figure}}",r"\begin{document}",r"\begin{center}\Large Supplementary Analyses\end{center}",
        "Numerical Stability and Threshold Transfer in Validation-Tuned Open-Set Detection. Complete unit-level data, all variants, frozen designs and scripts accompany this document. Panels are never pooled across datasets or architectures."]
    def table(caption,head,rows,cols):
        lines.extend([r"\begin{table}[htbp]\centering\small",r"\caption{"+caption+"}",r"\begin{tabular}{"+cols+"}\\toprule",head+r"\\\midrule"]+[" & ".join(r)+r"\\" for r in rows]+[r"\bottomrule\end{tabular}\end{table}"])
    rows=[]
    for i,r in enumerate(I.ptr("B1","policy_summary")):
        rows.append([r["model"],r["dataset"],I.n("B1",("policy_summary",i,"delta"),2),"Interior" if r["gate"]=="interior_only" else "Any source",I.n("B1",("policy_summary",i,"enabled"),0),I.n("B1",("policy_summary",i,"delta_fpr95"),sign=True),I.n("B1",("policy_summary",i,"delta_auroc"),sign=True)])
    table("All prespecified validation gates relative to Temp-MSP. Gain must strictly exceed delta; zero-enabled rules retain Temp-MSP.",r"Model & Dataset & $\delta$ & Gate & Enabled & $\Delta$FPR@95 & $\Delta$AUROC",rows,"llrlrrr")
    lines.append(r"\clearpage")
    for ds in ["pacs","cifar10"]:
        rows=[]
        for i,r in enumerate(I.ptr("B2","summary")):
            if r["model"]!="ViT-B32" or r["dataset"]!=ds:continue
            rows.append([r["method"],I.n("B2",("summary",i,"rho"),3),"Worst" if r["policy"]=="worst_class" else "Pooled"]+[I.n("B2",("summary",i,k),3) for k in ["unknown_recall","known_rejection","accepted_known_accuracy","unknown_contamination","recall_gap"]])
        table(ds.upper()+" complete ViT-B/32 recall-policy scan. Fractions; contamination depends on the constructed test prevalence.",r"Score & $\rho$ & Policy & Recall & Rejection & Acc. & Contam. & Gap",rows,"lr lrrrrr")
        lines.append(r"\clearpage")
    lines += [r"\begin{figure}[htbp]\centering\includegraphics[width=\textwidth]{figures/acceptance_policy.pdf}",r"\caption{Accepted-known accuracy and accepted-unknown contamination across requested validation recall. Solid and dashed curves use pooled and worst-class thresholds. The classifier remains fixed.}\end{figure}",r"\clearpage"]
    rows=[]
    for i,r in enumerate(I.ptr("B4","summary")):
        temp="Limit" if r["variant"]=="limit" else I.n("B4",("summary",i,"temperature"),0)
        rows.append([r["model"],r["dataset"],temp]+[I.n("B4",("summary",i,k)) for k in ["auroc","fpr95","spearman_to_T1000","kendall_to_T1000"]])
    table("Finite high-temperature and limiting adapter scores; rank correlations are unit means relative to the T=1000 scores.",r"Model & Dataset & $T$ & AUROC & FPR@95 & Spearman & Kendall",rows,"lllrrrr")
    rows=[]
    for i,r in enumerate(I.ptr("B4","dense_summary")):
        rows.append([r["model"],r["dataset"],r["method"],I.n("B4",("dense_summary",i,"lower_count"),0)+"/"+I.n("B4",("dense_summary",i,"upper_count"),0)]+[I.n("B4",("dense_summary",i,k),sign=True) for k in ["delta_fpr_original","delta_fpr_expanded"]])
    table("Dense-grid boundary counts and FPR@95 changes relative to reference and expanded grids. Every grid remains reported.",r"Model & Dataset & Score & Lower/upper & $\Delta$ reference & $\Delta$ expanded",rows,"llllrr")
    lines.append(r"\clearpage")
    rows=[]
    for i,r in enumerate(I.ptr("B5","saturation_records")):
        rows.append([r["domain"].replace("_"," "),r["unit"].rsplit("seed",1)[1],I.n("B5",("saturation_records",i,"temperature"),1)]+[I.n("B5",("saturation_records",i,k),0) for k in ["zero_scores","boundary_tie_size"]]+[I.n("B5",("saturation_records",i,k)) for k in ["original_fpr95","stable_same_parameter_fpr95"]])
    table("PACS R4 saturation checks at the float32-selected parameters. Zero-score counts and the actual ROC boundary-tie size are different quantities.",r"Domain & Seed & $T$ & Zero scores & Boundary ties & Float32 FPR & Stable fixed FPR",rows,"lrrrrrr")
    rows=[]
    for i,r in enumerate(I.ptr("B6","summary")):
        rows.append([r["dataset"],r["comparator"],r["metric"].replace("_"," "),I.n("B6",("summary",i,"clusters"),0),I.n("B6",("summary",i,"mean"),sign=True),"/".join(I.n("B6",("summary",i,k),0) for k in ["lower","higher","tied"]),"["+I.n("B6",("summary",i,"leave_one_out_min"),sign=True)+", "+I.n("B6",("summary",i,"leave_one_out_max"),sign=True)+"]"])
    table("Both metrics for seed-averaged cluster summaries. L/H/T describes the sign of auto-minus-comparator changes; direction desirability differs between AUROC and FPR.",r"Dataset & Comparator & Metric & Clusters & Mean & L/H/T & LOO range",rows,"lllrrll")
    lines.append(r"\clearpage")
    rows=[]
    for i,r in enumerate(I.ptr("C3a","records")):
        if r["selector"]!="known_NLL" or r["method"]=="Energy-only-T1":continue
        domain=r["unit"].split("_rotation")[0].replace("_"," ")
        rows.append([domain,"NLL stop" if r["budget"]!="full20" else "Full20",r["method"],I.n("C3a",("records",i,"auroc")),I.n("C3a",("records",i,"fpr95"))])
    table("Exact four-unit PACS rotation00/seed0 counterparts under known-NLL checkpoint selection. The same roles, not the 84-unit overall mean, form the comparison.",r"Domain & Budget & Score & AUROC & FPR@95",rows,"lllrr")
    lines.append(r"\clearpage\section*{Historical submitted panel arithmetic check}")
    lines.append("This section concerns only the original 80-unit submitted panel, not the main disjoint-unknown panels. Its float32 files are unchanged. Stable fixed-parameter and validation-reselected calculations leave mean FPR@95 unchanged for the three scores; extremely small AUROC differences are shown rather than rounded away.")
    rows=[]
    for i,r in enumerate(I.ptr("B7","summary")):
        rows.append([r["method"],r["variant"].replace("_"," "),I.n("B7",("summary",i,"n"),0),I.n("B7",("summary",i,"auroc"),12),I.n("B7",("summary",i,"fpr95"),12)])
    table("Historical 80-unit arithmetic check. All variants are retained; this table is not part of the main manuscript's evidence panel.",r"Score & Arithmetic and selection & Units & AUROC & FPR@95",rows,"llrrr")
    lines.append(r"\clearpage\section*{Completed full-budget and negative-label controls}")
    lines.append("All three PACS checkpoint selectors are reported, on every seed0 domain/role combination. No target outcome selects an epoch. These are shared-loss/budget controls, not independently optimized detector training.")
    rows=[]
    for i,r in enumerate(I.ptr("C3b","summary")):
        selector={"known_NLL":"Known NLL","validation_MSP_AUROC":"MSP AUROC","validation_energy_AUROC":"Energy AUROC"}[r["selector"]]
        rows.append([selector,r["method"],I.n("C3b",("summary",i,"n"),0)]+[I.n("C3b",("summary",i,k)) for k in ["auroc","fpr95","frozen_unknown_recall","frozen_known_rejection"]])
    table("PACS full20 seed0 selector controls. Frozen-threshold recall and rejection accompany target ROC metrics.",r"Selector & Score & Units & AUROC & FPR@95 & Recall & Rejection",rows,"llrrrrr")
    lines.append("\n\nThe NegLabel port uses the pinned official-reference commit 3253db684075b2db47844676eccdfda40d67a573. Positive/noun prompts are `the nice \\{\\}', and adjectives use `This is a \\{\\} photo'. The cosine scale is 100, grouping temperature one and group count 100. Selection retains the least similar 15 percent of nouns and adjectives separately, using the 0.95 similarity quantile to known positive labels. Remainders are dropped before the official seed0 CUDA permutation. Group probability means are converted to float64 unknown log-odds. External WordNet is additional information, not a training-free substitute with an equal information budget.\n\n")
    lines.append("Same-input official-function tests pass for negative-label selection and probability grouping. The CUDA random-permutation grouping test also passes. This aligns functions, not an entire MMClassification/OpenAI-CLIP encoder pipeline. The port uses our OpenCLIP ViT-B/32 feature pipeline and does not reproduce published benchmark numbers. Literal benchmark-name token exclusion does not remove synonyms or all semantic leakage.")
    rows=[]
    for i,r in enumerate(I.ptr("C2_NegLabel","summary")):
        rows.append([r["dataset"],"Standard" if r["variant"]=="standard" else "Name-excluded",I.n("C2_NegLabel",("summary",i,"n"),0)]+[I.n("C2_NegLabel",("summary",i,k)) for k in ["auroc","fpr95","frozen_unknown_recall","frozen_known_rejection"]])
    table("Both prespecified negative-label vocabularies on the complete matched sample panels; all outcomes are retained.",r"Dataset & Vocabulary & Units & AUROC & FPR@95 & Recall & Rejection",rows,"llrrrrr")
    lines.append(r"\clearpage\section*{Office-Home input audit and timing pilot}")
    lines.append("The two fixed timing pilots below are provenance for the complete panel reported subsequently. They are included in the 20-unit result, not additional replications. Class roles use 35 known, 15 validation-unknown and 15 target-unknown categories. Each source domain supplies 10 files per known class; validation uses 350 known and 150 unknown files. Later seeds require separate authorization and have not run. Stage expansion was based on measured resources, not outcome direction.\n\n")
    lines.append("Before any Office-Home fitting, SHA256 groups spanning domains or class folders were excluded from the new manifest only; original files and earlier manifests were retained. Same-domain/same-category duplicates remain, so nominal counts differ from unique content counts. This is an exact-byte audit, not a near-duplicate or pretraining-exposure guarantee. Official dataset source: https://www.hemanthdv.org/officeHomeDataset.html.")
    rows=[]
    for key,label in [("original_images","Original files"),("excluded_images","Excluded in manifest"),("retained_images","Retained files"),("classes","Classes"),("minimum_images_per_domain_category","Minimum per domain/class")]:
        rows.append([label,I.n("C1_dedup_v3",(key,),0)])
    table("Office-Home v3 input-manifest counts. No physical image deletion.",r"Statistic & Count",rows,"lr")
    rows=[]
    for i,r in enumerate(I.ptr("C1_pilot_v3_eval64","records")):
        rows.append([r["unit"].split("_rotation")[0],I.n("C1_pilot_v3_eval64",("records",i,"epochs"),0),I.n("C1_pilot_v3_eval64",("records",i,"measured_unit_pipeline_seconds"),2),I.n("C1_pilot_v3_eval64",("records",i,"unique_content_counts","val_unknown"),0)])
    table("Measured timing pilots, including archive verification and postprocessing; unique unknown-validation contents versus 150 nominal files.",r"Target & Epochs & Seconds & Unique val. unknown",rows,"lrrr")
    rows=[]
    for i,r in enumerate(I.ptr("C1_pilot_v3_eval64","records")):
        for j,m in enumerate(r["results"]):
            rows.append([r["unit"].split("_rotation")[0],m["method"]]+[I.n("C1_pilot_v3_eval64",("records",i,"results",j,k)) for k in ["auroc","fpr95"]])
    table("Pilot outcomes for every prespecified score. Timing pilots are not the completed 20-unit benchmark and are not pooled with PACS/CIFAR-10.",r"Target & Score & AUROC & FPR@95",rows,"llrr")
    complete=I.ptr("C1_complete_panel_audit")
    assert complete["all_checks_pass"] and complete["n"]==20
    lines.append(r"\clearpage\section*{Complete Office-Home seed0 panel}")
    lines.append("Every frozen domain/role unit and every score is retained. Results use float64 mixing/stable scores, equal unit weights and the fixed adapter classifier. ROC FPR@95 is a test-label ranking metric; transferred recall/rejection use a validation threshold frozen before target scoring. These custom role schedules are not a reproduction of a published Office-Home domain-adaptation leaderboard.")
    rows=[]
    for i,r in enumerate(complete["summary"]):
        rows.append([r["method"]]+[I.n("C1_complete_panel_audit",("summary",i,k),4) for k in ["auroc","fpr95","known_acc","osr_acc","frozen_threshold_test_unknown_tpr","frozen_threshold_test_known_fpr"]])
    table("Complete Office-Home panel, all seven methods. Fractions; each row uses all 20 seed0 units. OSR accuracy uses the validation-maxF1 threshold; recall/rejection use validation-95 percent thresholds.",r"Score & AUROC & FPR@95 & Known acc. & OSR acc. & Recall & Rejection",rows,"lrrrrrr")
    rows=[]
    for domain in ["Art","Clipart","Product","Real World"]:
        for method in [r["method"] for r in complete["summary"]]:
            i=next(i for i,r in enumerate(complete["domain_summary"]) if r["target"]==domain and r["method"]==method)
            rows.append([domain,method,I.n("C1_complete_panel_audit",("domain_summary",i,"n"),0)]+[I.n("C1_complete_panel_audit",("domain_summary",i,k),4) for k in ["auroc","fpr95","frozen_threshold_test_unknown_tpr","frozen_threshold_test_known_fpr"]])
    table("All domain-level Office-Home descriptions. Each domain contains five role rotations at seed0; these are not independent population estimates.",r"Target & Score & Units & AUROC & FPR@95 & Recall & Rejection",rows,"llrrrrr")
    lines.append(r"\clearpage\section*{Office-Home unit choices and measured resources}")
    rows=[]
    for i,r in enumerate(complete["records"]):
        if r["method"]!="autoMixTemp":continue
        unit=r["unit"].replace("_rotation"," R").replace("_seed0","")
        j=next(j for j,p in enumerate(complete["paired_records"]) if p["unit"]==r["unit"] and p["comparator"]=="MSP")
        k=next(j for j,p in enumerate(complete["paired_records"]) if p["unit"]==r["unit"] and p["comparator"]=="Temp-MSP")
        rows.append([unit,r["selection"]["score_source"],I.n("C1_complete_panel_audit",("records",i,"selection","T_score"),1),
            I.n("C1_complete_panel_audit",("records",i,"selection","alpha"),2),
            I.n("C1_complete_panel_audit",("paired_records",j,"delta_fpr95"),4,sign=True),I.n("C1_complete_panel_audit",("paired_records",k,"delta_fpr95"),4,sign=True)])
    table("Every autoMixTemp source/temperature choice and target FPR change. Alpha is not applicable to explicit adapter/zero-shot endpoints. Negative FPR changes favor autoMixTemp; no target result selects a configuration.",r"Unit & Source & $T$ & $\alpha$ & $\Delta$ vs MSP & $\Delta$ vs Temp",rows,"llrrrr")
    rows=[]
    for i,r in enumerate(complete["units"]):
        rows.append([r["unit"].replace("_rotation"," R").replace("_seed0",""),I.n("C1_complete_panel_audit",("units",i,"epochs"),0),
            I.n("C1_complete_panel_audit",("units",i,"measured_pipeline_seconds"),2),I.n("C1_complete_panel_audit",("units",i,"unique_content","val_unknown"),0),
            I.n("C1_complete_panel_audit",("units",i,"unique_content","test"),0)])
    table("Measured per-unit processing seconds include the archived fitting/evaluation and its postprocessing, not idle intervals between tasks. Unique-content counts differ from nominal file counts; same-domain/same-category duplicates remain.",r"Unit & Epochs & Processing seconds & Unique val. unknown & Unique target",rows,"lrrrr")
    lines.append(r"\end{document}")
    lines.insert(lines.index(r"\begin{document}"),r"\raggedbottom\renewcommand{\topfraction}{.95}\renewcommand{\textfraction}{.02}\renewcommand{\floatpagefraction}{.7}\setcounter{topnumber}{4}\setcounter{totalnumber}{6}")
    (SRC/"supplement.tex").write_text("\n".join(lines),encoding="ascii")
    with (SRC/"numbers_revision2.tex").open("a",encoding="ascii") as f:f.write("\n".join(I.MACROS)+"\n")
    (ROOT/"evidence/number_registry.json").write_text(json.dumps(I.REG,indent=2),encoding="utf-8")
    print("Supplement generated with",len(I.REG),"total evidence-linked numeric cells.")


if __name__=="__main__":main()
