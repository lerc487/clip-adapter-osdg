"""Finite dependency chain: audit each authorized experiment once, then exit."""
from datetime import datetime,timezone
import os
import subprocess
import sys
import time
from gap_closure_core import ROOT,R2,read,sha,write


def status(stage,**kw):
    p=ROOT/"evidence/R5_independent_audit_queue.json";temp=p.with_suffix(".tmp")
    write(temp,dict(stage=stage,pid=os.getpid(),updated_utc=datetime.now(timezone.utc).isoformat(),**kw));temp.replace(p)


def paused():
    for root in [ROOT,R2]:
        marker=root/"new_runs/PAUSE_REQUESTED"
        if marker.exists():
            try:internal=read(marker).get("purpose")=="controlled_unit_boundary_yield_for_two_official_pilots"
            except Exception:internal=False
            if not internal:return True
    return False


def run(script,label):
    status("running_independent_cpu_audit",task=label)
    with (ROOT/"logs"/(label+"_independent_audit.log")).open("x",encoding="utf-8") as f:
        subprocess.run([sys.executable,"-B","-s","-u",str(ROOT/"scripts"/script)],cwd=ROOT,
            env=dict(os.environ,CUDA_VISIBLE_DEVICES="-1",PYTHONDONTWRITEBYTECODE="1"),stdout=f,stderr=subprocess.STDOUT,check=True)


def main():
    spec_path=ROOT/"prespec/R5_finite_audit_chain.json";spec=read(spec_path)
    assert sha(spec_path)==read(spec_path.with_name("R5_finite_audit_chain_seal.json"))["sha256"]
    for path,digest in spec["code_hashes"].items():assert sha(path)==digest,path
    complete=set()
    try:
        while len(complete)<3:
            if paused():status("paused_no_new_analysis_started",completed=sorted(complete));return
            for label,progress,result,script,audit in [
                ("E6","E6_pilot_progress.json","E6_pilot_results.json","r5_locoop_pilot_audit.py","E6_pilot_audit.json"),
                ("E5","E5_officehome_stage2_progress.json","E5_officehome_stage2_results.json","r5_officehome_full_audit.py","E5_officehome_full_audit.json"),
                ("E4","E4_target_progress.json","E4_target_results.json","r5_checkpoint_target_audit.py","E4_independent_audit.json")]:
                if label in complete:continue
                p=ROOT/"evidence"/progress
                if p.exists() and "failed" in read(p)["stage"]:
                    raise RuntimeError(label+" upstream task failed; no substitute or automatic retry")
                result_path=ROOT/"evidence"/result
                if not result_path.exists():continue
                if not (ROOT/"evidence"/audit).exists():run(script,label)
                assert read(ROOT/"evidence"/audit)["all_checks_pass"]
                if label=="E5":
                    if not (ROOT/"evidence/E5_content_dependence.json").exists():
                        run("r5_officehome_diagnostics.py","E5_diagnostics")
                    for name in ["E5_search_utility","E5_transfer_tradeoffs","E5_content_dependence"]:
                        assert read(ROOT/"evidence"/(name+".json"))["scope"].startswith("All60 Office-Home")
                complete.add(label)
            if len(complete)<3:
                status("waiting_for_remaining_authorized_outputs",completed=sorted(complete));time.sleep(30)
        status("all_authorized_outputs_audited_manuscript_integration_pending",completed=sorted(complete),
            loco_op_batch_not_authorized=True,upload_ready=False)
    except Exception as exc:
        status("failed_requires_inspection",completed=sorted(complete),error=repr(exc));raise


if __name__=="__main__":main()
