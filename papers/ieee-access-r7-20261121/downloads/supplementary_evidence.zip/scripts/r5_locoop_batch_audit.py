"""Independent CPU verification of all official batch scores and known-only choices."""
import sys
from pathlib import Path
import numpy as np

from r5_locoop_batch_common import ROOT, BASE, SPEC, INPUTS, METHODS, sealed, unit_inputs, read, write, sha, grouped, now
from r5_independent_audit_helpers import roc, check, fixtures


def audit_unit(spec, job):
    original = Path(unit_inputs(spec, job)["input_run"])
    output = Path(job["output"])
    record = read(output / "results.json")
    expected_spec = spec["pilot_prespec_sha256"] if job["reused_pilot"] else sha(SPEC)
    assert record["prespec_sha256"] == expected_spec
    assert record["dataset"] == job["dataset"] and record["unit"] == job["unit"]
    if job["reused_pilot"]:
        assert sha(output / "results.json") == job["pilot_result_sha256"]
    else:
        assert record["fit_id"] == job["fit_id"] and record["lambda_value"] == job["lambda_value"]
    cfg = read(output / "config.json")
    import hashlib
    assert hashlib.sha256(cfg["yaml"].encode("utf-8")).hexdigest() == job["config_sha256"]
    choice = read(output / "checkpoint_choice_frozen.json")
    frozen = read(output / "validation_thresholds_frozen.json")
    assert len(record["epochs"]) == 50 and [r["epoch"] for r in record["epochs"]] == list(range(1, 51))
    best = min(record["epochs"], key=lambda r: (r["known_validation_nll"], r["epoch"]))
    assert best["epoch"] == choice["epoch"] == record["best_epoch"]
    assert best["known_validation_nll"] == choice["known_validation_nll"]
    assert sha(choice["checkpoint_file"]) == choice["checkpoint_sha256"]
    assert frozen["checkpoint_choice_sha256"] == sha(output / "checkpoint_choice_frozen.json")
    nll_error = 0.
    trace_count = 0
    expected_labels = [r["label"] for r in read(original / "val_known_samples.json")]
    checkpoint_hashes = []
    for epoch in record["epochs"]:
        checkpoint = output / "prompt_learner" / ("model.pth.tar-" + str(epoch["epoch"]))
        digest = sha(checkpoint)
        checkpoint_hashes.append(digest)
        if not job["reused_pilot"]:
            assert digest == epoch["checkpoint_sha256"]
            p = Path(epoch["validation_logits_file"])
            assert p == output / "known_validation_trace" / ("epoch_%02d.npz" % epoch["epoch"])
            assert sha(p) == epoch["validation_logits_sha256"]
            with np.load(p, allow_pickle=False) as z:
                x = z["global_logits"].astype(np.float64)
                labels = z["labels"]
                assert z["batch_sizes"].sum() == len(labels)
            np.testing.assert_array_equal(labels, expected_labels)
            nll = float(np.mean(np.logaddexp.reduce(x, axis=1) - x[np.arange(len(x)), labels]))
            error = abs(nll - epoch["known_validation_nll"])
            assert error <= 1e-5, (job["fit_id"], epoch["epoch"], error)
            check(nll, epoch["float64_diagnostic_nll"], (job["fit_id"], "trace NLL"), 1e-11)
            nll_error = max(nll_error, error)
            trace_count += 1
    path = output / "saved_logits_and_scores.npz"
    assert sha(path) == record["saved_arrays_sha256"]
    with np.load(path, allow_pickle=False) as z:
        a = {key: z[key] for key in z.files}
    score_errors = []
    for role in ["val_known", "val_unknown", "test"]:
        np.testing.assert_array_equal(a[role + "_labels"], [s["label"] for s in read(original / (role + "_samples.json"))])
        g = a[role + "_global_logits"].astype(np.float64) / 100.
        l = a[role + "_local_logits"].astype(np.float64) / 100.
        maximum = g.max(1)
        other = g.copy()
        other[np.arange(len(g)), g.argmax(1)] = -np.inf
        mcm = np.logaddexp.reduce(other, axis=1) - maximum
        gp = maximum - np.logaddexp.reduce(g, axis=1)
        lp = (l - np.logaddexp.reduce(l, axis=2)[..., None]).max(axis=(1, 2))
        gl = -(np.exp(gp) + np.exp(lp))
        for method, calculated in [("MCM64", mcm), ("GLMCM64", gl)]:
            error = float(np.max(np.abs(calculated - a[role + "_" + method])))
            assert error <= 1e-12, (job["fit_id"], role, method, error)
            score_errors.append(error)
        gf = a[role + "_global_logits"].astype(np.float32) / np.float32(100.)
        lf = a[role + "_local_logits"].astype(np.float32) / np.float32(100.)
        gp = np.exp(gf - gf.max(1, keepdims=True))
        gp /= gp.sum(1, keepdims=True)
        lp = np.exp(lf - lf.max(2, keepdims=True))
        lp /= lp.sum(2, keepdims=True)
        for method, calculated in [("MCM_official", -gp.max(1)), ("GLMCM_official", -gp.max(1) - lp.max(axis=(1, 2)))]:
            error = float(np.max(np.abs(calculated - a[role + "_" + method])))
            assert error <= 1e-6, (job["fit_id"], role, method, error)
        assert all(np.isfinite(a[role + "_" + method]).all() for method in METHODS)
    assert all(r["passed"] for r in record["official_score_alignment"])
    vy = np.r_[np.zeros(len(a["val_known_labels"]), dtype=int), np.ones(len(a["val_unknown_labels"]), dtype=int)]
    ty = a["test_labels"]
    y = (ty < 0).astype(int)
    known = y == 0
    pred = a["test_global_logits"].argmax(1)
    rows = []
    assert {r["method"] for r in record["results"]} == set(METHODS)
    for archived in record["results"]:
        method = archived["method"]
        sv = np.r_[a["val_known_" + method], a["val_unknown_" + method]]
        st = a["test_" + method]
        threshold = roc(sv, vy)["threshold"]
        check(threshold, frozen["thresholds"][method], (job["fit_id"], method, "threshold"))
        check(threshold, archived["validation95_threshold"], (job["fit_id"], method, "reported threshold"))
        values = roc(st, y)
        reject = st >= threshold
        calculated = dict(auroc=values["auroc"], fpr95=values["fpr95"],
            frozen_unknown_recall=float(reject[~known].mean()), frozen_known_rejection=float(reject[known].mean()),
            known_accuracy=float((pred[known] == ty[known]).mean()))
        for key, value in calculated.items():
            check(value, archived[key], (job["fit_id"], method, key), 1e-11)
        rows.append(dict(dataset=job["dataset"], unit=job["unit"], lambda_value=job["lambda_value"],
            method=method, reused_pilot=job["reused_pilot"], **calculated))
    return dict(all_checks_pass=True, fit_id=job["fit_id"], dataset=job["dataset"], unit=job["unit"],
        lambda_value=job["lambda_value"], reused_pilot=job["reused_pilot"], records=rows,
        best_epoch=best["epoch"], all50_checkpoints_sha256=checkpoint_hashes,
        raw_known_validation_trace_epochs_verified=trace_count, max_float64_vs_recorded_float32_nll_error=nll_error,
        max_stable_score_error=max(score_errors), result_sha256=sha(output / "results.json"),
        saved_arrays_sha256=sha(path), config_sha256=job["config_sha256"],
        measured_processing_seconds=record["measured_pipeline_seconds"], prespec_sha256=sha(SPEC))


def main():
    fixture = fixtures()
    spec = sealed()
    if "--fixtures" in sys.argv:
        print("Independent batch complete-tie ROC fixtures passed; no training or inference.")
        return
    assert read(ROOT / "evidence/E6_locoop_batch_progress.json")["completed_new"] == 64
    records = []
    audits = []
    for job in spec["jobs"]:
        audit = audit_unit(spec, job)
        records.extend(audit["records"])
        audits.append({key: value for key, value in audit.items() if key != "records"})
        print("Full independent audit " + job["fit_id"], flush=True)
    assert len(audits) == 66 and len(records) == 264
    inputs = read(INPUTS)
    for item in inputs["images"]:
        assert sha(item["absolute_path"]) == item["sha256"], item["absolute_path"]
    fields = ["auroc", "fpr95", "frozen_unknown_recall", "frozen_known_rejection", "known_accuracy"]
    summary = grouped(records, ["dataset", "lambda_value", "method"], fields)
    assert all(r["n"] == (28 if r["dataset"] == "pacs" else 5) for r in summary)
    facts = read(ROOT / "evidence/E0_precision.json")["records"]
    paired = []
    for row in records:
        for comparator in ["MSP", "Temp-MSP", "autoMixTemp"]:
            reference = next(r for r in facts if (r["model"], r["dataset"], r["unit"], r["method"]) ==
                ("ViT-B32", row["dataset"], row["unit"], comparator))
            paired.append(dict(dataset=row["dataset"], unit=row["unit"], lambda_value=row["lambda_value"],
                method=row["method"], comparator=comparator, delta_auroc=row["auroc"] - reference["auroc"],
                delta_fpr95=row["fpr95"] - reference["fpr95"], delta_recall=row["frozen_unknown_recall"] - reference["recall"],
                delta_rejection=row["frozen_known_rejection"] - reference["rejection"]))
    result = dict(all_checks_pass=True, fits=66, new_fits=64, reused_pilots=2, distinct_sample_role_units=33,
        method_fit_rows_verified=264, lambda_values=[.1, .25], records=records, summary=summary, fits_audit=audits,
        paired_records=paired, paired_summary=grouped(paired, ["dataset", "lambda_value", "method", "comparator"],
            ["delta_auroc", "delta_fpr95", "delta_recall", "delta_rejection"]),
        raw_known_validation_trace_epochs_verified=sum(a["raw_known_validation_trace_epochs_verified"] for a in audits),
        reused_pilot_NLL_audit_scope="Two original pilots: recorded50-epoch NLL trace and checkpoint hash; no saved per-epoch raw known logits. New64fits retain and verify all50raw known-validation arrays each.",
        raw_image_paths_reverified=len(inputs["images"]), prespec_sha256=sha(SPEC), inputs_sha256=sha(INPUTS),
        official_trainer_unmodified=True, target_based_lambda_selection=False, lambda_panels_not_pooled=True,
        independent_retraining_or_IID_population_inference=False, different_prompt_vs_adapter_training_budget=True,
        generated_utc=now(), upload_ready=False)
    write(ROOT / "evidence/E6_locoop_batch_audit.json", result, exclusive=True)
    lines = ["# E6 官方LoCoOp双lambda完整比较核验报告", "", "## 1. 做了什么", "",
        "完整保留PACS28/CIFAR5个seed0角色单元及lambda=0.1/0.25两个预设面板，共66次拟合，其中复用2次试点、新增64次。全部264条得分结果独立CPU核验，未按目标结果选择lambda或删去不利变体。", "",
        "## 2. 文件和章节", "", "`E6_locoop_batch_audit.json`、`E6_locoop_batch_results.json`、冻结设计及输入清单。对应R3.4基线比较；核验完成后仍需入稿和刷新正式回复/表图编号。", "",
        "## 3. 实际数字及JSON来源", "", "| Data | lambda | Score | n | AUROC | FPR@95 | Target recall | Known rejection |",
        "| --- | --- | --- | --- | --- | --- | --- | --- |"]
    for row in summary:
        lines.append("| " + " | ".join([row["dataset"], str(row["lambda_value"]), row["method"], str(row["n"])] +
            [format(row[key], ".6f") for key in fields[:4]]) + " |")
    lines += ["", "所有数值来自审核JSON的summary；两个lambda不合并为独立重复。每次实际耗时在fits_audit中，先前23.1小时只是试点外推。", "",
        "## 4. 有利还是不利", "", "所有方向的比较保留在paired_summary，不据目标表现挑选lambda。LoCoOp独立训练提示、最多50轮；adapter最多20轮，两者训练损失、增强和预算不同。匹配的是样本角色，不是训练成本或公开榜单数字。不能据此保证部署召回或录用。", "",
        "## 5. 需要作者决定的事", "", "本批范围按授权全部执行；无需按结果扩缩样本。论文、正式逐条回复、源包/高亮稿及完整质量检查完成后，仍由作者决定是否提交。"]
    (ROOT / "reports/E6_官方LoCoOp双lambda完整比较核验报告.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    print("All66 fits and264 score rows independently verified; manuscript integration remains required.")


if __name__ == "__main__":
    main()
