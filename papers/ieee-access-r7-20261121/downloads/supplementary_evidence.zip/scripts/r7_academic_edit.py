"""Minimal scientific-writing edits; immutable evidence, tables and methods remain."""
from pathlib import Path
import hashlib
import json
import re

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT.parent / "revision6_editorial_closeout_20261120"
EDITS = []

def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def dump(path, value): Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding="utf-8")
def replace(task, file, before, after, reason, invariant):
    path = ROOT / "source" / file
    text = path.read_text(encoding="utf-8")
    assert text.count(before)==1, (task,file,text.count(before))
    path.write_text(text.replace(before,after),encoding="utf-8")
    EDITS.append(dict(id=task,file="source/"+file,before=before,after=after,
                      rationale=reason,scientific_content_preserved=invariant))
def section_paragraph(start, end):
    text=(ROOT/"source/body_revision.tex").read_text(encoding="utf-8")
    return text[text.index(start):text.index(end,text.index(start))]

def main():
    inputs = [p for folder in ["source","evidence","final_review_20261120"] for p in (OLD/folder).rglob("*") if p.is_file()]
    dump(ROOT/"evidence/G0_R6_protected_inputs.json",[dict(path=str(p),sha256=sha(p)) for p in inputs])
    src=ROOT/"source/manuscript.tex"
    abstract=src.read_text(encoding="utf-8").split(r"\begin{abstract}")[1].split(r"\end{abstract}")[0].strip()
    new_abstract=(
        "Stable log-odds remove subtractive-score ties, separating numerical fidelity from detection ranking and threshold transfer. "
        "We audit frozen Contrastive Language--Image Pretraining (CLIP)-Adapter checkpoints on 84 PACS and 15 CIFAR-10 units with disjoint validation and target unknown classes. "
        "Relative to maximum softmax probability (MSP), autoMixTemp changes area under the receiver operating characteristic curve (AUROC)/false-positive rate at 95\\% unknown recall (FPR@95) by \\AbsPACSAUC{}/\\AbsPACSFPR{} on PACS and \\AbsCIFARAUC{}/\\AbsCIFARFPR{} on CIFAR-10. "
        "Frozen validation thresholds attain target recall \\PACSAutoRecall{} and \\CIFARAutoRecall{}. "
        "A separate three-seed, 60-unit Office-Home panel yields AUROC/FPR@95 \\OHAUC{}/\\OHFPR{} and recall/known rejection \\OHRecall{}/\\OHReject{}; its small advantage over temperature-only scoring accompanies lower recall. "
        "Controls include a second CLIP backbone, full-budget and detector-specific checkpoint selection, negative-label detection, and 66 official Local regularized Context Optimization (LoCoOp) prompt fits on matched seed0 roles at two fixed regularization weights. "
        "Some controls outperform autoMixTemp. Probability diagnostics show poorer reliability, and validation gates identify no consistent interior-mixing benefit. "
        "The fixed-fit audit thus distinguishes ranking gains from probability reliability and transferred high recall.")
    replace("M01","manuscript.tex",abstract,new_abstract,
            "Lead with the numerical finding and remove the repeated list of capabilities not claimed.",
            "Every reported panel, outcome macro, comparator scope and adverse abstract finding is retained; no new algorithm or deployment claim.")
    replace("M02","body_revision.tex",
        "Open-set recognition rejects categories outside a classifier's known labels~\\cite{scheirer2013,bendale2016,geng2021}. Detection ranking, known-class probability reliability, and transfer of a validation threshold are different properties. Improving the test receiver operating characteristic (ROC) false-positive rate at 95\\% unknown recall (FPR@95) does not establish transferable high recall.",
        "Open-set recognition rejects categories outside a classifier's known labels~\\cite{scheirer2013,bendale2016,geng2021}. Detection ranking, known-class probability reliability and validation-threshold transfer answer different deployment questions. We examine how score precision relates to these properties: does improved test receiver operating characteristic (ROC) false-positive rate at 95\\% unknown recall (FPR@95) carry over to a validation-frozen operating point?",
        "State the scientific question rather than opening with a limitation.","The distinction between ROC discrimination, reliability and threshold transfer is unchanged.")
    replace("M03","body_revision.tex",
        "AutoMixTemp combines established operations; extra search must be justified by transferred performance rather than the word automatic.",
        "Temp-MSP provides the temperature-only reference for evaluating the additional source search in autoMixTemp.",
        "Replace rhetorical self-defense with the actual controlled comparison.","Temperature-only scoring remains the simpler comparator; no universal advantage is asserted.")
    before=section_paragraph("The contributions are:",r"\Needspace{5\baselineskip}")
    after=("The contributions are: \\begin{enumerate}"
        "\\item identify how subtractive MSP ties affect FPR@95 through a fixed-parameter comparison with stable log-odds;"
        "\\item quantify the relationship between detection ranking, probability reliability and validation-threshold transfer;"
        "\\item test these findings on disjoint-unknown panels with independent-dataset, architectural and checkpoint controls."
        "\\end{enumerate} The added source search is assessed through its validation/target gains and measured computational cost.\n\n")
    replace("M04","body_revision.tex",before,after,
        "Use three concrete scientific contributions and move their interpretation out of the contribution list.",
        "The contribution remains a controlled empirical audit of established scores, with no new algorithm claim.")
    replace("M05","body_revision.tex",
        "Name exclusion changes these means only slightly (Table~\\ref{tab:primary}); it does not remove the extra vocabulary budget or all semantic overlap.",
        "Name exclusion changes these means only slightly (Table~\\ref{tab:primary}).",
        "Remove a repeated information-budget caveat from the results sentence.",
        "The same vocabulary-budget and semantic-overlap restrictions remain explicit in Sections III-D, IV-B and VI-C, and the table caption.")
    replace("M06","body_revision.tex",
        "With gain $=$ Temp-MSP minus autoMixTemp FPR@95 (Table~\\ref{tab:usecases}), validation/target Spearman correlations are \\PACSGainCorr{} on PACS and \\CIFARGainCorr{} on CIFAR-10.",
        "Validation-gated search yields backbone-dependent target changes (Supplementary Table~S1). With gain $=$ Temp-MSP minus autoMixTemp FPR@95 (Table~\\ref{tab:usecases}), validation/target Spearman correlations are \\PACSGainCorr{} on PACS and \\CIFARGainCorr{} on CIFAR-10.",
        "Give the observed finding before the gain definition and supporting correlations.",
        "Every gate count, sign convention, correlation and negative mixing result is preserved.")
    before=section_paragraph("At pooled validation recall 0.95,","\n\nActual PACS")
    after=("Class-wise conservative rules raise both recall and rejection (Fig.~\\ref{fig:transfer}). "
        "At pooled validation recall 0.95, autoMixTemp reaches PACS/CIFAR-10 target recall \\PACSAutoRecall{}/\\CIFARAutoRecall{} (Table~\\ref{tab:transfer}); "
        "at validation recall 0.99, worst-class PACS recall/rejection is \\PACSWorstNinetyNineRecall{}/\\PACSWorstNinetyNineReject{}, versus \\CIFARWorstNinetyNineRecall{}/\\CIFARWorstNinetyNineReject{} on CIFAR-10. "
        "Both reported worst-class recalls remain below 95\\%.")
    replace("M07","body_revision.tex",before,after,
        "Open with the measured recall/rejection trade-off and retain the failed high-recall outcome.","All thresholds and numeric macros are unchanged, including the below-95-percent results.")
    future=("Under an unrestricted future unknown distribution, all its probability mass could lie in a nonempty acceptance region. Validation classes alone therefore cannot guarantee unknown recall while retaining useful known acceptance.")
    replace("M08","body_revision.tex",future,"",
        "Move the general deployment limitation from Results to the dedicated limitations discussion.","The complete acceptance-region argument is retained in Section VI-C, not deleted.")
    replace("M09","body_revision.tex",
        "These probability diagnostics cover MSP, Temp-MSP, autoMixTemp and known-NLL temperature scaling, not every detector.",
        "Probability diagnostics are evaluated for MSP, Temp-MSP, autoMixTemp and known-NLL temperature scaling.",
        "Define the evaluated scope directly instead of adding a defensive tail.","Only the same four probability variants are covered; all metric definitions and adverse findings remain.")
    ownership="ViT-B/32 ownership-subset FPR@95 changes (PACS/CIFAR-10/Office-Home) are \\Closev{}/\\Closex{}/\\Closez{} against MSP and \\Closew{}/\\Closey{}/\\Closeaa{} against Temp-MSP (Supplementary Table~S15)."
    diagnostic="A further primary-panel diagnostic assigns each eligible test-content hash to one domain/role cluster by fixed hash priority, excluding within-unit training/validation overlaps. Seeds share the assigned subset and are averaged. This changes the evaluation subset, not the full-panel means; training and validation dependence remains. "
    replace("M10","body_revision.tex",diagnostic+ownership,
        ownership+" The diagnostic assigns each eligible test-content hash to one domain/role cluster by fixed hash priority, excluding within-unit training/validation overlaps. Seeds share the assigned subset and are averaged. Its estimand is the assigned subset; training and validation dependence remains.",
        "Place the ownership-subset result before the diagnostic procedure.","The subset estimand and remaining dependence are retained; all six changes are identical.")
    replace("M11","body_revision.tex",
        "This does not establish an unconditional operating-point improvement or isolate an interior-mixing benefit.",
        "",
        "Remove a second statement of the trade-off immediately after the lower-recall result.",
        "The lower recall/rejection comparison remains adjacent; the mixing and operating-point scope is stated once in the interpretation and limitations.")
    replace("M12","body_revision.tex",
        "Table~\\ref{tab:locoop} retains all regularization variants. LoCoOp MCM at $\\lambda=0.25$ attains CIFAR-10 AUROC/FPR@95",
        "LoCoOp MCM at $\\lambda=0.25$ shows a dataset-dependent comparison with autoMixTemp (Table~\\ref{tab:locoop}). Its CIFAR-10 AUROC/FPR@95 is",
        "Put the cross-dataset finding before the comparison values.","Both fixed weights remain in the unchanged table and supplement; the stated lambda and all reported values are identical.")
    replace("M13","body_revision.tex",
        "The comparison matches images and class roles, not training costs or published leaderboard protocols.",
        "",
        "Consolidate the repeated comparison-budget statement in Methods, the table caption and Limitations.",
        "Different prompt/adapter budgets and non-leaderboard status remain explicit in Section IV-D, VI-C, Table 15 and the response.")
    replace("M14","body_revision.tex",r"\section{Reproducibility and Limitations}",r"\section{Reproducibility, Discussion, and Limitations}",
        "Name the interpretation now provided within the existing section; no new major section.","The manuscript still has Sections I-VII; method and reproducibility details remain unchanged.")
    before=section_paragraph(r"\subsection{Scope and limitations}",r"\section{Conclusion}")
    after=(
        "\\subsection{Interpretation of the findings}\\label{sec:discussion}\n"
        "Numerical stability and temperature selection act at different levels. Stable log-odds preserve distinctions lost by subtractive float32 MSP; temperature and source selection determine the rankings evaluated under that representation. The frozen-threshold results then separate target ROC discrimination from transferred recall and known rejection.\n\n"
        "The probability diagnostics show that improved rejection ranking can coexist with poorer known-class reliability. The source gates expose panel-dependent gains, with no consistently transferable interior-mixing benefit. These findings support temperature-only scoring as the simpler reference and joint search as an optional, auditable extension whose operating-point trade-offs must be assessed explicitly.\n\n"
        "\\subsection{Scope and limitations}\\label{sec:limits}\n"
        "The estimates describe finite fitted panels. Across units, images, class roles and training/validation data are reused, including test images within a target domain. Image, cluster and joint reweighting condition on fixed fits and validation choices. Neither these ranges nor optimization seeds estimate uncertainty from retraining, recalibration, class-population sampling or unseen domains; IID population inference is therefore excluded.\n\n"
        "External validity is bounded by the fixed role schedules, three datasets and two backbones. Office-Home seeds share the smaller sampled budget and image manifests, while CIFAR-10 uses fixed few-shot images rather than a standard cross-dataset OOD benchmark. Near-duplicates and CLIP pretraining exposure remain unaudited.\n\n"
        "Comparison budgets also differ. Adapter checkpoint controls share a training loss; LoCoOp uses a separate prompt-training objective and budget on matched seed0 roles with two fixed regularization weights, rather than exhaustive tuning. NegLabel uses extra vocabulary information, and literal-name exclusion leaves semantic-leakage concerns.\n\n"
        "Different validation and target unknown classes provide no exchangeability basis for a deployment guarantee. "+future+"\n\n"
        "The contribution is a controlled numerical and operating-point audit of established scores. Some sensitivity analyses were specified after access to target outcomes and are retrospective.\n\n")
    replace("M15","body_revision.tex",before,after,
        "Separate scientific interpretation from statistical, generalization and information-budget limits; consolidate repeated restrictions.",
        "Every dependence, unknown-shift, benchmark-budget, pretraining, semantic-leakage and retrospective-design limitation is retained; no population or deployment guarantee is introduced.")
    before=section_paragraph("Stable autoMixTemp improves mean detection metrics",r"\clearpage")
    after=("The audit separates numerical score fidelity from temperature/source selection. Stable log-odds resolve subtractive-MSP ties, and the analyzed autoMixTemp panels improve mean detection metrics relative to MSP. Probability and selective-risk diagnostics show that these ranking gains coexist with poorer reliability and uneven selective risk. Conservative validation thresholds increase recall at a known-rejection cost.\n\n"
        "Temperature-only scoring remains the simpler reference: RN50 favors Temp-MSP on FPR@95, and full-budget PACS controls show limited checkpoint-selector effects. NegLabel and some LoCoOp variants outperform autoMixTemp on CIFAR-10, while their PACS comparisons are less favorable. Office-Home's small ROC advantage over Temp-MSP accompanies lower recall; autoMixTemp attains recall \\OHRecall{} with known rejection \\OHReject{}. Together, these findings support auditing score construction and threshold transfer alongside detection ranking, with joint search as an optional source selector.\n\n")
    replace("M16","body_revision.tex",before,after,
        "Summarize the scientific relationship and implications without repeating the limitations checklist.",
        "All original conclusion directions, comparator outcomes and Office-Home values are retained; no superiority, reliable calibration or high-recall guarantee is claimed.")
    dump(ROOT/"evidence/G1_manuscript_language_edits.json",EDITS)
    print("Targeted manuscript edits recorded; methods, numerical macros, tables, figures and supplement untouched.")

if __name__=="__main__": main()
