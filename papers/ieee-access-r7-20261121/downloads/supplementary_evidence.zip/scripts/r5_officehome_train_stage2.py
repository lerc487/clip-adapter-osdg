"""Use the original v3 manifest and engine for the now-authorized seed1/2."""
import os
import sys
from pathlib import Path
from gap_closure_core import ROOT, R2, read, sha


def main():
    spec = read(ROOT / "prespec/E5_officehome_stage2.json")
    assert sha(ROOT / "prespec/E5_officehome_stage2.json") == read(ROOT / "prespec/E5_officehome_stage2_seal.json")["sha256"]
    assert read(ROOT / "evidence/R5_authorization_20261119.json")["officehome_seed1_seed2"]
    manifest = Path(spec["manifest"])
    assert sha(manifest) == spec["manifest_sha256"]
    plan = read(manifest)
    unit = next(u for u in plan["units"] if u["unit_id"] == os.environ["OFFICEHOME_UNIT_ID"])
    assert unit["unit_id"] in spec["unit_ids"] and unit["seed"] in [1,2]
    sys.path.insert(0, str(ROOT / "new_runs/c3b/code"))
    import train_disjoint
    sys.path.insert(0, str(R2 / "scripts"))
    from officehome_train import selected_rows
    from c3b_scoring import score, select

    def samples(data_root, domain, names):
        assert str(Path(data_root).resolve()) == plan["data_root"]
        return [(str(Path(data_root) / p), c) for p,c in selected_rows(unit, domain, names)]

    train_disjoint.collect_samples = samples
    train_disjoint.score_unknown_from_logits = score
    train_disjoint.choose_score_source_and_temp = select
    train_disjoint.main()


if __name__ == "__main__":
    main()
