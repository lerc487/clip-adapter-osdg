"""Continue only the explicitly authorized serial GPU stages, fail closed."""
import ctypes
import hashlib
import json
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1]


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def state(stage,**kw):
    p=ROOT/"evidence/authorized_queue_progress.json";tmp=p.with_suffix(".tmp")
    tmp.write_text(json.dumps(dict(stage=stage,updated=time.strftime("%Y-%m-%dT%H:%M:%S"),**kw),indent=2),encoding="utf-8");tmp.replace(p)


def alive(pid):
    kernel=ctypes.WinDLL("kernel32",use_last_error=True);kernel.OpenProcess.restype=ctypes.c_void_p
    handle=kernel.OpenProcess(0x00100000,False,pid)
    if not handle:return False
    try:return kernel.WaitForSingleObject(ctypes.c_void_p(handle),0)==0x102
    finally:kernel.CloseHandle(ctypes.c_void_p(handle))


def main():
    path=ROOT/"prespec/authorized_queue.json"
    hashes={"scripts/"+name:sha(ROOT/"scripts"/name) for name in ["follow_authorized_stages.py","officehome_download.py","officehome_pilot.py","officehome_train.py","neglabel_infer.py"]}
    spec=dict(task="authorized_queue",GPU_order=["C3b","Office-Home two-unit timing pilot","NegLabel matched-sample port"],
        no_stage1_or_stage2_autostart=True,no_LoCoOp=True,no_ViTB16=True,
        stop="Stop on upstream failure, dead C3b process, data/role validation failure or pause marker. Never skip the Office-Home pilot to run NegLabel. Only read metadata to schedule, never inspect target performance for scheduling.",code_hashes=hashes)
    if path.exists():assert read(path)==spec
    else:
        with path.open("x",encoding="utf-8") as f:json.dump(spec,f,indent=2)
        with (ROOT/"prespec/authorized_queue_seal.json").open("x",encoding="utf-8") as f:json.dump(dict(task="authorized_queue",sha256=sha(path)),f,indent=2)
    lock=ROOT/"new_runs/authorized_followup.lock"
    with lock.open("x") as f:f.write(str(__import__("os").getpid()))
    try:
        while True:
            if (ROOT/"new_runs/PAUSE_REQUESTED").exists():state("paused_by_marker");return
            c3=read(ROOT/"evidence/C3b_progress.json")
            acquisition=read(ROOT/"evidence/C1_acquisition_progress.json")
            if "failed" in c3["stage"] or "failed" in acquisition["stage"]:raise RuntimeError("Upstream failed; inspect before continuing")
            if c3["stage"].startswith("paused"):state("waiting_for_user_resume_C3b");return
            if c3["stage"]!="complete_requires_manuscript_integration" and not alive(c3["pid"]):raise RuntimeError("C3b process exited without completion status")
            ready=c3["stage"]=="complete_requires_manuscript_integration" and acquisition["stage"]=="accepted_waiting_C3b_then_two_unit_pilot"
            state("waiting_C3b_and_data_acceptance",C3b_completed=c3["completed"],C3b_total=c3["total"],data_stage=acquisition["stage"])
            if ready:break
            time.sleep(30)
        for name,h in hashes.items():assert sha(ROOT/name)==h
        for stage,script in [("OfficeHome_timing_pilot","officehome_pilot.py"),("NegLabel_feature_evaluation","neglabel_infer.py")]:
            if (ROOT/"new_runs/PAUSE_REQUESTED").exists():state("paused_before_next_stage",next_stage=stage);return
            state(stage)
            with (ROOT/"new_runs"/(stage+"_queue.log")).open("w",encoding="utf-8") as f:
                subprocess.run([sys.executable,"-B","-s","-u",str(ROOT/"scripts"/script)],stdout=f,stderr=subprocess.STDOUT,check=True)
            if stage=="OfficeHome_timing_pilot":
                pilot=read(ROOT/"evidence/C1_pilot_progress.json")
                if pilot["stage"]!="complete_awaiting_stage1_user_decision":state("pilot_not_complete_no_skip",pilot_status=pilot);return
        state("authorized_stages_complete_requires_integration",OfficeHome_stage1_remaining18_not_started=True)
    except Exception as exc:state("failed_requires_inspection",error=repr(exc));raise
    finally:lock.unlink(missing_ok=True)


if __name__=="__main__":main()
