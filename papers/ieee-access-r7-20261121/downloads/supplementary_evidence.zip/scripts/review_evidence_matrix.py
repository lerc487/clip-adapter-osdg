"""Author-facing assessment of17concerns; completion does not imply acceptance."""
from collections import Counter
from datetime import datetime,timezone
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))

DETAILS={
"R1.1":("额外搜索何时值得使用",["B1.json","C1_complete_panel_audit.json"],"按adapter/zero-shot/interior分层并测试验证门控，所有不利结果保留。","未找到跨面板一致的内部混合适用规则；不能声称额外搜索必要或混合普遍更优。"),
"R1.2":("数据集、骨干与未知类覆盖",["stable.json","additional.json","C1_complete_panel_audit.json"],"主PACS/CIFAR-10严格未知类不重合；RN50及完整Office-Home补充已核验。","Office-Home仅seed0且预算不同；自定义角色并非完整标准OOD评测套件。"),
"R1.3":("重复图像与重叠角色的依赖",["B6.json","C1_dedup_v3.json"],"共享图像权重、簇级统计及联合重采样，Office-Home跨域/跨类完全重复组排除。","同域簇仍共享图像，训练和验证决策固定；不能解释为独立样本总体推断。"),
"R1.4":("迁移阈值的召回与误拒",["B2.json","C1_complete_panel_audit.json"],"同时报告目标召回/已知误拒，并保留不同验证召回目标和worst-class阈值。","未实现一般性的目标95%召回保证或普遍的高召回低误拒双重优势。"),
"R1.5":("压缩、删除历史叙述及术语",["word_counts.json","A1.json"],"正文对称字数核对、摘要长度核对，投稿历史移出正文，验证集统一validation。","文字补充完成不等于创新性问题被接受。"),
"R2.1":("新颖性与logit-source selection必要性",["B1.json","C2_NegLabel.json"],"将贡献定位为数值/概率/迁移分离的实证审计，不再包装为新校准机制。","现有组件仍是既有操作；未证明所有场景需要联合搜索，编辑仍可认为贡献有限。"),
"R2.2":("概率校准指标是否全面",["B3.json"],"补ECE15、NLL、Brier及known-NLL温度对照，报告恶化结果。","结论不支持检测调参改善概率可靠性，不能把已计算指标写成方法获益。"),
"R2.3":("验证未知与目标未知类别不重合",["input_manifest.json","C1_complete_panel_audit.json"],"冻结类别与图像清单核验每个训练/验证/目标角色。","不证明CLIP预训练从未接触相关类别或图像。"),
"R2.4":("温度边界、替代范围与稳定性",["B4.json"],"保留原/扩展/61点稠密网格、高温极限和秩相关，所有范围均报告。","完成敏感性研究，但不声称参考边界已饱和、温度最优或稳定。"),
"R2.5":("高召回条件下降低误拒的实用性",["B2.json"],"保守阈值及召回缺口分布、误拒代价已报告。","保守规则仍不能对不同目标未知类提供通用95%召回；实用性结论必须下调。"),
"R2.6":("补独立OSR或OOD基准",["stable.json","C1_complete_panel_audit.json"],"CIFAR-10和完整Office-Home独立数据集均已纳入。","所用自定义类角色和采样预算不能直接对标公开排行榜，也不支持广泛外推。"),
"R2.7":("域间异质性与置信度解释",["B5.json","C1_complete_panel_audit.json"],"追踪float32边界并列，补域/角色表及基线难度、置信度、NLL的描述性关系。","未建立单一因果解释；相关性不能作为机制证明。"),
"R2.8":("依赖感知统计与独立采样",["B6.json","C1_complete_panel_audit.json"],"PACS簇/联合重采样、CIFAR五簇仅计数范围，额外数据集单独报告。","仍非严格独立类/域总体采样，也未重拟合所有训练和验证决策。"),
"R3.1":("训练和验证中排除目标未知类",["input_manifest.json","C1_complete_panel_audit.json"],"与R2.3相同，按保存清单而非仅靠文字声明核验。","CLIP预训练暴露仍未知。"),
"R3.2":("可靠性、接受准确率及拒绝错误关系",["B2.json","B3.json"],"补可靠性图、risk-coverage/AURC、接受已知准确率和未知污染比例。","污染比例依赖构造的测试占比；固定分类器拒绝前准确率不变不是可靠性获益。"),
"R3.3":("DeepLab与EfficientNet说明和引用",[],"引用原始架构论文并明确不是本稿已运行比较方法，未堆砌不相关应用DOI。","没有这两种架构的实验结果，不暗示已测试。"),
"R3.4":("checkpoint、CLIP架构与近期基线",["C3b.json","C2_NegLabel.json","completed_result_audit.json"],"28个PACS全20epoch轨迹三选点、RN50、MCM和官方函数对齐NegLabel均完成。","LoCoOp/ViT-B16依决定未运行；同损失预算下的选点对照不等于各检测器独立充分优化。"),
}

def main():
    office=read(ROOT/"evidence/C1_complete_panel_audit.json");assert office["all_checks_pass"] and office["n"]==20
    assert read(ROOT/"evidence/officehome_portable_score_checks.json")["all_checks_pass"]
    responses=read(ROOT/"evidence/responses.json");rules=read(ROOT/"prespec/C1_complete_panel_integration.json")["review_assessment_rules"]
    records=[]
    for rule in rules:
        key=rule["id"];brief,files,done,limitation=DETAILS[key]
        for file in files:assert (ROOT/"evidence"/file).exists()
        response=next(r for r in responses["records"] if r["id"]==key)
        records.append(dict(id=key,brief=brief,status=rule["status"],evidence_files=files,completed_work=done,
            residual=limitation,actual_action_location=response["action"],criterion_frozen_before_complete_panel=rule["reason"]))
    assert len(records)==17 and len({r["id"] for r in records})==17
    counts=dict(Counter(r["status"] for r in records))
    output=dict(created_utc=datetime.now(timezone.utc).isoformat(),authorized_experiment_evidence_complete=True,
        author_assessment_not_editorial_acceptance=True,status_counts=counts,records=records,upload_ready=False)
    (ROOT/"evidence/review_evidence_matrix.json").write_text(json.dumps(output,indent=2,ensure_ascii=False),encoding="utf-8")
    lines=["# 17条审稿意见证据核对表","", "已授权实验及预设分析均已完成并核验。这不等于所有科学诉求都已实现，更不是编辑或审稿人认可的保证。","",
        f"作者自查：技术补充已完成{counts.get('technical_response_completed',0)}条；部分回应、仍有实质限制{counts.get('partial',0)}条。分类标准在完整Office-Home结果形成前已封存，未按结果好坏更改。","",
        "“技术补充已完成”表示指定的分析、实验或文字修改已提供并核对；“部分回应”表示有证据与解释，但原要求的功能、必要性、独立性或比较未充分实现。下表不得当作审稿人已判定解决。","",
        "| 编号 | 意见重点 | 作者自查状态 | 已补充的证据 | 仍须承认的限制 |","| --- | --- | --- | --- | --- |"]
    for r in records:
        status="技术补充已完成" if r["status"]=="technical_response_completed" else "部分回应"
        lines.append("| "+" | ".join([r["id"],r["brief"],status,r["completed_work"],r["residual"]])+" |")
    lines += ["","## 当前编译稿位置","","| 编号 | 实际章节和图表 | JSON来源 |","| --- | --- | --- |"]
    for r in records:lines.append("| "+" | ".join([r["id"],r["actual_action_location"],", ".join(r["evidence_files"]) or "source/references.bib；编译后的参考文献"])+" |")
    lines += ["","## 提交判断","","这份材料可以进入作者最终审阅，但不能以“实验已齐全”为由宣称全部实质问题解决。尤其应确认是否接受审计研究的贡献定位、未运行LoCoOp的比较范围，以及无法保证目标高召回的结论边界。此处不启动新实验、不改变作者已作出的排除决定，也不代替作者执行重投。"]
    path=ROOT/"reports/17条审稿意见证据核对表.md";path.write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps(dict(technical_response_completed=counts.get("technical_response_completed",0),partial=counts.get("partial",0),assessment_is_not_acceptance=True),indent=2))

if __name__=="__main__":main()
