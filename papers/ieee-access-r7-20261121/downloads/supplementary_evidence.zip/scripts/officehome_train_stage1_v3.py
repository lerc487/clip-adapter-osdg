"""Authorize only the frozen20-unit seed0 stage, with no new sample selection."""
import hashlib
import json
import os
from pathlib import Path
import sys
from officehome_train import selected_rows

ROOT=Path(__file__).resolve().parents[1]


def main():
    literal=json.loads((ROOT/"prespec/C1_roles_manifest_v3.json").read_text())
    manifest=ROOT/literal["manifest"]
    assert hashlib.sha256(manifest.read_bytes()).hexdigest()==literal["manifest_sha256"]
    plan=json.loads(manifest.read_text());assert plan["training_eligible"]
    unit=next(u for u in plan["units"] if u["unit_id"]==os.environ["OFFICEHOME_UNIT_ID"])
    assert unit["unit_id"] in plan["stage1"] and unit["seed"]==0
    assert json.loads((ROOT/"evidence/C1_stage1_authorization_20261119.json").read_text())["stage1_remaining18_authorized"]
    sys.path.insert(0,str(ROOT/"new_runs/c3b/code"))
    import train_disjoint
    from c3b_scoring import score,select
    def samples(data_root,domain,names):
        assert str(Path(data_root).resolve())==plan["data_root"]
        return [(str(Path(data_root)/p),c) for p,c in selected_rows(unit,domain,names)]
    train_disjoint.collect_samples=samples
    train_disjoint.score_unknown_from_logits=score
    train_disjoint.choose_score_source_and_temp=select
    train_disjoint.main()


if __name__=="__main__":main()
