"""Wait in this task for the existing queue; never launch or retry a fit."""
from datetime import datetime,timedelta,timezone
import json
from pathlib import Path
import time

ROOT=Path(__file__).resolve().parents[1]
PATH=ROOT.parent/"revision2_20261118/evidence/C1_stage1_v3_progress.json"
last=None;changed=time.monotonic()
while True:
    data=json.loads(PATH.read_text(encoding="utf-8-sig"))
    key=(data["stage"],data["completed"],data.get("current"),data.get("next_unit"))
    if key!=last:
        print(datetime.now(timezone(timedelta(hours=8))).isoformat(),json.dumps(data,ensure_ascii=False),flush=True)
        last=key;changed=time.monotonic()
    if data["stage"]=="complete_requires_manuscript_integration":
        assert data["completed"]==20;print("All20units complete; ready for CPU verification, not yet publication-ready.",flush=True);break
    if "failed" in data["stage"] or "paused" in data["stage"]:raise RuntimeError("Existing queue requires attention: "+repr(data))
    if time.monotonic()-changed>3600:raise RuntimeError("No unit-boundary state update for an hour; inspect the existing process before proceeding.")
    time.sleep(30)
