"""Read-only input adapters for the final scientific gap audit."""
from collections import defaultdict
import csv
import hashlib
import json
from pathlib import Path
import sys

import numpy as np

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
R2 = BASE / "revision2_20261118"
sys.path.insert(0, str(R2 / "scripts"))
sys.path.insert(0, str(BASE / "05_new_runs/code"))
from c3b_scoring import branch, score, select
from verified_metrics import fpr_at_recall


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value, exclusive=False):
    path = Path(path)
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("x" if exclusive else "w", encoding="utf-8") as f:
        json.dump(value, f, indent=2, ensure_ascii=False, allow_nan=False)


def save(task, value):
    spec = ROOT / "prespec" / (task + ".json")
    seals = read(ROOT / "prespec/R5_gap_analysis_seals.json")
    assert sha(spec) == seals["specs"][task]
    for rel, digest in seals["code"].items():
        assert sha(ROOT / rel) == digest, rel
    value.update(task=task, prespec_sha256=sha(spec), no_training=True,
                 no_encoder_inference=True, prospective_confirmation=False,
                 interpretation="Retrospective, validation-frozen descriptive analysis. No IID inference, universal benefit, or deployment guarantee.")
    write(ROOT / "evidence" / (task + ".json"), value)
    for name, rows in value.items():
        if not isinstance(rows, list) or not rows or not isinstance(rows[0], dict):
            continue
        if any(isinstance(v, (dict, list)) for row in rows for v in row.values()):
            continue
        keys = list(dict.fromkeys(k for row in rows for k in row))
        with (ROOT / "evidence" / (task + "_" + name + ".csv")).open("w", newline="", encoding="utf-8-sig") as f:
            w = csv.DictWriter(f, keys)
            w.writeheader()
            w.writerows(rows)
    print(task + " complete", flush=True)


def units():
    primary = read(ROOT / "evidence/stable.json")["records"]
    extra = [r for r in read(ROOT / "evidence/additional.json")["records"] if r["family"] == "rn50"]
    for model, rows in [("ViT-B32", primary), ("RN50", extra)]:
        for dataset in ["pacs", "cifar10"]:
            grouped = defaultdict(dict)
            for r in rows:
                if r["dataset"] == dataset:
                    grouped[r["unit"]][r["method"]] = r
            for unit, methods in sorted(grouped.items()):
                directory = BASE / "05_new_runs"
                if model == "RN50":
                    directory /= "rn50"
                yield model, dataset, unit, directory / dataset / unit, methods
    grouped = defaultdict(dict)
    for r in read(ROOT / "evidence/C1_complete_panel_audit.json")["records"]:
        grouped[r["unit"]][r["method"]] = r
    for unit, methods in sorted(grouped.items()):
        directory = R2 / "new_runs/officehome/dedup_v3/stage1_eval64" / unit
        if not directory.exists():
            directory = R2 / "new_runs/officehome/dedup_v3/pilot_eval64" / unit
        assert (directory / "logits.npz").is_file(), directory
        yield "ViT-B32", "officehome", unit, directory, methods


def load_arrays(directory):
    with np.load(directory / "logits.npz", allow_pickle=False) as z:
        return {k: z[k] for k in z.files}


def choose(a, route, mode, grid):
    return select(route, mode, grid, a["kz"], a["ka"], a["uz"], a["ua"],
                  True, .5, [0., .25, .5, .75, 1.], "fpr95")


def detection(a, selection, mode="msp"):
    t = selection["T_score"]
    sv = np.r_[score(branch(a["kz"], a["ka"], selection), t, mode),
               score(branch(a["uz"], a["ua"], selection), t, mode)]
    st = score(branch(a["tz"], a["ta"], selection), t, mode)
    return st, sv


def tag(model, dataset, unit):
    return dict(model=model, dataset=dataset, unit=unit)


def cache_path(model, dataset, unit):
    return ROOT / "evidence/r5_stable_score_cache" / model / dataset / (unit + ".npz")


def identities(dataset):
    if dataset == "pacs":
        rows = read(BASE / "02_historical/pacs_same_checkpoint_20260919/data_manifest.json")
    elif dataset == "cifar10":
        rows = read(BASE / "05_new_runs/data/cifar10_manifest.json")
    else:
        rows = read(R2 / "new_runs/officehome/dedup_v3/filtered_inventory.json")["files"]
    norm = lambda p: p.replace("\\", "/").removeprefix("CIFAR10_folders/")
    return {norm(r["path"]): r["sha256"] for r in rows}


def sample_hashes(directory, filename, lookup):
    norm = lambda p: p.replace("\\", "/").removeprefix("CIFAR10_folders/")
    return [lookup[norm(r["path"])] for r in read(directory / filename)]


def grouped_means(rows, group_keys, fields):
    groups = defaultdict(list)
    for row in rows:
        groups[tuple(row[k] for k in group_keys)].append(row)
    return [dict(zip(group_keys, key), n=len(group), **{
        field: float(np.mean([r[field] for r in group if r[field] is not None]))
        if any(r[field] is not None for r in group) else None for field in fields})
        for key, group in sorted(groups.items(), key=lambda x: str(x[0]))]
