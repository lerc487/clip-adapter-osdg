"""Regenerate the main comparison with both declared NegLabel variants."""
import hashlib
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/"source"


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":8,"axes.spines.top":False,"axes.spines.right":False,
        "axes.labelsize":8,"xtick.labelsize":7.2,"ytick.labelsize":7.2,"pdf.fonttype":42})
    controls=[("MSP","MSP"),("Temp-MSP","Temp-MSP, FPR"),("autoMixTemp","autoMixTemp"),
        ("Temp-MSP-AUROC","Temp-MSP, AUROC"),("Energy-only-T1","Energy, T=1"),("Energy-T-tuned","Energy, tuned T"),
        ("MCM-canonical","MCM, canonical"),("MCM-matched-prompts","MCM, matched"),("Zero-shot-max-cosine","Maximum cosine"),
        ("NegLabel-standard","NegLabel, standard*"),("NegLabel-excluded","NegLabel, name-excl.*")]
    stable=read(ROOT/"evidence/stable.json");mcm=read(ROOT/"evidence/mcm.json");neg=read(ROOT/"evidence/C2_NegLabel.json")
    records=[];fig,axs=plt.subplots(2,2,figsize=(7.2,5.8),sharey=True,layout="constrained")
    for col,ds in enumerate(["pacs","cifar10"]):
        for row,metric in enumerate(["auroc","fpr95"]):
            ax=axs[row,col];values=[]
            for i,(method,label) in enumerate(controls):
                if method.startswith("NegLabel"):
                    variant="standard" if method.endswith("standard") else "benchmark_names_excluded"
                    index=next(j for j,r in enumerate(neg["summary"]) if r["dataset"]==ds and r["variant"]==variant)
                    value=neg["summary"][index][metric];file="C2_NegLabel.json";pointer=["summary",index,metric]
                elif method in stable["summaries"][ds]:
                    value=stable["summaries"][ds][method][metric];file="stable.json";pointer=["summaries",ds,method,metric]
                else:
                    value=mcm["summary"][ds][method][metric];file="mcm.json";pointer=["summary",ds,method,metric]
                records.append(dict(dataset=ds,method=method,metric=metric,file=file,pointer=pointer,value=value,display_percent=format(value*100,".2f")))
                values.append(value*100)
                color="#C06232" if method=="autoMixTemp" else "#275C6F" if method.startswith("Temp") else "#386B52" if method.startswith("NegLabel") else "#647680"
                marker="D" if method.startswith("NegLabel") else "o"
                ax.scatter(value*100,i,color=color,s=22,marker=marker,zorder=3)
                ax.annotate(format(value*100,".2f"),(value*100,i),xytext=(5,0),textcoords="offset points",va="center",fontsize=6.6,color=color)
            extent=max(values)-min(values);pad=max(extent*.2,.35)
            ax.set_xlim(min(values)-pad*.35,max(values)+pad*1.65)
            ax.set_yticks(np.arange(len(controls)),[label for method,label in controls]);ax.set_ylim(len(controls)-.4,-.7)
            ax.grid(axis="x",color="#DFE5E8",lw=.7)
            ax.set_title(("PACS" if ds=="pacs" else "CIFAR-10")+"  "+("AUROC" if metric=="auroc" else "FPR@95"),loc="left",fontsize=9,fontweight="bold")
            ax.set_xlabel("AUROC (%)  higher is better" if metric=="auroc" else "FPR@95 (%)  lower is better")
            if col:ax.tick_params(labelleft=False)
    fig.get_layout_engine().set(rect=(0,.055,1,1))
    fig.text(.02,.015,"* NegLabel ports add external WordNet information; rows share images, not information budgets.",fontsize=7,color="#354C58")
    fig.savefig(SRC/"figures/score_comparison.pdf",bbox_inches="tight",pad_inches=.07)
    fig.savefig(ROOT/"logs/score_comparison.png",dpi=160,bbox_inches="tight",pad_inches=.07);plt.close(fig)
    registry=read(ROOT/"evidence/figure_data_registry.json")
    registry["completed_control_figure_records"]=records
    registry["figure_hashes"]["score_comparison.pdf"]=sha(SRC/"figures/score_comparison.pdf")
    (ROOT/"evidence/figure_data_registry.json").write_text(json.dumps(registry,indent=2),encoding="utf-8")
    print("Main comparison updated with44evidence-bound plotted values.")


if __name__=="__main__":main()
