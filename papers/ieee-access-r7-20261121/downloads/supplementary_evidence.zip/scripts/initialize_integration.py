"""Freeze a new documentation/integrity integration, preserving revision2."""
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parents[1];PREV=ROOT.parent/"revision2_20261118"


def sha(p):
    h=hashlib.sha256()
    with p.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
    return h.hexdigest()
def new(p,x):
    with p.open("x",encoding="utf-8") as f:json.dump(x,f,indent=2,allow_nan=False)


def main():
    source_manifest=[dict(path=str(p),sha256=sha(p)) for p in sorted((PREV/"source").rglob("*")) if p.is_file()]
    files=["C3b.json","C1_pilot_v3_eval64.json","C2_NegLabel.json","C2_NegLabel_alignment.json","C2_NegLabel_CUDA_alignment.json","C1_dedup_v3.json","C1_pilot_v3_eval64_numerical_fixtures.json"]
    spec=dict(task="integration_20261119",created_utc=datetime.now(timezone.utc).isoformat(),
        previous_root=str(PREV),source_baseline=source_manifest,input_hashes={f:sha(PREV/"evidence"/f) for f in files},
        design="Integrity-check completed C3b and NegLabel runs and all method/selector/vocabulary variants, reaggregate their frozen equal-unit means, and integrate them without retuning. For C3b compare known-NLL full20 to exact primary seed0 counterparts; report exact equality counts/differences, not causal/population claims. For NegLabel recompute all198unit-variant metrics from saved scores and fixed role labels. Retain all adverse outcomes. Office-Home currently contributes only two timed pilot records, not a complete panel.",
        retrospective_context="These completed outcomes have now been inspected. This specification controls integration and verification, not a prospective new performance study. Original experimental specifications remain unchanged.",
        output="New main source/PDF, actual-original-baseline yellow highlights,17template responses, supplementary analyses, numeric bindings, task reports and checks. Publication readiness remains false until outstanding data integration/author review are finished.",
        no_new_training=True,no_target_configuration_selection=True,no_IID_claims=True,
        OfficeHome_stage1="User separately authorized18remaining seed0 units; running in previous root with fixed manifest. Do not claim20complete or include partial stage1 as main evidence.")
    p=ROOT/"prespec/integration_20261119.json";new(p,spec)
    new(ROOT/"prespec/integration_20261119_seal.json",dict(task=spec["task"],sha256=sha(p)))
    shutil.copytree(PREV/"source",ROOT/"source")
    for p in (PREV/"evidence").iterdir():
        if p.is_file() and p.suffix in [".json",".csv",".npz"] and "progress" not in p.name and not p.name.startswith("C1_stage1"):
            shutil.copy2(p,ROOT/"evidence"/p.name)
    for p in (PREV/"scripts").glob("*.py"):shutil.copy2(p,ROOT/"scripts"/p.name)
    for p in (PREV/"prespec").glob("*.json"):shutil.copy2(p,ROOT/"prespec"/p.name)
    shutil.copy2(PREV/"logs/artifact.md",ROOT/"logs/artifact.md")
    new(ROOT/"evidence/integration_input_manifest.json",dict(source=source_manifest,completed_analysis_inputs=spec["input_hashes"],
        prior_root=str(PREV),new_root=str(ROOT)))
    print("New integration directory initialized; previous source preserved.")


if __name__=="__main__":main()
