"""Independently verify the fixed60-unit panel, without changing fitted files."""
from collections import Counter, defaultdict
from pathlib import Path
import sys
import numpy as np
from gap_closure_core import ROOT, R2, read, sha, write, grouped_means
from audit_officehome_complete import select, VARIANTS, maxf1_threshold
from r5_independent_audit_helpers import roc, scores, combine, check, fixtures

WORK = R2 / "new_runs/officehome/dedup_v3"
NEW = ROOT / "new_runs/officehome/stage2_eval64"
METHODS = [v[0] for v in VARIANTS]
FIELDS = ["auroc", "fpr95", "known_acc", "osr_acc", "frozen_threshold_test_known_fpr", "frozen_threshold_test_unknown_tpr"]


def seal():
    path = ROOT / "prespec/E5_full_panel_audit.json"
    spec = read(path)
    assert sha(path) == read(path.with_name("E5_full_panel_audit_seal.json"))["sha256"]
    for name, digest in spec["code_hashes"].items():
        assert sha(name) == digest, name
    assert sha(WORK / "roles_manifest.json") == spec["roles_sha256"]
    return spec


def synthetic():
    test = fixtures()
    rng = np.random.default_rng(101)
    a = {k:rng.normal(size=(n,3)).astype(np.float32) for k,n in [("ka",9),("kz",9),("ua",7),("uz",7)]}
    y = np.r_[np.zeros(9,dtype=int),np.ones(7,dtype=int)]
    for name, route, mode, tune in VARIANTS:
        chosen = select(a, route, mode, tune, [.5,1.,2.], [0.,.25,.5,.75,1.])
        sv = np.r_[scores(combine(a["kz"],a["ka"],chosen),chosen["T_score"],mode=="energy"),
                   scores(combine(a["uz"],a["ua"],chosen),chosen["T_score"],mode=="energy")]
        measured = roc(sv,y)
        check(measured["auroc"],chosen["val_auroc"],(name,"fixture_auroc"))
        check(measured["fpr95"],chosen["val_fpr95"],(name,"fixture_fpr"))
    return dict(**test,seven_selection_variants_checked=True)


def location(unit, plan):
    if unit["seed"]:
        run = NEW / unit["unit_id"]
    else:
        run = WORK / ("pilot_eval64" if unit["unit_id"] in plan["pilot"] else "stage1_eval64") / unit["unit_id"]
    return run


def audit_unit(unit, plan, parent, exclusions, all_images):
    uid = unit["unit_id"]; run = location(unit,plan)
    evaluated = run.parent / (uid+"_stable_evaluation")
    timing = read(run.parent / (uid+"_timing.json"))
    assert timing == next(t for t in parent["timings"] if t["unit"]==uid)
    hashes = read(run/"artifact_hashes.json")
    for name,digest in hashes.items():
        assert sha(run/name)==digest,(uid,name)
    config = read(run/"config.json")["arguments"]
    assert config["seed"]==unit["seed"] and config["early_stop_metric"]=="known_nll"
    assert config["early_stop"]==3 and config["epochs"]==20
    assert config["model"]=="ViT-B-32" and config["pretrained"]=="openai"
    if unit["seed"]:
        assert timing["stage2_spec_sha256"]==sha(ROOT/"prespec/E5_officehome_stage2.json")
        assert timing["stable_results_sha256"]==sha(evaluated/"results.json")
    class_sets=[set(unit[k]) for k in ["known","validation_unknown","target_unknown"]]
    assert list(map(len,class_sets))==[35,15,15]
    assert not any(class_sets[i]&class_sets[j] for i in range(3) for j in range(i+1,3))
    classes=read(run/"class_map.json")["known"];assert set(classes)==class_sets[0]
    local={name:i for i,name in enumerate(classes)}; labels={};content={};counts={}
    for role,expected in unit["roles"].items():
        actual=read(run/(role+"_samples.json"))
        assert [(r["path"].replace("\\","/"),r["label"]) for r in actual]==[(r["path"],local.get(r["category"],-1)) for r in expected],(uid,role)
        assert not set(r["path"] for r in expected)&exclusions
        labels[role]=np.asarray([r["label"] for r in actual]);counts[role]=len(expected)
        content[role]={r["sha256"] for r in expected}
        for r in expected:
            if r["path"] in all_images:assert all_images[r["path"]]==r["sha256"]
            all_images[r["path"]]=r["sha256"]
    unique={k:len(v) for k,v in content.items()}
    assert counts==timing["sample_counts"] and unique==timing["unique_content_counts"]
    assert counts["train"]==700 and counts["val_known"]==350 and counts["val_unknown"]==150
    assert all(not content[a]&content[b] for i,a in enumerate(content) for b in list(content)[i+1:])
    with np.load(run/"logits.npz",allow_pickle=False) as z:a={k:z[k] for k in z.files}
    for key,role in [("yk","val_known"),("yu","val_unknown"),("ty","test")]:
        np.testing.assert_array_equal(a[key],labels[role])
    for key,role in [("ka","val_known"),("kz","val_known"),("ua","val_unknown"),("uz","val_unknown"),("ta","test"),("tz","test")]:
        assert a[key].shape==(counts[role],35) and np.isfinite(a[key]).all()
    saved=read(evaluated/"results.json"); choices=read(evaluated/"validation_choices_frozen.json")
    assert saved["raw_logits_sha256"]==hashes["logits.npz"] and not saved["raw_training_archive_modified"]
    with np.load(evaluated/"stable_scores.npz",allow_pickle=False) as z:archived={k:z[k] for k in z.files}
    assert set(archived)==set(METHODS)
    known=a["ty"]>=0;y=(~known).astype(int);pred=a["ta"].argmax(1)
    vy=np.r_[np.zeros(len(a["ka"]),dtype=int),np.ones(len(a["ua"]),dtype=int)]
    records=[];maximum=0.
    for name,route,mode,tune in VARIANTS:
        row=next(r for r in saved["results"] if r["method"]==name)
        assert row==next(r for r in timing["results"] if r["method"]==name)
        parent_row=next(r for r in parent["records"] if r["unit"]==uid and r["method"]==name)
        assert all(parent_row[k]==v for k,v in row.items())
        sel=select(a,route,mode,tune,[float(t) for t in config["temp_candidates"].split(",")],[float(t) for t in config["mix_alphas"].split(",")])
        frozen=next(r["selection"] for r in choices["choices"] if r["method"]==name)
        for key in ["score_source","alpha","T_score"]:
            assert sel[key]==frozen[key]==row["selection"][key],(uid,name,key)
        for key in ["val_fpr95","val_auroc"]:check(sel[key],frozen[key],(uid,name,key))
        sv=np.r_[scores(combine(a["kz"],a["ka"],sel),sel["T_score"],mode=="energy"),
                 scores(combine(a["uz"],a["ua"],sel),sel["T_score"],mode=="energy")]
        st=scores(combine(a["tz"],a["ta"],sel),sel["T_score"],mode=="energy")
        error=float(np.max(np.abs(st-archived[name])));assert error<=1e-10,(uid,name,error)
        maximum=max(maximum,error)
        threshold=roc(sv,vy)["threshold"];check(threshold,row["frozen_val_tpr95_threshold"],(uid,name,"threshold"),1e-10)
        f1=maxf1_threshold(sv,vy);check(f1,row["maxf1_validation_threshold"],(uid,name,"maxF1"),1e-10)
        reject=st>=threshold;classification=pred.copy();classification[st>=f1]=-1
        computed=dict(auroc=roc(st,y)["auroc"],fpr95=roc(st,y)["fpr95"],known_acc=float((pred[known]==a["ty"][known]).mean()),
            osr_acc=float((classification==a["ty"]).mean()),frozen_threshold_test_known_fpr=float(reject[known].mean()),
            frozen_threshold_test_unknown_tpr=float(reject[~known].mean()))
        for key,value in computed.items():check(value,row[key],(uid,name,key))
        assert row["checkpoint_sha256"]==hashes["best_adapter.pt"] and row["validation_choices_sha256"]==sha(evaluated/"validation_choices_frozen.json")
        records.append(dict(unit=uid,seed=unit["seed"],target=unit["target"],rotation=unit["rotation"],method=name,**computed,
            selection=sel,frozen_val_tpr95_threshold=threshold,maxf1_validation_threshold=f1,
            known_files=int(known.sum()),unknown_files=int(y.sum())))
    out=ROOT/"evidence/officehome_full_saved_scores"/(uid+".npz");out.parent.mkdir(exist_ok=True)
    assert not out.exists(),out
    np.savez_compressed(out,target_labels=a["ty"],adapter_predictions=pred,**archived)
    provenance=dict(unit=uid,seed=unit["seed"],directory=str(run),artifact_hashes_sha256=sha(run/"artifact_hashes.json"),
        files=hashes,stable_result_sha256=sha(evaluated/"results.json"),saved_scores_sha256=sha(out),
        max_score_absolute_error=maximum,nominal=counts,unique_content=unique,epochs=timing["epochs"],
        measured_pipeline_seconds=timing["measured_unit_pipeline_seconds"])
    return records,provenance


def main():
    spec=seal();fixture=synthetic()
    if "--fixtures" in sys.argv:
        write(ROOT/"evidence/E5_full_audit_fixtures.json",dict(**fixture,audit_sha256=sha(__file__),prespec_sha256=sha(ROOT/"prespec/E5_full_panel_audit.json")),exclusive=True)
        print("E5 full-panel audit synthetic fixtures passed; no fitted outcomes inspected.",flush=True);return
    assert not (ROOT/"evidence/E5_officehome_full_audit.json").exists()
    assert read(ROOT/"evidence/E5_full_audit_fixtures.json")["audit_sha256"]==sha(__file__)
    progress=read(ROOT/"evidence/E5_officehome_stage2_progress.json")
    assert progress["stage"]=="training_complete_requires_independent_audit" and progress["completed"]==40
    seed0_path=R2/"evidence/C1_stage1_v3_eval64.json";stage2_path=ROOT/"evidence/E5_officehome_stage2_results.json"
    assert sha(seed0_path)==spec["seed0_sha256"]
    parents=[read(seed0_path),read(stage2_path)];assert list(map(lambda p:len(p["records"]),parents))==[140,280]
    assert parents[1]["stage2_spec_sha256"]==sha(ROOT/"prespec/E5_officehome_stage2.json")
    plan=read(WORK/"roles_manifest.json");assert len(plan["units"])==60
    assert {u["unit_id"] for u in plan["units"]}==set(spec["unit_ids"])
    exclusions=set(read(WORK/"exclusion_manifest.json")["paths"]);images={};rows=[];provenance=[]
    for unit in plan["units"]:
        results,trace=audit_unit(unit,plan,parents[bool(unit["seed"])],exclusions,images)
        rows.extend(results);provenance.append(trace)
        print("E5 audited "+unit["unit_id"],flush=True)
    for relative,digest in images.items():assert sha(Path(plan["data_root"])/relative)==digest,relative
    assert len(rows)==420 and len(images)==15389
    summary=grouped_means(rows,["method"],FIELDS)
    seed_summary=grouped_means(rows,["seed","method"],FIELDS)
    domain_summary=grouped_means(rows,["target","method"],FIELDS)
    seed_domain=grouped_means(rows,["seed","target","method"],FIELDS)
    pairs=[];lookup={(r["unit"],r["method"]):r for r in rows}
    for r in rows:
        if r["method"]!="autoMixTemp":continue
        for comparator in ["MSP","Temp-MSP"]:
            ref=lookup[(r["unit"],comparator)]
            pairs.append(dict(unit=r["unit"],seed=r["seed"],target=r["target"],comparator=comparator,
                **{"delta_"+k:r[k]-ref[k] for k in FIELDS}))
    source_counts=dict(Counter("interior" if r["selection"]["score_source"]=="mix" and 0<r["selection"]["alpha"]<1 else r["selection"]["score_source"]
        for r in rows if r["method"]=="autoMixTemp"))
    write(ROOT/"evidence/E5_officehome_full_audit.json",dict(all_checks_pass=True,n=60,seeds=[0,1,2],methods_verified=7,
        method_unit_records_verified=420,records=rows,summary=summary,seed_summary=seed_summary,domain_summary=domain_summary,
        seed_domain_summary=seed_domain,paired_records=pairs,paired_summary=grouped_means(pairs,["comparator"],["delta_"+k for k in FIELDS]),
        seed_paired_summary=grouped_means(pairs,["seed","comparator"],["delta_"+k for k in FIELDS]),selection_source_counts=source_counts,
        units=provenance,unique_raw_image_paths_verified=len(images),max_saved_score_absolute_error=max(r["max_score_absolute_error"] for r in provenance),
        unique_unknown_validation_min=min(r["unique_content"]["val_unknown"] for r in provenance),
        unique_unknown_validation_max=max(r["unique_content"]["val_unknown"] for r in provenance),
        measured_pipeline_seconds_sum=sum(r["measured_pipeline_seconds"] for r in provenance),
        raw_parent_sha256=[sha(seed0_path),sha(stage2_path)],audit_prespec_sha256=sha(ROOT/"prespec/E5_full_panel_audit.json"),
        fixtures=fixture,no_new_training=True,no_target_retuning=True,no_IID_inference=True,not_pooled_with_primary=True,
        interpretation="Equal-unit finite-panel descriptions. Optimization seeds share images and class-role rotations; they are not independent population samples. Separate data budget; no source-target pooling."),exclusive=True)
    print("All60 units/420 method rows independently verified.",flush=True)


if __name__=="__main__":main()
