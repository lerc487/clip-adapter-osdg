"""Only the two authorized timed units; no automatic20-unit extension."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/"new_runs/officehome"


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);temp=p.with_suffix(".tmp")
    temp.write_text(json.dumps(x,indent=2,allow_nan=False),encoding="utf-8");temp.replace(p)


def state(stage,**kw):dump(ROOT/"evidence/C1_pilot_progress.json",dict(stage=stage,updated=time.strftime("%Y-%m-%dT%H:%M:%S"),**kw))


def freeze():
    files=[ROOT/"scripts"/name for name in ["officehome_train.py","officehome_pilot.py","c3b_scoring.py"]]+list((ROOT/"new_runs/c3b/code").glob("*.py"))
    record=dict(task="C1_pilot",stage_design_sha256=sha(ROOT/"prespec/C1_stages.json"),
        design="Two literal pilot IDs from accepted_roles.json, first two sorted target domains at rotation00/seed0. No target-quality gate. Two source domains each10 known images/class, held-out validation350known/150unknown. Frozen sample order, same adapter protocol; known-NLL early stop3, maximum20epochs.",
        metrics="All archived six score variants plus validation-FPR-tuned energy. Report per-unit wall time covering training and primary archive evaluation, separate postprocessing time, actual epochs, known/validation/test counts; no main-panel pooling.",
        conditions="Wait C3b complete and data accepted; acquire shared GPU_QUEUE.lock. Stop after two, stage1 remaining18 and stage2 seed1/2 require later author approval. Error/partial directories stop, no parameter fallback.",
        fixtures="Before GPU use, test manifest-routing code on synthetic source/validation/target roles, including absent target-unknown samples from training and validation. No model inference or benchmark outcome used.",
        code_hashes={p.relative_to(ROOT).as_posix():sha(p) for p in files})
    path=ROOT/"prespec/C1_pilot.json"
    if path.exists():assert read(path)==record
    else:
        with path.open("x",encoding="utf-8") as f:json.dump(record,f,indent=2)
        with (ROOT/"prespec/C1_pilot_seal.json").open("x",encoding="utf-8") as f:json.dump(dict(task="C1_pilot",sha256=sha(path)),f,indent=2)
    return record


def evaluate_energy(run):
    import numpy as np
    from sklearn.metrics import roc_auc_score
    sys.path.insert(0,str(ROOT/"new_runs/c3b/code"))
    from verified_metrics import fpr_at_recall
    from c3b_scoring import score,select
    config=read(run/"config.json")["arguments"]
    with np.load(run/"logits.npz",allow_pickle=False) as z:a={k:z[k] for k in z.files}
    temps=[float(v) for v in config["temp_candidates"].split(",")]
    sel=select("adapter","energy",temps,a["kz"],a["ka"],a["uz"],a["ua"],True,.5,[0.,.25,.5,.75,1.],"fpr95")
    sv=np.r_[score(a["ka"],sel["T_score"],"energy"),score(a["ua"],sel["T_score"],"energy")]
    vy=np.r_[np.zeros(len(a["ka"]),dtype=int),np.ones(len(a["ua"]),dtype=int)]
    threshold=fpr_at_recall(sv,vy)["threshold"]
    st=score(a["ta"],sel["T_score"],"energy");known=a["ty"]>=0;y=(~known).astype(int);reject=st>=threshold
    return dict(method="Energy-T-tuned",selection=sel,auroc=float(roc_auc_score(y,st)),fpr95=fpr_at_recall(st,y)["fpr95"],
        known_acc=float((a["ta"].argmax(1)[known]==a["ty"][known]).mean()),frozen_val_tpr95_threshold=threshold,
        frozen_threshold_test_known_fpr=float(reject[known].mean()),frozen_threshold_test_unknown_tpr=float(reject[~known].mean()))


def verify_samples(run,unit,data):
    for role in ["train","val_known","val_unknown","test"]:
        actual=read(run/(role+"_samples.json"));expected=unit["roles"][role]
        paths={r["path"].replace("\\","/") for r in actual};frozen={r["path"] for r in expected}
        assert paths==frozen,(role,len(paths),len(frozen))
        for row in expected:assert sha(Path(data)/row["path"])==row["sha256"]
    protocol=read(run/"disjoint_protocol.json")
    assert set(protocol["known"])==set(unit["known"])
    assert set(protocol["calibration_unknown"])==set(unit["validation_unknown"])
    assert set(protocol["target_unknown"])==set(unit["target_unknown"])


def report(rows):
    lines=["# Office Home 两单元计时试点报告","","## 1 做了什么","完成预设的两个 rotation00 seed0 单元。没有自动扩展至20单元。","","## 2 文件位置","evidence/C1_pilot.json；new_runs/officehome/pilot；prespec/C1_pilot.json。","","## 3 实测数据与来源","下表所有时间来自 evidence/C1_pilot.json 的实际 perf_counter 测量，不是排程估计。","","| 单元 | 完成 epoch | 训练与主评估 秒 | 附加处理 秒 |","| --- | ---: | ---: | ---: |"]
    for row in rows:lines.append(f"| {row['unit']} | {row['epochs']} | {row['training_and_primary_evaluation_seconds']:.2f} | {row['additional_postprocessing_seconds']:.2f} |")
    lines += ["","所有方法的真实数值与不利结果保存在同一 JSON，不按试点效果决定是否扩展。","","## 4 对结论的影响","这两个单元用于资源计时，不构成 Office-Home 完整面板。验证未知样本仅150张，阈值估计可能更噪；10-shot训练预算与 PACS 不同，结果不合并。","","## 5 需要用户决定的事","请根据实测耗时与资源决定是否授权阶段1剩余18单元；若授权须完成全部预设20单元，不因结果方向增减。seed1/2阶段仍需另外确认。"]
    (ROOT/"reports/C1_两单元计时试点报告.md").write_text("\n".join(lines)+"\n",encoding="utf-8")


def main():
    spec=freeze()
    if "--prepare-only" in sys.argv:print("C1 timing-pilot execution design sealed; no GPU use.");return
    assert read(ROOT/"evidence/C3b_progress.json")["stage"]=="complete_requires_manuscript_integration"
    assert read(ROOT/"evidence/C1_acquisition.json")["accepted"]
    plan=read(WORK/"accepted_roles.json");literal=read(ROOT/"prespec/C1_accepted_roles.json")
    assert sha(WORK/"accepted_roles.json")==literal["manifest_sha256"]
    for name,digest in spec["code_hashes"].items():assert sha(ROOT/name)==digest
    lock=ROOT/"new_runs/GPU_QUEUE.lock"
    with lock.open("x") as f:f.write(str(os.getpid()))
    done=0;rows=[]
    try:
        for uid in plan["pilot"]:
            if (ROOT/"new_runs/PAUSE_REQUESTED").exists():state("paused_at_unit_boundary",completed=done,total=2);return
            unit=next(u for u in plan["units"] if u["unit_id"]==uid);run=WORK/"pilot"/uid
            timing=WORK/"pilot"/(uid+"_timing.json");log=WORK/"pilot"/(uid+".log");run.parent.mkdir(parents=True,exist_ok=True)
            if run.exists() and not timing.exists():raise RuntimeError("Partial C1 pilot requires inspection: "+uid)
            if not run.exists():
                command=[sys.executable,"-B","-s","-u",str(ROOT/"scripts/officehome_train.py"),"--data_root",plan["data_root"],
                    "--target_domain",unit["target"],"--val_domain",unit["val"],
                    "--unknown_classes",",".join(unit["validation_unknown"]+unit["target_unknown"]),
                    "--calibration_unknown_classes",",".join(unit["validation_unknown"]),"--target_unknown_classes",",".join(unit["target_unknown"]),
                    "--seed","0","--model","ViT-B-32","--epochs","20","--early_stop","3","--early_stop_metric","known_nll",
                    "--batch_size","64","--lr","2e-5","--hidden_ratio","0.0625","--max_scale","0.05","--cos_reg","0.2","--amp",
                    "--num_workers","0","--openclip_cache_dir","C:/icip_osr/.cache/clip","--templates",
                    "a photo of a {}|a sketch of a {}|a cartoon of a {}|a painting of a {}"]
                dump(WORK/"pilot"/(uid+"_launch.json"),dict(command=command,unit=uid,accepted_roles_sha256=sha(WORK/"accepted_roles.json"),prespec_sha256=sha(ROOT/"prespec/C1_pilot.json")))
                state("training",completed=done,total=2,current=uid)
                started=time.perf_counter()
                with log.open("w",encoding="utf-8") as f:
                    subprocess.run(command,cwd=WORK,env=dict(os.environ,PAPER2_RUN_DIR=str(run),OFFICEHOME_UNIT_ID=uid,PYTHONDONTWRITEBYTECODE="1"),
                        stdout=f,stderr=subprocess.STDOUT,check=True)
                wall=time.perf_counter()-started
                post=time.perf_counter();verify_samples(run,unit,plan["data_root"])
                for name,h in read(run/"artifact_hashes.json").items():assert sha(run/name)==h
                energy=evaluate_energy(run);results=read(run/"results.json")+[energy]
                measured=dict(unit=uid,epochs=len((run/"epochs.jsonl").read_text().splitlines()),
                    training_and_primary_evaluation_seconds=wall,additional_postprocessing_seconds=time.perf_counter()-post,
                    sample_counts={k:len(v) for k,v in unit["roles"].items()},results=results)
                dump(timing,measured)
            measured=read(timing);rows.append(measured);done+=1;state("unit_complete",completed=done,total=2,current=uid)
        dump(ROOT/"evidence/C1_pilot.json",dict(task="C1_pilot",records=rows,prespec_sha256=sha(ROOT/"prespec/C1_pilot.json"),
            accepted_roles_sha256=sha(WORK/"accepted_roles.json"),stage1_remaining18_authorized=False,stage2_authorized=False,
            mean_training_and_primary_evaluation_seconds=sum(r["training_and_primary_evaluation_seconds"] for r in rows)/len(rows),
            no_population_claim=True,not_pooled_with_PACS=True))
        report(rows);state("complete_awaiting_stage1_user_decision",completed=done,total=2,remaining_stage1_units=18)
    except Exception as exc:state("failed_requires_inspection",completed=done,total=2,error=repr(exc));raise
    finally:lock.unlink(missing_ok=True)


if __name__=="__main__":main()
