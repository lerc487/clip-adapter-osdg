"""Run an unchanged training copy with stable postprocessing hooks only."""
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"new_runs/c3b/code"))
import train_disjoint
from c3b_scoring import score,select

train_disjoint.score_unknown_from_logits=score
train_disjoint.choose_score_source_and_temp=select

if __name__=="__main__":train_disjoint.main()
