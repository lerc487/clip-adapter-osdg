"""Use the accepted Office-Home sample manifest, never a fresh random split."""
import json
import os
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]


def selected_rows(unit,domain,names):
    names=set(names)
    if domain==unit["target"]:roles=["test"]
    elif domain==unit["val"]:roles=["val_known","val_unknown"]
    else:roles=["train"]
    return [(r["path"],r["category"]) for role in roles for r in unit["roles"][role]
            if r["domain"]==domain and r["category"] in names]


def main():
    import hashlib
    manifest=ROOT/"new_runs/officehome/accepted_roles.json"
    literal=json.loads((ROOT/"prespec/C1_accepted_roles.json").read_text())
    assert hashlib.sha256(manifest.read_bytes()).hexdigest()==literal["manifest_sha256"]
    plan=json.loads(manifest.read_text());unit=next(u for u in plan["units"] if u["unit_id"]==os.environ["OFFICEHOME_UNIT_ID"])
    sys.path.insert(0,str(ROOT/"new_runs/c3b/code"))
    import train_disjoint
    from c3b_scoring import score,select
    def samples(data_root,domain,names):
        assert str(Path(data_root).resolve())==plan["data_root"]
        return [(str(Path(data_root)/p),c) for p,c in selected_rows(unit,domain,names)]
    train_disjoint.collect_samples=samples
    train_disjoint.score_unknown_from_logits=score
    train_disjoint.choose_score_source_and_temp=select
    train_disjoint.main()


if __name__=="__main__":main()
