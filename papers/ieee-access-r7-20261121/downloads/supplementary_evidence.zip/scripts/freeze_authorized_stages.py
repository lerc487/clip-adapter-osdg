"""Record the user's staged authorization and freeze C3b before GPU work."""
import hashlib
import json
from pathlib import Path
import shutil
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write_new(p,x):
    with p.open("x",encoding="utf-8") as f:json.dump(x,f,indent=2,ensure_ascii=False)


def main():
    work=ROOT/"new_runs/c3b"
    for name in ["code","pacs","evaluations","logs"]:(work/name).mkdir(parents=True,exist_ok=True)
    for old in (BASE/"05_new_runs/code").glob("*.py"):
        dest=work/"code"/old.name
        if dest.exists():assert sha(old)==sha(dest)
        else:shutil.copy2(old,dest)
    units=[u for u in read(BASE/"03_protocol/pacs_disjoint_plan.json")["units"] if u["seed"]==0]
    assert len(units)==28
    for u in units:
        existing=BASE/"05_new_runs/vitb32_full20/pacs"/u["unit_id"]
        u["reuse_readonly"]=(existing/"completed.json").exists()
        u["existing_run"]=str(existing) if u["reuse_readonly"] else None
    assert sum(u["reuse_readonly"] for u in units)==4
    code=list((work/"code").glob("*.py"))+[ROOT/"scripts"/f for f in ["c3b_scoring.py","c3b_train.py","c3b_evaluate.py","c3b_queue.py"]]
    spec=dict(task="C3b",created_utc=datetime.now(timezone.utc).isoformat(),authorized=True,
        prior_target_access="Earlier 84-unit and four full20 outcomes were inspected; this is an additional sensitivity design, not prospective confirmation.",
        design="PACS four targets by seven fixed role rotations, seed0; 20 epochs, no early stopping; four completed full20 trajectories reused read-only, 24 new fits.",
        data_root="C:/icip_osr/data/PACS",units=units,selectors=["known_NLL","validation_MSP_AUROC","validation_energy_AUROC"],
        selector_rules="Recompute each epoch's known NLL and MSP/energy T=1 AUROC from validation logits in float64. Minimum NLL or maximum AUROC; earliest exact tie. Freeze all epoch and score selections before target inference.",
        methods=["Energy-T-tuned","autoMixTemp"],temperature_grid=[.2,.3,.4,.5,.6,.8,1,1.2,1.5,2,3,4,5],
        mixing_grid=[0.,.25,.5,.75,1.],source_order=["adapter","zeroshot","mix"],
        score_selection="Validation FPR@95 minimized, then AUROC maximized, then first in adapter/zeroshot/mix and temperature order, exact comparisons matching stable audit.",
        arithmetic="float64 stable MSP log-odds and negative energy; threshold-realizable FPR@95, unknown-positive; alpha mixing in float64.",
        training="Copied prior train_disjoint, same known cross-entropy plus cosine penalty, AdamW lr2e-5, batch64, amp, hidden ratio.0625, maxscale.05, cosine.2, ViT-B/32 openai, same four prompts. Only scoring hooks are replaced; no objective retuning.",
        metrics=["AUROC","FPR@95","frozen_validation95_target_unknown_recall","known_rejection","known_accuracy"],
        summary="All 28 units equally weighted, all three selectors and both methods reported regardless of direction. No IID significance, population inference or deployment guarantee. Not merged with primary panel or Office-Home.",
        failure_policy="Stop on nonzero exit, nonfinite output, partial directory, mismatched artifacts, absent data; do not reduce budget or change parameters. Pause at unit boundaries when PAUSE_REQUESTED exists.",
        fixtures="Before launch verify float64 scoring/selection equality to the existing stable audit on deterministic synthetic tensors, no GPU and no target data.",
        scheduling="One GPU process at a time; C3b, then authorized Office-Home timing pilot after data acceptance, then NegLabel. C3b queue stops after completion pending next-stage setup.",
        frozen_code_hashes={str(p.relative_to(ROOT)).replace("\\","/"):sha(p) for p in code},
        prior_plan_sha256=sha(BASE/"03_protocol/pacs_disjoint_plan.json"))
    write_new(ROOT/"prespec/C3b.json",spec)
    write_new(ROOT/"prespec/C3b_seal.json",dict(task="C3b",sha256=sha(ROOT/"prespec/C3b.json"),sealed_utc=datetime.now(timezone.utc).isoformat(),frozen_before_new_execution=True))
    write_new(ROOT/"evidence/authorization_20261119.json",dict(
        source="Explicit user reply to C0 in this conversation",recorded_utc=datetime.now(timezone.utc).isoformat(),
        C3b="Authorized 28 total full20 PACS units, seed0, three selectors, background serial queue.",
        C1="Authorized staged Office-Home; await data path or explicit download confirmation; two-unit pilot then user timing decision for 20-unit seed0 stage; seed1/seed2 require later decision; no outcome-based staging.",
        C2_NegLabel="Authorized lightweight official-reference port with same-input official-function numeric alignment; two vocabularies fixed; notify before WordNet download; not a reproduction of published numbers.",
        C2_LoCoOp="Not run by user decision; write protocol-mismatch rationale, not execution failure.",C4="Not run by user decision.",
        GPU_order=["C3b","Office-Home two-unit pilot","NegLabel"],single_GPU=True,unfavorable_results_retained=True))
    print(json.dumps(dict(spec_sha256=sha(ROOT/"prespec/C3b.json"),units=28,new_fits=24,reused=4),indent=2))


if __name__=="__main__":main()
