"""Complete18additional units, reusing the two fixed pilots read-only."""
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from officehome_pilot import verify_samples
from officehome_pilot_v3_eval64 import verify_exact_labels
from officehome_stable_evaluation import evaluate_stable

ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/"new_runs/officehome/dedup_v3"


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):
    p.parent.mkdir(parents=True,exist_ok=True);tmp=p.with_suffix(".tmp")
    tmp.write_text(json.dumps(x,indent=2,allow_nan=False),encoding="utf-8");tmp.replace(p)
def new(p,x):
    with p.open("x",encoding="utf-8") as f:json.dump(x,f,indent=2,allow_nan=False)
def state(stage,**kw):dump(ROOT/"evidence/C1_stage1_v3_progress.json",dict(stage=stage,protocol_version="C1_dedup_v3",pid=os.getpid(),updated=time.strftime("%Y-%m-%dT%H:%M:%S"),**kw))


def freeze():
    plan=read(WORK/"roles_manifest.json");assert len(plan["stage1"])==20 and len(plan["pilot"])==2
    p=ROOT/"prespec/C1_stage1_v3_eval64.json"
    if p.exists():return read(p),plan
    auth=ROOT/"evidence/C1_stage1_authorization_20261119.json"
    new(auth,dict(source="Explicit user reply after receipt of measured pilot timings in this conversation",
        answer="继续阶段1剩余18个单元",recorded_utc=datetime.now(timezone.utc).isoformat(),
        stage1_remaining18_authorized=True,stage2_seed1_seed2_authorized=False,
        scope="Finish all20fixedseed0units, reuse two completed pilots read-only; no outcome-conditioned unit or method removal."))
    names=["officehome_stage1_v3.py","officehome_train_stage1_v3.py","officehome_stable_evaluation.py","officehome_pilot_v3_eval64.py","officehome_pilot.py","officehome_train.py","c3b_scoring.py"]
    code=[ROOT/"scripts"/n for n in names]+sorted((ROOT/"new_runs/c3b/code").glob("*.py"))
    reused=[]
    for uid in plan["pilot"]:
        directory=WORK/"pilot_eval64"/uid;timing=directory.parent/(uid+"_timing.json")
        reused.append(dict(unit=uid,run=str(directory),timing=str(timing),timing_sha256=sha(timing),
            stable_results_sha256=sha(directory.parent/(uid+"_stable_evaluation")/"results.json")))
    template=WORK/"pilot_eval64"/(plan["pilot"][0]+"_launch.json")
    spec=dict(task="C1_stage1_v3_eval64",created_utc=datetime.now(timezone.utc).isoformat(),authorization_sha256=sha(auth),
        parent_stage_design_sha256=sha(ROOT/"prespec/C1_stages.json"),input_amendment_sha256=sha(ROOT/"prespec/C1_dedup_v3.json"),
        literal_roles_spec_sha256=sha(ROOT/"prespec/C1_roles_manifest_v3.json"),roles_manifest_sha256=sha(WORK/"roles_manifest.json"),
        parent_score_protocol_sha256=sha(ROOT/"prespec/C1_pilot_v3_eval64.json"),
        unit_ids=plan["stage1"],reused_pilots=reused,new_training_ids=[u for u in plan["stage1"] if u not in plan["pilot"]],
        command_template=str(template),command_template_sha256=sha(template),
        training="Same pilot command and settings, replace only wrapper, target/validation domains, frozen unknown-class lists. Seed0 only; max20epochs, known-NLL patience3, fixed reference score grids; no retraining of completed pilots.",
        scoring="Use already sealed float64 mixing/stable scoring helper for all seven methods. Its numerical protocol pointer remains the parent pilot spec; add a stage1 execution link and this scope/manifest hash to every new unit timing record. Preserve original archive outputs.",
        methods=["MSP","Temp-MSP","Energy-only-T1","Mix-alpha0.5-T-tuned","autoMixTemp","Zero-shot-T-tuned","Energy-T-tuned"],
        summary="All20units, each method, equal-unit descriptive means for AUROC/FPR95/known accuracy/OSR accuracy/frozen threshold recall and rejection; per-unit times and nominal/unique content counts. No IID confidence or deployment guarantee. Separate from PACS and CIFAR. All outcomes retained.",
        staging="Pilot outcomes have already been inspected. Stage1 coverage/order and conditions were frozen before the pilot, and expansion was authorized after actual timing. No configuration or scope selected for favorable outcomes. Stage2 seed1/2 remains unauthorized.",
        failure="One global GPU lock; pause at unit boundaries; stop on errors, partial output, mismatched frozen hashes or manifests. No silent retries, resampling, budget reduction or method substitution.",
        code_hashes={f.relative_to(ROOT).as_posix():sha(f) for f in code})
    new(p,spec);new(ROOT/"prespec/C1_stage1_v3_eval64_seal.json",dict(task=spec["task"],sha256=sha(p)))
    return spec,plan


def main():
    spec,plan=freeze();seal=read(ROOT/"prespec/C1_stage1_v3_eval64_seal.json")
    assert sha(ROOT/"prespec/C1_stage1_v3_eval64.json")==seal["sha256"]
    assert sha(WORK/"roles_manifest.json")==spec["roles_manifest_sha256"]
    for name,h in spec["code_hashes"].items():assert sha(ROOT/name)==h
    for u in spec["reused_pilots"]:assert sha(Path(u["timing"]))==u["timing_sha256"]
    assert read(ROOT/"evidence/C1_pilot_v3_eval64_fixture_checks.json")["passed"]
    assert read(ROOT/"evidence/C1_pilot_v3_eval64_numerical_fixtures.json")["passed"]
    if "--prepare-only" in sys.argv:print("Stage1 fixed20units sealed, two read-only pilots plus18newfits; noGPU used.");return
    lock=ROOT/"new_runs/GPU_QUEUE.lock"
    with lock.open("x") as f:f.write(str(os.getpid()))
    rows=[];completed=0
    try:
        for uid in spec["unit_ids"]:
            if (ROOT/"new_runs/PAUSE_REQUESTED").exists():state("paused_at_unit_boundary",completed=completed,total=20,next_unit=uid);return
            unit=next(u for u in plan["units"] if u["unit_id"]==uid);assert unit["seed"]==0
            if uid in plan["pilot"]:
                item=next(u for u in spec["reused_pilots"] if u["unit"]==uid)
                measured=read(Path(item["timing"]));run=Path(item["run"])
                for name,h in read(run/"artifact_hashes.json").items():assert sha(run/name)==h
                assert sha(run.parent/(uid+"_stable_evaluation")/"results.json")==item["stable_results_sha256"]
                rows.append(measured);completed+=1;state("reused_pilot_verified",completed=completed,total=20,current=uid);continue
            run=WORK/"stage1_eval64"/uid;timing=run.parent/(uid+"_timing.json");log=run.parent/(uid+".log")
            run.parent.mkdir(parents=True,exist_ok=True)
            if run.exists() and not timing.exists():raise RuntimeError("Partial stage1 unit requires inspection: "+uid)
            if not run.exists():
                command=list(read(Path(spec["command_template"]))["command"])
                assert command[4].endswith("officehome_train_v3.py")
                command[0]=sys.executable;command[4]=str(ROOT/"scripts/officehome_train_stage1_v3.py")
                for flag,value in {"--data_root":plan["data_root"],"--target_domain":unit["target"],"--val_domain":unit["val"],
                    "--unknown_classes":",".join(unit["validation_unknown"]+unit["target_unknown"]),
                    "--calibration_unknown_classes":",".join(unit["validation_unknown"]),"--target_unknown_classes":",".join(unit["target_unknown"])}.items():
                    command[command.index(flag)+1]=value
                dump(run.parent/(uid+"_launch.json"),dict(command=command,unit=uid,stage1_spec_sha256=seal["sha256"],roles_manifest_sha256=spec["roles_manifest_sha256"]))
                state("training",completed=completed,total=20,current=uid,new_training_total=18,reused_pilots=2)
                start=time.perf_counter()
                with log.open("x",encoding="utf-8") as f:
                    subprocess.run(command,cwd=WORK,env=dict(os.environ,PAPER2_RUN_DIR=str(run),OFFICEHOME_UNIT_ID=uid,PYTHONDONTWRITEBYTECODE="1"),stdout=f,stderr=subprocess.STDOUT,check=True)
                wall=time.perf_counter()-start;start=time.perf_counter()
                verify_samples(run,unit,plan["data_root"]);verify_exact_labels(run,unit)
                for name,h in read(run/"artifact_hashes.json").items():assert sha(run/name)==h
                evaluation=run.parent/(uid+"_stable_evaluation");results=evaluate_stable(run,evaluation)
                dump(evaluation/"stage1_execution_link.json",dict(stage1_spec_sha256=seal["sha256"],parent_score_protocol_sha256=spec["parent_score_protocol_sha256"],roles_manifest_sha256=spec["roles_manifest_sha256"]))
                post=time.perf_counter()-start
                measured=dict(unit=uid,protocol_version="C1_dedup_v3",epochs=len((run/"epochs.jsonl").read_text().splitlines()),
                    training_and_primary_evaluation_seconds=wall,additional_postprocessing_seconds=post,measured_unit_pipeline_seconds=wall+post,
                    sample_counts={k:len(v) for k,v in unit["roles"].items()},unique_content_counts={k:len({r["sha256"] for r in v}) for k,v in unit["roles"].items()},
                    stage1_spec_sha256=seal["sha256"],roles_manifest_sha256=spec["roles_manifest_sha256"],results=results)
                dump(timing,measured)
            rows.append(read(timing));completed+=1;state("unit_complete",completed=completed,total=20,current=uid)
        assert len(rows)==20 and len({r["unit"] for r in rows})==20
        records=[dict(unit=r["unit"],**m) for r in rows for m in r["results"]];summary=[]
        for method in spec["methods"]:
            selected=[r for r in records if r["method"]==method];assert len(selected)==20
            fields=["auroc","fpr95","known_acc","osr_acc","frozen_threshold_test_known_fpr","frozen_threshold_test_unknown_tpr"]
            summary.append(dict(method=method,n=20,**{k:sum(r[k] for r in selected)/20 for k in fields}))
        dump(ROOT/"evidence/C1_stage1_v3_eval64.json",dict(task=spec["task"],stage1_spec_sha256=seal["sha256"],
            roles_manifest_sha256=spec["roles_manifest_sha256"],records=records,summary=summary,timings=rows,
            no_IID_inference=True,not_pooled_with_other_datasets=True,stage2_authorized=False))
        state("complete_requires_manuscript_integration",completed=20,total=20,new_fits=18,reused_pilots=2,stage2_not_started=True)
    except Exception as exc:state("failed_requires_inspection",completed=completed,total=20,error=repr(exc));raise
    finally:lock.unlink(missing_ok=True)


if __name__=="__main__":main()
