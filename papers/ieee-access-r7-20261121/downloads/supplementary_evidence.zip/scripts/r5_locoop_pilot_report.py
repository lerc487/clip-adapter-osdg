"""Report audited timing and all pilot outcomes, without launching a batch."""
from gap_closure_core import ROOT,read,sha,write


def main():
    audit=read(ROOT/"evidence/E6_pilot_audit.json");plan=read(ROOT/"evidence/E6_batch_planning_projection.json")
    assert audit["all_checks_pass"] and plan["batch_started"] is False
    facts=read(ROOT/"evidence/E0_precision.json")["records"]
    timings=plan["measured_pilots"];rows=[]
    for t in timings:
        ds,uid=t["dataset"],t["unit"]
        for method in ["MSP","Temp-MSP","autoMixTemp"]:
            r=next(v for v in facts if (v["model"],v["dataset"],v["unit"],v["method"])==("ViT-B32",ds,uid,method))
            rows.append(dict(dataset=ds,unit=uid,method=method,auroc=r["auroc"],fpr95=r["fpr95"],recall=r["recall"],rejection=r["rejection"],budget="fixed_adapter_primary"))
        for r in audit["records"]:
            if r["dataset"]==ds:
                rows.append(dict(dataset=ds,unit=uid,method="LoCoOp-"+r["method"],auroc=r["auroc"],fpr95=r["fpr95"],
                    recall=r["frozen_unknown_recall"],rejection=r["frozen_known_rejection"],budget="separate_prompt50epochs_lambda0.1"))
    pacs=next(r["measured_processing_seconds"] for r in timings if r["dataset"]=="pacs")
    cifar=next(r["measured_processing_seconds"] for r in timings if r["dataset"]=="cifar10")
    projected_one=27*pacs+4*cifar
    write(ROOT/"evidence/E6_pilot_report_bindings.json",dict(pilot_audit_sha256=sha(ROOT/"evidence/E6_pilot_audit.json"),
        rows=rows,timings=timings,full_two_lambda_new_fits=64,full_two_lambda_projected_hours=plan["projected_processing_seconds"]/3600,
        fixed_lambda01_new_fits=31,fixed_lambda01_projected_hours=projected_one/3600,
        projection_not_future_measured_runtime=True,projection_based_only_on_time_and_scope=True,batch_started=False),exclusive=True)
    lines=["# E6 官方 LoCoOp 两单元试点：完成与批量决策报告","",
        "## 1. 做了什么",
        "使用固定提交版本的官方 LoCoOp/Dassl 原代码，不做近似实现。PACS与CIFAR各一个固定seed0单元，均完成50轮提示学习；只用已知验证NLL选checkpoint。测试未知类不参与训练和选点。官方MCM/GL-MCM及两种float64表示全部保留。独立CPU审计已通过。",
        "", "## 2. 文件和章节",
        "`evidence/E6_pilot_audit.json`、`E6_pilot_results.json`、`E6_batch_planning_projection.json`、`E6_pilot_report_bindings.json`；原始数组和50轮提示checkpoint在 `new_runs/locoop_pilot/`。完整比较对应R3.4，尚未以两个试点代替正文完整面板。",
        "", "## 3. 实际数字及 JSON 来源",
        "下列耗时为实际处理时间，包含模型构建、50轮训练与已知验证、选点及得分/归档；不包括此前环境安装和之后独立审计，不是未来用时：","",
        "| 数据集/固定单元 | 训练文件 | 已知验证 | 目标文件 | 实测秒 | 实测分钟 |",
        "| --- | --- | --- | --- | --- | --- |"]
    for r in timings:
        lines.append("| "+" | ".join(map(str,[r["dataset"]+"/"+r["unit"],r["train_files"],r["known_validation_files"],r["target_files"],format(r["measured_processing_seconds"],".3f"),format(r["measured_processing_seconds"]/60,".2f")]))+" |")
    lines.extend(["", "全部试点结果（每行只代表该数据集一个固定单元，不能当总体均值）：","",
        "| 数据集 | 方法 | AUROC | FPR95 | 冻结阈值未知召回 | 已知误拒 |",
        "| --- | --- | --- | --- | --- | --- |"])
    for r in rows:
        lines.append("| "+" | ".join([r["dataset"],r["method"]]+[format(r[k],".6f") for k in ["auroc","fpr95","recall","rejection"]])+" |")
    lines.extend(["", "各方法采用未知为正、完整并列组的统一ROC定义，不是原论文的已知为正、最接近95%召回评估。官方float32与float64结果分开列示，没有静默替换。",
        "", "## 4. 有利还是不利",
        "试点证明官方训练和字面样本角色接入可行，不再使用‘没有运行LoCoOp’作为回应。它不证明autoMixTemp优于LoCoOp：只有两单元、不同检测器另训提示且训练预算不同，所有有利/不利结果都保留。PACS提示训练使用2838张源已知图像、CIFAR96张；不能称标准ImageNet少样本基准数字复现。",
        "", "## 5. 需要作者决定的事",
        "为覆盖全部seed0域/类别角色，可做PACS28+CIFAR5，共33个单元；两个预声明正则权重0.1/0.25分别跑完并全部报告，共66次拟合，复用已完成两个权重0.1试点，新增64次。",
        "",f"按实测两试点外推，新增64次约 **{plan['projected_processing_seconds']/3600:.1f}小时**；若只固定权重0.1，则新增31次约 **{projected_one/3600:.1f}小时**。这两项是基于样本量/耗时的排程估计，不是未来实测，角色规模、I/O和其他CPU任务会改变耗时，也不含最终审计。",
        "", "建议完整的两权重匹配范围，以增加超参数敏感性覆盖；是否批准由作者决定。两方案均不增加ViT-B/16、不按目标成绩挑权重、不覆盖旧结果。未获确认前不启动LoCoOp批量。Office-Home已恢复剩余36个新增单元；独立checkpoint的41个缺失目标快照随后串行推理。",
        "", "参考方法来源：[LoCoOp官方代码](https://github.com/AtsuMiyai/LoCoOp)、[LoCoOp原论文](https://arxiv.org/abs/2306.01293)、[GL-MCM正式论文](https://doi.org/10.1007/s11263-025-02356-z)。官方建议在非ImageNet条件下明确报告topk与正则权重，并区分MCM和GL-MCM；本试点均已封存。",
        "", "审计完成不等于全部17条已获解决，更不等于录用保证。"])
    with (ROOT/"reports/E6_官方LoCoOp两试点完成与批量决策报告.md").open("x",encoding="utf-8") as f:f.write("\n".join(lines)+"\n")
    print("Audited pilot report saved; full64fit projection %.1fh, fixedweight31fit projection %.1fh; no batch launched."%(plan["projected_processing_seconds"]/3600,projected_one/3600))


if __name__=="__main__":main()
