"""Check the scoped editorial requirements without recomputing research runs."""
from pathlib import Path
from xml.etree import ElementTree as ET
from zipfile import ZipFile
import csv
import hashlib
import json
import re
import statistics
import unicodedata
from pypdf import PdfReader

ROOT = Path(__file__).resolve().parents[1]
OLD = ROOT.parent / "revision5_gap_closure_20261119"
OUT = ROOT / "final_review_20261120"
def read(path): return json.loads(Path(path).read_text(encoding="utf-8-sig"))
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def norm(s): return re.sub(r"\s+", "", unicodedata.normalize("NFKC", s).replace("\u00ad", ""))
def dump(path, data): Path(path).write_text(json.dumps(data, indent=2, ensure_ascii=False, allow_nan=False), encoding="utf-8")
def text(path): return "\n".join(p.extract_text() for p in PdfReader(path).pages)

def main():
    clean = text(ROOT / "source/manuscript.pdf")
    highlighted = text(ROOT / "source/manuscript_highlighted.pdf")
    assert clean == highlighted, "Clean/highlighted extracted text differs"
    assert len(PdfReader(ROOT / "source/manuscript.pdf").pages) <= 14
    docs = {"main":clean, "supplement":text(ROOT / "source/supplement.pdf"),
            "response":text(OUT / "response_to_reviewers.pdf")}
    banned = ["AI-assisted", "original submission", "post-review", "authorized", "requested", "merely", "superseded"]
    scans = {name:{word:len(re.findall(re.escape(word), value, re.I)) for word in banned} for name, value in docs.items()}
    assert not any(n for row in scans.values() for n in row.values()), scans
    source = ROOT / "source"
    aux = (source / "manuscript.aux").read_text(encoding="utf-8")
    citations = []
    for group in re.findall(r"\\citation\{([^}]+)\}", aux):
        for key in group.split(","):
            if key not in citations: citations.append(key)
    bib = dict((k,int(v)) for k,v in re.findall(r"\\bibcite\{([^}]+)\}\{(\d+)\}", aux))
    assert [bib[k] for k in citations] == list(range(1,36))
    assert citations[-1] == "codex" and bib["codex"] == 35
    counts = read(ROOT / "evidence/F5_editorial_word_counts.json")
    assert counts["abstract_words_including_numbers"] <= 180
    assert counts["current_body_words"] / counts["before_body_words"] <= .85
    response = read(ROOT / "evidence/responses.json")
    before = read(OLD / "evidence/responses.json")
    assert [(r["id"],r["concern"]) for r in response["records"]] == [(r["id"],r["concern"]) for r in before["records"]]
    with ZipFile(OUT / "response_to_reviewers.docx") as z:
        xml = ET.fromstring(z.read("word/document.xml"))
    ns = {"w":"http://schemas.openxmlformats.org/wordprocessingml/2006/main"}
    paras = ["".join(p.itertext()) for p in xml.findall("w:body/w:p", ns)]
    word = norm("\n".join(paras))
    pdf = norm(docs["response"])
    for row in response["records"]:
        for key in ["concern", "response", "action"]:
            assert norm(row[key]) in word and norm(row[key]) in pdf, (row["id"],key)
    assert all(sum(p.startswith(prefix) for p in paras)==17 for prefix in ["Reviewer's concern:","Author response:","Author action:"])
    registry = read(ROOT / "evidence/response_number_registry.json")
    assert registry["compiled_manuscript_sha256"] == sha(source / "manuscript.pdf")
    for r in registry["records"]:
        v = read(ROOT / "evidence" / r["file"])
        for key in r["pointer"]: v = v[key]
        assert v == r["value"] and format(v,"."+str(r["decimals"])+"f")==r["display"]
        assert norm(r["display"]) in word
    f1 = read(ROOT / "evidence/F1_editorial_verified_values.json")
    for key, origin in f1["origins"].items():
        if "pointer" not in origin: continue
        value = read(ROOT / "evidence" / origin["file"])
        for k in origin["pointer"]: value = value[k]
        assert f1["values"][key] == value * origin.get("scale",1), key
    labels, supp = response["labels"], response["supplementary_labels"]
    mapping = read(ROOT / "evidence/F2_figure_renumbering.json")
    for row in mapping:
        if row["new"] is None: assert "fig:"+row["label"] not in labels
        else: assert labels["fig:"+row["label"]]["number"] == str(row["new"])
    assert sorted(int(v["number"]) for k,v in labels.items() if k.startswith("tab:")) == list(range(1,16))
    assert all(supp["tab:supp-"+str(i)]["number"]=="S"+str(i) for i in range(1,20))
    assert all(supp["tab:oh-seed-"+str(i)]["number"]=="S"+str(17+i) for i in range(3))
    assert supp["fig:supp-acceptance"]["number"] == "S1"
    reference_checks = []
    for row in response["records"]:
        action = row["action"]
        main_action = action.split("Supplementary",1)[0]
        for token in re.findall(r"(?<![A-Za-z])\d+(?![A-Za-z])", main_action):
            assert 1 <= int(token) <= 15
        for item in re.findall(r"S(\d+)", action): assert 1 <= int(item) <= 19
        assert "Complete per-unit outcomes" not in action
        reference_checks.append(dict(comment=row["id"], actual_action=action, current_locations_verified=True,
                                     reviewer_concern_quote_numbers_are_historical=True))
    protected = read(ROOT / "evidence/F0_editorial_input_manifest.json")
    assert all(sha(r["path"]) == r["sha256"] for r in protected)
    unchanged = []
    for p in (OLD / "evidence").iterdir():
        if p.is_file() and re.match(r"^(E[0-8](?:_|\.)|B[1-7](?:_|\.)|C[123])",p.name):
            assert sha(ROOT / "evidence" / p.name)==sha(p),p.name
            unchanged.append(p.name)
    proof = dict(all_editorial_checks_pass=True, clean_highlight_text_exactly_equal=True,
        main_pages=len(PdfReader(source / "manuscript.pdf").pages),
        supplement_pages=len(PdfReader(source / "supplement.pdf").pages),
        response_pages=len(PdfReader(OUT / "response_to_reviewers.pdf").pages),
        word_counts=counts, forbidden_phrase_counts=scans, author_ai_footnotes_removed=7,
        main_figures=8, main_tables=15, supplementary_tables=19,
        reference_count=35, first_citation_order_verified=True, codex_reference_number=35,
        clean_highlight_pdf_current_hashes=[sha(source / f) for f in ["manuscript.pdf","manuscript_highlighted.pdf"]],
        all_17_full_responses_retained=True, literal_reviewer_quotes_preserved=True,
        response_word_and_pdf_text_verified=True, reference_checks=reference_checks,
        reviewer_quote_reference_exception="Literal reviewer concerns retain their historical numbers; all author responses/actions use current numbering.",
        old_revision_files_preserved=len(protected), scientific_evidence_files_unchanged=unchanged,
        original_research_results_modified=False, new_experiments=False,
        author_ai_scope_confirmation_pending=True, real_author_photos_not_supplied=True,
        submission_not_performed=True)
    dump(ROOT / "evidence/F7_editorial_closeout_checks.json",proof)
    dump(OUT / "editorial_closeout_checks.json",proof)
    print(json.dumps(proof,indent=2,ensure_ascii=False))

if __name__=="__main__": main()
