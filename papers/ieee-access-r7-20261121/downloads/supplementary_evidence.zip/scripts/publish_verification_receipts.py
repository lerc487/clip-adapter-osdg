"""Publish final package receipts without changing the already-tested ZIPs."""
import hashlib
import json
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parents[1];OUT=ROOT/"deliverables"
for name in ["source_roundtrip_checks.json","portable_consistency_checks.json","officehome_portable_score_checks.json"]:
    shutil.copy2(ROOT/"evidence"/name,OUT/name)
manifest={p.name:dict(bytes=p.stat().st_size,sha256=hashlib.sha256(p.read_bytes()).hexdigest())
    for p in sorted(OUT.iterdir()) if p.is_file() and p.name!="artifact_manifest.json"}
(OUT/"artifact_manifest.json").write_text(json.dumps(manifest,indent=2),encoding="utf-8")
check=json.loads((OUT/"source_roundtrip_checks.json").read_text())
assert check["source_zip_sha256"]==manifest["clean_latex_source.zip"]["sha256"]
assert check["delivered_pdf_sha256"]==manifest["manuscript.pdf"]["sha256"]
assert check["all_page_rendered_pixels_match"]
print("Final artifact manifest and source/PDF roundtrip receipts verified.")
