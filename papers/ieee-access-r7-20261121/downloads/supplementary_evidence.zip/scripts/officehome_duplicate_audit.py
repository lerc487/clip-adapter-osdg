"""Read-only metadata audit of exact duplicate images, not new training."""
from collections import Counter,defaultdict
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/"new_runs/officehome"


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    specfile=ROOT/"prespec/C1_duplicate_audit.json"
    spec=dict(task="C1_duplicate_audit",inputs="Completed all-image integrity_check.json, no model outputs.",
        design="Group every image by exact SHA256, report every duplicate group and cross-domain subset, category agreement, all domain/category counts. Compute exact availability counts if all members of cross-domain duplicate groups were excluded, without excluding/resampling anything.",
        interpretation="Exact-byte duplication only, not a near-duplicate or pretraining-leakage audit. No target outcomes inspected. Do not proceed with revised sampling before user approval and a new immutable protocol version.",
        source_sha256=sha(WORK/"integrity_check.json"),script_sha256=sha(Path(__file__)))
    if specfile.exists():assert read(specfile)==spec
    else:
        with specfile.open("x",encoding="utf-8") as f:json.dump(spec,f,indent=2)
        with (ROOT/"prespec/C1_duplicate_audit_seal.json").open("x",encoding="utf-8") as f:json.dump(dict(task="C1_duplicate_audit",sha256=sha(specfile)),f,indent=2)
    integrity=read(WORK/"integrity_check.json");files=integrity["files"];grouped=defaultdict(list)
    for r in files:grouped[r["sha256"]].append(r)
    groups=[dict(sha256=h,images=rows,cross_domain=len({r["domain"] for r in rows})>1,
        category_agreement=len({r["category"] for r in rows})==1) for h,rows in sorted(grouped.items()) if len(rows)>1]
    cross=[g for g in groups if g["cross_domain"]];cross_hashes={g["sha256"] for g in cross}
    retained=[r for r in files if r["sha256"] not in cross_hashes]
    original=Counter((r["domain"],r["category"]) for r in files);available=Counter((r["domain"],r["category"]) for r in retained)
    counts=[dict(domain=d,category=c,original=n,hypothetical_available_after_cross_domain_group_exclusion=available[(d,c)]) for (d,c),n in sorted(original.items())]
    result=dict(task="C1_duplicate_audit",prespec_sha256=sha(specfile),source_sha256=spec["source_sha256"],
        image_count=len(files),decode_errors=len(integrity["errors"]),domain_counts=dict(sorted(Counter(r["domain"] for r in files).items())),
        classes=len({r["category"] for r in files}),exact_duplicate_groups=len(groups),exact_duplicate_group_images=sum(len(g["images"]) for g in groups),
        cross_domain_duplicate_groups=len(cross),cross_domain_duplicate_group_images=sum(len(g["images"]) for g in cross),
        cross_domain_conflicting_category_groups=sum(not g["category_agreement"] for g in cross),
        hypothetical_available_images=len(retained),hypothetical_min_images_per_domain_category=min(available.values()),
        hypothetical_cells_below10=[r for r in counts if r["hypothetical_available_after_cross_domain_group_exclusion"]<10],
        groups=groups,domain_category_counts=counts,no_data_modified=True,no_sampling_changed=True,no_officehome_training=True)
    (ROOT/"evidence/C1_duplicate_audit.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    report=["# Office Home 官方下载与重复图像检查报告","","## 1 做了什么",
        "已从[官方数据页](https://www.hemanthdv.org/officeHomeDataset.html)的 Google Drive 链接下载原 ZIP，完成服务器长度核对、ZIP CRC、逐图解码及 SHA256。严格角色检查发现同一图像出现在不同域，按预设停止验收；没有删图、换样本、改协议或启动 Office-Home 训练。","","## 2 文件和预设",
        "原 ZIP 与下载清单：new_runs/officehome/acquisition。全图像清单：integrity_check.json。首次冲突：cross_role_duplicate_error.json。完整只读重复检查：evidence/C1_duplicate_audit.json；分析前已封存 prespec/C1_duplicate_audit.json 及哈希。","","## 3 实际数据与 JSON 来源",
        "以下均为已下载清单的精确计数，来源 evidence/C1_duplicate_audit.json；不是模型结果。","","| 项目 | 计数 |","| --- | ---: |",
        f"| 图像 | {result['image_count']} |",f"| 类别 | {result['classes']} |",f"| 解码错误 | {result['decode_errors']} |",
        f"| 全部字节完全重复组 | {result['exact_duplicate_groups']} |",f"| 跨域字节完全重复组 | {result['cross_domain_duplicate_groups']} |",
        f"| 跨域重复组内图像总数 | {result['cross_domain_duplicate_group_images']} |",
        f"| 若排除跨域重复组全部成员 后的可用图像数 | {result['hypothetical_available_images']} |",
        f"| 该排除规则下 单域单类最少可用图像 | {result['hypothetical_min_images_per_domain_category']} |",
        "","上述排除后的计数只用于检查采样是否可行，没有执行排除、重采样或训练。所有重复组与单域单类的原始和可用计数都在 JSON 中列出。检查只覆盖精确字节重复，不能排除相似图像、语义重复或预训练暴露。","","## 4 对结论的影响",
        "首次冲突在 Art/rotation00/seed0：Art/Drill/00012.jpg 与 Real World/Drill/00040.jpg 字节完全相同。一份落在目标测试、另一份进入源域训练，会影响固定角色协议的独立性。这不是下载损坏；不应绕过检查并把结果称为无泄漏验证。C3b 不受此数据问题影响，仍运行；Office-Home 试点及后续 NegLabel 接续已停止，不自动跳过阶段。","","## 5 需要用户决定的事",
        "建议仅在新版本清单中排除所有跨域精确重复组的全部成员，保留磁盘原数据不变，再使用原固定采样/轮换规则重建清单。须新增协议版本和哈希，不覆盖现有预设，并明确结果是该去重版本。确认前不执行。也可暂缓 Office-Home，先完成 C3b。"]
    (ROOT/"reports/C1_官方下载与重复图像检查报告.md").write_text("\n".join(report)+"\n",encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k not in ["groups","domain_category_counts"]},indent=2))


if __name__=="__main__":main()
