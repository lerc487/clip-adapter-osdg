"""Integrate all audited lambda panels and canonical full64 display values."""
import re
import sys
from pathlib import Path
import numpy as np
from gap_closure_core import ROOT, read, sha, write
import integrate_results as I


def table(caption, head, rows, columns):
    return "\n".join([r"\begin{table}[htbp]\centering\small", r"\caption{" + caption + "}",
        r"\begin{tabular}{" + columns + r"}\toprule", head + r"\\\midrule"] +
        [" & ".join(row) + r"\\" for row in rows] + [r"\bottomrule\end{tabular}\end{table}"])


def main():
    src = ROOT / "source"
    I.ROOT = ROOT
    I.SRC = src
    I.DATA = {}
    e7 = read(ROOT / "evidence/E7_final_numeric_evidence.json")
    I.REG = read(ROOT / "evidence/E7_final_number_registry.json")
    I.MACROS = []
    text = (src / "numbers_revision2.tex").read_text()
    aliases = [line for line in text.splitlines() if line.startswith(r"\newcommand{") and not line.startswith(r"\newcommand{\Num")]
    definitions = ["\\newcommand{\\" + r["macro"] + "}{" + r["display"] + "}" for r in I.REG]
    (src / "numbers_revision2.tex").write_text("\n".join(definitions + aliases) + "\n", encoding="ascii")
    audit = read(ROOT / "evidence/E6_locoop_batch_audit.json")
    assert audit["all_checks_pass"] and audit["fits"] == 66 and audit["method_fit_rows_verified"] == 264
    facts = read(ROOT / "evidence/E0_precision.json")["records"]
    matched = []
    for ds in ["pacs", "cifar10"]:
        for method in ["MSP", "Temp-MSP", "autoMixTemp"]:
            rows = [r for r in facts if r["model"] == "ViT-B32" and r["dataset"] == ds and r["method"] == method and r["unit"].endswith("seed0")]
            old = [r for r in e7["stable"]["records"] if r["dataset"] == ds and r["method"] == method and r["unit"].endswith("seed0")]
            assert len(rows) == (28 if ds == "pacs" else 5)
            matched.append(dict(dataset=ds, method=method, lambda_value=None, n=len(rows), budget="adapter-max20",
                auroc=float(np.mean([r["auroc"] for r in rows])), fpr95=float(np.mean([r["fpr95"] for r in rows])),
                frozen_unknown_recall=float(np.mean([r["recall"] for r in rows])),
                frozen_known_rejection=float(np.mean([r["rejection"] for r in rows])),
                known_accuracy=float(np.mean([r["classification_accuracy"] for r in old]))))
        for coefficient in [.1, .25]:
            for method in ["MCM_official", "GLMCM_official", "MCM64", "GLMCM64"]:
                row = next(r for r in audit["summary"] if (r["dataset"], r["lambda_value"], r["method"]) == (ds, coefficient, method))
                matched.append(dict(row, budget="prompt50"))
    evidence = dict(summary=matched,
        primary_sha256=sha(ROOT / "evidence/E0_precision.json"), audit_sha256=sha(ROOT / "evidence/E6_locoop_batch_audit.json"),
        seed0_only=True, no_target_based_lambda_choice=True, lambda_panels_not_pooled=True,
        distinct_training_budgets=True, no_new_experiments=True)
    evidence_path = ROOT / "evidence/E8_locoop_matched_summary.json"
    if evidence_path.exists():
        assert read(evidence_path) == evidence
    else:
        write(evidence_path, evidence, exclusive=True)
    rows = []
    for i, row in enumerate(matched):
        if row["method"] in ["MCM64", "GLMCM64"]:
            continue
        label = {"MCM_official": "LoCoOp, MCM", "GLMCM_official": "LoCoOp, GL-MCM"}.get(row["method"], row["method"])
        coefficient = "---" if row["lambda_value"] is None else I.n("E8_locoop_matched_summary", ("summary", i, "lambda_value"), 3)
        rows.append(["PACS" if row["dataset"] == "pacs" else "CIFAR-10", label, coefficient,
            I.n("E8_locoop_matched_summary", ("summary", i, "n"), 0)] +
            [I.n("E8_locoop_matched_summary", ("summary", i, field), 3) for field in ["auroc", "fpr95", "frozen_unknown_recall", "frozen_known_rejection"]])
    I.table("locoop", "Matched seed0 sample roles: 28 PACS and five CIFAR-10 units per panel. LoCoOp uses the unmodified official trainer/loss, 50 prompt-training epochs and its own known-validation-NLL checkpoint, not the adapter's max20 budget. Both fixed regularization weights are shown, never chosen by target outcomes. Official MCM/GL-MCM scores are reported here; float64 counterparts and each classifier's known accuracy are supplementary. Fractions are equal-unit means; lambda panels are not pooled.",
        r"Data & Score & $\lambda$ & $n$ & AUROC & FPR@95 & Unknown recall & Known rejection", rows, "llrrrrrr")
    named = {}
    for ds, prefix in [("pacs", "LocoPACS"), ("cifar10", "LocoCIFAR")]:
        i = next(i for i, r in enumerate(matched) if (r["dataset"], r["method"], r["lambda_value"]) == (ds, "MCM_official", .25))
        for key, tag in [("auroc", "AUC"), ("fpr95", "FPR"), ("frozen_unknown_recall", "Recall"), ("frozen_known_rejection", "Reject")]:
            named[prefix + tag] = I.n("E8_locoop_matched_summary", ("summary", i, key), 3)
        i = next(i for i, r in enumerate(matched) if (r["dataset"], r["method"]) == (ds, "autoMixTemp"))
        for key, tag in [("auroc", "AUC"), ("fpr95", "FPR")]:
            named["Matched" + prefix + tag] = I.n("E8_locoop_matched_summary", ("summary", i, key), 3)
    body = (src / "body_revision.tex").read_text()
    anchor = r"\subsection{Estimands and dependence}\label{sec:dependence}"
    method = r"""\subsection{Official prompt-learning control}\label{sec:locoop-protocol}
LoCoOp uses the pinned official trainer/loss and identical seed0 sample roles: 28 PACS and five CIFAR-10 units, each at fixed regularization weights $\lambda=0.1$ and $0.25$. Sixteen generic context tokens are trained for 50 epochs with the official augmentation, SGD learning rate 0.002 and batch size 32; top-$k$ is $\max(1,\lfloor0.2|\mathcal K|\rfloor)$. Known-validation NLL independently selects the earliest minimum checkpoint. Official MCM/GL-MCM scores use temperature one. Both weights and float64 counterparts are retained, not target-selected. Training loss, augmentation and budget differ from the adapter control.

"""
    assert body.count(anchor) == 1
    body = body.replace(anchor, method + anchor)
    anchor = r"\section{Reproducibility and Limitations}\label{sec:repro}"
    results = r"""\subsection{Matched prompt-learning comparison}\label{sec:locoop-results}
\input{tables/locoop}
\begin{figure*}[t]\centering
\includegraphics[width=.97\textwidth]{figures/locoop_comparison.pdf}
\caption{Matched seed0 roles, not the three-seed primary means. Both LoCoOp regularization weights use separate 50-epoch prompt fits. ROC improvements do not establish a better transferred threshold or equal training cost.}\label{fig:locoop}
\end{figure*}
Table~\ref{tab:locoop} retains all regularization variants. LoCoOp MCM at $\lambda=0.25$ attains CIFAR-10 AUROC/FPR@95 \LocoCIFARAUC{}/\LocoCIFARFPR{}, versus \MatchedLocoCIFARAUC{}/\MatchedLocoCIFARFPR{} for matched autoMixTemp. On PACS its FPR@95 is \LocoPACSFPR{}, versus \MatchedLocoPACSFPR{}. LoCoOp is therefore stronger on some CIFAR-10 metrics, not uniformly across datasets. The comparison matches images and class roles, not training costs or published leaderboard protocols.

"""
    body = body.replace(anchor, results + anchor)
    body = body.replace("Official LoCoOp has two audited timing pilots only, not a complete baseline panel; learned prompts use a separate training budget.",
        "LoCoOp covers matched seed0 roles only, with a separate prompt-training budget and two fixed regularization weights rather than exhaustive tuning.")
    body = body.replace("python -B -s scripts/verify_evidence.py\npython -B -s scripts/r5_verify_review_draft.py", "python -B -s scripts/verify_final_package.py")
    body = body.replace("The NegLabel port is stronger on CIFAR-10 but weaker on PACS.", "NegLabel and some LoCoOp variants outperform autoMixTemp on CIFAR-10, while their PACS comparisons are less favorable.")
    # Avoid repeating qualification paragraphs merely to introduce the new baseline.
    body = body.replace("The arithmetic comparison isolates score realization, not semantic shift. Both representations remain reproducible from the same saved logits.\n\n", "")
    body = body.replace("The supplement retains every domain/role outcome, source/temperature choice and per-domain summary, including adverse comparisons. Optimization seeds reuse the frozen image manifests and are not independent dataset samples.",
        "Per-domain, seed and source-choice results are supplementary; seeds reuse the image manifests.")
    (src / "body_revision.tex").write_text(body, encoding="ascii")
    wrapper = (src / "manuscript.tex").read_text()
    abstract = r"""Numerically stable scoring improves discrimination without establishing predictive reliability or transferable high recall. We audit frozen Contrastive Language--Image Pretraining (CLIP)-Adapter checkpoints on 84 PACS and 15 CIFAR-10 units with disjoint validation and target unknown classes. Stable log-odds avoid ties from subtractive maximum softmax probability (MSP). Relative to MSP, autoMixTemp changes area under the receiver operating characteristic curve (AUROC)/false-positive rate at 95\% unknown recall (FPR@95) by \AbsPACSAUC{}/\AbsPACSFPR{} on PACS and \AbsCIFARAUC{}/\AbsCIFARFPR{} on CIFAR-10. Frozen validation thresholds attain target recall \PACSAutoRecall{} and \CIFARAutoRecall{}. A separate three-seed, 60-unit Office-Home panel yields AUROC/FPR@95 \OHAUC{}/\OHFPR{} and recall/known rejection \OHRecall{}/\OHReject{}. Its small advantage over temperature-only scoring accompanies lower recall. Controls include a second CLIP backbone, full-budget and detector-specific checkpoint selection, negative-label detection, and 66 official LoCoOp prompt fits on matched seed0 roles at two fixed regularization weights. Some controls outperform autoMixTemp. Probability and selective-risk diagnostics do not establish reliability gains; validation gates identify no consistent interior-mixing benefit. Dependence-aware analyses remain conditional on fixed fits. The contribution is an empirical score/threshold audit, not a new calibration mechanism or deployment guarantee."""
    wrapper = re.sub(r"(?s)(\\begin\{abstract\}).*?(\\end\{abstract\})", lambda m: m[1] + "\n" + abstract + "\n" + m[2], wrapper)
    (src / "manuscript.tex").write_text(wrapper, encoding="ascii")
    # Replace the two-pilot-only appendix with complete, explicitly separate lambda panels.
    supplement = (src / "supplement.tex").read_text().replace(r"\clearpage\input{locoop_pilot_supplement}", r"\clearpage\input{locoop_complete_supplement}")
    (src / "supplement.tex").write_text(supplement, encoding="ascii")
    lines = [r"\section*{Complete official LoCoOp comparison}",
        "All 66 fits include two reused timing pilots and 64 new fits; the matched sample-role panel has 33 distinct units, not 66 independent units. Both fixed regularization weights and all four score realizations are retained. No target result selects a weight. The official trainer/loss is unchanged; a literal-role adapter and known-validation-NLL checkpoint callback replace the supplied dataset interface. Same-input score alignment and independent complete-tie ROC checks passed. All 50 prompt states were verified in every fit; the 64 new fits additionally retain 3200 raw known-validation logit traces. The two reused pilots have recorded epoch NLL rather than raw per-epoch logits. This is not published-number reproduction."]
    for ds in ["pacs", "cifar10"]:
        rows = []
        for i, r in enumerate(matched):
            if r["dataset"] != ds:
                continue
            coefficient = "---" if r["lambda_value"] is None else I.n("E8_locoop_matched_summary", ("summary", i, "lambda_value"), 3)
            rows.append([r["method"].replace("_", r"\_"), coefficient] +
                [I.n("E8_locoop_matched_summary", ("summary", i, k), 3) for k in ["auroc", "fpr95", "frozen_unknown_recall", "frozen_known_rejection", "known_accuracy"]])
        lines += [table(ds.upper() + " matched seed0 results. Official float32 scores are preserved and numerical counterparts labeled; known accuracy belongs to each fit's classifier.",
            r"Score & $\lambda$ & AUROC & FPR@95 & Recall & Rejection & Known acc.", rows, "lrrrrrr"), r"\clearpage"]
    lines += [r"\section*{Full Office-Home threshold and dependence diagnostics}"]
    for name, title in [("E5_transfer_tradeoffs", "Office-Home60 full validation-recall scan. Score choices remain fixed; only thresholds vary. Fractions; contamination depends on test prevalence.")]:
        data = read(ROOT / "evidence" / (name + ".json"))
        rows = [[r["method"], I.n(name, ("summary", i, "rho"), 3), "Pooled" if r["policy"] == "pooled" else "Worst"] +
            [I.n(name, ("summary", i, k), 3) for k in ["unknown_recall", "known_rejection", "accepted_known_accuracy", "unknown_contamination"]] for i, r in enumerate(data["summary"])]
        lines += [table(title, r"Score & $\rho$ & Rule & Recall & Rejection & Acc. & Contam.", rows, "lrlrrrr"), r"\clearpage"]
    rows = []
    for file in ["E3_content_dependence", "E5_content_dependence"]:
        data = read(ROOT / "evidence" / (file + ".json"))
        for i, r in enumerate(data["paired_summary"]):
            if file == "E3_content_dependence" and r["dataset"] == "officehome":
                continue
            rows.append([r["model"], r["dataset"], r["comparator"], I.n(file, ("paired_summary", i, "n"), 0)] +
                [I.n(file, ("paired_summary", i, k), 3, sign=True) for k in ["delta_auroc", "delta_fpr95"]])
    lines += [table("Unique-content target ownership diagnostic, with seeds averaged within assigned clusters. This changes the evaluation subset, not the original main means. Training/validation reuse and pretraining exposure remain; no IID population inference.",
        r"Backbone & Data & Comparator & Clusters & $\Delta$AUROC & $\Delta$FPR@95", rows, "lllr rr")]
    lines += ["The interpolation precision reconciliation converts both operands before multiplication. It changes one primary CIFAR-10 autoMixTemp AUROC by approximately $-8.333\\times10^{-8}$, not its displayed three-decimal value; original scores and prior evidence remain unchanged. PACS conditional ROC ranges are retained by an exact cross-class-order/tie invariance check; affected CIFAR sensitivities were replayed. Probability/risk diagnostics were recomputed, not inferred from ROC invariance."]
    (src / "locoop_complete_supplement.tex").write_text("\n\n".join(lines) + "\n", encoding="ascii")
    with (src / "numbers_revision2.tex").open("a", encoding="ascii") as f:
        f.write("\n".join(I.MACROS) + "\n")
        f.write("\n".join("\\newcommand{\\" + key + "}{" + value + "}" for key, value in named.items()) + "\n")
    write(ROOT / "evidence/number_registry.json", I.REG)
    write(ROOT / "evidence/E8_manuscript_integration.json", dict(audit_sha256=sha(ROOT / "evidence/E6_locoop_batch_audit.json"),
        numerical_reconciliation_sha256=sha(ROOT / "evidence/E7_final_numeric_evidence.json"), new_training=False,
        all_lambda_variants_retained=True, matched_seed0_roles_only=True, author_approval=False, upload_ready=False), exclusive=True)
    print("All66fits/264rows integrated, including adverse results and full64 evidence bindings.")


if __name__ == "__main__":
    main()
