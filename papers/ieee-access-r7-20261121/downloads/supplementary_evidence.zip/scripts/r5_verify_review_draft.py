"""Verify the compiled working draft; never issue a submission-ready verdict."""
import hashlib
import json
from pathlib import Path
import re
import subprocess
import sys
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "source"
sys.path.insert(0, str(ROOT / "scripts"))
from verify_consistency import words


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    for name in ["E5_officehome_full_audit", "E4_independent_audit", "E6_pilot_audit"]:
        assert read(ROOT / "evidence" / (name + ".json"))["all_checks_pass"], name
    registry = read(ROOT / "evidence/number_registry.json")
    definitions = (SRC / "numbers_revision2.tex").read_text()
    names = re.findall(r"\\newcommand\{\\([^}]+)\}", definitions)
    assert len(names) == len(set(names)), "Duplicate numeric/alias command"
    data = {}
    for r in registry:
        data.setdefault(r["file"], read(ROOT / "evidence" / r["file"]))
        value = data[r["file"]]
        for key in r["pointer"]:
            value = value[key]
        assert value == r["value"], (r["macro"], "source value")
        display = format(value * r["scale"], ("+" if r["signed"] else "") + "." + str(r["decimals"]) + "f")
        assert display == r["display"]
        assert "\\newcommand{\\" + r["macro"] + "}{" + display + "}" in definitions, r["macro"]
    alltext = "\n".join(p.read_text() for p in SRC.rglob("*.tex"))
    assert set(re.findall(r"\\(Num[a-z]+)\b", alltext)) <= set(names)
    for name in ["manuscript", "supplement"]:
        log = (SRC / (name + ".log")).read_text(errors="replace")
        assert not any(item in log for item in ["undefined references", "undefined citations", "! LaTeX Error"]), name
    text = subprocess.check_output(["pdftotext", str(SRC / "manuscript.pdf"), "-"], text=True, encoding="utf-8")
    assert not any(item in text for item in ["TBD", "AUTHOR REVIEW DRAFT", "Not submitted"])
    body = (SRC / "body_revision.tex").read_text()
    assert not any(item in body for item in ["LoCoOp remains unevaluated", "These seed0 results", "only one optimization seed"])
    bbl = (SRC / "manuscript.bbl").read_text()
    references = len(re.findall(r"\\bibitem", bbl))
    cites = list(map(int, re.findall(r"(?<![A-Za-z0-9])\[(\d+)\](?![A-Za-z0-9])", text)))
    assert cites and max(cites) <= references
    prose = body + "\n" + (SRC / "architecture_results.tex").read_text()
    count = words(prose)
    assert count / 3309 <= .85, count
    protected = read(ROOT / "evidence/R4_protected_manifest.json")
    if isinstance(protected, dict):
        protected = protected.get("files", protected.get("records", []))
    assert protected, "Empty protected manifest"
    assert all(sha(r["path"]) == r["sha256"] for r in protected)
    response = read(ROOT / "evidence/responses_working_R5.json")
    assert len(response["records"]) == 17 and not response["upload_ready"]
    result = dict(mechanical_working_draft_checks_pass=True, result_macro_bindings_verified=len(registry),
        reference_count=references, maximum_body_citation=max(cites), body_words=count, baseline_body_words=3309,
        body_ratio=count / 3309, protected_R4_files_verified=len(protected), point_by_point_working_replies=17,
        manuscript_sha256=sha(SRC / "manuscript.pdf"), supplement_sha256=sha(SRC / "supplement.pdf"),
        source_files=[dict(path=str(p.relative_to(ROOT)), sha256=sha(p)) for p in SRC.rglob("*") if p.suffix in [".tex", ".bib", ".sty", ".cls"]],
        final_precision_reconciliation_verified=False, full_visual_QA_complete=False,
        fresh_source_zip_roundtrip_verified=False, final_highlight_pdf_verified=False,
        loco_op_full_panel_available=False, loco_op_batch_decision_pending=True,
        all_17_substantive_concerns_resolved=False, author_approval=False, upload_ready=False,
        generated_utc=datetime.now(timezone.utc).isoformat())
    (ROOT / "evidence/R5_working_draft_checks.json").write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps({k: v for k, v in result.items() if k != "source_files"}, indent=2))


if __name__ == "__main__":
    main()
