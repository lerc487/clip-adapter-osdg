"""Build the approved domain-or-category deduplicated manifest, preserving v2."""
from collections import Counter,defaultdict
from datetime import datetime,timezone
from pathlib import Path
import json
import time
from officehome_manifest_v2 import read,sha,write_new,seal,collisions

ROOT=Path(__file__).resolve().parents[1]
OLD=ROOT/"new_runs/officehome";NEW=OLD/"dedup_v3"


def state(stage,**kw):
    p=ROOT/"evidence/C1_manifest_v3_progress.json";temp=p.with_suffix(".tmp")
    temp.write_text(json.dumps(dict(stage=stage,updated=time.strftime("%Y-%m-%dT%H:%M:%S"),**kw),indent=2),encoding="utf-8");temp.replace(p)


def main():
    NEW.mkdir(parents=True,exist_ok=True)
    source=read(OLD/"integrity_check.json");audit=read(ROOT/"evidence/C1_duplicate_audit.json")
    proposal=read(ROOT/"evidence/C1_label_conflict_audit.json")
    files=source["files"];data=Path(source["data_root"])
    assert sha(OLD/"integrity_check.json")==audit["source_sha256"] and not source["errors"]
    groups=[g for g in audit["groups"] if g["cross_domain"] or not g["category_agreement"]]
    hashes={g["sha256"] for g in groups};paths={r["path"] for g in groups for r in g["images"]}
    assert len(groups)==proposal["proposed_union_duplicate_groups"]==96
    assert len(paths)==proposal["proposed_union_excluded_images"]==199
    protected=list((ROOT/"prespec").glob("*.json"))
    protected += list((OLD/"dedup_v2").glob("*.json"))
    protected += [OLD/"integrity_check.json",OLD/"cross_role_duplicate_error.json",ROOT/"scripts/officehome_manifest_v2.py"]
    protected += [ROOT/"scripts"/n for n in ["officehome_train.py","officehome_pilot.py","follow_authorized_stages.py"]]
    before={p.relative_to(ROOT).as_posix():sha(p) for p in protected}
    auth=ROOT/"evidence/C1_dedup_v3_authorization.json"
    write_new(auth,dict(source="Explicit user reply in this conversation on2026-11-19 Asia/Shanghai",
        answer="同意新增v3，排除跨域或跨类别重复组",rule="Exclude all members of exact-byte duplicate groups spanning domains OR categories, using a new manifest only.",
        original_files_remain=True,v2_remains=True,stage1_remaining18_authorized=False,stage2_authorized=False))
    spec=dict(task="C1_dedup_v3",created_utc=datetime.now(timezone.utc).isoformat(),
        authorization_sha256=sha(auth),parent_stage_design_sha256=sha(ROOT/"prespec/C1_stages.json"),
        original_inventory_sha256=sha(OLD/"integrity_check.json"),duplicate_audit_sha256=sha(ROOT/"evidence/C1_duplicate_audit.json"),
        label_conflict_audit_sha256=sha(ROOT/"evidence/C1_label_conflict_audit.json"),
        change="Prospective input-integrity amendment after image-hash inspection and before any Office-Home model fit or score. No target performance has been inspected.",
        exclusion="All members of groups where domain count>1 OR category count>1; no subjectively selected representative. Same-domain/same-category duplicates retained with nominal and unique-content counts disclosed. No near-duplicate or pretraining-leakage claim.",
        excluded_hashes=sorted(hashes),excluded_paths=sorted(paths),
        role_rule="Unchanged four sorted domains, next cyclic validation domain, two remaining sources, casefold/name65-class order, step13 and5rotations;35known/15validation-unknown/15target-unknown. Rank by SHA256(seed|relativepath),10files per class per source or validation domain. All retained target-role files. Freeze seed0/1/2 plans; run only two authorized seed0 pilots, never auto-start remaining18 or later seeds.",
        verification="Rehash all original images against completed decoding inventory. Require >=10 retained images per domain/category, disjoint category roles, disjoint paths/content across train/validation/test, no same-content opposing known/unknown labels in validation/test and no same-content differing known labels. Stop on any violation; no fallback or further exclusion.",
        invariants="Stablefloat64 scoring and original training settings unchanged; equal-unit descriptive reporting separately from PACS; nominal150validation unknown samples need not be independent, no deployment guarantee.",
        frozen_code_hashes={"scripts/"+n:sha(ROOT/"scripts"/n) for n in ["officehome_manifest_v3.py","officehome_manifest_v2.py"]},
        protected_previous_hashes=before)
    design_hash=seal("C1_dedup_v3",spec)
    state("verifying_unchanged_original_images",completed=0,total=len(files));start=time.perf_counter()
    for i,row in enumerate(files):
        assert sha(data/row["path"])==row["sha256"],row["path"]
        if (i+1)%1000==0:state("verifying_unchanged_original_images",completed=i+1,total=len(files))
    seconds=time.perf_counter()-start
    retained=[r for r in files if r["sha256"] not in hashes]
    assert len(retained)==proposal["proposed_remaining_images"]==15389
    assert {r["path"] for r in files if r["sha256"] in hashes}==paths
    domains=sorted({r["domain"] for r in retained},key=lambda s:(s.casefold(),s));classes=sorted({r["category"] for r in retained},key=lambda s:(s.casefold(),s))
    byclass=defaultdict(list);byhash=defaultdict(list)
    for row in retained:byclass[(row["domain"],row["category"])].append(row);byhash[row["sha256"]].append(row)
    assert len(domains)==4 and len(classes)==65 and len(byclass)==260
    assert min(len(v) for v in byclass.values())>=10
    assert all(len({r["domain"] for r in rows})==1 and len({r["category"] for r in rows})==1 for rows in byhash.values())
    write_new(NEW/"exclusion_manifest.json",dict(protocol_version="C1_dedup_v3",groups=groups,paths=sorted(paths),raw_data_changed=False))
    write_new(NEW/"filtered_inventory.json",dict(protocol_version="C1_dedup_v3",data_root=str(data),files=retained,
        raw_inventory_sha256=sha(OLD/"integrity_check.json"),design_sha256=design_hash))
    state("building_and_checking_role_manifests",retained_images=len(retained));units=[];checks=[]
    for rotation in range(5):
        shifted=[classes[(j+13*rotation)%65] for j in range(65)];known,vu,tu=shifted[:35],shifted[35:50],shifted[50:]
        assert set(known).isdisjoint(vu) and set(known).isdisjoint(tu) and set(vu).isdisjoint(tu)
        for index,target in enumerate(domains):
            val=domains[(index+1)%4];sources=[d for d in domains if d not in [target,val]]
            for seed in [0,1,2]:
                def take(domain,names,sampled):
                    rows=[]
                    for name in names:
                        pool=byclass[(domain,name)]
                        ordered=sorted(pool,key=lambda r:(__import__("hashlib").sha256((str(seed)+"|"+r["path"]).encode()).hexdigest(),r["path"])) if sampled else sorted(pool,key=lambda r:r["path"])
                        rows += ordered[:10] if sampled else ordered
                    return rows
                train=[r for d in sources for r in take(d,known,True)]
                vk=take(val,known,True);uv=take(val,vu,True);tk=take(target,known,False);ut=take(target,tu,False)
                uid=f"{target}_rotation{rotation:02d}_seed{seed}"
                roles=dict(train=train,val_known=vk,val_unknown=uv,test=tk+ut)
                assert len(train)==700 and len(vk)==350 and len(uv)==150
                major=[train,vk+uv,tk+ut]
                assert all(not collisions(a,b) for i,a in enumerate(major) for b in major[i+1:])
                assert not collisions(vk,uv) and not collisions(tk,ut)
                assert not (set(r["path"] for r in sum(major,[]))&paths)
                checks.append(dict(unit=uid,major_role_content_overlap=0,validation_known_unknown_overlap=0,test_known_unknown_overlap=0,
                    counts={k:len(v) for k,v in roles.items()},unique_content_counts={k:len({r["sha256"] for r in v}) for k,v in roles.items()}))
                units.append(dict(unit_id=uid,target=target,val=val,seed=seed,rotation=rotation,known=known,validation_unknown=vu,target_unknown=tu,roles=roles))
    pilot=[u["unit_id"] for u in units if u["rotation"]==0 and u["seed"]==0][:2]
    plan=dict(protocol_version="C1_dedup_v3",data_root=str(data),domains=domains,classes=classes,rotation_step=13,units=units,pilot=pilot,
        stage1=[u["unit_id"] for u in units if u["seed"]==0],stage2=[u["unit_id"] for u in units if u["seed"] in [1,2]],
        stage1_requires_measured_pilot_and_user_decision=True,stage2_requires_later_user_decision=True,
        training_eligible=True,exclusion_manifest_sha256=sha(NEW/"exclusion_manifest.json"),design_sha256=design_hash,
        frozen_before_any_officehome_inference=True)
    write_new(NEW/"roles_manifest.json",plan)
    literal=dict(task="C1_roles_manifest_v3",manifest="new_runs/officehome/dedup_v3/roles_manifest.json",manifest_sha256=sha(NEW/"roles_manifest.json"),
        design_sha256=design_hash,domains=domains,classes=classes,pilot=pilot,training_eligible=True)
    literal_hash=seal("C1_roles_manifest_v3",literal)
    assert all(sha(ROOT/p)==h for p,h in before.items())
    result=dict(task="C1_dedup_v3",design_sha256=design_hash,literal_roles_spec_sha256=literal_hash,roles_manifest_sha256=literal["manifest_sha256"],
        original_images=len(files),excluded_groups=len(groups),excluded_images=len(paths),retained_images=len(retained),classes=len(classes),
        domains=dict(sorted(Counter(r["domain"] for r in retained).items())),minimum_images_per_domain_category=min(len(v) for v in byclass.values()),
        original_images_verified_unchanged=len(files),raw_hash_recheck_seconds=seconds,original_data_modified=False,previous_specifications_and_v2_unchanged=True,
        remaining_cross_domain_duplicate_groups=0,remaining_cross_category_duplicate_groups=0,
        remaining_within_domain_same_category_duplicate_groups=sum(len(v)>1 for v in byhash.values()),
        remaining_within_domain_same_category_duplicate_images=sum(len(v) for v in byhash.values() if len(v)>1),
        planned_stage1_units=len(plan["stage1"]),planned_stage2_units=len(plan["stage2"]),planned_units_are_not_completed_runs=True,
        pilot=pilot,training_eligible=True,no_officehome_model_results=True,per_unit_checks=checks)
    write_new(ROOT/"evidence/C1_dedup_v3.json",result)
    state("accepted_waiting_C3b_then_two_unit_pilot_v3",training_eligible=True,retained_images=len(retained),pilot=pilot)
    lines=["# Office Home v3 清单封存与验证报告","","## 1 做了什么",
        "按用户授权，在新清单中排除跨域或跨类别的字节完全重复组全部成员。磁盘原图、ZIP、旧预设、v2 及旧失败记录均保留。重新逐图核对原始 SHA256，并以原排序、轮换和采样规则封存 v3；没有进行模型推理。","","## 2 文件位置",
        "new_runs/officehome/dedup_v3/ 的 exclusion_manifest.json、filtered_inventory.json、roles_manifest.json；prespec/C1_dedup_v3.json、C1_roles_manifest_v3.json 及 seal；数值与逐单元检查：evidence/C1_dedup_v3.json。","","## 3 数字与 JSON 来源",
        "以下均来自 evidence/C1_dedup_v3.json，不是实验性能。","","| 项目 | 数量 |","| --- | ---: |",
        f"| 原始图像 | {len(files)} |",f"| 排除重复组 | {len(groups)} |",f"| 仅在清单中排除图像 | {len(paths)} |",f"| 保留图像 | {len(retained)} |",
        f"| 类别 | {len(classes)} |",f"| 单域单类最少图像 | {result['minimum_images_per_domain_category']} |",
        "| 剩余跨域完全重复组 | 0 |","| 剩余跨类别完全重复组 | 0 |",
        f"| 保留的同域同类完全重复组 | {result['remaining_within_domain_same_category_duplicate_groups']} |","",
        "全部预设角色表均通过训练/验证/测试内容分离及已知/未知标签冲突检查。每源域每已知类10张，验证已知350张、验证未知150张；逐运行名义数与唯一内容数均已记录。","","## 4 对结论的影响",
        "v3 消除了已审计的精确字节跨域与跨类别重复，不代表排除了近似重复或预训练暴露。同域同类重复仍保留，名义样本数不等于独立图像数；不作 IID 推断。清单修改发生在任何 Office-Home 模型结果之前。该10-shot预算不与 PACS 全样本面板合并。","","## 5 后续与用户决定",
        "只授权先运行 Art_rotation00_seed0 与 Clipart_rotation00_seed0 两个计时试点。C3b 完成后按单 GPU 顺序运行，之后接 NegLabel。试点实测耗时汇报后，再决定是否运行剩余18单元；seed1/2仍须另行确认。不会按试点效果方向改变阶段。"]
    (ROOT/"reports/C1_v3清单封存与验证报告.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps({k:v for k,v in result.items() if k!="per_unit_checks"},indent=2,ensure_ascii=False))


if __name__=="__main__":main()
