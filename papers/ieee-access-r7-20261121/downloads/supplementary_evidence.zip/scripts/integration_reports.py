"""Report completed tasks separately from the authorized running experiment."""
import json
from pathlib import Path
import shutil

ROOT=Path(__file__).resolve().parents[1]
PREV=ROOT.parent/"revision2_20261118"

def read(path):return json.loads(path.read_text(encoding="utf-8-sig"))
def write(name,text):(ROOT/"reports"/name).write_text(text+"\n",encoding="utf-8")

def main():
    for path in (PREV/"reports").iterdir():
        if path.is_file() and (path.name.startswith(("A1_","A2_paragraph","A3_","B1_","B2_","B3_","B4_","B5_","B6_","B7_","C3a_","D1_","D2_","D3_","D4_")) or path.name=="C2_LoCoOp_不运行论证.md"):
            shutil.copy2(path,ROOT/"reports"/path.name)
    audit=read(ROOT/"evidence/completed_result_audit.json")
    c3=read(ROOT/"evidence/C3b.json")
    table="\n".join(f"| {r['selector']} | {r['method']} | {r['n']} | {r['auroc']:.6f} | {r['fpr95']:.6f} | {r['frozen_unknown_recall']:.6f} | {r['frozen_known_rejection']:.6f} |" for r in c3["summary"])
    write("C3b_完成报告.md",f"""# C3b PACS 全预算对照完成报告

## 1 做了什么
完成预设的四域×七轮换×seed0 共28单元。复用4条封存轨迹，新增24条训练；三个验证选点规则全部保留。另对全部168条目标结果重算AUROC/FPR并核验checkpoint/logits哈希。

## 2 文件和章节
source/architecture_results.tex、source/tables/fullbudget.tex；正文V-G/V-H、表12；补充表S10。代码与原始归档仍在revision2_20261118，未覆盖旧模型。

## 3 新数字及 JSON 来源
来源：evidence/C3b.json 的summary；独立核验：evidence/completed_result_audit.json。

| 选点 | 方法 | 单元 | AUROC | FPR@95 | 冻结阈值未知召回 | 已知误拒 |
| --- | --- | --- | --- | --- | --- | --- |
{table}

每种方法的28对known-NLL主协议/full20 AUROC/FPR均完全相同。均值差为零，不把旧四单元的低energy FPR归因于取消早停。

## 4 有利还是不利
完整28单元中energy并未超过autoMixTemp；但验证目标对选点存在影响，不足以声称独立优化了各类检测器。此前四单元的energy优势属于其类角色构成，保留在补充材料，不能删除。

## 5 需要决定的事
无新训练决策。ViT-B/16依用户决定不运行；不能写成审稿人所有基线要求已彻底满足。
""")
    neg=read(ROOT/"evidence/C2_NegLabel.json")
    table="\n".join(f"| {r['dataset']} | {r['variant']} | {r['n']} | {r['auroc']:.6f} | {r['fpr95']:.6f} | {r['frozen_unknown_recall']:.6f} | {r['frozen_known_rejection']:.6f} |" for r in neg["summary"])
    write("C2_NegLabel_完成报告.md",f"""# C2 NegLabel 轻量端口完成报告

## 1 做了什么
同一PACS 84/CIFAR-10 15单元，标准词表与字面基准类别名剔除词表均完成。遵循固定官方函数；CPU选择/分组、CUDA随机排列分组的同输入对齐通过。重新检查全部198组保存分数的目标指标及冻结阈值迁移指标。

## 2 文件和章节
正文III-D、IV-B、V-B、VI-B与结论；表2、图3、补充表S11。代码、官方commit和预设见prespec/C2_NegLabel*.json；非官方全环境/编码器流水线复现。

## 3 新数字及 JSON 来源
来源：evidence/C2_NegLabel.json；对齐：C2_NegLabel_alignment.json、C2_NegLabel_CUDA_alignment.json；重算：completed_result_audit.json。

| 数据集 | 词表 | 单元 | AUROC | FPR@95 | 未知召回 | 已知误拒 |
| --- | --- | --- | --- | --- | --- | --- |
{table}

## 4 有利还是不利
NegLabel相对autoMixTemp在CIFAR-10更强、在PACS较弱，结论具有任务依赖性。外部WordNet负标签词表是额外信息预算。字面类别名剔除并不清除同义词、语义或CLIP预训练暴露。不得写成复现原论文数字，或用PACS结果暗示全面优于NegLabel。

## 5 需要决定的事
无需追加词表或调参；两个预设版本全部保留。LoCoOp按用户决定不运行，限制仍明确。
""")
    progress=read(PREV/"evidence/C1_stage1_v3_progress.json")
    (ROOT/"evidence/C1_stage1_status_snapshot.json").write_text(json.dumps(progress,indent=2),encoding="utf-8")
    write("C1_阶段1运行说明.md",f"""# C1 Office Home 阶段1运行说明

## 1 做了什么
依据用户批准，复用两个计时试点，启动剩余18个seed0单元。单GPU串行，范围固定为四域×五轮换；不启动seed1/2。

## 2 文件和章节
运行目录：{PREV}/new_runs/officehome/dedup_v3/stage1_eval64。
冻结设计：prespec/C1_stage1_v3_eval64.json及seal；动态进度以revision2_20261118/evidence/C1_stage1_v3_progress.json为准。补充文件只收入两个计时试点，尚未把部分阶段1结果当作完整面板。

## 3 数字及 JSON 来源
此报告快照：{progress['updated']}，归档核验完成{progress['completed']}/{progress['total']}，当前{progress['current']}。来源：evidence/C1_stage1_status_snapshot.json。阶段1最终结果形成前不写目标结果均值。
v3清单共保留15389图像；排除199张跨域或跨类别完全重复组成员，原始文件保留。仍有同域同类别重复，名义样本数不等于独特内容数。

## 4 有利还是不利
当前不判断完整面板结果。35已知/15验证未知/15目标未知；源与验证每类固定10张，与PACS训练预算不同。验证未知约150张，阈值估计更噪；不与主面板合并。

## 5 需要决定的事
阶段1已获批准，无需重复确认。阶段2 seed1/2仍需另行决定，当前不会启动。
""")
    wc=read(ROOT/"evidence/word_counts.json")
    write("A2_报告.md",f"""# A2 精简与布局整合报告

## 1 做了什么
保留所有必要图表，并纳入完成的C3b/NegLabel；表11分数据集并列、表12紧凑排版，避免单表占一空页。正文不含投稿历史，敏感性设计时点仅保留一句中性限制。

## 2 文件和章节
source/body_revision.tex、architecture_results.tex、manuscript.tex、tables/architecture.tex、tables/fullbudget.tex。全部节/表/图的实际位置以responses.json与Author action为准。

## 3 数字及 JSON 来源
evidence/word_counts.json：同规则正文{wc['before']}→{wc['after']}词，比例{wc['ratio']:.6f}；摘要{wc['abstract_words']}词。未靠删除回应所需图表达到压缩目标。

## 4 有利还是不利
压缩仅改善阅读，不提高方法证据强度。概率校准、迁移召回和额外词表对照的不利结果均保留。

## 5 需要决定的事
需作者核对新题目、完整论点和元数据。Office-Home阶段1未整合前不是投稿终稿。
""")
    write("README_本轮报告索引.md","# 本轮报告索引\n\nC3b、C2_NegLabel、C1阶段1与A2为本轮更新报告。A1、A3、B1–B7、C3a、D1–D4沿用此前已完成分析的真实报告；早期版面位置不作为当前引用依据，当前编号见evidence/responses.json和CHANGES.md。LoCoOp不运行说明保留。C1动态进度需读取原实验目录，打包快照不会自动更新。")

if __name__=="__main__":main()
