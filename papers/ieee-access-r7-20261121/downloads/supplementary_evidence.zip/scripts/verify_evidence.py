"""Portable numeric-binding check requiring only the delivered JSON/source files."""
import hashlib
import json
from pathlib import Path
from functools import lru_cache

ROOT=Path(__file__).resolve().parents[1]


@lru_cache(maxsize=None)
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))


def main():
    registry=read(ROOT/"evidence/number_registry.json")
    macros=(ROOT/"source/numbers_revision2.tex").read_text()
    for row in registry:
        value=read(ROOT/"evidence"/row["file"])
        for key in row["pointer"]:value=value[key]
        assert value==row["value"]
        display=format(value*row["scale"],("+" if row["signed"] else "")+"."+str(row["decimals"])+"f")
        assert display==row["display"]
        assert "\\newcommand{\\"+row["macro"]+"}{"+display+"}" in macros
    for task,digest in read(ROOT/"prespec/sealed_hashes.json").items():
        assert hashlib.sha256((ROOT/"prespec"/(task+".json")).read_bytes()).hexdigest()==digest
    additional_seals=[]
    for p in sorted((ROOT/"prespec").glob("*_seal.json")):
        seal=read(p);spec=ROOT/"prespec"/(seal["task"]+".json")
        assert hashlib.sha256(spec.read_bytes()).hexdigest()==seal["sha256"]
        additional_seals.append(seal["task"])
    figures=read(ROOT/"evidence/figure_data_registry.json")
    for row in figures.get("completed_control_figure_records",[]):
        value=read(ROOT/"evidence"/row["file"])
        for key in row["pointer"]:value=value[key]
        assert value==row["value"] and format(100*value,".2f")==row["display_percent"]
    for name,digest in figures["figure_hashes"].items():
        assert hashlib.sha256((ROOT/"source/figures"/name).read_bytes()).hexdigest()==digest
    for row in figures.get("officehome_figure_records",[]):
        value=read(ROOT/"evidence"/row["file"])
        for key in row["pointer"]:value=value[key]
        assert value==row["value"] and format(100*value,".2f")==row["display_percent"]
    output=dict(evidence_bindings_checked=len(registry),additional_seals_checked=additional_seals,all_checks_pass=True,
        figure_hashes_checked=len(figures["figure_hashes"]),completed_control_plot_values_checked=len(figures.get("completed_control_figure_records",[])),
        officehome_plot_values_checked=len(figures.get("officehome_figure_records",[])),
        scope="Portable JSON/macro and prespec-hash verification, not a claim to reconstruct private model states or independently validate experimental design.")
    (ROOT/"evidence/portable_consistency_checks.json").write_text(json.dumps(output,indent=2),encoding="utf-8")
    print(json.dumps(output,indent=2))


if __name__=="__main__":main()
