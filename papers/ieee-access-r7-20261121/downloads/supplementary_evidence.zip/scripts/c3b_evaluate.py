"""Freeze validation-only selectors, then evaluate their target logits separately."""
import argparse
import hashlib
import json
from pathlib import Path
import sys
import time

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"new_runs/c3b/code"))
import numpy as np
import torch
from scipy.special import logsumexp
from sklearn.metrics import roc_auc_score
from torch.utils.data import DataLoader
import open_clip
from train_disjoint import Adapter,MultiDomainFolder,collect_logits_on_loader
from verified_metrics import fpr_at_recall
from c3b_scoring import score,select,branch


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):p.write_text(json.dumps(x,indent=2,allow_nan=False),encoding="utf-8")


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--run",type=Path,required=True)
    parser.add_argument("--out",type=Path,required=True);args=parser.parse_args()
    run=args.run;out=args.out;out.mkdir(parents=True,exist_ok=False)
    started=time.perf_counter();config=read(run/"config.json")["arguments"]
    validations={};metrics=[];hashes={}
    for epoch in range(1,21):
        p=run/f"epoch_checkpoints/validation_{epoch:02d}.npz"
        hashes[p.name]=sha(p)
        with np.load(p,allow_pickle=False) as z:a={k:z[k] for k in z.files}
        validations[epoch]=a
        y=np.r_[np.zeros(len(a["ka"]),dtype=int),np.ones(len(a["ua"]),dtype=int)]
        z=np.asarray(a["ka"],dtype=np.float64)
        metrics.append(dict(epoch=epoch,known_nll=float(np.mean(logsumexp(z,axis=1)-z[np.arange(len(z)),a["yk"]])),
            msp_auroc=float(roc_auc_score(y,np.r_[score(a["ka"],1.,"msp"),score(a["ua"],1.,"msp")])),
            energy_auroc=float(roc_auc_score(y,np.r_[score(a["ka"],1.,"energy"),score(a["ua"],1.,"energy")]))))
    selected={"known_NLL":min(metrics,key=lambda r:(r["known_nll"],r["epoch"]))["epoch"],
        "validation_MSP_AUROC":min(metrics,key=lambda r:(-r["msp_auroc"],r["epoch"]))["epoch"],
        "validation_energy_AUROC":min(metrics,key=lambda r:(-r["energy_auroc"],r["epoch"]))["epoch"]}
    temps=[float(t) for t in config["temp_candidates"].split(",")]
    alphas=[float(t) for t in config["mix_alphas"].split(",")]
    choices={}
    for epoch in sorted(set(selected.values())):
        a=validations[epoch];choices[str(epoch)]={}
        for method,route,mode in [("Energy-T-tuned","adapter","energy"),("autoMixTemp","auto","msp")]:
            choices[str(epoch)][method]=select(route,mode,temps,a["kz"],a["ka"],a["uz"],a["ua"],True,.5,alphas,"fpr95")
    frozen=dict(selectors=selected,epoch_metrics=metrics,score_choices=choices,validation_hashes=hashes,
        policy="All epoch and score choices frozen before target evaluation; earliest exact tie.",
        arithmetic="float64 MSP log-odds / negative energy; adapter-first score tie order")
    dump(out/"validation_choices_frozen.json",frozen)
    choice_hash=sha(out/"validation_choices_frozen.json")
    needed=[epoch for epoch in sorted(set(selected.values())) if not (run/f"epoch_checkpoints/selected_test_{epoch:02d}.npz").exists()]
    if needed:
        model,_,transform=open_clip.create_model_and_transforms(config["model"],pretrained=config["pretrained"],cache_dir=config["openclip_cache_dir"])
        model=model.cuda().eval()
        samples=read(run/"test_samples.json")
        loader=DataLoader(MultiDomainFolder([(str(Path(config["data_root"])/s["path"]),s["label"]) for s in samples],transform),batch_size=64,num_workers=0,shuffle=False)
    records=[]
    for epoch in sorted(set(selected.values())):
        checkpoint=run/f"epoch_checkpoints/epoch_{epoch:02d}.pt"
        cached=run/f"epoch_checkpoints/selected_test_{epoch:02d}.npz"
        if cached.exists():
            with np.load(cached,allow_pickle=False) as z:tz=z["tz"];ta=z["ta"];ty=z["ty"]
            cache_source=str(cached);cache_sha=sha(cached)
        else:
            ck=torch.load(checkpoint,map_location="cpu");text=ck["text_features"].cuda()
            adapter=Adapter(text.shape[1],config["hidden_ratio"],config["max_scale"],config["alpha_init"]).cuda()
            adapter.load_state_dict(ck["adapter_state"]);adapter.eval()
            tz,ta,ty=collect_logits_on_loader(model,adapter,text,loader,"cuda")
            saved=out/f"selected_test_{epoch:02d}.npz";np.savez_compressed(saved,tz=tz,ta=ta,ty=ty)
            cache_source=str(saved);cache_sha=sha(saved)
            del adapter,text,ck
        np.testing.assert_array_equal(ty,[s["label"] for s in read(run/"test_samples.json")])
        a=validations[epoch];y=(ty<0).astype(int);known=ty>=0;pred=ta.argmax(1)
        vy=np.r_[np.zeros(len(a["ka"]),dtype=int),np.ones(len(a["ua"]),dtype=int)]
        for method,mode in [("Energy-T-tuned","energy"),("autoMixTemp","msp")]:
            sel=choices[str(epoch)][method];t=sel["T_score"]
            st=score(branch(tz,ta,sel),t,mode)
            sv=np.r_[score(branch(a["kz"],a["ka"],sel),t,mode),score(branch(a["uz"],a["ua"],sel),t,mode)]
            threshold=fpr_at_recall(sv,vy)["threshold"];reject=st>=threshold
            for selector,chosen in selected.items():
                if chosen!=epoch:continue
                records.append(dict(unit=run.name,selector=selector,epoch=epoch,method=method,selection=sel,
                    auroc=float(roc_auc_score(y,st)),fpr95=fpr_at_recall(st,y)["fpr95"],
                    frozen_unknown_recall=float(reject[~known].mean()),frozen_known_rejection=float(reject[known].mean()),
                    known_accuracy=float((pred[known]==ty[known]).mean()),checkpoint_sha256=sha(checkpoint),
                    target_logits_file=cache_source,target_logits_sha256=cache_sha,validation_choices_sha256=choice_hash))
    assert len(records)==6
    dump(out/"results.json",dict(task="C3b",unit=run.name,run_input=str(run),results=records,
        seconds=time.perf_counter()-started,prespec_sha256=sha(ROOT/"prespec/C3b.json"),
        interpretation="Fixed training budget and loss; selector sensitivity, not independently optimized detector training."))
    dump(out/"completed.json",dict(results_sha256=sha(out/"results.json"),rows=len(records)))


if __name__=="__main__":main()
