"""Complete the precision correction on fixed raw-parameter and old80 audits."""
import numpy as np
from sklearn.metrics import roc_auc_score
from gap_closure_core import ROOT,BASE,read,sha,write,units,load_arrays,branch,score,select
import cache_analyses as original


def full_choose(a,route,mode,grid,objective):
    return select(route,mode,grid,a["kz"],a["ka"],a["uz"],a["ua"],True,.5,[0.,.25,.5,.75,1.],objective)


def main():
    spec_path=ROOT/"prespec/E0_legacy_precision.json";spec=read(spec_path)
    assert sha(spec_path)==read(spec_path.with_name("E0_legacy_precision_seal.json"))["sha256"]
    for path,digest in spec["code_hashes"].items():assert sha(path)==digest,path
    rows=[]
    for model,ds,unit,d,_ in units():
        if model!="ViT-B32" or ds=="officehome":continue
        a=load_arrays(d);y=a["ty"]<0;old={r["method"]:r for r in read(d/"results.json")}
        for method in ["MSP","Temp-MSP","autoMixTemp"]:
            sel=old[method]["selection"];st=score(branch(a["tz"],a["ta"],sel),sel["T_score"],"msp")
            from r5_independent_audit_helpers import roc
            value=roc(st,y.astype(int))
            rows.append(dict(dataset=ds,unit=unit,method=method,selection=sel,auroc=value["auroc"],fpr95=value["fpr95"],
                raw_float32_auroc=old[method]["auroc"],raw_float32_fpr95=old[method]["fpr95"]))
    assert len(rows)==297
    write(ROOT/"evidence/E0_fixed_original_parameters.json",dict(records=rows,
        prespec_sha256=sha(spec_path),no_validation_reselection=True,no_archives_modified=True,
        definition="Both operands converted to float64 before interpolation; original float32-selected parameters kept. Primary99units,three scores. Do not confuse fixed arithmetic with changed hyperparameters."),exclusive=True)
    original.branch=lambda a,p,sel:branch(a[p+"z"],a[p+"a"],sel)
    original.choose=full_choose
    def output(_task,value):
        value.update(task="E0_legacy80",prespec_sha256=sha(spec_path),main_manuscript_permitted=False,
            precision="Both interpolation operands converted before multiplication; all old variants and files preserved.")
        write(ROOT/"evidence/E0_legacy80.json",value,exclusive=True)
    original.dump=output;original.B7()
    print("Primary fixed-parameter and historical80 precision replay complete.",flush=True)


if __name__=="__main__":main()
