"""Check every official literal-role adapter and both lambdas without a model/GPU."""
import hashlib
from pathlib import Path
import torch
from torch.utils.data import SequentialSampler
from dassl.data import DataManager

from r5_locoop_batch_common import ROOT, SPEC, INPUTS, sealed, read, write, sha, now
from r5_locoop_bridge import config_for
from r5_independent_audit_helpers import fixtures


def main():
    assert not torch.cuda.is_available(), "Fixture must use CUDA_VISIBLE_DEVICES=-1"
    spec = sealed()
    records = []
    for item in read(INPUTS)["units"]:
        dataset, unit = item["dataset"], item["unit"]
        source = Path(item["input_run"])
        for name, digest in item["manifest_hashes"].items():
            assert sha(source / name) == digest
        jobs = [j for j in spec["jobs"] if (j["dataset"], j["unit"]) == (dataset, unit)]
        assert [j["lambda_value"] for j in jobs] == [.1, .25]
        for job in jobs:
            cfg = config_for(dataset, unit, job["output"], use_cuda=True)
            cfg.defrost()
            cfg.lambda_value = job["lambda_value"]
            cfg.freeze()
            assert hashlib.sha256(cfg.dump().encode("utf-8")).hexdigest() == job["config_sha256"]
            assert cfg.MODEL.BACKBONE.NAME == "ViT-B/32" and cfg.OPTIM.MAX_EPOCH == 50
            assert cfg.lambda_value == job["lambda_value"] and cfg.topk == 1
        # Data roles do not depend onlambda; instantiate one official manager per unit.
        cfg = config_for(dataset, unit, jobs[0]["output"], use_cuda=False)
        dm = DataManager(cfg)
        root = Path(read(source / "config.json")["arguments"]["data_root"])
        expected_train = [(str(root / s["path"]), s["label"]) for s in read(source / "train_samples.json")]
        expected_val = [(str(root / s["path"]), s["label"]) for s in read(source / "val_known_samples.json")]
        assert [(s.impath, s.label) for s in dm.dataset.train_x] == expected_train
        assert [(s.impath, s.label) for s in dm.dataset.val] == expected_val
        assert [(s.impath, s.label) for s in dm.dataset.test] == expected_val
        assert tuple(dm.dataset.classnames) == tuple(item["known_classes"])
        assert isinstance(dm.val_loader.sampler, SequentialSampler) and not dm.val_loader.drop_last
        batch = next(iter(dm.train_loader_x))
        assert batch["img"].shape[1:] == (3, 224, 224)
        assert all(s.label >= 0 for s in dm.dataset.train_x + dm.dataset.val + dm.dataset.test)
        records.append(dict(dataset=dataset, unit=unit, both_lambda_configs_verified=True,
            literal_train_validation_order_verified=True, no_target_in_training_manager=True,
            known_classes=dm.num_classes, train_loader_drop_last=dm.train_loader_x.drop_last,
            sequential_complete_known_validation=True))
        print("CPU-only full-role fixture passed " + dataset + "/" + unit, flush=True)
    result = dict(all_checks_pass=True, units=33, configurations_verified=66, records=records,
        synthetic_metrics=fixtures(), no_model_constructed=True, no_training=True, no_encoder_inference=True,
        no_gpu_available=True, prespec_sha256=sha(SPEC), fixture_script_sha256=sha(__file__), generated_utc=now())
    write(ROOT / "evidence/E6_locoop_batch_fixtures.json", result, exclusive=True)
    print("All33 literal-role managers and66 configurations verified without model construction.")


if __name__ == "__main__":
    main()
