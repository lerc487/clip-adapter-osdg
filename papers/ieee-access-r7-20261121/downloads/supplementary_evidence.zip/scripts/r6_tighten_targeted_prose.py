"""Remove repetition within the user-targeted sections, preserving every result."""
from pathlib import Path
import json
ROOT = Path(__file__).resolve().parents[1]
p = ROOT / "source/body_revision.tex"
text = p.read_text(encoding="utf-8")
records = json.loads((ROOT / "evidence/F3_editorial_change_records.json").read_text(encoding="utf-8"))
def replace(task, before, after):
    global text
    assert before in text
    text = text.replace(before, after)
    records.append(dict(task=task, file="source/body_revision.tex", before=before, after=after,
                        evidence="No values changed; scoped repetition removed."))
start = text.index("At pooled validation recall 0.95,")
stop = text.index("\n\nActual PACS", start)
replace("A6", text[start:stop], "At pooled validation recall 0.95, autoMixTemp reaches PACS/CIFAR-10 target recall \\PACSAutoRecall{}/\\CIFARAutoRecall{} (Table~\\ref{tab:transfer}). Class-wise conservative rules raise both recall and rejection (Fig.~\\ref{fig:transfer}): at validation recall 0.99, worst-class PACS recall/rejection is \\PACSWorstNinetyNineRecall{}/\\PACSWorstNinetyNineReject{}, versus \\CIFARWorstNinetyNineRecall{}/\\CIFARWorstNinetyNineReject{} on CIFAR-10. Neither transfers 95\\% recall.")
replace("A3", "Table~\\ref{tab:usecases} uses gain $=$ Temp-MSP minus autoMixTemp FPR@95 (positive favors autoMixTemp); validation/target gain Spearman correlations are \\PACSGainCorr{} (PACS) and \\CIFARGainCorr{} (CIFAR-10).", "With gain $=$ Temp-MSP minus autoMixTemp FPR@95 (Table~\\ref{tab:usecases}), validation/target Spearman correlations are \\PACSGainCorr{} on PACS and \\CIFARGainCorr{} on CIFAR-10.")
replace("A8", "Per-domain and source-choice records accompany the evidence; per-seed results are in Supplementary Tables~S17--S19, and threshold and ownership summaries in Tables~S14 and S15. Seeds reuse the image manifests.", "Supplementary Tables~S17--S19 give seed-wise results; Tables~S14 and S15 give threshold/ownership diagnostics. Seeds reuse images.")
replace("A8", "Official prompts, grouping and selection functions and vocabulary outcomes are documented with Supplementary Table~S11.", "Supplementary Table~S11 documents prompts, grouping, selection and both vocabularies.")
p.write_text(text, encoding="utf-8")
(ROOT / "evidence/F3_editorial_change_records.json").write_text(json.dumps(records, indent=2), encoding="utf-8")
