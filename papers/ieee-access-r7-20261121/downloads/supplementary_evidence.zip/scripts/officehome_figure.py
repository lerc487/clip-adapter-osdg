"""Readable two-panel complete Office-Home score comparison, with no intervals."""
import hashlib
import json
from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def main():
    data=read(ROOT/"evidence/C1_complete_panel_audit.json");assert data["all_checks_pass"] and data["n"]==20
    plt.rcParams.update({"font.family":"DejaVu Sans","font.size":8,"axes.spines.top":False,"axes.spines.right":False,"pdf.fonttype":42})
    labels={"MSP":"MSP","Temp-MSP":"Temp-MSP","Energy-only-T1":"Energy, T=1","Mix-alpha0.5-T-tuned":"Mix, alpha=0.5","autoMixTemp":"autoMixTemp","Zero-shot-T-tuned":"Zero-shot, tuned T","Energy-T-tuned":"Energy, tuned T"}
    fig,axes=plt.subplots(1,2,figsize=(7.2,3.1),sharey=True,layout="constrained");registry=[]
    for ax,metric in zip(axes,["auroc","fpr95"]):
        values=[]
        for i,row in enumerate(data["summary"]):
            value=row[metric]*100;values.append(value)
            color="#C06232" if row["method"]=="autoMixTemp" else "#275C6F" if row["method"]=="Temp-MSP" else "#647680"
            ax.scatter(value,i,s=26,color=color,zorder=3)
            ax.annotate(format(value,".2f"),(value,i),xytext=(5,0),textcoords="offset points",va="center",fontsize=7,color=color)
            registry.append(dict(file="C1_complete_panel_audit.json",pointer=["summary",i,metric],value=row[metric],display_percent=format(value,".2f")))
        extent=max(max(values)-min(values),1.);ax.set_xlim(min(values)-.15*extent,max(values)+.4*extent)
        ax.set_yticks(np.arange(len(data["summary"])),[labels[r["method"]] for r in data["summary"]]);ax.set_ylim(len(data["summary"])-.4,-.7)
        ax.grid(axis="x",color="#DFE5E8",linewidth=.7)
        ax.set_title("Office-Home  "+("AUROC" if metric=="auroc" else "FPR@95"),loc="left",fontsize=10,fontweight="bold")
        ax.set_xlabel("AUROC (%)  higher is better" if metric=="auroc" else "FPR@95 (%)  lower is better")
    axes[1].tick_params(labelleft=False)
    fig.get_layout_engine().set(rect=(0,.08,1,1))
    fig.text(.02,.015,"4 domains x 5 rotations, seed0; sampled budget; no pooling with the primary panels.",fontsize=7,color="#354C58")
    destination=ROOT/"source/figures/officehome_comparison.pdf"
    fig.savefig(destination,bbox_inches="tight",pad_inches=.07);fig.savefig(ROOT/"logs/officehome_comparison.png",dpi=160,bbox_inches="tight",pad_inches=.07);plt.close(fig)
    metadata=read(ROOT/"evidence/figure_data_registry.json");metadata["officehome_figure_records"]=registry
    metadata["figure_hashes"][destination.name]=hashlib.sha256(destination.read_bytes()).hexdigest()
    (ROOT/"evidence/figure_data_registry.json").write_text(json.dumps(metadata,indent=2),encoding="utf-8")
    print("Office-Home comparison generated from14evidence-bound values.")

if __name__=="__main__":main()
