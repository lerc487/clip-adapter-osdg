"""Evaluate both operational outcomes, including the complete Office-Home panel."""
from gap_closure_core import *


def main():
    choices = {(r["model"], r["dataset"], r["unit"], r["method"]): r for r in read(ROOT / "evidence/E0_precision.json")["records"]}
    rows = []
    for model, ds, unit, directory, old in units():
        with np.load(cache_path(model, ds, unit), allow_pickle=False) as z:
            a = {k: z[k] for k in z.files}
        samples = read(directory / "val_unknown_samples.json")
        classes = np.array([r["path"].replace("\\", "/").split("/")[-2] for r in samples])
        vy = a["validation_labels"]; y = a["target_labels"] < 0; known = ~y
        known_count = int((vy == 0).sum())
        for method in ["MSP", "Temp-MSP", "Energy-T-tuned", "autoMixTemp"]:
            st, sv = a[method], a[method + "_validation"]
            assert len(classes) == int(vy.sum())
            for rho in [.9, .95, .975, .99]:
                pooled = fpr_at_recall(sv, vy, rho)["threshold"]
                class_thresholds = []
                for name in sorted(set(classes)):
                    mask = np.r_[np.ones(known_count, dtype=bool), classes == name]
                    class_thresholds.append(fpr_at_recall(sv[mask], vy[mask], rho)["threshold"])
                for policy, threshold in [("pooled", pooled), ("worst_class", min(class_thresholds))]:
                    reject = st >= threshold; accepted = ~reject; accepted_known = accepted & known
                    recall = float(reject[y].mean())
                    rows.append(dict(**tag(model, ds, unit), method=method, rho=rho, policy=policy, threshold=threshold,
                        unknown_recall=recall, known_rejection=float(reject[known].mean()), recall_gap=recall-rho,
                        accepted_known_accuracy=float((a["adapter_predictions"][accepted_known] == a["target_labels"][accepted_known]).mean()) if accepted_known.any() else None,
                        unknown_contamination=float((accepted & y).sum()/accepted.sum()) if accepted.any() else None))
        print("E2 " + ds + " " + unit, flush=True)
    summary = grouped_means(rows, ["model", "dataset", "method", "rho", "policy"],
        ["unknown_recall", "known_rejection", "recall_gap", "accepted_known_accuracy", "unknown_contamination"])
    indexed = {(r["model"], r["dataset"], r["unit"], r["rho"], r["policy"], r["method"]): r for r in rows}
    paired = []
    for auto in [r for r in rows if r["method"] == "autoMixTemp"]:
        for comparator in ["MSP", "Temp-MSP"]:
            ref = indexed[tuple(auto[k] for k in ["model", "dataset", "unit", "rho", "policy"])+(comparator,)]
            dr, df = auto["unknown_recall"]-ref["unknown_recall"], auto["known_rejection"]-ref["known_rejection"]
            weak = dr >= -1e-12 and df <= 1e-12
            paired.append(dict(**tag(auto["model"], auto["dataset"], auto["unit"]), rho=auto["rho"], policy=auto["policy"],
                comparator=comparator, delta_recall=dr, delta_rejection=df,
                joint_dominance=weak and (dr > 1e-12 or df < -1e-12),
                identical=abs(dr) <= 1e-12 and abs(df) <= 1e-12,
                lower_rejection_lower_recall=df < -1e-12 and dr < -1e-12,
                target_recall_at_least_95=auto["unknown_recall"] >= .95-1e-12,
                target_95_with_no_more_rejection_than_comparator=auto["unknown_recall"] >= .95-1e-12 and df <= 1e-12))
    paired_summary = grouped_means(paired, ["model", "dataset", "rho", "policy", "comparator"], ["delta_recall", "delta_rejection"])
    for row in paired_summary:
        rs = [r for r in paired if all(r[k] == row[k] for k in ["model", "dataset", "rho", "policy", "comparator"])]
        row.update({k + "_count": sum(r[k] for r in rs) for k in ["joint_dominance", "identical", "lower_rejection_lower_recall", "target_recall_at_least_95", "target_95_with_no_more_rejection_than_comparator"]})
    gaps = []
    for r in summary:
        rr = [x for x in rows if all(x[k] == r[k] for k in ["model", "dataset", "method", "rho", "policy"])]
        values = [x["recall_gap"] for x in rr]
        gaps.append({k: r[k] for k in ["model", "dataset", "method", "rho", "policy", "n"]} |
            dict(negative_gap_count=sum(v < -1e-12 for v in values), **{"q"+str(q): float(np.quantile(values, q/100)) for q in [0,25,50,75,100]}))
    save("E2_transfer_tradeoffs", dict(records=rows, summary=summary, paired_records=paired, paired_summary=paired_summary,
        gap_summary=gaps, outcomes_not_selected_on_targets=True,
        scope="All existing fitted panels kept separate. Every original rho and both policies retained; no target outcome selects a policy, score or threshold. Pareto counts are descriptive, not a deployment-selection rule.",
        logical_boundary="For any nonempty acceptance region, an unconstrained future unknown distribution can be supported inside it and have zero rejection recall. Distribution-free unknown recall and useful known acceptance cannot both be inferred from unrelated validation classes alone. This is a mathematical boundary, not an experimental observation."))


if __name__ == "__main__":
    main()
