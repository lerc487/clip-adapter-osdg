"""Rebuild both PDFs from the exact sourceZIP and compare every rendered pixel."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import hashlib
import json
import subprocess
from PIL import Image, ImageChops

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "source"
OUT = ROOT / "final_review_20261120"
OUT.mkdir(exist_ok=True)


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    zip_path = OUT / "IEEE_Access_Access-2026-47709_source.zip"
    included = []
    obsolete = {"locoop_pilot_supplement.tex"}
    with ZipFile(zip_path, "w", ZIP_DEFLATED) as z:
        for path in sorted(SRC.rglob("*")):
            if not path.is_file() or path.name in obsolete:
                continue
            relative = path.relative_to(SRC)
            allowed = path.suffix.lower() in {".tex", ".bib", ".bst", ".cls", ".sty", ".pfb", ".tfm", ".map", ".fd"}
            allowed |= path.suffix.lower() == ".png" and relative.parent == Path(".")
            used_figures = json.loads((ROOT / "evidence/E9_final_figure_registry.json").read_text(encoding="utf-8"))["figure_hashes"]
            allowed |= path.suffix.lower() == ".pdf" and relative.parts[0] == "figures" and path.name in used_figures
            allowed |= relative.as_posix() == "author_photos/README.txt"
            if allowed:
                z.write(path, relative.as_posix())
                included.append(dict(path=relative.as_posix(), sha256=sha(path)))
    work = ROOT / "new_runs/E13_final_source_roundtrip_v2"
    work.mkdir(exist_ok=False)
    with ZipFile(zip_path) as z:
        for name in z.namelist():
            assert (work / name).resolve().is_relative_to(work.resolve()), name
        z.extractall(work)
    tex = Path(r"C:\texlive\2025\bin\windows")
    commands = [[str(tex / "pdflatex.exe"), "-interaction=nonstopmode", "-halt-on-error", "manuscript.tex"],
        [str(tex / "bibtex.exe"), "manuscript"]]
    commands += [commands[0], commands[0]]
    commands += [[str(tex / "pdflatex.exe"), "-interaction=nonstopmode", "-halt-on-error", "supplement.tex"]] * 2
    for i, command in enumerate(commands):
        with (work / ("build_" + str(i) + ".txt")).open("w", encoding="utf-8") as f:
            subprocess.run(command, cwd=work, stdout=f, stderr=subprocess.STDOUT, check=True)
    results = []
    for name, scale, reference in [("manuscript", "1500", "E12_main_pages"), ("supplement", "1400", "E12_supp_pages")]:
        destination = work / (name + "_pages")
        destination.mkdir()
        subprocess.run(["pdftoppm", "-scale-to", scale, "-png", str(work / (name + ".pdf")), str(destination / "page")], check=True)
        pages = sorted(destination.glob("page-*.png"))
        originals = sorted((ROOT / "logs" / reference).glob("page-*.png"))
        assert len(pages) == len(originals)
        for rebuilt, original in zip(pages, originals):
            a, b = Image.open(rebuilt).convert("RGB"), Image.open(original).convert("RGB")
            assert a.size == b.size and ImageChops.difference(a, b).getbbox() is None, (name, rebuilt.name)
        results.append(dict(document=name, pages=len(pages), every_rendered_pixel_matches=True))
    receipt = dict(all_checks_pass=True, source_zip_sha256=sha(zip_path), files=included,
        fresh_compile=True, documents=results, work_dir=str(work), source_pdf_visible_content_matches=True,
        clean_pdf_sha256=sha(SRC / "manuscript.pdf"), supplement_pdf_sha256=sha(SRC / "supplement.pdf"))
    (ROOT / "evidence/E13_source_roundtrip.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    print("SourceZIP fresh compile and every-page pixel comparison passed: " + json.dumps(results))


if __name__ == "__main__":
    main()
