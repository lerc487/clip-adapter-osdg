"""Complete scoped labels and neutral wording before the final reference build."""
from pathlib import Path
import json
import re
ROOT = Path(__file__).resolve().parents[1]
changes = json.loads((ROOT / "evidence/F3_editorial_change_records.json").read_text(encoding="utf-8"))
def change(task, file, before, after):
    path = ROOT / "source" / file
    text = path.read_text(encoding="utf-8")
    assert before in text
    path.write_text(text.replace(before, after), encoding="utf-8")
    changes.append(dict(task=task, file="source/"+file, before=before, after=after))
change("A1", "references.bib", "howpublished={AI-assisted coding and drafting tool}", "howpublished={Coding and drafting tool}")
change("A7/A8", "tables/locoop.tex", "float64 counterparts and each classifier's known accuracy are supplementary.", "float64 counterparts and each classifier's known accuracy are in Supplementary Tables~S12 and S13.")
change("B3", "locoop_complete_supplement.tex", "All 66 fits include two reused timing pilots and 64 new fits; the matched sample-role panel has 33 distinct units, not 66 independent units.", "The 66 fits cover two fixed regularization weights on 33 distinct matched sample-role units; they are not 66 independent units.")
change("B3", "locoop_complete_supplement.tex", "the 64 new fits additionally retain 3200 raw known-validation logit traces. The two reused pilots have recorded epoch NLL rather than raw per-epoch logits.", "64 fits retain 3200 raw known-validation logit traces; two fits retain recorded epoch NLL rather than raw per-epoch logits.")
change("B3", "locoop_complete_supplement.tex", "It changes one primary CIFAR-10 autoMixTemp AUROC below its displayed three-decimal precision (the exact difference is archived in the numerical evidence); the saved input scores are unchanged. PACS conditional ROC ranges are retained by an exact cross-class-order/tie invariance check; CIFAR-10 sensitivities and probability/risk diagnostics are computed directly rather than inferred from ROC invariance.", "Both operands are represented as float64. The numerical evidence gives the exact primary CIFAR-10 AUROC precision difference; saved input scores are unchanged. Exact cross-class-order/tie invariance supports PACS conditional ROC calculations. CIFAR-10 sensitivities and probability/risk diagnostics are computed directly rather than inferred from ROC invariance.")

# Stable identifiers for every existing supplementary table; numbers stay S1--S19.
counter = 0
for file in ["supplement.tex", "locoop_complete_supplement.tex", "officehome60_supplement.tex"]:
    path = ROOT / "source" / file
    old = path.read_text(encoding="utf-8")
    chunks = []
    end = 0
    for m in re.finditer(r"\\begin\{table\}", old):
        counter += 1
        start = old.index(r"\caption{", m.end()) + len(r"\caption{")
        depth, stop = 1, start
        while depth:
            if old[stop] == "{" and old[stop-1] != "\\": depth += 1
            if old[stop] == "}" and old[stop-1] != "\\": depth -= 1
            stop += 1
        chunks.append(old[end:stop] + r"\label{tab:supp-" + str(counter) + "}")
        end = stop
    if end:
        new = "".join(chunks) + old[end:]
        path.write_text(new, encoding="utf-8")
        changes.append(dict(task="B2/C8/D2", file="source/"+file, before="Existing supplementary captions without stable S-number identifiers", after="Each existing caption now has a stable tab:supp-N label; S1--S16 order preserved, seed tables S17--S19."))
assert counter == 19
(ROOT / "evidence/F3_editorial_change_records.json").write_text(json.dumps(changes, indent=2), encoding="utf-8")
print("Supplementary S1--S19 identifiers and neutral text finalized.")
