"""One report per requested cache task, with actual JSON-derived values."""
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/"scripts"))
from cache_analyses import read


def main():
    descriptions={
        "B1":("按选择类型分层、验证与目标增益相关，以及预设门控规则。","两种门控、两个阈值、四个面板均保留；不能把纯 zero-shot 选择当作混合收益。严格 interior-only 门控未识别出跨面板一致有利的适用场景。","strata"),
        "B2":("完成四个验证召回目标和 pooled/worst-class 两种阈值规则。","更保守规则提高未知召回，但同时提高已知误拒；不能写成在维持 95% 召回下获得部署收益。","summary"),
        "B3":("补充连续 known-validation NLL 温度拟合及固定分类器 risk-coverage/AURC。","检测调参恶化概率指标。常规 NLL 温度缩放针对概率目标，但 PACS 上目标 NLL 仍比 MSP 差，不能只展示其 ECE 改善。","summary"),
        "B4":("完成高温与极限评分、秩相关，以及预设 61 点稠密 log-T 网格。","高温排序接近极限不等于参考网格上界已经饱和；稠密网格相对扩展网格并非处处有利，不据目标结果选网格。","dense_summary"),
        "B5":("复核 28 个域角色单元格、六个 R4 饱和运行及簇级置信度关系。","单元格原值范围超出 -3.8 的极小部分，但保留一位小数确为 -3.8 至 +0.8 pp；不能把四舍五入值当严格边界。置信度关系仅描述性，不作因果解释。","associations"),
        "B6":("完成簇均值/胜负平/删簇范围，PACS 各 10,000 次簇与联合重采样。","PACS 条件性区间在当前面板支持正向变化，但没有消除固定拟合和共享图像依赖；CIFAR 五簇不给新簇区间。","summary"),
        "B7":("旧 80 单元完成 float32、原参数 stable 与验证重选 stable 复算。","旧 80 单元的三种方法平均 FPR@95 均不变；AUROC 只有极小数值差异。不能把新 84 单元的饱和问题倒推到原送审数字。仅进入回复和补充材料。","summary"),
        "C3a":("补充同四个 PACS rotation00/seed0 单元的主协议与 full20 配对。","相同四单元的 known-NLL 选择下，energy 和 autoMixTemp 指标与 full20 相同；大面板与四单元的差别不能归因于取消早停。","summary")}
    for task,(what,meaning,field) in descriptions.items():
        data=read(ROOT/"evidence"/(task+".json"))
        lines=["# "+task+" 独立完成报告","","## 1 做了什么",what,"","## 2 修改位置",f"分析脚本 scripts/cache_analyses.py（B6 为 cluster_sensitivity.py）；证据 evidence/{task}.json。正文与回复的最终节表图位置在 CHANGES.md 完成编译后记录。","","## 3 新数字与来源",f"唯一数值来源：evidence/{task}.json；预设 SHA256：{data['prespec_sha256']}。下列为该 JSON 的 {field} 原值，不估算或选择有利行。","","```json",json.dumps(data[field],indent=2,ensure_ascii=False),"```","","## 4 对结论的影响",meaning,"","## 5 需要用户决定的事","本缓存任务无需新增训练。C1/C2/C3b/C4 是否启动，须按 C0 报告另外确认。"]
        (ROOT/"reports"/(task+"_完成报告.md")).write_text("\n".join(lines)+"\n",encoding="utf-8")
    print("Separate reports written for B1-B7 and C3a.")


if __name__=="__main__":main()
