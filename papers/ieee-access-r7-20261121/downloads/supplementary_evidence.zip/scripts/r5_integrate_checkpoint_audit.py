"""Integrate audited detector-specific checkpoint selection and its full reference."""
import csv
import hashlib
import json
from pathlib import Path
import shutil
import sys

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "source"
sys.path.insert(0, str(ROOT / "scripts"))
import integrate_results as I


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def main():
    specpath = ROOT / "prespec/E4_manuscript_integration.json"
    spec = read(specpath)
    assert sha(specpath) == read(specpath.with_name("E4_manuscript_integration_seal.json"))["sha256"]
    assert sha(__file__) == spec["script_sha256"]
    audit = read(ROOT / "evidence/E4_independent_audit.json")
    assert audit["all_checks_pass"] and audit["unit_count"] == 33
    assert audit["method_selector_rows_verified"] == 264 and audit["validated_epoch_snapshots"] == 660
    backup = ROOT / "new_runs/E4_integration_before"
    backup.mkdir(exist_ok=False)
    for rel in ["source/architecture_results.tex", "source/body_revision.tex", "source/numbers_revision2.tex", "source/supplement.tex", "evidence/number_registry.json"]:
        p = ROOT / rel
        q = backup / rel
        q.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(p, q)
    I.REG = read(ROOT / "evidence/number_registry.json")
    I.MACROS = []
    rows = []
    for ds, label in [("pacs", "PACS"), ("cifar10", "CIFAR-10")]:
        for method in ["MSP", "Temp-MSP", "Energy-T-tuned", "autoMixTemp"]:
            for selector, tag in [("known_NLL_reference", "Known NLL"), ("detector_validation_FPR95", "Own FPR@95")]:
                i = next(i for i, r in enumerate(audit["summary"]) if (r["dataset"], r["method"], r["selector"]) == (ds, method, selector))
                rows.append([label, method.replace("Energy-T-tuned", "Energy tuned"), tag,
                    I.n("E4_independent_audit", ("summary", i, "n"), 0)] +
                    [I.n("E4_independent_audit", ("summary", i, k), 3) for k in ["auroc", "fpr95", "recall", "rejection"]])
    I.table("own_checkpoint", "Detector-specific validation selection on complete 20-epoch trajectories at seed0. Own FPR@95 jointly chooses the epoch and score parameters using validation FPR@95, then validation AUROC and the earliest exact epoch. The reference chooses an epoch by known-validation NLL and tunes each detector on that epoch. Fractions are equal-unit means; target results never select an epoch. Training loss and fitted trajectories remain shared.",
        r"Data & Score & Epoch selector & $n$ & AUROC & FPR@95 & Unknown recall & Known rejection", rows, "lllrrrrr")
    with (SRC / "numbers_revision2.tex").open("a", encoding="ascii") as f:
        f.write("\n".join(I.MACROS) + "\n")
    (ROOT / "evidence/number_registry.json").write_text(json.dumps(I.REG, indent=2), encoding="utf-8")
    architecture = (SRC / "architecture_results.tex").read_text()
    architecture += r"""
\paragraph{Detector-specific validation selection}
Each detector also independently selects its epoch and temperature/source parameters by validation FPR@95 on the same complete trajectories (Table~\ref{tab:own_checkpoint}). The 264 detector/selector records include all 33 matched seed0 units and their known-NLL references; 660 epoch-validation snapshots were independently checked before target replay was verified. These controls remove a shared-checkpoint selection restriction, not the shared training loss. Their frozen-threshold recall and rejection remain separate from labeled-target ROC performance.
\input{tables/own_checkpoint}
"""
    (SRC / "architecture_results.tex").write_text(architecture, encoding="ascii")
    body = (SRC / "body_revision.tex").read_text()
    body = body.replace("LoCoOp remains unevaluated; learned prompts require a separate training budget and verified sample-role integration.",
        "Official LoCoOp has two audited timing pilots only, not a complete baseline panel; learned prompts use a separate training budget.")
    body = body.replace("python -B -s scripts/cache_analyses.py B2\npython -B -s scripts/cache_analyses.py B3\npython -B -s scripts/cluster_sensitivity.py",
        "python -B -s scripts/r5_verify_review_draft.py")
    (SRC / "body_revision.tex").write_text(body, encoding="ascii")
    # Every pilot score is retained; two pilots are not a matched panel estimate.
    pilots = read(ROOT / "evidence/E6_pilot_audit.json")
    assert pilots["all_checks_pass"]
    pilot_rows = []
    for i, r in enumerate(pilots["records"]):
        pilot_rows.append(["PACS" if r["dataset"] == "pacs" else "CIFAR-10", r["method"].replace("_", r"\_")] +
            [I.n("E6_pilot_audit", ("records", i, k), 3) for k in ["auroc", "fpr95", "frozen_unknown_recall", "frozen_known_rejection"]])
    pilot_tex = [r"\section*{Official LoCoOp timing pilots}",
        "Two prespecified seed0 units, one per primary dataset, used the pinned official LoCoOp trainer/loss and Dassl implementation with literal sample-role adapters. Training used ViT-B/32, 16 learned context tokens, 50 epochs, SGD learning rate 0.002, batch size 32, AMP, regularization weight 0.1 and top-k equal to the larger of one and the floor of 0.2 times the known-class count. Earliest minimum known-validation NLL selected the prompt checkpoint before validation-unknown or target scoring. The official T=1 scoring function and both float64 counterparts were retained and independently checked on common inputs. These are timing/feasibility pilots, not published-number reproduction or a complete matched baseline comparison.",
        r"\begin{tabular}{llrrrr}\toprule", r"Data & Score realization & AUROC & FPR@95 & Recall & Rejection\\\midrule"]
    pilot_tex += [" & ".join(row) + r"\\" for row in pilot_rows]
    pilot_tex += [r"\bottomrule\end{tabular}",
        "Scores are evaluated with unknown-positive complete-tie ROC metrics. Prompt learning changes the classifier and training budget; unchanged adapter accuracy is not asserted for LoCoOp. All pilot variants are shown and no pilot outcome selects a later batch scope."]
    (SRC / "locoop_pilot_supplement.tex").write_text("\n".join(pilot_tex) + "\n", encoding="ascii")
    with (SRC / "numbers_revision2.tex").open("a", encoding="ascii") as f:
        f.write("\n".join(I.MACROS[len(rows) * 5:]) + "\n")
    (ROOT / "evidence/number_registry.json").write_text(json.dumps(I.REG, indent=2), encoding="utf-8")
    supp = (SRC / "supplement.tex").read_text()
    supp = supp.replace(r"\end{document}", r"\clearpage\input{locoop_pilot_supplement}" + "\n" + r"\end{document}")
    (SRC / "supplement.tex").write_text(supp, encoding="ascii")
    # Flat per-unit files make the exact comparison inspectable without reading prose.
    out = ROOT / "reports/E4_checkpoint_all264.csv"
    with out.open("w", newline="", encoding="utf-8-sig") as f:
        keys = ["dataset", "unit", "selector", "method", "epoch", "auroc", "fpr95", "recall", "rejection", "known_accuracy", "accepted_known_accuracy"]
        writer = csv.DictWriter(f, fieldnames=keys, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(audit["records"])
    fields = ["auroc", "fpr95", "recall", "rejection"]
    lines = ["# E4 独立checkpoint选点核验与入稿", "", "## 1. 做了什么", "",
        "33条完整20轮轨迹分别按检测器自身验证FPR@95选epoch/温度及来源，对照同轨迹known-NLL选点；全部264条结果和660个验证快照已独立核验。不重训，不使用目标结果选点。", "", "## 2. 文件和章节", "",
        "`E4_independent_audit.json`、`E4_target_results.json`；结果的checkpoint敏感性小节、`tables/own_checkpoint.tex`及完整CSV。", "", "## 3. 实际数字及JSON来源", "",
        "| Data | Method | Selector | n | AUROC | FPR@95 | Recall | Rejection |", "| --- | --- | --- | --- | --- | --- | --- | --- |"]
    for r in audit["summary"]:
        lines.append("| " + " | ".join([r["dataset"], r["method"], r["selector"], str(r["n"])] + [format(r[k], ".6f") for k in fields]) + " |")
    lines += ["", "## 4. 有利还是不利", "", "全部选择器和方法的正负结果均保留；独立验证选点排除了共享选点限制，但不等于分别为检测器优化训练损失，也不能据此证明95%目标召回或普适优势。", "", "## 5. 需要作者决定的事", "",
        "本项不再需要训练授权。官方LoCoOp完整批量范围仍需确认；两个试点的完成不等于R3.4的所有基线比较已充分。整稿和回复信还需最终编译与一致性检查。"]
    (ROOT / "reports/E4_独立checkpoint选点核验与入稿报告.md").write_text("\n".join(lines) + "\n", encoding="utf-8")
    receipt = dict(audit_sha256=sha(ROOT / "evidence/E4_independent_audit.json"), rows=264, snapshots=660,
        units=33, new_training=False, loco_op_full_panel=False, final_response_completed=False, upload_ready=False)
    (ROOT / "evidence/E4_manuscript_integration_receipt.json").write_text(json.dumps(receipt, indent=2), encoding="utf-8")
    print("E4 all264 verified rows integrated, with both selectors and frozen transfer outcomes.")


if __name__ == "__main__":
    main()
