"""Freeze detector-specific epoch and temperature choices; never infer targets."""
from gap_closure_core import *


def main():
    runs = []
    c3 = R2 / "new_runs/c3b/evaluations"
    for result in sorted(c3.glob("*/results.json")):
        record = read(result)
        runs.append(("pacs", result.parent.name, Path(record["run_input"]), result.parent))
    for run in sorted((BASE / "05_new_runs/vitb32_full20/cifar10").glob("*")):
        if run.is_dir():
            runs.append(("cifar10", run.name, run, None))
    assert len(runs) == 33 and len({(d,u) for d,u,_,_ in runs}) == 33
    selected, epochs, candidates, inputs, need = [], [], [], [], []
    for ds, unit, run, extra in runs:
        config = read(run / "config.json")["arguments"]
        grid = [float(x) for x in config["temp_candidates"].split(",")]
        choices = defaultdict(list)
        for epoch in range(1,21):
            path = run / f"epoch_checkpoints/validation_{epoch:02d}.npz"
            with np.load(path, allow_pickle=False) as z:
                a = {k:z[k] for k in z.files}
            inputs.append(dict(dataset=ds,unit=unit,epoch=epoch,validation_file=str(path),sha256=sha(path)))
            for method, route, mode, ts in [("MSP","adapter","msp",[1.]),("Temp-MSP","adapter","msp",grid),
                                           ("Energy-T-tuned","adapter","energy",grid),("autoMixTemp","auto","msp",grid)]:
                sel = choose(a, route, mode, ts)
                row = dict(dataset=ds,unit=unit,method=method,epoch=epoch,selection=sel)
                choices[method].append(row); epochs.append(row)
        for method, rows in choices.items():
            best = min(rows, key=lambda r:(r["selection"]["val_fpr95"],-r["selection"]["val_auroc"],r["epoch"]))
            epoch = best["epoch"]
            checkpoint = run / f"epoch_checkpoints/epoch_{epoch:02d}.pt"
            assert checkpoint.is_file()
            possible = [run / f"epoch_checkpoints/selected_test_{epoch:02d}.npz"]
            if extra:
                possible.append(extra / f"selected_test_{epoch:02d}.npz")
            cached = next((p for p in possible if p.is_file()),None)
            row = dict(**best,run=str(run),checkpoint=str(checkpoint),checkpoint_sha256=sha(checkpoint),
                       existing_target_cache=str(cached) if cached else None)
            selected.append(row)
            if cached is None:
                need.append(dict(dataset=ds,unit=unit,epoch=epoch,method=method,checkpoint=str(checkpoint)))
        print("E4 frozen " + ds + " " + unit, flush=True)
    unique_need = sorted({(r["dataset"],r["unit"],r["epoch"]) for r in need})
    save("E4_epoch_validation_selection", dict(records=selected,per_epoch_records=epochs,validation_inputs=inputs,
        missing_target_cache_method_rows=need,missing_distinct_target_caches=[dict(dataset=d,unit=u,epoch=e) for d,u,e in unique_need],
        unit_count=len(runs),method_choice_count=len(selected),missing_distinct_target_cache_count=len(unique_need),
        target_files_read=False,new_target_inference_started=False,training_loss_unchanged=True,
        scope="Each detector independently selects an epoch and its scoring parameters on validation FPR95 then validation AUROC, with earliest exact epoch tie. All 20 epochs and all original parameter candidates are retained. This removes forced sharing of checkpoint selection but is not independent detector-specific training-loss optimization.",
        next_gate="No missing target cache is reconstructed until user authorization. Choices are frozen before target evaluation. No result-dependent reduction of the fixed 33-unit scope."))


if __name__ == "__main__":
    main()
