"""Highlight against the confirmed actual IEEE Access submitted PDF."""
import importlib.util
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
path=ROOT.parent/"tools/highlight_revision_pdf.py"
spec=importlib.util.spec_from_file_location("highlight",path)
module=importlib.util.module_from_spec(spec)
spec.loader.exec_module(module)
module.ROOT=ROOT.parent
module.BASE=ROOT.parent/"00_submitted_baseline/source/manuscript.pdf"
module.NEW=ROOT/"source/manuscript.pdf"
module.OUT=ROOT/"source/manuscript_highlighted.pdf"
module.QA=ROOT/"logs/highlight_QA"
module.main()
