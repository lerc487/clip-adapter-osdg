"""Resume ordered GPU stages using the newly authorized v3 input manifest."""
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time
from follow_authorized_stages import alive

ROOT=Path(__file__).resolve().parents[1]


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def state(stage,**kw):
    p=ROOT/"evidence/authorized_queue_v3_eval64_progress.json";tmp=p.with_suffix(".tmp")
    tmp.write_text(json.dumps(dict(stage=stage,protocol_version="C1_dedup_v3",pid=os.getpid(),updated=time.strftime("%Y-%m-%dT%H:%M:%S"),**kw),indent=2),encoding="utf-8");tmp.replace(p)


def main():
    names=["follow_authorized_stages_v3_eval64.py","follow_authorized_stages.py","officehome_pilot_v3_eval64.py","officehome_train_v3.py","neglabel_infer.py"]
    hashes={"scripts/"+n:sha(ROOT/"scripts"/n) for n in names}
    spec=dict(task="authorized_queue_v3_eval64",parent_queue_sha256=sha(ROOT/"prespec/authorized_queue.json"),
        input_amendment_sha256=sha(ROOT/"prespec/C1_dedup_v3.json"),literal_manifest_spec_sha256=sha(ROOT/"prespec/C1_roles_manifest_v3.json"),
        pilot_spec_sha256=sha(ROOT/"prespec/C1_pilot_v3_eval64.json"),GPU_order=["C3b","Office-Home two-unit v3 timing pilot","NegLabel matched-sample port"],
        authorization="Existing staged GPU authorization plus explicitv3 domain-or-category duplicate exclusion; not an authorization for remaining18units or seed1/2.",
        no_stage1_or_stage2_autostart=True,no_LoCoOp=True,no_ViTB16=True,
        stop="Only metadata gates, never target-performance gates. Wait for C3b completion and v3 eligibility; stop on failure, unexpected process exit or pause. Preserve old v1/v2 failure records; no stage skipping or fallback.",
        code_hashes=hashes)
    p=ROOT/"prespec/authorized_queue_v3_eval64.json"
    if p.exists():assert read(p)==spec
    else:
        with p.open("x",encoding="utf-8") as f:json.dump(spec,f,indent=2)
        with (ROOT/"prespec/authorized_queue_v3_eval64_seal.json").open("x",encoding="utf-8") as f:json.dump(dict(task="authorized_queue_v3_eval64",sha256=sha(p)),f,indent=2)
    assert read(ROOT/"evidence/C1_pilot_v3_eval64_fixture_checks.json")["passed"]
    lock=ROOT/"new_runs/authorized_followup.lock"
    with lock.open("x") as f:f.write(str(os.getpid()))
    try:
        while True:
            if (ROOT/"new_runs/PAUSE_REQUESTED").exists():state("paused_by_marker");return
            c3=read(ROOT/"evidence/C3b_progress.json");data=read(ROOT/"evidence/C1_manifest_v3_progress.json")
            if "failed" in c3["stage"] or not data.get("training_eligible",False):raise RuntimeError("Upstream not eligible, no continuation")
            if c3["stage"].startswith("paused"):state("waiting_for_user_resume_C3b");return
            if c3["stage"]!="complete_requires_manuscript_integration" and not alive(c3["pid"]):raise RuntimeError("C3b exited without completion status")
            state("waiting_for_C3b",C3b_completed=c3["completed"],C3b_total=c3["total"],data_ready=True)
            if c3["stage"]=="complete_requires_manuscript_integration":break
            time.sleep(30)
        for name,h in hashes.items():assert sha(ROOT/name)==h
        for stage,script in [("OfficeHome_v3_eval64_timing_pilot","officehome_pilot_v3_eval64.py"),("NegLabel_feature_evaluation_v3queue_eval64","neglabel_infer.py")]:
            if (ROOT/"new_runs/PAUSE_REQUESTED").exists():state("paused_before_next_stage",next_stage=stage);return
            state(stage)
            with (ROOT/"new_runs"/(stage+"_queue.log")).open("a",encoding="utf-8") as f:
                f.write("\nSTART "+time.strftime("%Y-%m-%dT%H:%M:%S")+"\n");f.flush()
                subprocess.run([sys.executable,"-B","-s","-u",str(ROOT/"scripts"/script)],stdout=f,stderr=subprocess.STDOUT,check=True)
            if stage=="OfficeHome_v3_eval64_timing_pilot":
                pilot=read(ROOT/"evidence/C1_pilot_v3_eval64_progress.json")
                if pilot["stage"]!="complete_awaiting_stage1_user_decision":state("pilot_incomplete_no_skip",pilot_status=pilot);return
        state("authorized_stages_complete_requires_integration",remaining_OfficeHome18_not_started=True)
    except Exception as exc:state("failed_requires_inspection",error=repr(exc));raise
    finally:lock.unlink(missing_ok=True)


if __name__=="__main__":main()

