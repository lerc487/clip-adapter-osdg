$ErrorActionPreference = 'Stop'
$root = Split-Path -Parent $PSScriptRoot
$research = 'C:\Users\e\.conda\envs\icip_osr\python.exe'
$bundle = 'C:\Program Files\WindowsApps\OpenAI.CodexPrimaryRuntime.v26-1116-1220-0_26.1116.1220.0_x64__3k8sg7r9htsxt\dependencies\python\python.exe'
$tex = 'C:\texlive\2025\bin\windows\pdflatex.exe'
$bib = 'C:\texlive\2025\bin\windows\bibtex.exe'
$env:PYTHONDONTWRITEBYTECODE = '1'

function Invoke-PythonTask([string]$interpreter, [string]$name, [string[]]$extra = @()) {
    & $interpreter -B -s (Join-Path $PSScriptRoot $name) @extra
    if ($LASTEXITCODE -ne 0) { throw "Failed: $name" }
}

$live = Join-Path (Split-Path -Parent $root) 'revision2_20261118\evidence\C1_stage1_v3_progress.json'
$progress = Get-Content -LiteralPath $live -Raw | ConvertFrom-Json
if ($progress.completed -ne 20 -or $progress.stage -ne 'complete_requires_manuscript_integration') {
    throw 'The complete20-unit panel is not ready; no partial result will be integrated.'
}

Invoke-PythonTask $research 'audit_officehome_complete.py'
Invoke-PythonTask $research 'verify_officehome_scores.py'
Invoke-PythonTask $research 'integrate_officehome.py'
Invoke-PythonTask $research 'supplement.py'
Invoke-PythonTask $research 'officehome_figure.py'

Push-Location (Join-Path $root 'source')
try {
    & $tex -interaction=nonstopmode -halt-on-error manuscript.tex > (Join-Path $root 'logs\main_build_1.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Initial manuscript compile failed' }
    & $bib manuscript > (Join-Path $root 'logs\bib_build.txt')
    if ($LASTEXITCODE -ne 0) { throw 'Bibliography compile failed' }
    foreach ($index in 2..3) {
        & $tex -interaction=nonstopmode -halt-on-error manuscript.tex > (Join-Path $root "logs\main_build_$index.txt")
        if ($LASTEXITCODE -ne 0) { throw 'Manuscript compile failed' }
    }
    foreach ($index in 1..2) {
        & $tex -interaction=nonstopmode -halt-on-error supplement.tex > (Join-Path $root "logs\supp_build_$index.txt")
        if ($LASTEXITCODE -ne 0) { throw 'Supplement compile failed' }
    }
} finally { Pop-Location }

& $research -B -s (Join-Path $PSScriptRoot 'verify_consistency.py') > (Join-Path $root 'logs\consistency_output.txt')
if ($LASTEXITCODE -ne 0) { throw 'Evidence/source preservation check failed' }
Invoke-PythonTask $research 'verify_evidence.py'
Invoke-PythonTask $research 'responses.py'
Invoke-PythonTask $research 'review_evidence_matrix.py'
Invoke-PythonTask $research 'officehome_reports.py'
Invoke-PythonTask $bundle 'documents.py' @('--response-only')
Invoke-PythonTask $bundle 'highlight_integrated.py'

foreach ($name in @('main_pages','supp_pages','highlight_pages','response_pages','response_render','template_render')) {
    New-Item -ItemType Directory -Force -Path (Join-Path $root "logs\$name") | Out-Null
}
$reference = Join-Path (Split-Path -Parent $root) 'revision3_20261119\logs\template_render\reference_template.pdf'
Copy-Item -LiteralPath $reference -Destination (Join-Path $root 'logs\template_render\reference_template.pdf')
$renderer = 'C:\Users\e\.codex\plugins\cache\openai-primary-runtime\documents\26.1116.12020\skills\documents\render_docx.py'
$rendererFailed = $false
try {
    & $bundle -B -s $renderer (Join-Path $root 'deliverables\response_to_reviewers.docx') --output_dir (Join-Path $root 'logs\response_render') --emit_pdf > (Join-Path $root 'logs\packaged_renderer.txt') 2>&1
    $rendererFailed = $LASTEXITCODE -ne 0
} catch { $rendererFailed = $true }
if ($rendererFailed) {
    $word = $null; $document = $null
    try {
        $word = New-Object -ComObject Word.Application
        $word.Visible = $false; $word.DisplayAlerts = 0
        $document = $word.Documents.Open((Join-Path $root 'deliverables\response_to_reviewers.docx'), $false, $true)
        $document.ExportAsFixedFormat((Join-Path $root 'logs\response_render\response.pdf'), 17)
        $document.Close(0); $document = $null
    } finally {
        if ($document) { $document.Close(0) }
        if ($word) { $word.Quit() }
        [GC]::Collect()
    }
}

pdftoppm -r 100 -png (Join-Path $root 'source\manuscript.pdf') (Join-Path $root 'logs\main_pages\page')
pdftoppm -r 100 -png (Join-Path $root 'source\supplement.pdf') (Join-Path $root 'logs\supp_pages\page')
pdftoppm -r 90 -png (Join-Path $root 'source\manuscript_highlighted.pdf') (Join-Path $root 'logs\highlight_pages\page')
pdftoppm -r 100 -png (Join-Path $root 'logs\response_render\response.pdf') (Join-Path $root 'logs\response_pages\page')
Invoke-PythonTask $bundle 'qa_contact_sheets.py'
Write-Output 'VISUAL_QA_REQUIRED: inspect all final rendered pages before recording checks or packaging.'
