"""Accept Office-Home and seal literal roles before the authorized timing pilot."""
import argparse
from collections import defaultdict
import hashlib
import json
from pathlib import Path
import time
from PIL import Image

ROOT=Path(__file__).resolve().parents[1]
EXT={".jpg",".jpeg",".png",".bmp",".webp"}


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def write_new(p,value):
    with p.open("x",encoding="utf-8") as f:json.dump(value,f,indent=2,allow_nan=False)


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--data-root",type=Path,required=True)
    args=parser.parse_args();data=args.data_root.resolve()
    spec=ROOT/"prespec/C1_stages.json";seal=json.loads((ROOT/"prespec/C1_stages_seal.json").read_text())
    assert sha(spec)==seal["sha256"]
    execution=ROOT/"prespec/C1_acceptance.json"
    record=dict(task="C1_acceptance",stage_design_sha256=seal["sha256"],script_sha256=sha(Path(__file__)),
        policy="Verify/decode and hash every image before freezing literal65-class role tables. Additionally stop and ask on identical image content across train/validation/test roles; never silently deduplicate or change sampling. No model inference.",data_root=str(data))
    if execution.exists():assert json.loads(execution.read_text())==record
    else:
        write_new(execution,record)
        write_new(ROOT/"prespec/C1_acceptance_seal.json",dict(task="C1_acceptance",sha256=sha(execution),frozen_before_image_acceptance=True))
    dest=ROOT/"new_runs/officehome";dest.mkdir(parents=True,exist_ok=True)
    if (dest/"accepted_roles.json").exists():raise RuntimeError("Accepted manifest already exists; do not overwrite")
    started=time.perf_counter();domains=sorted([p for p in data.iterdir() if p.is_dir()],key=lambda p:(p.name.casefold(),p.name))
    assert len(domains)==4,"Need the exact four-domain data root, not a containing or partial folder"
    class_lists=[sorted([p.name for p in d.iterdir() if p.is_dir()],key=lambda s:(s.casefold(),s)) for d in domains]
    assert len(class_lists[0])==65 and all(c==class_lists[0] for c in class_lists),"Class folder mismatch"
    inventory=[];byclass={};errors=[]
    for domain in domains:
        for name in class_lists[0]:
            entries=[]
            for p in sorted((domain/name).iterdir()):
                if p.suffix.lower() not in EXT:continue
                relative=p.relative_to(data).as_posix()
                try:
                    with Image.open(p) as image:image.verify()
                    with Image.open(p) as image:image.load();size=list(image.size)
                    row=dict(path=relative,sha256=sha(p),size=size,domain=domain.name,category=name)
                    entries.append(row);inventory.append(row)
                except Exception as exc:errors.append(dict(path=relative,error=repr(exc)))
            if len(entries)<10:errors.append(dict(domain=domain.name,category=name,error="Fewer than10 usable images; no downsampling fallback"))
            byclass[(domain.name,name)]=entries
    write_new(dest/"integrity_check.json",dict(data_root=str(data),files=inventory,errors=errors,seconds=time.perf_counter()-started,
        stage_design_sha256=seal["sha256"],script_sha256=sha(Path(__file__))))
    if errors:raise RuntimeError("Integrity/size issues recorded; ask user, do not silently filter")
    classes=class_lists[0];units=[]
    for rotation in range(5):
        shifted=[classes[(j+13*rotation)%65] for j in range(65)]
        known,vu,tu=shifted[:35],shifted[35:50],shifted[50:]
        for i,target in enumerate(domains):
            val=domains[(i+1)%4];sources=[d for d in domains if d not in [target,val]]
            for seed in [0,1,2]:
                def take(domain,names,sampled):
                    rows=[]
                    for name in names:
                        entries=byclass[(domain.name,name)]
                        chosen=sorted(entries,key=lambda r:(hashlib.sha256((str(seed)+"|"+r["path"]).encode()).hexdigest(),r["path"]))[:10] if sampled else entries
                        rows += chosen
                    return rows
                train=[r for source in sources for r in take(source,known,True)]
                validation_known=take(val,known,True);validation_unknown=take(val,vu,True)
                test=take(target,known+tu,False)
                # Stop on content duplicates across roles rather than silently removing images.
                hashes=defaultdict(set)
                for role,rows in [("train",train),("validation",validation_known+validation_unknown),("test",test)]:
                    for r in rows:hashes[r["sha256"]].add(role)
                overlap=[h for h,roles in hashes.items() if len(roles)>1]
                if overlap:
                    write_new(dest/"cross_role_duplicate_error.json",dict(target=target.name,rotation=rotation,seed=seed,hashes=overlap))
                    raise RuntimeError("Cross-role identical image content found; stop and ask, do not filter")
                assert len(train)==700 and len(validation_known)==350 and len(validation_unknown)==150
                units.append(dict(unit_id=f"{target.name}_rotation{rotation:02d}_seed{seed}",target=target.name,val=val.name,seed=seed,rotation=rotation,
                    known=known,validation_unknown=vu,target_unknown=tu,roles=dict(train=train,val_known=validation_known,val_unknown=validation_unknown,test=test)))
    pilot=[u["unit_id"] for u in units if u["rotation"]==0 and u["seed"]==0][:2]
    assert len(pilot)==2
    result=dict(data_root=str(data),domains=[d.name for d in domains],classes=classes,rotation_step=13,units=units,pilot=pilot,
        stage1=[u["unit_id"] for u in units if u["seed"]==0],stage2=[u["unit_id"] for u in units if u["seed"] in [1,2]],
        stage1_requires_measured_pilot_and_user_decision=True,stage2_requires_later_user_decision=True,
        input_inventory_sha256=sha(dest/"integrity_check.json"),stage_design_sha256=seal["sha256"],GPU_used=False)
    write_new(dest/"accepted_roles.json",result)
    literal_spec=ROOT/"prespec/C1_accepted_roles.json"
    write_new(literal_spec,dict(task="C1_accepted_roles",manifest="new_runs/officehome/accepted_roles.json",manifest_sha256=sha(dest/"accepted_roles.json"),
        domains=result["domains"],classes=classes,rotation_step=13,pilot=pilot,stage_design_sha256=seal["sha256"],frozen_before_training=True))
    write_new(ROOT/"prespec/C1_accepted_roles_seal.json",dict(task="C1_accepted_roles",sha256=sha(literal_spec),frozen_before_training=True))
    print("Integrity accepted and exact Office-Home roles frozen. No training started.")


if __name__=="__main__":main()
