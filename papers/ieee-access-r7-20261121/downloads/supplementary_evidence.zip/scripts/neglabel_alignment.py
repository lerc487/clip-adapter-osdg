"""Execute pinned official AST function bodies on common synthetic inputs."""
import ast
from copy import deepcopy
import hashlib
import json
from pathlib import Path
from types import SimpleNamespace
import torch
from neglabel_core import select_negative_features,grouped_id_score,stable_unknown_logodds

ROOT=Path(__file__).resolve().parents[1]
VENDOR=ROOT/"vendor_review/neglabel_pinned"


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def official_functions():
    source=ast.parse((VENDOR/"mmcls/models/ood/clip_ood.py").read_text())
    cls=next(n for n in source.body if isinstance(n,ast.ClassDef) and n.name=="ScalableClassifier")
    grouping=deepcopy(next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=="grouping"))
    source=ast.parse((VENDOR/"mmcls/models/classifiers/multi_modal.py").read_text())
    cls=next(n for n in source.body if isinstance(n,ast.ClassDef) and n.name=="CLIPScalableClassifier")
    init=next(n for n in cls.body if isinstance(n,ast.FunctionDef) and n.name=="__init__")
    block=next(n for n in init.body if isinstance(n,ast.With) and "neg_sim = []" in ast.unparse(n))
    signature=ast.parse("def official_select(self,noun_length,adj_length,emb_batchsize,pencentile,neg_topk,pos_topk=None):\n pass").body[0]
    signature.body=[deepcopy(block),ast.parse("return self.text_features_neg, self.adj_start_idx").body[0]]
    module=ast.fix_missing_locations(ast.Module(body=[grouping,signature],type_ignores=[]))
    scope={"torch":torch};exec(compile(module,"pinned_official_function_bodies","exec"),scope)
    return scope["grouping"],scope["official_select"]


def main():
    spec=ROOT/"prespec/C2_NegLabel.json";seal=json.loads((ROOT/"prespec/C2_NegLabel_seal.json").read_text())
    assert sha(spec)==seal["sha256"]
    configuration=json.loads(spec.read_text())
    for name,digest in configuration["frozen_implementation_hashes"].items():assert sha(ROOT/name)==digest
    grouping,official_select=official_functions()
    torch.manual_seed(2117)
    positive=torch.nn.functional.normalize(torch.randn(5,64),dim=1)
    negative=torch.nn.functional.normalize(torch.randn(8103,64),dim=1)
    original,adj_start=official_select(SimpleNamespace(text_features_pos=positive.clone(),text_features_neg=negative.clone()),6101,2002,1000,.95,.15)
    port,indices,port_adj=select_negative_features(positive,negative,6101)
    assert torch.equal(original,port) and adj_start==port_adj
    fixtures=[]
    for dtype in [torch.float32,torch.float64]:
        for scale in [1.,25.,100.]:
            pos=(torch.randn(13,5)*scale).to(dtype);neg=(torch.randn(13,1203)*scale).to(dtype)
            official=grouping(SimpleNamespace(t=1.,local_rank="0"),pos,neg,None,ngroup=100,random_permute=False)
            ours=grouped_id_score(pos,neg)
            difference=float((official-ours).abs().max())
            assert torch.allclose(official,ours,atol=1e-7,rtol=1e-6)
            stable=stable_unknown_logodds(pos,neg)
            probability=torch.sigmoid(-stable)
            stable_diff=float((official.double()-probability).abs().max())
            assert torch.allclose(official.double(),probability,atol=5e-7,rtol=5e-6)
            fixtures.append(dict(dtype=str(dtype),scale=scale,rows=len(pos),negative_columns=neg.shape[1],groups=100,
                max_abs_id_score_error=difference,max_abs_stable_transform_probability_error=stable_diff))
    result=dict(task="C2_NegLabel_alignment",prespec_sha256=seal["sha256"],official_commit=configuration["official_commit"],
        official_selection_exact=True,selected_feature_count=len(port),noun_selected=adj_start,adjective_selected=len(port)-adj_start,
        grouping_fixtures=fixtures,all_checks_pass=True,device="CPU",no_model_inference=True,
        function_extraction="Unmodified grouping function AST, random_permute=False; unmodified official no_grad negative-selection block wrapped with its input arguments.",
        scope="Same-input selection and scoring alignment only, not end-to-end reproduction. CUDA random_permute=True alignment is deferred until the NegLabel GPU slot. No CLIP encoder/preprocessing equivalence or published-number reproduction is claimed.")
    (ROOT/"evidence/C2_NegLabel_alignment.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print(json.dumps(result,indent=2))


if __name__=="__main__":main()
