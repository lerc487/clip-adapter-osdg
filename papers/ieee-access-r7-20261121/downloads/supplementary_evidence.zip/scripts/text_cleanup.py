"""Task A1 then A3: targeted edits, with moved provenance retained separately."""
import json
from pathlib import Path
import re

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent


def main():
    p=ROOT/"source/body_revision.tex";text=p.read_text(encoding="utf-8")
    moved=[]
    blocks=text.split("\n\n")
    revised=[]
    for block in blocks:
        old=block
        if block.startswith("Our original submission analyzed"):
            block="We evaluate 84 PACS units and 15 CIFAR-10 units with disjoint validation and target unknown categories. Subtracting a float32 maximum softmax probability from one can collapse distinct confident examples into zero-score ties. We separate this numerical effect from validation retuning by evaluating stable scores at fixed parameters and then repeating validation-only selection."
        elif block.startswith("The original 80-unit PACS study had"):
            block=""
        elif block.startswith("We verified equivalence on nonsaturated"):
            block="We checked nonsaturated equivalence, binary-class temperature invariance, and extreme logits against an independent 400-digit arithmetic reference. We compare subtractive float32 scores, stable scores at float32-selected parameters, and stable scores with validation selection repeated. Saved logits and model states remain unchanged; subsequent tables use the final representation unless specified."
        elif block.startswith("These intervals describe how"):
            block="The ranges measure fixed-model test-image sensitivity; their scope is defined in Section~\\ref{sec:limits}."
        elif block.startswith("The original submitted ZIP"):
            block="Data-role manifests, model states, validation/test logits and artifact hashes accompany the analyses. The official CIFAR-10 archive is checked against its published MD5. The environment uses Python 3.10.19, PyTorch 1.13.1+cu116, NumPy 1.26.4 and an NVIDIA RTX 2060."
        elif block.startswith("Code, full per-unit tables"):
            block="The supplementary material contains code, per-unit tables, numerical fixtures, role assignments and auxiliary diagnostics. Equation~(\\ref{eq:stable}) defines the stable score explicitly."
        elif block.startswith("Finally, numerical stabilization"):
            block="Numerical stabilization is an established mathematical technique, not a new detector. Some sensitivity analyses were specified after target results had been inspected and are not prospective confirmations."
        elif block.startswith("OpenAI Codex~"):
            block="OpenAI Codex~\\cite{codex} assisted with code inspection, experiment and analysis scripts, numerical checks, figures, and English drafting and revision. Results were obtained by executing the documented procedures on saved or newly trained models. The authors are responsible for the data, interpretation and final manuscript."
        block=block.replace("The expansion is a post-review sensitivity analysis, not a target-selected replacement grid.","The expanded grid is evaluated as a fixed alternative range.")
        block=block.replace("This evidence motivates replacing the original ``posterior calibration'' terminology with detection-score selection throughout the contribution statement.","These results support detection-score selection, not probability calibration.")
        block=block.replace("not selected retrospectively using target outcomes","without target-based policy selection")
        block=block.replace("original float32","subtractive float32").replace("Original and stable observations","Float32 and stable observations")
        block=block.replace("original selected parameters","float32-selected parameters").replace("original parameters","float32-selected parameters")
        block=block.replace("original choices","float32-selected choices").replace("original low-temperature","low-temperature")
        block=block.replace("The original grid","The reference grid").replace("Original-grid","Reference-grid").replace("original upper search bound","reference upper search bound")
        if block!=old:moved.append(dict(before=old,after=block))
        if block:revised.append(block)
    text="\n\n".join(revised)+"\n"
    (ROOT/"reports/A1_moved_provenance.json").write_text(json.dumps(moved,indent=2),encoding="utf-8")
    # The original wording remains available for the response, never as manuscript prose.
    p.write_text(text,encoding="ascii")
    a1_bad=re.findall(r"\b(?:original|earlier|post-review|retrospective|submission)\b",text,re.I)
    (ROOT/"evidence/A1.json").write_text(json.dumps(dict(task="A1",remaining_history_tokens=a1_bad,moved_blocks=len(moved)),indent=2),encoding="utf-8")
    for q in (ROOT/"source").rglob("*.tex"):
        if q.name=="response_to_reviewers.tex":continue
        s=q.read_text(encoding="ascii")
        for before,after in [("calibration unknown categories","validation unknown categories"),("calibration-unknown","validation-unknown"),
            ("calibration/target","validation/target"),("calibration categories","validation categories"),
            ("calibration data","validation data"),("calibration inputs","validation inputs"),
            ("deployment calibration population","deployment validation population"),
            ("original grid","reference grid"),("Original grid","Reference grid"),("Original float32","Subtractive float32")]:s=s.replace(before,after)
        q.write_text(s,encoding="ascii")
    (ROOT/"evidence/A3.json").write_text(json.dumps(dict(task="A3",validation_terminology_applied=True,
        figure_redraw_required=True,probability_calibration_reserved_for_probability_metrics=True),indent=2),encoding="utf-8")
    print("A1 targeted provenance removal and A3 terminology edits complete; figures/tables await regeneration.")


if __name__=="__main__":main()
