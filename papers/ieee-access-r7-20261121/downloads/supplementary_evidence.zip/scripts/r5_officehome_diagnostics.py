"""Extend the fixed retrospective diagnostics to all60 Office-Home units."""
from collections import defaultdict
from pathlib import Path
import sys
import numpy as np
from gap_closure_core import ROOT, read, sha, write, grouped_means
from r5_independent_audit_helpers import scores,combine,roc,check
import r5_search_utility as e1
import r5_transfer_tradeoffs as e2
import r5_content_dependence as e3

TASKS={"E1":"E5_search_utility", "E2":"E5_transfer_tradeoffs", "E3":"E5_content_dependence"}
CACHE=ROOT/"evidence/officehome_full_diagnostic_cache"
RUNS={}
CANONICAL=[]


def office_units():
    for uid,(directory,methods) in sorted(RUNS.items()):
        yield "ViT-B32","officehome",uid,directory,methods


def output(task,value):
    name=TASKS[task]
    value.update(task=name,source_analysis=task,scope="All60 Office-Home v3 units,3seeds; do not pool with primary panels or treat overlapping roles/seeds as IID.",
        audit_sha256=sha(ROOT/"evidence/E5_officehome_full_audit.json"),
        prespec_sha256=sha(ROOT/"prespec/E5_complete_diagnostics.json"),
        no_training=True,no_encoder_inference=True,no_target_retuning=True,prospective_confirmation=False)
    write(ROOT/"evidence"/(name+".json"),value,exclusive=True)
    print(name+" complete",flush=True)


def prepare():
    spec_path=ROOT/"prespec/E5_complete_diagnostics.json";spec=read(spec_path)
    assert sha(spec_path)==read(spec_path.with_name("E5_complete_diagnostics_seal.json"))["sha256"]
    for path,digest in spec["code_hashes"].items():assert sha(path)==digest,path
    audited=read(ROOT/"evidence/E5_officehome_full_audit.json")
    assert audited["all_checks_pass"] and audited["n"]==60 and len(audited["records"])==420
    grouped=defaultdict(dict)
    for r in audited["records"]:grouped[r["unit"]][r["method"]]=r
    CACHE.mkdir(exist_ok=True)
    for trace in audited["units"]:
        uid=trace["unit"];directory=Path(trace["directory"]);methods=grouped[uid]
        assert sha(directory/"artifact_hashes.json")==trace["artifact_hashes_sha256"]
        for name,digest in trace["files"].items():assert sha(directory/name)==digest,(uid,name)
        with np.load(directory/"logits.npz",allow_pickle=False) as z:a={k:z[k] for k in z.files}
        vy=np.r_[np.zeros(len(a["ka"]),dtype=int),np.ones(len(a["ua"]),dtype=int)]
        arrays=dict(target_labels=a["ty"],adapter_predictions=a["ta"].argmax(1),validation_labels=vy)
        for name in ["MSP","Temp-MSP","Energy-T-tuned","autoMixTemp"]:
            old=methods[name];sel=old["selection"];energy=name=="Energy-T-tuned"
            st=scores(combine(a["tz"],a["ta"],sel),sel["T_score"],energy)
            sv=np.r_[scores(combine(a["kz"],a["ka"],sel),sel["T_score"],energy),
                     scores(combine(a["uz"],a["ua"],sel),sel["T_score"],energy)]
            check(roc(st,(a["ty"]<0).astype(int))["auroc"],old["auroc"],(uid,name,"auroc"))
            arrays[name]=st;arrays[name+"_validation"]=sv
            CANONICAL.append(dict(model="ViT-B32",dataset="officehome",unit=uid,**{k:old[k] for k in ["method","selection","auroc","fpr95"]}))
        cache=CACHE/(uid+".npz");assert not cache.exists(),cache
        np.savez_compressed(cache,**arrays)
        RUNS[uid]=(directory,methods)
    write(ROOT/"evidence/E5_complete_diagnostics_inputs.json",dict(records=CANONICAL,
        caches=[dict(unit=uid,sha256=sha(CACHE/(uid+".npz"))) for uid in sorted(RUNS)],
        audit_sha256=sha(ROOT/"evidence/E5_officehome_full_audit.json"),
        spec_sha256=sha(spec_path)),exclusive=True)


def main():
    prepare()
    original_read=e1.read
    e1.read=lambda p:dict(records=CANONICAL) if Path(p)==ROOT/"evidence/E0_precision.json" else original_read(p)
    e1.units=lambda:iter(())
    def save_search(_name,value):
        old=original_read(ROOT/"evidence/E1_search_utility.json")
        value["timing_records"]=[];value["timing_summary"]=[]
        value["timing_scope"]="No new timing repeated. See separately archived E1_search_utility.json for nine fixed primary/seed0 domain units, warmup and3repeats. Newseed outcomes do not become new timing observations."
        value["existing_timing_evidence_sha256"]=sha(ROOT/"evidence/E1_search_utility.json")
        assert len(old["timing_summary"])==9
        output("E1",value)
    e1.save=save_search;e1.main()
    e2.units=office_units;e2.cache_path=lambda _m,_d,u:CACHE/(u+".npz")
    e2.save=lambda _name,value:output("E2",value);e2.main()
    e3.units=office_units;e3.cache_path=lambda _m,_d,u:CACHE/(u+".npz")
    e3.ROOT=ROOT/"new_runs/officehome_diagnostics"
    e3.save=lambda _name,value:output("E3",value);e3.main()


if __name__=="__main__":main()
