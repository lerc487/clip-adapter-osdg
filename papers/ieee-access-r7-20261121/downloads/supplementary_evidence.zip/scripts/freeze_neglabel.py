"""Seal the lightweight port before numerical tests or new model inference."""
import hashlib
import json
from pathlib import Path
from datetime import datetime,timezone

ROOT=Path(__file__).resolve().parents[1]


def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    manifest=json.loads((ROOT/"evidence/NegLabel_official_source_manifest.json").read_text())
    spec=dict(task="C2_NegLabel",created_utc=datetime.now(timezone.utc).isoformat(),authorized=True,
        official_repository="https://github.com/tmlr-group/NegLabel",official_commit=manifest["commit"],
        port="User-authorized lightweight port of official negative-label selection and grouping score using our open_clip feature pipeline, not MMClassification and not a reproduction of published numbers.",
        vocabulary="Pinned official txtfiles WordNet lists, files in sorted path order, line-order first-occurrence dedup globally, noun and adjective prompts collected separately; no benchmark result inspected to choose vocabulary.",
        variants=["standard full official WordNet pool","benchmark-name-token-excluded pool before label selection"],
        excluded_names=["dog","elephant","giraffe","guitar","horse","house","person","airplane","automobile","bird","cat","deer","frog","ship","truck"],
        exclusion_rule="Normalize underscores/hyphens to spaces, casefold and tokenize ASCII letters; exclude entries containing an entire benchmark name token/phrase, not arbitrary substrings. This is literal-name exclusion, not a semantic-synonym leakage guarantee. Same fixed PACS/CIFAR union applied to both datasets.",
        positive_prompt="the nice {}",noun_prompt="the nice {}",adjective_prompt="This is a {} photo",
        prompt_origin="Official custom_config/clip.py uses prompt index85; read literal prompt_templates[85] from pinned class_names.py before inference.",
        encoder="ViT-B/32 openai through existing open_clip, unadapted normalized image/text features; cosine logits multiplied by100, t=1, hence cosine-temperature.01. No tuned detector temperature or adapter retraining.",
        negative_selection="Official quantile.95 similarities against current known positive labels; retain lowest15 percent within nouns and adjectives separately, floor counts; selection uses positive text only, never unknown target labels or images.",
        grouping="100 groups; drop remainder before shuffle; seed0 CUDA permutation matching official function, same fixed index order each batch; mean known probability. Group fuse None. Stable float64 log-odds of mean unknown/known probabilities for detection ranking; numerical transform checked against official probability.",
        evaluation="Exactly the saved known/validation-unknown/target sample manifests of PACS84 and CIFAR15 primary ViT-B/32 units. Independent vocabulary selection by known class roles. Validate threshold at unknown recall.95, report target AUROC,FPR@95,frozen unknown recall,known rejection for both variants and all units. Equal-unit means separately, no IID inference or deployment guarantee.",
        information_budget="External WordNet negative-label vocabulary is an additional information budget. Benchmark-name-excluded variant is a leakage sensitivity, not a claim all pretraining or semantic leakage is absent.",
        alignment="Before model inference, deterministic synthetic CPU same-input checks of AST-extracted unmodified official selection block and grouping function. At GPU slot additionally test official random_permute=True against the same CUDA permutation. Store maximum errors and source hashes; stop if alignment fails.",
        tolerances={"selected_features":"exact equal tensor and count","id_group_probability":{"atol":1e-7,"rtol":1e-6},"stable_transform_probability":{"atol":5e-7,"rtol":5e-6}},
        scheduling="No GPU before C3b and Office-Home authorized pilot; currently only vocabulary download and CPU function alignment. No silent skip ahead in queue.",
        reporting="All outcomes retained. Scope is official-function-aligned port on matched samples; no claim of entire official pipeline or published score reproduction.",
        frozen_implementation_hashes={"scripts/"+n:sha(ROOT/"scripts"/n) for n in ["neglabel_core.py","neglabel_alignment.py"]},
        downloaded_source_manifest_sha256=sha(ROOT/"evidence/NegLabel_official_source_manifest.json"))
    p=ROOT/"prespec/C2_NegLabel.json"
    with p.open("x",encoding="utf-8") as f:json.dump(spec,f,indent=2)
    with (ROOT/"prespec/C2_NegLabel_seal.json").open("x",encoding="utf-8") as f:json.dump(dict(task="C2_NegLabel",sha256=sha(p),frozen_before_alignment_and_inference=True),f,indent=2)
    print("NegLabel port design sealed before CPU alignment or model inference.")


if __name__=="__main__":main()
