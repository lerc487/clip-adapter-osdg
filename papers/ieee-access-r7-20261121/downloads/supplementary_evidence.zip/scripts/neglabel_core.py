"""Official-reference NegLabel operations without MMClassification imports."""
import torch


def select_negative_features(positive,negative,noun_length,retain=.15,quantile=.95,batch=1000):
    positive=positive.float();negative=negative.float()
    distances=torch.cat([torch.quantile(negative[i:i+batch]@positive.T,q=quantile,dim=-1)
        for i in range(0,len(negative),batch)])
    noun_index=torch.argsort(distances[:noun_length])[:int(noun_length*retain)]
    adjective_index=torch.argsort(distances[noun_length:])[:int((len(negative)-noun_length)*retain)]+noun_length
    indices=torch.cat([noun_index,adjective_index])
    return negative[indices],indices,int(noun_length*retain)


def grouped_id_score(positive_similarity,negative_similarity,groups=100,temperature=1.,permutation=None):
    drop=negative_similarity.shape[1]%groups
    neg=negative_similarity[:,:-drop] if drop else negative_similarity
    if permutation is not None:neg=neg[:,permutation]
    neg=neg.reshape(len(neg),groups,-1)
    scores=[]
    for i in range(groups):
        full=torch.cat([positive_similarity,neg[:,i,:]],dim=-1)/temperature
        scores.append(full.softmax(-1)[:,:positive_similarity.shape[1]].sum(-1))
    return torch.stack(scores,dim=-1).mean(-1)


def stable_unknown_logodds(positive_similarity,negative_similarity,groups=100,temperature=1.,permutation=None):
    pos=positive_similarity.double()/temperature
    neg=negative_similarity.double()/temperature
    drop=neg.shape[1]%groups
    if drop:neg=neg[:,:-drop]
    if permutation is not None:neg=neg[:,permutation]
    neg=neg.reshape(len(neg),groups,-1)
    lp=torch.logsumexp(pos,dim=-1).unsqueeze(1)
    ln=torch.logsumexp(neg,dim=-1)
    normalizer=torch.logaddexp(lp,ln)
    return torch.logsumexp(ln-normalizer,dim=1)-torch.logsumexp(lp-normalizer,dim=1)
