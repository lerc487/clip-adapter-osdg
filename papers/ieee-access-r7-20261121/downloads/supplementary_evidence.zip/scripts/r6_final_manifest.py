"""Remove inherited packaging receipts, then verify and seal current outputs."""
from pathlib import Path
from zipfile import ZipFile, ZIP_DEFLATED
import csv
import hashlib
import io
import json
import subprocess
import sys
import r6_package

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "final_review_20261120"
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
def read(path): return json.loads(Path(path).read_text(encoding="utf-8"))
def write(path, value): Path(path).write_text(json.dumps(value,indent=2,ensure_ascii=False),encoding="utf-8")
r6_package.notes()
path = OUT / "supplementary_evidence.zip"
blocked = {"content_manifest.json", "evidence/E15_supplementary_archive_checks.json", "evidence/E16_final_author_review_package.json"}
with ZipFile(io.BytesIO(path.read_bytes())) as old:
    entries = [(name,old.read(name)) for name in old.namelist() if name not in blocked]
manifest = [dict(path=name,sha256=hashlib.sha256(data).hexdigest(),bytes=len(data)) for name,data in entries]
with ZipFile(path,"w",ZIP_DEFLATED) as z:
    for name,data in entries: z.writestr(name,data)
    z.writestr("content_manifest.json",json.dumps(manifest,indent=2))
work = ROOT / "new_runs/F10_public_archive_check"
work.mkdir(exist_ok=False)
with ZipFile(path) as z:
    assert z.testzip() is None
    for name in z.namelist(): assert (work/name).resolve().is_relative_to(work.resolve())
    z.extractall(work)
    inventory = [dict(path=name,bytes=len(z.read(name)),sha256=hashlib.sha256(z.read(name)).hexdigest()) for name in sorted(z.namelist())]
for row in manifest: assert sha(work/row["path"])==row["sha256"]
with (ROOT/"logs/F10_public_archive_verification.txt").open("w",encoding="utf-8") as log:
    subprocess.run([sys.executable,"-X","utf8","-B",str(work/"scripts/verify_final_package.py")],cwd=work,stdout=log,stderr=subprocess.STDOUT,check=True)
with (OUT/"ZIP_FILE_LIST.csv").open("w",newline="",encoding="utf-8-sig") as f:
    w=csv.DictWriter(f,["path","bytes","sha256"]);w.writeheader();w.writerows(inventory)
coverage = read(ROOT/"evidence/F8_supplementary_coverage.json")
coverage.update(archive_sha256=sha(path),files=len(inventory),stale_packaging_receipts_excluded=sorted(blocked-{"content_manifest.json"}))
write(ROOT/"evidence/F8_supplementary_coverage.json",coverage)
audit = read(ROOT/"evidence/E15_supplementary_archive_checks.json")
audit.update(zip_sha256=sha(path),archive_files=len(inventory),all_extracted_file_hashes_verified=True,portable_numeric_verification_pass=True)
write(ROOT/"evidence/E15_supplementary_archive_checks.json",audit)
receipt = read(OUT/"final_package_checks.json")
receipt.update(supplementary_archive=audit,supplementary_coverage=coverage)
receipt["files"]=[dict(path=p.name,bytes=p.stat().st_size,sha256=sha(p)) for p in sorted(OUT.iterdir()) if p.is_file() and p.name not in {"SHA256SUMS.txt","final_package_checks.json"}]
for dest in [OUT/"final_package_checks.json",ROOT/"evidence/F9_editorial_delivery.json",ROOT/"evidence/E16_final_author_review_package.json"]:write(dest,receipt)
(OUT/"SHA256SUMS.txt").write_text("\n".join(sha(p)+"  "+p.name for p in sorted(OUT.iterdir()) if p.is_file() and p.name!="SHA256SUMS.txt")+"\n",encoding="ascii")
(ROOT/"CURRENT_AUTHOR_REVIEW.md").write_text("# Current R6 author-review package\n\nUse final_review_20261120/. All scoped editorial changes and checks are complete. Main and highlighted manuscripts are 14 pages, supplement 14 pages and response 10 pages. No new experiments or modified research outcomes. Author approval of the AI-use statement and final submission remains pending. R5 is unchanged.\n",encoding="utf-8")
print("Current ZIP verified after removing inherited packaging receipts; final hashes refreshed.")
