"""Create a separate revision and seal task designs before any new analysis."""
import hashlib
import json
from pathlib import Path
import shutil
from datetime import datetime, timezone

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    for name in ["source", "evidence", "prespec", "reports", "logs", "deliverables", "vendor_review"]:
        (ROOT / name).mkdir(exist_ok=True)
    prior = BASE / "06_manuscript/revision_20261118/source"
    if not (ROOT / "evidence/input_manifest.json").exists():
        shutil.copytree(prior, ROOT / "source", dirs_exist_ok=True)
        protected = list(prior.rglob("*"))
        protected += list((BASE / "00_submitted_baseline").rglob("*"))
        for directory in [BASE / "05_new_runs", BASE / "02_historical/pacs_same_checkpoint_20260919/runs"]:
            protected += [p for p in directory.rglob("*") if p.suffix in [".npz", ".npy", ".pt"]
                          and "paused_attempts" not in p.parts]
        manifest = [{"path": str(p), "bytes": p.stat().st_size, "sha256": sha(p)}
                    for p in sorted(set(protected)) if p.is_file()]
        (ROOT / "evidence/input_manifest.json").write_text(json.dumps(manifest, indent=2), encoding="utf-8")
    common = dict(created_utc=datetime.now(timezone.utc).isoformat(),
        historical_target_access="Previous target outcomes have already been inspected. These are frozen retrospective sensitivity designs, not prospective confirmations.",
        inputs="Read-only saved logits and parameters from 99 primary ViT-B/32 units and 33 RN50 units; historical 80 units only for B7.",
        arithmetic="Float64 stable log-odds MSP; exact threshold-realizable FPR@95; unknown=positive; equal unit weights within each dataset/backbone.",
        no_target_tuning=True, report_all_variants=True,
        uncertainty="No IID significance or population/deployment guarantee; no correlation p-values.")
    designs = {
        "B1": dict(panels=["ViT-B/32 PACS84", "ViT-B/32 CIFAR15", "RN50 PACS28", "RN50 CIFAR5"],
            type="adapter / zeroshot / strictly interior logit interpolation", deltas="auto minus Temp-MSP AUROC/FPR; validation gain = Temp validation FPR minus auto validation FPR",
            thresholds=[0, .01], gate="Use the validation-selected auto candidate only if its FPR gain is strictly greater than delta; otherwise use Temp-MSP. Also report a strict-interior-only gate. No target-based policy choice.",
            metrics=["per-unit paired deltas", "type means and lower/higher/exact-tie counts", "Spearman validation gain versus target gain"],
            interpretation="No application setting is established unless the validation-gated rule offers favorable target changes without hiding negative panels. Associations are descriptive only."),
        "B2": dict(recall_targets=[.90,.95,.975,.99], methods=["MSP","Temp-MSP","autoMixTemp","Energy-T-tuned"],
            policies=["pooled validation unknown recall", "minimum per-unknown-class threshold (most stringent rejection threshold)"],
            metrics=["target unknown recall", "known false rejection", "accepted known accuracy using fixed adapter classifier", "accepted unknown contamination", "recall minus requested recall", "gap q0 q25 q50 q75 q100 and negative fraction"],
            explanation="Two validation unknown classes differ from target unknown classes; no exchangeability or guarantee assumed."),
        "B3": dict(known_nll_temperature=dict(optimizer="bounded scalar minimization of known-validation NLL over log T",bounds=[.01,1000],xatol=1e-8, maxiter=500, failure="Stop/report failed optimizer; do not switch silently"),
            metrics=["15 equal-width confidence-bin ECE", "known NLL", "multiclass Brier sum", "known-sample risk coverage and AURC", "B2 accepted accuracy and unknown contamination"],
            aurc="Order known target examples by increasing unknown score; include whole equal-score groups, right-continuous risk integral sum(delta coverage * cumulative classification error). Fixed adapter classifier for all methods."),
        "B4": dict(temperatures=[100,1000,10000,1000000], limit="mean logits minus maximum logit; greater is more unknown",
            ranks="Per-unit Spearman and Kendall tau-b versus T1000 adapter-MSP scores; also compare limit. No p-values.",
            dense_grid=dict(start=.1,stop=10000,points=61,spacing="log10"),methods=["Temp-MSP","autoMixTemp"],
            selection="Validation FPR95, then higher validation AUROC, then deterministic adapter/zero/alpha order and ascending T; report all target results and endpoint counts.",
            interpretation="Report large-T convergence/rank results without asserting an optimal or stable temperature; do not select grids on target performance."),
        "B5": dict(scope="Primary PACS stable panel; fixed target-domain x role-rotation clusters average three seeds",
            features=["baseline MSP target FPR95", "known target mean max-softmax confidence at T1", "validation minus target baseline AUROC", "known target baseline NLL"],
            diagnostics="Recompute all 28 stable cells and original float32 R4 art_painting/sketch units; record original parameters, number of zero scores, realized ROC boundary group composition and stable scores at same parameters.",
            statistics="Spearman across 28 cluster means, without p-values; additionally retain within-domain exploratory associations and all per-unit values; no causal claims."),
        "B6": dict(panels="Primary ViT-B/32 only; PACS 28 clusters, CIFAR10 5 clusters; average three seeds within target-domain x class-role clusters",
            comparators=["autoMixTemp minus MSP","autoMixTemp minus Temp-MSP"],metrics=["AUROC","FPR95"],
            summaries=["cluster means", "lower/higher/exact-tie counts", "leave-one-cluster-out range"],
            pacs_cluster_bootstrap=dict(draws=10000,seed=2026111806,scheme="sample 28 fixed clusters with replacement"),
            pacs_joint=dict(draws=10000,seed=2026111807,scheme="independent cluster resampling plus one Poisson1 image-content-hash weight shared by all test appearances; recompute all test ROC thresholds; models/validation decisions frozen",batch=32),
            cifar="Only counts and leave-one-cluster-out ranges; no interval", intervals="central 95% conditional sensitivity ranges, not inferential CIs"),
        "B7": dict(scope="Historical 80 units only; response and supplement, never main text", methods=["MSP","Temp-MSP","autoMixTemp"],
            variants=["original recorded float32", "stable at original parameters", "stable with same original validation grid reselected"],
            metrics=["AUROC","FPR95","boundary ties"],preserve_all_original_files=True),
        "C0_C2": dict(action="Feasibility and official-code inspection only; do not train or execute new detection inference until user confirmation",
            local_data_check=["Office-Home","VLCS","DomainNet"],
            timing="Observed existing per-unit elapsed times and measured GPU properties only; any projected time must be explicitly derived, not claimed as measured for an unrun method.",
            neglabel="Official standard external negative vocabulary and complete PACS/CIFAR category-name exclusion variant, if implementation/data available. Do not substitute an approximate method.",
            locoop="Official implementation dependency and sample-role adaptation feasibility, not a surrogate implementation."),
        "C3a": dict(scope="Cached results only; four matching PACS rotation00 seed0 units", comparison="Primary NLL-stopped trajectory versus full20 trajectory, paired by exact target/known/unknown roles", methods=["autoMixTemp","Energy-T-tuned","Energy-only-T1"],
            inference="Separate subset composition from trajectory/checkpoint effects; do not compare four-unit means to the 84-unit mean as if the estimand were identical.")}
    sealed = {}
    for name, design in designs.items():
        p = ROOT / "prespec" / (name + ".json")
        if not p.exists():
            p.write_text(json.dumps(dict(task=name,**common,design=design),indent=2),encoding="utf-8")
        sealed[name] = sha(p)
    seal = ROOT / "prespec/sealed_hashes.json"
    if seal.exists():
        assert json.loads(seal.read_text()) == sealed
    else:
        seal.write_text(json.dumps(sealed,indent=2),encoding="ascii")
    print("New revision isolated; immutable inputs recorded and task specifications sealed.",flush=True)


if __name__ == "__main__":
    main()
