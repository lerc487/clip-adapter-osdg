"""Keep the added numerical explanations concise without removing requested facts."""
from pathlib import Path
import json
import re
ROOT = Path(__file__).resolve().parents[1]
registry = json.loads((ROOT / "evidence/number_registry.json").read_text(encoding="utf-8"))
changes = json.loads((ROOT / "evidence/F3_editorial_change_records.json").read_text(encoding="utf-8"))
def macro(key):
    row = next(r for r in registry if r["file"] == "F1_editorial_verified_values.json" and r["pointer"] == ["values", key])
    return "\\" + row["macro"] + "{}"
path = ROOT / "source/body_revision.tex"
text = path.read_text(encoding="utf-8")
def swap(task, old, new):
    global text
    assert old in text
    text = text.replace(old, new)
    changes.append(dict(task=task, file="source/body_revision.tex", before=old, after=new,
                        evidence="F1_editorial_verified_values.json; scoped prose compression only"))
start = text.index("Source-stratified outcomes are in Table")
stop = text.index(r"\input{tables/usecases}", start)
new = ("Table~\\ref{tab:usecases} uses gain $=$ Temp-MSP minus autoMixTemp FPR@95 (positive favors autoMixTemp); validation/target gain Spearman correlations are \\PACSGainCorr{} (PACS) and \\CIFARGainCorr{} (CIFAR-10). For ViT-B/32, validation gain $>0$ enables " + macro("ViT-B32pacsgatecount") + "/84 PACS and " + macro("ViT-B32cifar10gatecount") + "/15 CIFAR-10 units; target changes (gated minus Temp-MSP) are " + macro("ViT-B32pacsgatedelta") + "/" + macro("ViT-B32cifar10gatedelta") + " (RN50: " + macro("RN50pacsgatedelta") + "/" + macro("RN50cifar10gatedelta") + "). ViT-B/32 interior-only gates enable " + macro("pacsinteriorcount") + "/84 and " + macro("cifar10interiorcount") + "/15 units with changes smaller than 0.001 in magnitude; RN50 does not share this bound. No consistent cross-panel mixing benefit is established (Supplementary Table~S1). ")
swap("A3", text[start:stop], new)
start = text.index(" On the ViT-B/32 ownership subsets")
stop = text.index("(Supplementary Table~S15).", start) + len("(Supplementary Table~S15).")
new = (" ViT-B/32 ownership-subset FPR@95 changes (PACS/CIFAR-10/Office-Home) are " + "/".join(macro(ds+"MSPownership") for ds in ["pacs", "cifar10", "officehome"]) + " against MSP and " + "/".join(macro(ds+"Temp-MSPownership") for ds in ["pacs", "cifar10", "officehome"]) + " against Temp-MSP (Supplementary Table~S15).")
swap("A4", text[start:stop], new)
start = text.index("Both lower- and upper-bound counts appear")
stop = text.index("For high temperature,", start)
swap("A5", text[start:stop], "Table~\\ref{tab:grid} reports both boundary counts: PACS dense-grid lower counts are 18/84 (Temp-MSP) and 17/84 (autoMixTemp). Both endpoints are selected, so temperature stability is not established (Supplementary Table~S5). ")
start = text.index("At actual scanned points,")
stop = text.index("\n\nPre-rejection", start)
def pair(ds, method):
    return macro(ds+method+"unknown_recallscan") + "/" + macro(ds+method+"known_rejectionscan")
new = ("Actual PACS recall/rejection points are " + pair("pacs", "MSP") + " for MSP ($\\rho=0.975$, worst-class) and " + pair("pacs", "autoMixTemp") + " for autoMixTemp ($\\rho=0.99$, pooled): no lower rejection at comparable recall. On CIFAR-10 at pooled $\\rho=0.975$, MSP gives " + pair("cifar10", "MSP") + " versus " + pair("cifar10", "autoMixTemp") + " for autoMixTemp, improving both quantities (Supplementary Tables~S2 and S3). No interpolation is used.")
swap("A6", text[start:stop], new)
path.write_text(text, encoding="utf-8")

# A negated exact zero is still zero; avoid a misleading negative-zero display.
values = json.loads((ROOT / "evidence/F1_editorial_verified_values.json").read_text(encoding="utf-8"))
numeric = (ROOT / "source/numbers_revision2.tex").read_text(encoding="utf-8")
for row in registry:
    if row["file"] == "F1_editorial_verified_values.json" and row["value"] == 0 and row["signed"]:
        old = row["display"]
        row["value"] = 0.0
        row["display"] = "+0.000"
        values["values"][row["pointer"][-1]] = 0.0
        numeric = numeric.replace("\\newcommand{\\" + row["macro"] + "}{" + old + "}", "\\newcommand{\\" + row["macro"] + "}{+0.000}")
(ROOT / "source/numbers_revision2.tex").write_text(numeric, encoding="utf-8")
for filename, data in [("number_registry.json", registry), ("F1_editorial_verified_values.json", values), ("F3_editorial_change_records.json", changes)]:
    (ROOT / "evidence" / filename).write_text(json.dumps(data, indent=2), encoding="utf-8")
print("Only the scoped new explanations compacted; all numbers and requested comparisons retained.")
