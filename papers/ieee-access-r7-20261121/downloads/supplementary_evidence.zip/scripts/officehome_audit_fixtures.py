"""Test the new CPU audit against the already-sealed scoring/metric functions."""
import hashlib
import json
from pathlib import Path
import sys
import numpy as np

ROOT=Path(__file__).resolve().parents[1];RUNS=ROOT.parent/"revision2_20261118"
sys.path.insert(0,str(RUNS/"new_runs/c3b/code"))
sys.path.insert(0,str(RUNS/"scripts"))
from c3b_scoring import score as reference_score,select as reference_select
from verified_metrics import fpr_at_recall,threshold_maxf1
sys.path.insert(0,str(ROOT/"scripts"))
import audit_officehome_complete as audit

def main():
    rng=np.random.default_rng(20261119);rows=[];counts=[]
    for scale in [1.,25.,100.]:
        a={key:(rng.normal(size=(n,35))*scale).astype(np.float32) for key,n in [("ka",41),("kz",41),("ua",23),("uz",23)]}
        for mode in ["msp","energy"]:
            for temperature in [.2,1.,5.]:
                left=audit.score(a["ka"],temperature,mode);right=reference_score(a["ka"],temperature,mode)
                error=float(np.max(np.abs(left-right)));assert error<=1e-10
                rows.append(dict(scale=scale,mode=mode,T=temperature,max_error=error))
        for name,route,mode,tune in audit.VARIANTS:
            actual=audit.select(a,route,mode,tune,[.2,1.,5.],[0.,.25,.5,.75,1.])
            reference=reference_select(route,mode,[.2,1.,5.],a["kz"],a["ka"],a["uz"],a["ua"],tune,.5,[0.,.25,.5,.75,1.],"fpr95")
            for key in ["score_source","alpha","T_score"]:assert actual[key]==reference[key]
            for key in ["val_fpr95","val_auroc"]:assert abs(actual[key]-reference[key])<=1e-12
            counts.append(dict(scale=scale,method=name,selection_matches=True))
    metrics=[]
    for discrete in [False,True]:
        s=rng.normal(size=101)
        if discrete:s=np.round(s,0)
        y=np.r_[np.zeros(61,dtype=int),np.ones(40,dtype=int)]
        fpr,threshold=audit.roc_details(s,y);ref=fpr_at_recall(s,y)
        assert fpr==ref["fpr95"] and threshold==ref["threshold"]
        assert audit.maxf1_threshold(s,y)==threshold_maxf1(s,y)["threshold"]
        metrics.append(dict(rounded_ties=discrete,empirical_roc_and_maxf1_match=True))
    script=ROOT/"scripts/audit_officehome_complete.py"
    result=dict(passed=True,synthetic_only=True,model_inference=False,benchmark_results_not_read=True,
        audit_script_sha256=hashlib.sha256(script.read_bytes()).hexdigest(),score_cases=rows,selection_cases=counts,metric_cases=metrics)
    (ROOT/"evidence/C1_complete_audit_fixture_checks.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    print("Independent score/ROC/selection audit fixtures passed; no partial Office-Home outcome consumed.")

if __name__=="__main__":main()
