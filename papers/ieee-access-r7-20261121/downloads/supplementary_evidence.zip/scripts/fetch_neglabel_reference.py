"""Download pinned official-reference text/function sources, no model inference."""
import hashlib
import json
from pathlib import Path
import time
import urllib.request

ROOT=Path(__file__).resolve().parents[1]
COMMIT="3253db684075b2db47844676eccdfda40d67a573"
BASE="https://raw.githubusercontent.com/tmlr-group/NegLabel/"+COMMIT+"/"


def main():
    tree=json.loads((ROOT/"vendor_review/NegLabel_tree.json").read_text())
    assert tree["sha"]==COMMIT
    paths=[r["path"] for r in tree["tree"] if r["path"].startswith("txtfiles/") and r["path"].endswith(".txt")]
    paths += ["mmcls/models/ood/clip_ood.py","mmcls/models/classifiers/multi_modal.py","mmcls/models/classifiers/class_names.py","custom_config/clip.py","LICENSE"]
    dest=ROOT/"vendor_review/neglabel_pinned";records=[]
    for path in paths:
        p=dest/path;p.parent.mkdir(parents=True,exist_ok=True)
        if not p.exists():
            error=None
            for _ in range(3):
                try:
                    with urllib.request.urlopen(BASE+path,timeout=40) as r:data=r.read()
                    p.write_bytes(data);error=None;break
                except Exception as exc:error=exc;time.sleep(1)
            if error:raise error
        data=p.read_bytes();blob=hashlib.sha1(b"blob "+str(len(data)).encode()+b"\0"+data).hexdigest()
        expected=next((r["sha"] for r in tree["tree"] if r["path"]==path),None)
        assert blob==expected,(path,blob,expected)
        records.append(dict(path=path,bytes=len(data),sha256=hashlib.sha256(data).hexdigest(),git_blob=blob))
        print("PINNED "+path,flush=True)
    (ROOT/"evidence/NegLabel_official_source_manifest.json").write_text(json.dumps(dict(commit=COMMIT,source=BASE,files=records,wordnet_notice_given=True,model_inference=False),indent=2),encoding="utf-8")


if __name__=="__main__":main()
