"""Build readable four-page contact sheets for final PDF visual inspection."""
from pathlib import Path
import re
import subprocess
from PIL import Image, ImageDraw

ROOT=Path(__file__).resolve().parents[1]
for kind in ["main_pages","supp_pages","response_pages","highlight_pages"]:
    files=sorted((ROOT/"logs"/kind).glob("page-*.png"))
    pdf={"main_pages":ROOT/"source/manuscript.pdf","supp_pages":ROOT/"source/supplement.pdf","response_pages":ROOT/"logs/response_render/response.pdf","highlight_pages":ROOT/"source/manuscript_highlighted.pdf"}[kind]
    if not pdf.exists():continue
    count=int(re.search(r"Pages:\s+(\d+)",subprocess.check_output(["pdfinfo",str(pdf)],text=True))[1])
    files=[p for p in files if int(p.stem.split("-")[-1])<=count]
    for start in range(0,len(files),4):
        canvas=Image.new("RGB",(1400,1880),"#d9d9d9")
        draw=ImageDraw.Draw(canvas)
        for index,path in enumerate(files[start:start+4]):
            page=Image.open(path).convert("RGB")
            page.thumbnail((680,900))
            x=(index%2)*700+10;y=(index//2)*940+30
            canvas.paste(page,(x,y));draw.text((x,y-20),path.name,fill="black")
        canvas.save(ROOT/"logs"/(kind+f"_contact_{start//4+1}.png"))
