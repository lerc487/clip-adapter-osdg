"""Render all integrated scientific figures from canonical immutable evidence."""
import importlib.util
from pathlib import Path
import textwrap
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np
from gap_closure_core import ROOT, BASE, read, write, sha

OUT = ROOT / "source/figures"
E7 = read(ROOT / "evidence/E7_final_numeric_evidence.json")


def mapped(path):
    path = Path(path)
    name = path.name
    if name in ["stable_score_audit_20261118.json", "stable.json"]:
        return E7["stable"]
    if name == "stable_diagnostics_20261118.json":
        return E7["diagnostics"]
    if name == "B2.json":
        return read(ROOT / "evidence/E2_transfer_tradeoffs.json")
    if name == "B3.json":
        return read(ROOT / "evidence/E0_probability.json")
    return read(path)


def load_script(path, name):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def save(fig, name):
    fig.savefig(OUT / (name + ".pdf"), bbox_inches="tight", pad_inches=.08)
    fig.savefig(OUT / (name + ".png"), dpi=160, bbox_inches="tight", pad_inches=.08)
    plt.close(fig)


def main():
    code = (ROOT / "scripts/figures_reference.py").read_text(encoding="utf-8")
    code = code.replace(":.2f", ":.3f").replace(":+.1f", ":+.3f").replace("fontsize=6.7", "fontsize=6.0").replace("AutoMixTemp", "autoMixTemp")
    clone = ROOT / "scripts/r5_reference_figures_full64.py"
    clone.write_text(code, encoding="ascii")
    ref = load_script(clone, "full64_reference_figures")
    ref.ROOT = BASE
    ref.OUT = OUT
    ref.read = mapped
    ref.main()
    # Reuse the fixed-policy/risk plotting definitions, substituting only evidence.
    code = (ROOT / "scripts/figures.py").read_text(encoding="utf-8")
    fragment = code[code.index("    policy=read("):code.index("    # Record exact source arrays")]
    namespace = dict(ROOT=ROOT, read=mapped, plt=plt, save=save)
    exec(compile(textwrap.dedent(fragment), "fixed_policy_risk_plots", "exec"), namespace)
    control_code = (ROOT / "scripts/completed_control_figure.py").read_text(encoding="utf-8").replace(":.2f", ":.3f").replace('".2f"', '".3f"')
    clone = ROOT / "scripts/r5_completed_control_full64.py"
    clone.write_text(control_code, encoding="ascii")
    control = load_script(clone, "full64_control_plot")
    control.read = mapped
    control.main()
    data = read(ROOT / "evidence/E8_locoop_matched_summary.json")
    labels = ["MSP", "Temp-MSP", "autoMixTemp", "LoCoOp MCM, 0.1", "LoCoOp GL-MCM, 0.1", "LoCoOp MCM, 0.25", "LoCoOp GL-MCM, 0.25"]
    identities = [("MSP", None), ("Temp-MSP", None), ("autoMixTemp", None), ("MCM_official", .1), ("GLMCM_official", .1), ("MCM_official", .25), ("GLMCM_official", .25)]
    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "pdf.fonttype": 42,
        "axes.spines.top": False, "axes.spines.right": False})
    fig, axes = plt.subplots(2, 2, figsize=(7.2, 4.0), sharey=True, layout="constrained")
    records = []
    for col, ds in enumerate(["pacs", "cifar10"]):
        for row, metric in enumerate(["auroc", "fpr95"]):
            ax = axes[row, col]
            values = []
            for j, (method, coefficient) in enumerate(identities):
                i = next(i for i, r in enumerate(data["summary"]) if (r["dataset"], r["method"], r["lambda_value"]) == (ds, method, coefficient))
                value = 100 * data["summary"][i][metric]
                values.append(value)
                color = "#C06232" if method == "autoMixTemp" else "#28688C" if coefficient is None else "#287C70" if coefficient == .1 else "#826C4E"
                ax.scatter(value, j, s=24, color=color, marker="^" if method == "GLMCM_official" else "o", zorder=3)
                ax.annotate(format(value, ".3f"), (value, j), xytext=(5, 0), textcoords="offset points", va="center", fontsize=6.8, color=color)
                records.append(dict(file="E8_locoop_matched_summary.json", pointer=["summary", i, metric], value=data["summary"][i][metric], display_percent=format(value, ".3f")))
            span = max(max(values) - min(values), 1.)
            ax.set_xlim(min(values) - .12 * span, max(values) + .47 * span)
            ax.set_ylim(6.6, -.6)
            ax.set_yticks(range(7), labels)
            ax.grid(axis="x", alpha=.18)
            ax.set_title(("PACS, n=28" if ds == "pacs" else "CIFAR-10, n=5") + ("  AUROC" if metric == "auroc" else "  FPR@95"), loc="left", fontsize=9)
            ax.set_xlabel("AUROC (%) - higher is better" if metric == "auroc" else "FPR@95 (%) - lower is better")
    fig.get_layout_engine().set(rect=(0, .045, 1, 1))
    fig.text(.02, .005, "Matched seed0 images; LoCoOp uses separate 50-epoch prompt fits. Numbers after LoCoOp labels are lambda.", fontsize=6.8)
    save(fig, "locoop_comparison")
    # Canonical evidence pointers for every data-driven figure family.
    registry = dict(figure_hashes={p.name: sha(p) for p in OUT.glob("*.pdf")},
        figure_sources={
            "protocol": ["E0_precision.json"], "score_comparison": ["E7_final_numeric_evidence.json", "mcm.json", "C2_NegLabel.json"],
            "precision_audit": ["E7_final_numeric_evidence.json"], "threshold_transfer": ["E2_transfer_tradeoffs.json"],
            "reliability": ["E7_final_numeric_evidence.json"], "risk_coverage": ["E0_probability.json"],
            "acceptance_policy": ["E2_transfer_tradeoffs.json"], "role_effects": ["E7_final_numeric_evidence.json", "B5.json"],
            "conditional_sensitivity": ["E7_final_numeric_evidence.json"], "temperature_curves": ["E7_final_numeric_evidence.json"],
            "officehome_comparison": ["E5_officehome_full_audit.json"], "locoop_comparison": ["E8_locoop_matched_summary.json"]},
        policy_risk_records=namespace["used"], loco_op_records=records,
        canonical_evidence_sha256=sha(ROOT / "evidence/E7_final_numeric_evidence.json"),
        vector_pdf=True, all_variants_retained=True, target_based_plot_selection=False)
    for files in registry["figure_sources"].values():
        for filename in files:
            assert (ROOT / "evidence" / filename).is_file(), filename
    write(ROOT / "evidence/E9_final_figure_registry.json", registry)
    print("Integrated vector figures regenerated with full64 probability/risk/conditional evidence and complete LoCoOp panels.")


if __name__ == "__main__":
    main()
