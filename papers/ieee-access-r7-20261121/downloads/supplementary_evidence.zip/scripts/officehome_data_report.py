"""Summarize accepted input metadata, not model results."""
from collections import Counter
import hashlib
import json
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/"new_runs/officehome"


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()


def main():
    acquisition=read(ROOT/"evidence/C1_acquisition.json");assert acquisition["accepted"]
    integrity=read(WORK/"integrity_check.json");plan=read(WORK/"accepted_roles.json")
    assert not integrity["errors"]
    files=integrity["files"];domains=Counter(r["domain"] for r in files)
    cells=Counter((r["domain"],r["category"]) for r in files)
    result=dict(task="C1_data_acceptance",accepted=True,archive_sha256=acquisition["archive_sha256"],
        integrity_json_sha256=sha(WORK/"integrity_check.json"),accepted_roles_sha256=sha(WORK/"accepted_roles.json"),
        image_count=len(files),domain_counts=dict(sorted(domains.items())),category_count=len(plan["classes"]),
        min_images_per_domain_category=min(cells.values()),image_errors=len(integrity["errors"]),
        pilot_ids=plan["pilot"],stage1_planned_units=len(plan["stage1"]),stage2_planned_units=len(plan["stage2"]),
        planned_units_not_executed_results=True,stage1_remaining18_not_authorized=True,stage2_not_authorized=True,
        nominal_per_unit_counts={"training":700,"validation_known":350,"validation_unknown":150},
        no_officehome_model_results=True,official_published_archive_digest=None)
    (ROOT/"evidence/C1_data_acceptance_summary.json").write_text(json.dumps(result,indent=2),encoding="utf-8")
    lines=["# Office Home 官方数据验收与试点准备报告","","## 1 做了什么",
        "按用户授权，从[官方数据页](https://www.hemanthdv.org/officeHomeDataset.html)链接的 Google Drive 下载原始 ZIP；核对服务器字节数、记录本地 SHA256、完成 ZIP CRC、逐图像解码与哈希检查。没有改用镜像、删图或降低采样量。","","## 2 文件和预设",
        "数据根目录：`"+plan["data_root"]+"`。原 ZIP 和下载清单在同级 acquisition 目录；完整图像检查为 new_runs/officehome/integrity_check.json；具体角色与图像清单为 accepted_roles.json。C1_stages、C1_download、C1_acceptance、C1_accepted_roles、C1_pilot 的预设与 SHA256 已封存。","","## 3 实际数据与 JSON 来源",
        "下列数据来自 evidence/C1_data_acceptance_summary.json，完整源记录在其指向的两个哈希绑定清单中。","",
        "| 域 | 图像数 |","| --- | ---: |"]
    lines += ["| "+d+" | "+str(n)+" |" for d,n in result["domain_counts"].items()]
    lines += ["",f"共 {result['image_count']} 张图像，{result['category_count']} 类，单域单类最少 {result['min_images_per_domain_category']} 张；解码错误 {result['image_errors']}。所有预设角色的跨训练/验证/测试相同字节图像检查通过。",
        "","归档 SHA256：`"+result["archive_sha256"]+"`。官方页面未提供独立发布的校验和，不能将本地哈希与 CRC 说成官方密码学认证。",
        "","仅排定两个试点："+"、".join(plan["pilot"])+"。各源域每已知类10张、验证每类10张是固定预算；验证未知仅150张，与 PACS 全样本预算不同。预设清单含阶段2种子仅为事前固定采样，不表示它们已训练或获运行授权。",
        "","## 4 对论文的影响","当前只完成数据验收和角色冻结，还没有 Office-Home 模型结果。它不能作为已完成独立数据集验证写入主表。不得按后续试点结果方向改变阶段。",
        "","## 5 需要用户决定的事","现阶段不需要再次批准两个计时试点。它们将在 C3b 完成后运行，再给出实际耗时；用户根据时间与资源决定是否授权剩余18单元。两个后续种子仍需单独确认。NegLabel 按既定次序在试点之后运行。"]
    (ROOT/"reports/C1_官方下载与数据验收报告.md").write_text("\n".join(lines)+"\n",encoding="utf-8")
    print(json.dumps(result,indent=2))


if __name__=="__main__":main()
