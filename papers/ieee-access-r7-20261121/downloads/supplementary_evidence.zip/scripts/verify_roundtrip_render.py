"""Compare every rendered source-ZIP page with the delivered clean PDF."""
import hashlib
import json
from pathlib import Path
import subprocess
from PIL import Image, ImageChops
from pypdf import PdfReader

ROOT=Path(__file__).resolve().parents[1]
path=ROOT/"evidence/source_roundtrip_checks.json"
data=json.loads(path.read_text(encoding="utf-8"))
work=Path(data["work_dir"])
destination=work/"page_render";destination.mkdir(exist_ok=True)
subprocess.run(["pdftoppm","-r","100","-png",str(work/"manuscript.pdf"),str(destination/"page")],check=True)
rows=[]
for page in sorted(destination.glob("page-*.png")):
    original=ROOT/"logs/main_pages"/page.name
    left=Image.open(original).convert("RGB");right=Image.open(page).convert("RGB")
    assert left.size==right.size and ImageChops.difference(left,right).getbbox() is None,page.name
    rows.append(dict(page=page.name,identical_rendered_pixels=True,pixel_sha256=hashlib.sha256(left.tobytes()).hexdigest()))
expected=len(PdfReader(work/"manuscript.pdf").pages)
assert len(rows)==expected
data["all_page_rendered_pixels_match"]=True
data["render_comparisons"]=rows
path.write_text(json.dumps(data,indent=2),encoding="utf-8")
print(f"Fresh source-ZIP render matches the delivered clean PDF on all {expected} pages.")
