"""Single-GPU queue; all new artifacts stay in revision2 and fail closed."""
import csv
import hashlib
import json
import os
from pathlib import Path
import subprocess
import sys
import time

ROOT=Path(__file__).resolve().parents[1];WORK=ROOT/"new_runs/c3b"


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,x):
    temp=p.with_suffix(".tmp");temp.write_text(json.dumps(x,indent=2,allow_nan=False),encoding="utf-8");temp.replace(p)


def state(stage,**kw):dump(ROOT/"evidence/C3b_progress.json",dict(stage=stage,pid=os.getpid(),updated=time.strftime("%Y-%m-%dT%H:%M:%S"),**kw))


def main():
    spec=read(ROOT/"prespec/C3b.json");seal=read(ROOT/"prespec/C3b_seal.json")
    assert sha(ROOT/"prespec/C3b.json")==seal["sha256"]
    for p,h in spec["frozen_code_hashes"].items():assert sha(ROOT/p)==h,p
    lock=ROOT/"new_runs/GPU_QUEUE.lock"
    with lock.open("x") as f:f.write(str(os.getpid()))
    done=0
    try:
        for unit in spec["units"]:
            uid=unit["unit_id"];out=WORK/"evaluations"/uid
            if (ROOT/"new_runs/PAUSE_REQUESTED").exists():
                state("paused_at_unit_boundary",completed=done,total=28,next_unit=uid);return
            if (out/"completed.json").exists():
                assert sha(out/"results.json")==read(out/"completed.json")["results_sha256"]
                done+=1;continue
            if out.exists():raise RuntimeError(f"Partial evaluation requires inspection: {out}")
            if unit["reuse_readonly"]:
                run=Path(unit["existing_run"])
            else:
                run=WORK/"pacs"/uid
                if not (run/"completed.json").exists():
                    if run.exists():raise RuntimeError(f"Partial training requires inspection: {run}")
                    command=[sys.executable,"-B","-s","-u",str(ROOT/"scripts/c3b_train.py"),
                        "--data_root",spec["data_root"],"--target_domain",unit["target"],"--val_domain",unit["val"],
                        "--unknown_classes",",".join(unit["calibration_unknown"]+unit["target_unknown"]),
                        "--calibration_unknown_classes",",".join(unit["calibration_unknown"]),"--target_unknown_classes",",".join(unit["target_unknown"]),
                        "--seed","0","--model","ViT-B-32","--epochs","20","--early_stop","0","--early_stop_metric","known_nll",
                        "--batch_size","64","--lr","2e-5","--hidden_ratio","0.0625","--max_scale","0.05","--cos_reg","0.2",
                        "--amp","--num_workers","0","--openclip_cache_dir","C:/icip_osr/.cache/clip","--templates",
                        "a photo of a {}|a sketch of a {}|a cartoon of a {}|a painting of a {}"]
                    dump(WORK/"logs"/(uid+"_launch.json"),dict(command=command,unit=unit,prespec_sha256=seal["sha256"]))
                    state("training",completed=done,total=28,current=uid)
                    with (WORK/"logs"/(uid+"_train.log")).open("w",encoding="utf-8") as f:
                        subprocess.run(command,cwd=WORK,env=dict(os.environ,PAPER2_RUN_DIR=str(run),PYTHONDONTWRITEBYTECODE="1"),stdout=f,stderr=subprocess.STDOUT,check=True)
            for name,digest in read(run/"artifact_hashes.json").items():assert sha(run/name)==digest
            state("evaluating_frozen_selectors",completed=done,total=28,current=uid,reusing_readonly_trajectory=unit["reuse_readonly"])
            with (WORK/"logs"/(uid+"_evaluate.log")).open("w",encoding="utf-8") as f:
                subprocess.run([sys.executable,"-B","-s","-u",str(ROOT/"scripts/c3b_evaluate.py"),"--run",str(run),"--out",str(out)],
                    cwd=WORK,env=dict(os.environ,PYTHONDONTWRITEBYTECODE="1"),stdout=f,stderr=subprocess.STDOUT,check=True)
            done+=1
            state("unit_complete",completed=done,total=28,current=uid)
        rows=[]
        for u in spec["units"]:rows += read(WORK/"evaluations"/u["unit_id"]/"results.json")["results"]
        summary=[]
        for selector in spec["selectors"]:
            for method in spec["methods"]:
                rr=[r for r in rows if r["selector"]==selector and r["method"]==method]
                assert len(rr)==28
                summary.append(dict(selector=selector,method=method,n=28,**{k:sum(r[k] for r in rr)/28 for k in ["auroc","fpr95","frozen_unknown_recall","frozen_known_rejection","known_accuracy"]}))
        dump(ROOT/"evidence/C3b.json",dict(task="C3b",prespec_sha256=seal["sha256"],records=rows,summary=summary,
            report_all_variants=True,no_target_selection=True,conditional_descriptive=True))
        with (ROOT/"evidence/C3b_summary.csv").open("w",newline="",encoding="utf-8-sig") as f:
            writer=csv.DictWriter(f,fieldnames=list(summary[0]));writer.writeheader();writer.writerows(summary)
        state("complete_requires_manuscript_integration",completed=done,total=28,new_training_units=24,reused_trajectories=4)
    except Exception as exc:
        state("failed_requires_inspection",completed=done,total=28,error=repr(exc));raise
    finally:lock.unlink(missing_ok=True)


if __name__=="__main__":main()
