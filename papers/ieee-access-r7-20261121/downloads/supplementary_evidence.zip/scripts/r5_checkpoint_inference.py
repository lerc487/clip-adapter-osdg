"""Run only preselected missing snapshots using the unchanged encoder pipeline."""
from datetime import datetime,timezone
import os
from pathlib import Path
import sys
import time
from sklearn.metrics import roc_auc_score
from gap_closure_core import *


def state(stage,done,total,**extra):
    write(ROOT/"evidence/E4_target_progress.json",dict(stage=stage,completed=done,total=total,
        pid=os.getpid(),updated_utc=datetime.now(timezone.utc).isoformat(),**extra))


def main():
    spec_path=ROOT/"prespec/E4_target_inference.json";spec=read(spec_path)
    assert sha(spec_path)==read(ROOT/"prespec/E4_target_inference_seal.json")["sha256"]
    assert read(ROOT/"evidence/R5_authorization_20261119.json")["detector_validation_checkpoint_selection_and_missing_target_inference"]
    assert sha(ROOT/"evidence/E4_full_validation_plan.json")==spec["choices_sha256"]
    for path,digest in spec["code_hashes"].items():assert sha(Path(path))==digest,path
    plan=read(ROOT/"evidence/E4_full_validation_plan.json")
    grouped=defaultdict(list)
    for r in plan["records"]:grouped[(r["dataset"],r["unit"],r["epoch"])].append(r)
    lock=R2/"new_runs/GPU_QUEUE.lock"
    with lock.open("x") as f:f.write(str(os.getpid()))
    model=None;rows=[];snapshots=[];done=0
    try:
        for (ds,unit,epoch),records in sorted(grouped.items()):
            if any((r/"new_runs/PAUSE_REQUESTED").exists() for r in [ROOT,R2]):
                state("paused_at_snapshot_boundary",done,len(grouped),current=unit,epoch=epoch);return
            run=Path(records[0]["run"]);checkpoint=Path(records[0]["checkpoint"])
            assert all(r["checkpoint_sha256"]==sha(checkpoint) for r in records)
            caches={r["existing_target_cache"] for r in records if r["existing_target_cache"]}
            out=ROOT/"new_runs/checkpoint_independent"/ds/unit/f"selected_test_{epoch:02d}.npz"
            if caches:
                path=Path(sorted(caches)[0]);origin="read_only_existing_cache"
            elif out.is_file():
                path=out;origin="resumed_new_cache"
            else:
                import torch
                import open_clip
                from torch.utils.data import DataLoader
                sys.path.insert(0,str(ROOT/"new_runs/c3b/code"))
                from train_disjoint import Adapter,MultiDomainFolder,collect_logits_on_loader
                config=read(run/"config.json")["arguments"]
                if model is None:
                    model,_,transform=open_clip.create_model_and_transforms(config["model"],pretrained=config["pretrained"],cache_dir=config["openclip_cache_dir"])
                    model=model.cuda().eval()
                assert config["model"]=="ViT-B-32"
                samples=read(run/"test_samples.json")
                loader=DataLoader(MultiDomainFolder([(str(Path(config["data_root"])/s["path"]),s["label"]) for s in samples],transform),batch_size=64,num_workers=0,shuffle=False)
                ck=torch.load(checkpoint,map_location="cpu");text=ck["text_features"].cuda()
                adapter=Adapter(text.shape[1],config["hidden_ratio"],config["max_scale"],config["alpha_init"]).cuda()
                adapter.load_state_dict(ck["adapter_state"]);adapter.eval()
                state("target_inference",done,len(grouped),current=unit,epoch=epoch)
                started=time.perf_counter();tz,ta,ty=collect_logits_on_loader(model,adapter,text,loader,"cuda")
                elapsed=time.perf_counter()-started
                out.parent.mkdir(parents=True,exist_ok=True)
                np.savez_compressed(out,tz=tz,ta=ta,ty=ty)
                write(out.with_suffix(".provenance.json"),dict(seconds=elapsed,checkpoint_sha256=sha(checkpoint),choices_sha256=spec["choices_sha256"],
                    target_logits_sha256=sha(out),same_original_collect_logits_function=True),exclusive=True)
                del adapter,text,ck
                path=out;origin="new_frozen_choice_inference"
            with np.load(path,allow_pickle=False) as z:a={k:z[k] for k in z.files}
            samples=read(run/"test_samples.json")
            np.testing.assert_array_equal(a["ty"],[s["label"] for s in samples])
            with np.load(run/f"epoch_checkpoints/validation_{epoch:02d}.npz",allow_pickle=False) as z:v={k:z[k] for k in z.files}
            vy=np.r_[np.zeros(len(v["ka"]),dtype=int),np.ones(len(v["ua"]),dtype=int)]
            ty=a["ty"];y=ty<0;known=~y;pred=a["ta"].argmax(1)
            for r in records:
                sel=r["selection"];mode="energy" if r["method"]=="Energy-T-tuned" else "msp";t=sel["T_score"]
                sv=np.r_[score(branch(v["kz"],v["ka"],sel),t,mode),score(branch(v["uz"],v["ua"],sel),t,mode)]
                assert abs(roc_auc_score(vy,sv)-sel["val_auroc"])<1e-12
                assert abs(fpr_at_recall(sv,vy)["fpr95"]-sel["val_fpr95"])<1e-12
                st=score(branch(a["tz"],a["ta"],sel),t,mode);threshold=fpr_at_recall(sv,vy)["threshold"]
                reject=st>=threshold;accepted_known=known & ~reject
                rows.append(dict(**r,auroc=float(roc_auc_score(y,st)),fpr95=fpr_at_recall(st,y)["fpr95"],
                    recall=float(reject[y].mean()),rejection=float(reject[known].mean()),known_accuracy=float((pred[known]==ty[known]).mean()),
                    accepted_known_accuracy=float((pred[accepted_known]==ty[accepted_known]).mean()) if accepted_known.any() else None,
                    threshold=threshold,target_logits_file=str(path),target_logits_sha256=sha(path),choices_sha256=spec["choices_sha256"]))
            done+=1;snapshots.append(dict(dataset=ds,unit=unit,epoch=epoch,origin=origin,path=str(path),sha256=sha(path)))
            state("snapshot_complete",done,len(grouped),current=unit,epoch=epoch)
        assert len(rows)==264
        summary=grouped_means(rows,["dataset","selector","method"],["auroc","fpr95","recall","rejection","known_accuracy","accepted_known_accuracy"])
        paired=[]
        for r in rows:
            if r["selector"]!="detector_validation_FPR95":continue
            ref=next(x for x in rows if (x["dataset"],x["unit"],x["method"],x["selector"])==(r["dataset"],r["unit"],r["method"],"known_NLL_reference"))
            paired.append(dict(dataset=r["dataset"],unit=r["unit"],method=r["method"],
                own_epoch=r["epoch"],reference_epoch=ref["epoch"],delta_auroc=r["auroc"]-ref["auroc"],delta_fpr95=r["fpr95"]-ref["fpr95"],
                delta_recall=r["recall"]-ref["recall"],delta_rejection=r["rejection"]-ref["rejection"]))
        write(ROOT/"evidence/E4_target_results.json",dict(records=rows,summary=summary,paired_records=paired,
            paired_summary=grouped_means(paired,["dataset","method"],["delta_auroc","delta_fpr95","delta_recall","delta_rejection"]),
            snapshots=snapshots,prespec_sha256=sha(spec_path),choices_sha256=spec["choices_sha256"],
            no_target_selection=True,no_new_training=True,independent_cpu_audit_pending=True),exclusive=True)
        state("complete_requires_independent_audit",done,len(grouped))
    except Exception as exc:
        state("failed_requires_inspection",done,len(grouped),error=repr(exc));raise
    finally:
        assert lock.read_text().strip()==str(os.getpid())
        lock.unlink()


if __name__=="__main__":main()
