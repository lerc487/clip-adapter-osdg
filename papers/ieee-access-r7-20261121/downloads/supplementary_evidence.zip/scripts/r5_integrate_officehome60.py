"""Integrate the audited three-seed panel, without changing experimental choices."""
import hashlib
import json
from pathlib import Path
import re
import shutil
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import numpy as np

ROOT = Path(__file__).resolve().parents[1]
SRC = ROOT / "source"
sys.path.insert(0, str(ROOT / "scripts"))
import integrate_results as I


def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def write(path, value):
    Path(path).write_text(json.dumps(value, indent=2), encoding="utf-8")


def main():
    specpath = ROOT / "prespec/E5_manuscript_integration.json"
    spec = read(specpath)
    assert sha(specpath) == read(specpath.with_name("E5_manuscript_integration_seal.json"))["sha256"]
    assert sha(__file__) == spec["script_sha256"]
    for rel, digest in spec["evidence_sha256"].items():
        assert sha(ROOT / rel) == digest, rel
    audit = read(ROOT / "evidence/E5_officehome_full_audit.json")
    assert audit["all_checks_pass"] and audit["n"] == 60
    assert audit["method_unit_records_verified"] == 420
    backup = ROOT / "new_runs/E5_integration_before"
    backup.mkdir(exist_ok=False)
    inputs = []
    for rel in spec["modified_files"]:
        p = ROOT / rel
        if p.exists():
            q = backup / rel
            q.parent.mkdir(parents=True, exist_ok=True)
            shutil.copy2(p, q)
            inputs.append(dict(path=rel, sha256=sha(p)))
    write(backup / "manifest.json", inputs)

    I.REG = read(ROOT / "evidence/number_registry.json")
    I.MACROS = []
    rows = []
    labels = {"Energy-T-tuned": "Energy, tuned $T$", "Energy-only-T1": "Energy, $T=1$",
              "Mix-alpha0.5-T-tuned": "Mix, $\\alpha=0.5$", "Zero-shot-T-tuned": "Zero-shot, tuned $T$"}
    fields = ["auroc", "fpr95", "frozen_threshold_test_unknown_tpr", "frozen_threshold_test_known_fpr"]
    order = ["MSP", "Temp-MSP", "Energy-only-T1", "Energy-T-tuned", "Mix-alpha0.5-T-tuned", "Zero-shot-T-tuned", "autoMixTemp"]
    for method in order:
        i = next(i for i, r in enumerate(audit["summary"]) if r["method"] == method)
        rows.append([labels.get(method, method)] + [I.n("E5_officehome_full_audit", ("summary", i, k), 3) for k in fields])
    I.table("officehome", "Separate Office-Home panel: four domains, five class-role rotations and three optimization seeds (60 units). All seven prespecified scores are retained. Values are equal-unit fractions. Its sampled data budget differs from the primary panels; means are not pooled. Frozen thresholds target 95\\% validation unknown recall, not guaranteed target recall.",
            r"Method & AUROC & FPR@95 & Target unknown recall & Known rejection", rows, "lrrrr")
    aliases = {"OHUnits": I.n("E5_officehome_full_audit", ("n",), 0),
               "OHUniqueMin": I.n("E5_officehome_full_audit", ("unique_unknown_validation_min",), 0),
               "OHUniqueMax": I.n("E5_officehome_full_audit", ("unique_unknown_validation_max",), 0)}
    for method, prefix in [("autoMixTemp", "OH"), ("Temp-MSP", "OHTempAbs"), ("MSP", "OHMSPAbs")]:
        i = next(i for i, r in enumerate(audit["summary"]) if r["method"] == method)
        for field, tag in zip(fields, ["AUC", "FPR", "Recall", "Reject"]):
            aliases[prefix + tag] = I.n("E5_officehome_full_audit", ("summary", i, field), 3)
    for method, prefix in [("MSP", "OHMSP"), ("Temp-MSP", "OHTemp")]:
        i = next(i for i, r in enumerate(audit["paired_summary"]) if r["comparator"] == method)
        for field, tag in [("delta_auroc", "AUC"), ("delta_fpr95", "FPR")]:
            aliases[prefix + tag] = I.n("E5_officehome_full_audit", ("paired_summary", i, field), 3, sign=True)
    macros = (SRC / "numbers_revision2.tex").read_text()
    for name, value in aliases.items():
        pattern = r"\\newcommand\{\\" + name + r"\}\{[^\n]*\}"
        replacement = "\\newcommand{\\" + name + "}{" + value + "}"
        if re.search(pattern, macros):
            macros = re.sub(pattern, lambda _: replacement, macros)
        else:
            macros += replacement + "\n"
    (SRC / "numbers_revision2.tex").write_text(macros + "\n".join(I.MACROS) + "\n", encoding="ascii")
    write(ROOT / "evidence/number_registry.json", I.REG)

    body = (SRC / "body_revision.tex").read_text()
    body = body.replace("units use seed0 only and the same adapter", "units use seeds 0, 1 and 2 and the same adapter")
    body = body.replace("These seed0 results use a sampled training/validation budget", "These three-seed results use a sampled training/validation budget")
    body = body.replace("including adverse comparisons. This panel broadens dataset coverage without establishing a consistent benefit from interior mixing, multi-seed robustness, or high-recall threshold transfer.",
        "including adverse comparisons. Optimization seeds reuse the frozen image manifests and are not independent dataset samples.")
    body = body.replace("On this panel, Temp-MSP has slightly higher mean AUROC and lower FPR@95 than autoMixTemp. AutoMixTemp's lower transferred known rejection accompanies lower unknown recall, rather than an unconditional improvement at the intended operating point.",
        "AutoMixTemp has slightly better aggregate ROC metrics than Temp-MSP on the full three-seed panel, but its lower known rejection accompanies lower unknown recall (Temp-MSP recall/rejection \\OHTempAbsRecall{}/\\OHTempAbsReject{}). This does not establish an unconditional operating-point improvement or isolate an interior-mixing benefit.")
    body = body.replace("Office-Home has only one optimization seed and a smaller sampled training/validation budget; its results do not estimate retraining or class-population uncertainty.",
        "Office-Home uses three optimization seeds with the same smaller sampled training/validation budget; they do not resample images or estimate class-population uncertainty.")
    body = body.replace("Office-Home also favors Temp-MSP on ROC metrics: autoMixTemp's transferred recall", "Office-Home's small aggregate ROC advantage over Temp-MSP accompanies lower transferred recall; autoMixTemp's recall")
    (SRC / "body_revision.tex").write_text(body, encoding="ascii")
    wrapper = (SRC / "manuscript.tex").read_text()
    wrapper = wrapper.replace("-unit Office-Home seed0 panel", "-unit, three-seed Office-Home panel")
    wrapper = wrapper.replace("Temp-MSP is slightly better on both Office-Home ROC metrics.", "Its slight ROC advantage over Temp-MSP accompanies lower unknown recall.")
    (SRC / "manuscript.tex").write_text(wrapper, encoding="ascii")

    plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 8, "axes.spines.top": False,
                         "axes.spines.right": False, "pdf.fonttype": 42})
    fig, axes = plt.subplots(1, 2, figsize=(7.2, 3.1), sharey=True, layout="constrained")
    registry = []
    names = {m: labels.get(m, m).replace("$", "").replace("\\alpha", "alpha") for m in order}
    for ax, metric in zip(axes, ["auroc", "fpr95"]):
        values = []
        for j, method in enumerate(order):
            i = next(i for i, r in enumerate(audit["summary"]) if r["method"] == method)
            value = 100 * audit["summary"][i][metric]
            values.append(value)
            color = "#C06232" if method == "autoMixTemp" else "#275C6F" if method == "Temp-MSP" else "#647680"
            ax.scatter(value, j, s=28, color=color, zorder=3)
            ax.annotate(format(value, ".3f"), (value, j), xytext=(5, 0), textcoords="offset points", va="center", fontsize=7, color=color)
            registry.append(dict(file="E5_officehome_full_audit.json", pointer=["summary", i, metric], value=value / 100,
                                 display_percent=format(value, ".3f"), source_value=audit["summary"][i][metric]))
        extent = max(max(values) - min(values), 1.)
        ax.set_xlim(min(values) - .15 * extent, max(values) + .43 * extent)
        ax.set_yticks(range(len(order)), [names[m] for m in order])
        ax.set_ylim(len(order) - .4, -.7)
        ax.grid(axis="x", color="#DFE5E8", linewidth=.7)
        ax.set_title("Office-Home  " + ("AUROC" if metric == "auroc" else "FPR@95"), loc="left", fontsize=10, fontweight="bold")
        ax.set_xlabel("AUROC (%)  higher is better" if metric == "auroc" else "FPR@95 (%)  lower is better")
    axes[1].tick_params(labelleft=False)
    fig.get_layout_engine().set(rect=(0, .08, 1, 1))
    fig.text(.02, .015, "4 domains x 5 rotations x 3 seeds; sampled budget; equal-unit descriptive means.", fontsize=7, color="#354C58")
    destination = SRC / "figures/officehome_comparison.pdf"
    fig.savefig(destination, bbox_inches="tight", pad_inches=.07)
    fig.savefig(ROOT / "logs/officehome60_comparison.png", dpi=180, bbox_inches="tight", pad_inches=.07)
    plt.close(fig)
    write(ROOT / "evidence/E5_manuscript_figure_bindings.json", dict(records=registry, figure_sha256=sha(destination), n=60))
    metadata = read(ROOT / "evidence/figure_data_registry.json")
    metadata["officehome_figure_records"] = registry
    metadata["figure_hashes"][destination.name] = sha(destination)
    write(ROOT / "evidence/figure_data_registry.json", metadata)

    # Keep the earlier seed0 archive readable, but do not present it as the full panel.
    supplement = (SRC / "supplement.tex").read_text()
    candidates = [m.start() for m in re.finditer(r"\\section\*\{[^\n]*Office-Home", supplement)]
    if candidates:
        supplement = supplement[:candidates[0]].removesuffix(r"\clearpage")
    else:
        supplement = supplement[:supplement.index(r"\end{document}")]
    supplement += r"\clearpage\input{officehome60_supplement}" + "\n" + r"\end{document}" + "\n"
    (SRC / "supplement.tex").write_text(supplement, encoding="ascii")
    supplement_rows = []
    for i, r in enumerate(audit["seed_summary"]):
        supplement_rows.append([str(r["seed"]), labels.get(r["method"], r["method"])] +
            [I.n("E5_officehome_full_audit", ("seed_summary", i, k), 3) for k in fields])
    # The companion is single-column; tabular rows fit on separate seed pages.
    content = [r"\section*{Office-Home: complete three-seed panel}",
        "All 60 frozen units and seven scores are included. Seed0 runs are reused rather than counted as extra replications. Raw images and earlier manifests are unchanged. Per-domain, per-seed, source-choice, threshold-transfer and unique-content diagnostics accompany this supplement in the JSON/CSV evidence."]
    for seed in [0, 1, 2]:
        content += [r"\subsection*{Optimization seed " + str(seed) + "}", r"\begin{tabular}{lrrrr}\toprule",
            r"Method & AUROC & FPR@95 & Unknown recall & Known rejection\\\midrule"]
        content += [" & ".join(row[1:]) + r"\\" for row in supplement_rows if row[0] == str(seed)]
        content += [r"\bottomrule\end{tabular}\par\medskip"]
    content += ["The full-panel ROC advantage is small, and lower transferred rejection accompanies lower recall. These are finite-panel descriptive comparisons, not IID significance or a deployment guarantee."]
    (SRC / "officehome60_supplement.tex").write_text("\n".join(content) + "\n", encoding="ascii")
    # Append only macros added by the supplementary seed table after the first flush.
    definitions = (SRC / "numbers_revision2.tex").read_text()
    for command in I.MACROS:
        if command not in definitions:
            definitions += command + "\n"
    (SRC / "numbers_revision2.tex").write_text(definitions, encoding="ascii")
    write(ROOT / "evidence/number_registry.json", I.REG)

    header = "| Method | AUROC | FPR@95 | Target recall | Known rejection |\n| --- | --- | --- | --- | --- |\n"
    table = header + "\n".join("| " + " | ".join([r["method"]] + [format(r[k], ".6f") for k in fields]) + " |" for r in audit["summary"])
    report = "# E5：Office-Home完整三种子核验与入稿\n\n"
    report += "## 1. 做了什么\n\n完成原预设60单元、420条方法结果的独立核验；新增40单元与原20单元均保留，无目标结果筛选。补充同口径门控、阈值扫描和内容依赖诊断。\n\n"
    report += "## 2. 文件和章节\n\n更新摘要、Office-Home协议、结果、局限、结论、对应表图及三种子补充表。`E5_officehome_full_audit.json`为数值来源，`E5_manuscript_figure_bindings.json`绑定图中数字；这一步不代表其他章节及最终回复已全部校验。\n\n"
    report += "## 3. 实际数字及JSON来源\n\n" + table + "\n\n来源：`evidence/E5_officehome_full_audit.json`的`summary`。所有均值按单元等权，不合并PACS/CIFAR。\n\n"
    report += "## 4. 有利还是不利\n\n完整面板中autoMixTemp的ROC均值略好于Temp-MSP，与单独seed0的排序不同，须同步纠正旧叙事。但目标召回更低，不能把已知误拒较低解释为无条件部署改善；仍不支持普适混合优势或95%召回保证。\n\n"
    report += "## 5. 需要作者决定的事\n\n无需新增Office-Home训练。LoCoOp批量范围仍待确认；当前仅两个试点，不得冒充完整匹配基线。待checkpoint独立核验及整包一致性检查后，再由作者决定是否提交。\n"
    (ROOT / "reports/E5_完整三种子核验与入稿报告.md").write_text(report, encoding="utf-8")
    write(ROOT / "evidence/E5_manuscript_integration_receipt.json", dict(n=60, rows=420,
        prespec_sha256=sha(specpath), audit_sha256=sha(ROOT / "evidence/E5_officehome_full_audit.json"),
        previous_inputs=inputs, source_pdf_match_verified=False, final_response_completed=False, upload_ready=False))
    print("Office-Home60 integrated; final compile, complete precision reconciliation and response remain gated.")


if __name__ == "__main__":
    main()
