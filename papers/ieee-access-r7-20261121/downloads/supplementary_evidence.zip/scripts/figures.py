"""Evidence-driven reference figures plus the prespecified policy/risk curves."""
import importlib.util
import json
from pathlib import Path
import sys

import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent;OUT=ROOT/"source/figures"
sys.path.insert(0,str(ROOT/"scripts"))
from cache_analyses import read,sha


def save(fig,name):
    fig.savefig(OUT/(name+".pdf"),bbox_inches="tight",pad_inches=.08)
    fig.savefig(OUT/(name+".png"),bbox_inches="tight",pad_inches=.08,dpi=150)
    plt.close(fig)


def main():
    code=(BASE/"tools/build_revision_figures.py").read_text(encoding="utf-8")
    code=code.replace("calibration unknown","validation unknown").replace("Original float32","Float32")
    code=code.replace("original parameters","float32-selected parameters").replace("original upper bound","reference upper bound")
    local=ROOT/"scripts/figures_reference.py";local.write_text(code,encoding="ascii")
    spec=importlib.util.spec_from_file_location("reference_figures",local);module=importlib.util.module_from_spec(spec);spec.loader.exec_module(module)
    module.ROOT=BASE;module.OUT=OUT;module.main()
    policy=read(ROOT/"evidence/B2.json")["summary"]
    risk=read(ROOT/"evidence/B3.json")["risk_coverage"]
    colors={"MSP":"#647680","Temp-MSP":"#28688C","autoMixTemp":"#C06232","Energy-T-tuned":"#287C70"}
    methods=list(colors);rhos=[.9,.95,.975,.99];used=[]
    fig,axs=plt.subplots(1,2,figsize=(7.2,3.5),layout="constrained")
    for ax,ds in zip(axs,["pacs","cifar10"]):
        for method in methods:
            for mode,ls,marker in [("pooled","-","o"),("worst_class","--","^")]:
                rows=sorted([r for r in policy if r["model"]=="ViT-B32" and r["dataset"]==ds and r["method"]==method and r["policy"]==mode],key=lambda r:r["rho"])
                assert [r["rho"] for r in rows]==rhos
                used += [dict(figure="threshold_transfer",**r) for r in rows]
                ax.plot([100*r["known_rejection"] for r in rows],[100*r["unknown_recall"] for r in rows],ls,marker=marker,ms=3,lw=1,color=colors[method])
        ax.axhline(95,color="#8B969D",ls=":",lw=.8)
        ax.set(xlabel="Target known false rejection (%)",ylabel="Target unknown recall (%)",ylim=(35,101))
        ax.set_title("PACS" if ds=="pacs" else "CIFAR-10",loc="left",fontsize=9);ax.grid(alpha=.15)
    handles=[plt.Line2D([],[],color=colors[m],label=m.replace("Energy-T-tuned","Energy tuned")) for m in methods]
    handles += [plt.Line2D([],[],color="#333333",ls="-",marker="o",ms=3,label="Pooled"),plt.Line2D([],[],color="#333333",ls="--",marker="^",ms=3,label="Worst class")]
    fig.legend(handles=handles,loc="upper center",bbox_to_anchor=(.5,1.12),ncol=3,fontsize=7)
    save(fig,"threshold_transfer")
    fig,axs=plt.subplots(1,2,figsize=(7.2,2.8),layout="constrained")
    for ax,ds in zip(axs,["pacs","cifar10"]):
        for method in methods[:3]:
            rows=sorted([r for r in risk if r["model"]=="ViT-B32" and r["dataset"]==ds and r["method"]==method],key=lambda r:r["coverage"])
            used += [dict(figure="risk_coverage",**r) for r in rows]
            ax.plot([100*r["realized_coverage"] for r in rows],[100*r["risk"] for r in rows],label=method,color=colors[method],lw=1.3)
        ax.set(xlabel="Mean known-sample coverage (%)",ylabel="Known classification risk (%)");ax.grid(alpha=.15)
        ax.set_title("PACS" if ds=="pacs" else "CIFAR-10",loc="left",fontsize=9)
    axs[1].legend(fontsize=7);save(fig,"risk_coverage")
    fig,axs=plt.subplots(2,2,figsize=(7.2,5.1),layout="constrained")
    for j,ds in enumerate(["pacs","cifar10"]):
        for i,(field,label) in enumerate([("accepted_known_accuracy","Accepted known accuracy (%)"),("unknown_contamination","Accepted unknown contamination (%)")]):
            ax=axs[i,j]
            for method in methods[:3]:
                for mode,ls in [("pooled","-"),("worst_class","--")]:
                    rows=sorted([r for r in policy if r["model"]=="ViT-B32" and r["dataset"]==ds and r["method"]==method and r["policy"]==mode],key=lambda r:r["rho"])
                    used += [dict(figure="acceptance_policy",field=field,**r) for r in rows]
                    ax.plot([r["rho"] for r in rows],[100*r[field] for r in rows],ls,marker="o",ms=3,color=colors[method],label=method+" "+mode)
            ax.set(xlabel="Requested validation unknown recall",ylabel=label);ax.grid(alpha=.15)
            ax.set_title("PACS" if ds=="pacs" else "CIFAR-10",loc="left",fontsize=9)
    axs[1,1].legend(fontsize=6,loc="best");save(fig,"acceptance_policy")
    # Record exact source arrays and renderer-generated axis values, not screenshots.
    evidence=dict(new_figure_records=used,reference_source_files=["stable.json","diagnostics.json","mcm.json"],
        reference_source_hashes={name:sha(ROOT/"evidence"/name) for name in ["stable.json","diagnostics.json","mcm.json"]},
        figure_hashes={p.name:sha(p) for p in OUT.glob("*.pdf")},
        backend="Matplotlib vector PDF; no experiment values read from images.")
    (ROOT/"evidence/figure_data_registry.json").write_text(json.dumps(evidence,indent=2),encoding="utf-8")
    print("Evidence-driven figures generated, including complete recall policies and known risk coverage.")


if __name__=="__main__":main()
