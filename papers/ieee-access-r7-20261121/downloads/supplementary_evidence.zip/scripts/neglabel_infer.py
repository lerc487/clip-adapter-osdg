"""Matched-sample NegLabel port; refuses GPU use before the ordered stages."""
import argparse
import ast
import hashlib
import json
import os
from pathlib import Path
import re
import sys
import time

ROOT=Path(__file__).resolve().parents[1];BASE=ROOT.parent;WORK=ROOT/"new_runs/neglabel"
sys.path.insert(0,str(ROOT/"new_runs/c3b/code"))
import numpy as np
import torch
from sklearn.metrics import roc_auc_score
from verified_metrics import fpr_at_recall
from neglabel_core import select_negative_features,grouped_id_score,stable_unknown_logodds
from neglabel_alignment import official_functions


def read(p):return json.loads(p.read_text(encoding="utf-8-sig"))
def sha(p):return hashlib.sha256(p.read_bytes()).hexdigest()
def dump(p,obj):
    p.parent.mkdir(parents=True,exist_ok=True)
    temp=p.with_suffix(".tmp");temp.write_text(json.dumps(obj,indent=2,allow_nan=False),encoding="utf-8");temp.replace(p)


def status(stage,**kw):dump(ROOT/"evidence/C2_NegLabel_progress.json",dict(stage=stage,updated=time.strftime("%Y-%m-%dT%H:%M:%S"),**kw))


def vocabulary(spec):
    manifest=read(ROOT/"evidence/NegLabel_official_source_manifest.json")
    words={"noun":[],"adj":[]};seen=set()
    for item in sorted(manifest["files"],key=lambda r:r["path"]):
        if not item["path"].startswith("txtfiles/"):continue
        p=ROOT/"vendor_review/neglabel_pinned"/item["path"];assert sha(p)==item["sha256"]
        kind=p.name.split(".")[0]
        for line in p.read_text().splitlines():
            word=line.strip()
            if word in seen:continue
            seen.add(word);words[kind].append(word)
    noun_length=len(words["noun"]);flat=words["noun"]+words["adj"]
    def allowed(word):
        tokens=re.findall(r"[a-z]+",word.casefold())
        return not any(name in tokens for name in spec["excluded_names"])
    mask=np.array([allowed(w) for w in flat],dtype=bool)
    tree=ast.parse((ROOT/"vendor_review/neglabel_pinned/mmcls/models/classifiers/class_names.py").read_text())
    prompt=ast.literal_eval(next(n.value for n in tree.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=="prompt_templates" for t in n.targets)))[85]
    assert prompt==spec["positive_prompt"]==spec["noun_prompt"]
    return flat,noun_length,mask,[prompt.format(w) if i<noun_length else spec["adjective_prompt"].format(w) for i,w in enumerate(flat)]


def units_and_images():
    units=[];paths=[]
    for ds in ["pacs","cifar10"]:
        for u in read(BASE/f"03_protocol/{ds}_disjoint_plan.json")["units"]:
            d=BASE/"05_new_runs"/ds/u["unit_id"];config=read(d/"config.json")["arguments"]
            roles={k:read(d/(k+"_samples.json")) for k in ["val_known","val_unknown","test"]}
            for rows in roles.values():paths += [str((Path(config["data_root"])/r["path"]).resolve()) for r in rows]
            units.append(dict(dataset=ds,unit=u["unit_id"],directory=str(d),data_root=config["data_root"],known=u["known"],roles=roles))
    paths=sorted(set(paths));assert len(units)==99
    assert all(Path(p).is_file() for p in paths)
    return units,paths


def freeze_execution():
    p=ROOT/"prespec/C2_NegLabel_execution.json"
    code=[ROOT/"scripts"/name for name in ["neglabel_infer.py","neglabel_core.py","neglabel_alignment.py"]]
    spec=dict(task="C2_NegLabel_execution",parent_design_sha256=sha(ROOT/"prespec/C2_NegLabel.json"),
        design="Implements the sealed lightweight-port design without changing scientific parameters. Feature batches64 images,256 texts, CPU float32 caches, official CUDA seed0 permutation. Primary ViT-B/32 only, both vocabularies, all99 saved unit manifests.",
        stage_gate="C3b complete and Office-Home two-unit pilot complete before acquiring shared GPU lock. Missing gate stops, no skipping or CPU image-model fallback.",
        cache_policy="Each cache saved with ordered input manifest and SHA256. Reuse only exact input/hash match; partial or changed cache stops. Original archive is read-only.",
        report_all=True,no_target_tuning=True,
        code_hashes={p.relative_to(ROOT).as_posix():sha(p) for p in code})
    if p.exists():assert read(p)==spec
    else:
        with p.open("x",encoding="utf-8") as f:json.dump(spec,f,indent=2)
        with (ROOT/"prespec/C2_NegLabel_execution_seal.json").open("x",encoding="utf-8") as f:json.dump(dict(task="C2_NegLabel_execution",sha256=sha(p)),f,indent=2)
    return spec


@torch.no_grad()
def encode_texts(model,tokenizer,texts,path):
    signature=hashlib.sha256(json.dumps(texts).encode()).hexdigest();meta=path.with_suffix(".json")
    if path.exists():
        m=read(meta);assert m["input_sha256"]==signature and m["sha256"]==sha(path)
        return torch.from_numpy(np.load(path,allow_pickle=False))
    if meta.exists():raise RuntimeError("Partial text cache")
    chunks=[]
    for i in range(0,len(texts),256):
        z=model.encode_text(tokenizer(texts[i:i+256]).cuda()).float();z=z/z.norm(dim=1,keepdim=True)
        assert torch.isfinite(z).all();chunks.append(z.cpu())
        status("text_features",completed=min(i+256,len(texts)),total=len(texts))
    z=torch.cat(chunks);np.save(path,z.numpy())
    dump(meta,dict(input_sha256=signature,sha256=sha(path),rows=len(z)))
    return z


def cuda_alignment():
    grouping,_=official_functions();torch.manual_seed(2117)
    pos=torch.randn(13,5,device="cuda");neg=torch.randn(13,1203,device="cuda")
    official=grouping(type("Reference",(),dict(t=1.,local_rank="0"))(),pos,neg,None,ngroup=100,random_permute=True)
    torch.manual_seed(0);torch.cuda.manual_seed(0);perm=torch.randperm(1200,device="cuda")
    actual=grouped_id_score(pos,neg,permutation=perm)
    error=float((official-actual).abs().max());assert torch.allclose(official,actual,atol=1e-7,rtol=1e-6)
    dump(ROOT/"evidence/C2_NegLabel_CUDA_alignment.json",dict(passed=True,max_abs_id_score_error=error,
        official_random_permute=True,device=torch.cuda.get_device_name(0),published_pipeline_reproduction=False))


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--prepare-only",action="store_true");args=parser.parse_args()
    execution=freeze_execution();spec=read(ROOT/"prespec/C2_NegLabel.json")
    assert read(ROOT/"evidence/C2_NegLabel_alignment.json")["all_checks_pass"]
    for name,h in execution["code_hashes"].items():assert sha(ROOT/name)==h
    words,noun_length,mask,prompts=vocabulary(spec);units,paths=units_and_images()
    WORK.mkdir(parents=True,exist_ok=True)
    dump(WORK/"frozen_inputs.json",dict(units=[dict(dataset=u["dataset"],unit=u["unit"],known=u["known"]) for u in units],
        wordnet_entries=len(words),noun_entries=noun_length,filtered_entries=int(mask.sum()),
        words_sha256=hashlib.sha256(json.dumps(words).encode()).hexdigest(),image_paths=paths,
        parent_design_sha256=sha(ROOT/"prespec/C2_NegLabel.json"),execution_sha256=sha(ROOT/"prespec/C2_NegLabel_execution.json")))
    if args.prepare_only:
        status("CPU_preparation_complete_waiting_ordered_GPU_slot",units=len(units),image_paths=len(paths),model_inference=False)
        print("NegLabel inputs and execution design prepared; no CUDA calls or image/text model inference.");return
    if read(ROOT/"evidence/C3b_progress.json")["stage"]!="complete_requires_manuscript_integration":raise RuntimeError("C3b must finish first")
    pilot=ROOT/"evidence/C1_pilot_progress.json"
    if not pilot.exists() or read(pilot).get("completed")!=2:raise RuntimeError("Office-Home two-unit timing pilot must finish before NegLabel; no queue skipping")
    lock=ROOT/"new_runs/GPU_QUEUE.lock"
    with lock.open("x") as f:f.write(str(os.getpid()))
    started=time.perf_counter()
    try:
        import open_clip
        from PIL import Image
        cuda_alignment()
        model,_,transform=open_clip.create_model_and_transforms("ViT-B-32",pretrained="openai",cache_dir="C:/icip_osr/.cache/clip")
        model=model.cuda().eval();tokenizer=open_clip.get_tokenizer("ViT-B-32")
        negative=encode_texts(model,tokenizer,prompts,WORK/"wordnet_features.npy")
        positive_cache={}
        for known in sorted({tuple(u["known"]) for u in units}):
            name=hashlib.sha256(json.dumps(known).encode()).hexdigest()[:16]
            positive_cache[known]=encode_texts(model,tokenizer,[spec["positive_prompt"].format(c.replace("_"," ")) for c in known],WORK/("positive_"+name+".npy"))
        image_file=WORK/"image_features.npy";image_meta=WORK/"image_features.json"
        image_signature=hashlib.sha256(json.dumps([(p,sha(Path(p))) for p in paths]).encode()).hexdigest()
        if image_file.exists():
            m=read(image_meta);assert m["input_sha256"]==image_signature and m["sha256"]==sha(image_file)
            images=torch.from_numpy(np.load(image_file,allow_pickle=False))
        else:
            chunks=[]
            with torch.no_grad():
                for i in range(0,len(paths),64):
                    batch=[]
                    for path in paths[i:i+64]:
                        with Image.open(path) as image:batch.append(transform(image.convert("RGB")))
                    z=model.encode_image(torch.stack(batch).cuda()).float();z=z/z.norm(dim=1,keepdim=True)
                    assert torch.isfinite(z).all();chunks.append(z.cpu());status("image_features",completed=min(i+64,len(paths)),total=len(paths))
            images=torch.cat(chunks);np.save(image_file,images.numpy());dump(image_meta,dict(input_sha256=image_signature,sha256=sha(image_file),rows=len(images)))
        del model;torch.cuda.empty_cache();index={p:i for i,p in enumerate(paths)};results=[];selection_cache={}
        for step,u in enumerate(units):
            for variant in ["standard","benchmark_names_excluded"]:
                cache_key=(tuple(u["known"]),variant)
                pos=positive_cache[tuple(u["known"])].cuda()
                if cache_key not in selection_cache:
                    keep=np.ones(len(words),dtype=bool) if variant=="standard" else mask
                    selected,indices,nouns=select_negative_features(pos.cpu(),negative[torch.from_numpy(keep)],int(keep[:noun_length].sum()))
                    count=len(selected)-len(selected)%100
                    assert count>=100
                    torch.manual_seed(0);torch.cuda.manual_seed(0);permutation=torch.randperm(count,device="cuda").cpu()
                    selection_cache[cache_key]=(selected,permutation)
                    identity=hashlib.sha256(json.dumps([u["known"],variant]).encode()).hexdigest()[:16]
                    original=np.flatnonzero(keep)[indices.numpy()]
                    dump(WORK/"selected_labels"/(identity+".json"),dict(known=u["known"],variant=variant,selected_indices=original.tolist(),selected_words=[words[j] for j in original],noun_selected=nouns,permutation=permutation.tolist()))
                neg,perm=selection_cache[cache_key];neg=neg.cuda();perm=perm.cuda();scores={}
                with torch.no_grad():
                    for role,rows in u["roles"].items():
                        ids=[index[str((Path(u["data_root"])/r["path"]).resolve())] for r in rows];batches=[]
                        for i in range(0,len(ids),64):
                            features=images[ids[i:i+64]].cuda();ps=100.*features@pos.T;ns=100.*features@neg.T
                            batches.append(stable_unknown_logodds(ps,ns,permutation=perm).cpu().numpy())
                        scores[role]=np.concatenate(batches)
                validation=np.r_[scores["val_known"],scores["val_unknown"]]
                vy=np.r_[np.zeros(len(scores["val_known"]),dtype=int),np.ones(len(scores["val_unknown"]),dtype=int)]
                threshold=fpr_at_recall(validation,vy)["threshold"]
                labels=np.array([r["label"] for r in u["roles"]["test"]]);y=(labels<0).astype(int);reject=scores["test"]>=threshold
                result=dict(dataset=u["dataset"],unit=u["unit"],method="NegLabel-function-aligned-port",variant=variant,
                    auroc=float(roc_auc_score(y,scores["test"])),fpr95=fpr_at_recall(scores["test"],y)["fpr95"],
                    validation95_threshold=threshold,frozen_unknown_recall=float(reject[y==1].mean()),frozen_known_rejection=float(reject[y==0].mean()),
                    external_vocabulary_information_budget=True)
                dest=WORK/"unit_results"/u["dataset"];dest.mkdir(parents=True,exist_ok=True)
                np.savez_compressed(dest/(u["unit"]+"_"+variant+".npz"),**scores)
                dump(dest/(u["unit"]+"_"+variant+".json"),result);results.append(result)
                del pos,neg,perm
            status("scoring_units",completed=step+1,total=len(units))
        summaries=[]
        for ds in ["pacs","cifar10"]:
            for variant in ["standard","benchmark_names_excluded"]:
                rows=[r for r in results if r["dataset"]==ds and r["variant"]==variant]
                summaries.append(dict(dataset=ds,variant=variant,n=len(rows),**{k:float(np.mean([r[k] for r in rows])) for k in ["auroc","fpr95","frozen_unknown_recall","frozen_known_rejection"]}))
        dump(ROOT/"evidence/C2_NegLabel.json",dict(records=results,summary=summaries,seconds=time.perf_counter()-started,
            parent_prespec_sha256=sha(ROOT/"prespec/C2_NegLabel.json"),execution_prespec_sha256=sha(ROOT/"prespec/C2_NegLabel_execution.json"),
            published_number_reproduction=False,official_function_aligned_port=True))
        status("complete_requires_manuscript_integration",completed=len(units),total=len(units))
    except Exception as exc:status("failed_requires_inspection",error=repr(exc));raise
    finally:lock.unlink(missing_ok=True)


if __name__=="__main__":main()
