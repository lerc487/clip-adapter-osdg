"""CPU-only complete-panel verification; never change a fitted artifact."""
from collections import Counter
import csv
from datetime import datetime,timezone
import hashlib
import json
from pathlib import Path
import sys

import numpy as np
from sklearn.metrics import roc_auc_score,roc_curve

ROOT=Path(__file__).resolve().parents[1];RUNS=ROOT.parent/"revision2_20261118"
WORK=RUNS/"new_runs/officehome/dedup_v3"

def read(path):return json.loads(path.read_text(encoding="utf-8-sig"))
def sha(path):
    h=hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda:f.read(1024*1024),b""):h.update(chunk)
    return h.hexdigest()
def dump(path,obj):path.write_text(json.dumps(obj,indent=2,allow_nan=False),encoding="utf-8")

def score(logits,t,mode):
    x=np.asarray(logits,dtype=np.float64)/float(t)
    if mode=="energy":return -float(t)*np.logaddexp.reduce(x,axis=1)
    maximum=x.max(axis=1)
    masked=x.copy();masked[np.arange(len(x)),x.argmax(axis=1)]=-np.inf
    return np.logaddexp.reduce(masked,axis=1)-maximum

def mix(z,a,source,alpha):
    if source=="adapter":return a
    if source=="zeroshot":return z
    return float(alpha)*a.astype(np.float64)+(1-float(alpha))*z.astype(np.float64)

def roc_details(s,y):
    fpr,tpr,thresholds=roc_curve(y,s,drop_intermediate=False)
    index=np.flatnonzero(tpr>=.95)[0]
    threshold=float(thresholds[index])
    reject=s>=threshold
    assert float(reject[y==1].mean())==float(tpr[index])
    assert float(reject[y==0].mean())==float(fpr[index])
    return float(fpr[index]),threshold

def maxf1_threshold(s,y):
    # Independent grouping enumeration, with the archived highest-threshold tie rule.
    order=np.argsort(-s,kind="stable");ss=s[order];yy=y[order]
    ends=np.r_[np.flatnonzero(ss[:-1]!=ss[1:]),len(ss)-1]
    tp=np.cumsum(yy,dtype=np.int64)[ends];fp=ends+1-tp
    f1=2*tp/(int(y.sum())+tp+fp)
    return float(ss[ends[int(f1.argmax())]])

VARIANTS=[("MSP","adapter","msp",False),("Temp-MSP","adapter","msp",True),
    ("Energy-only-T1","adapter","energy",False),("Mix-alpha0.5-T-tuned","mix","msp",True),
    ("autoMixTemp","auto","msp",True),("Zero-shot-T-tuned","zeroshot","msp",True),
    ("Energy-T-tuned","adapter","energy",True)]

def select(a,route,mode,tune,temperatures,alphas):
    options=[("adapter",None),("zeroshot",None)]+[("mix",v) for v in alphas] if route=="auto" else [(route,.5 if route=="mix" else None)]
    y=np.r_[np.zeros(len(a["ka"]),dtype=int),np.ones(len(a["ua"]),dtype=int)]
    best=None
    for source,alpha in options:
        known=mix(a["kz"],a["ka"],source,alpha);unknown=mix(a["uz"],a["ua"],source,alpha)
        for t in temperatures if tune else [1.]:
            values=np.r_[score(known,t,mode),score(unknown,t,mode)]
            auc=float(roc_auc_score(y,values));fpr,threshold=roc_details(values,y)
            key=(fpr,-auc)
            if best is None or key<best[0]:best=(key,dict(score_source=source,alpha=alpha,T_score=float(t),val_fpr95=fpr,val_auroc=auc))
    return best[1]

def numeric_equal(left,right,context,tolerance=1e-12):
    assert np.isfinite(left) and np.isfinite(right) and abs(left-right)<=tolerance,(context,left,right)

def main():
    spec_path=ROOT/"prespec/C1_complete_panel_integration.json"
    spec=read(spec_path);assert sha(spec_path)==read(ROOT/"prespec/C1_complete_panel_integration_seal.json")["sha256"]
    fixtures=read(ROOT/"evidence/C1_complete_audit_fixture_checks.json")
    assert fixtures["passed"] and fixtures["audit_script_sha256"]==sha(Path(__file__))
    progress=read(RUNS/"evidence/C1_stage1_v3_progress.json")
    assert progress["stage"]=="complete_requires_manuscript_integration" and progress["completed"]==20,progress
    result_path=RUNS/"evidence/C1_stage1_v3_eval64.json"
    parent=read(result_path);stage=read(RUNS/"prespec/C1_stage1_v3_eval64.json")
    assert sha(RUNS/"prespec/C1_stage1_v3_eval64.json")==spec["stage1_spec_sha256"]==parent["stage1_spec_sha256"]
    assert sha(WORK/"roles_manifest.json")==spec["roles_manifest_sha256"]==parent["roles_manifest_sha256"]
    for relative,digest in stage["code_hashes"].items():assert sha(RUNS/relative)==digest,relative
    assert len(parent["records"])==140 and len(parent["timings"])==20 and not parent["stage2_authorized"]
    inputs=dict(created_utc=datetime.now(timezone.utc).isoformat(),parent_result_sha256=sha(result_path),
        audit_spec_sha256=sha(spec_path),roles_manifest_sha256=spec["roles_manifest_sha256"],
        previous_revision_protected_files=read(ROOT/"evidence/officehome_integration_input_manifest.json"))
    frozen_inputs=ROOT/"evidence/C1_complete_panel_input_hashes.json"
    if frozen_inputs.exists():assert read(frozen_inputs)["parent_result_sha256"]==inputs["parent_result_sha256"]
    else:
        with frozen_inputs.open("x",encoding="utf-8") as f:json.dump(inputs,f,indent=2)
    plan=read(WORK/"roles_manifest.json");exclusions=set(read(WORK/"exclusion_manifest.json")["paths"])
    units={u["unit_id"]:u for u in plan["units"] if u["unit_id"] in spec["expected_units"]}
    assert set(units)==set(spec["expected_units"])
    image_hashes={};records=[];units_audit=[];raw_hashes={};max_error=0.
    export=ROOT/"evidence/officehome_saved_scores";export.mkdir(exist_ok=True)
    for uid in spec["expected_units"]:
        unit=units[uid]
        run=WORK/("pilot_eval64" if uid in plan["pilot"] else "stage1_eval64")/uid
        evaluated=run.parent/(uid+"_stable_evaluation")
        timing=read(run.parent/(uid+"_timing.json"))
        assert next(r for r in parent["timings"] if r["unit"]==uid)==timing
        hashes=read(run/"artifact_hashes.json")
        for relative,digest in hashes.items():assert sha(run/relative)==digest,(uid,relative)
        raw_hashes[uid]=dict(directory=str(run),artifact_hashes_sha256=sha(run/"artifact_hashes.json"),files=hashes,
            stable_result_sha256=sha(evaluated/"results.json"),scores_sha256=sha(evaluated/"stable_scores.npz"))
        config=read(run/"config.json")["arguments"]
        assert config["seed"]==0 and config["early_stop_metric"]=="known_nll" and config["early_stop"]==3 and config["epochs"]==20
        assert config["model"]=="ViT-B-32" and config["pretrained"]=="openai"
        assert unit["seed"]==0 and len(unit["known"])==35 and len(unit["validation_unknown"])==15 and len(unit["target_unknown"])==15
        sets=[set(unit[k]) for k in ["known","validation_unknown","target_unknown"]]
        assert all(not sets[i]&sets[j] for i in range(3) for j in range(i+1,3))
        classes=read(run/"class_map.json")["known"];assert set(classes)==sets[0]
        local={name:i for i,name in enumerate(classes)};labels={};role_hashes={};role_counts={};unique_counts={}
        for role,expected in unit["roles"].items():
            actual=read(run/(role+"_samples.json"))
            assert [(r["path"].replace("\\","/"),r["label"]) for r in actual]==[(r["path"],local.get(r["category"],-1)) for r in expected],(uid,role)
            assert not ({r["path"] for r in expected}&exclusions)
            role_counts[role]=len(expected);role_hashes[role]={r["sha256"] for r in expected};unique_counts[role]=len(role_hashes[role])
            labels[role]=np.asarray([r["label"] for r in actual],dtype=int)
            for row in expected:
                if row["path"] in image_hashes:assert image_hashes[row["path"]]==row["sha256"]
                image_hashes[row["path"]]=row["sha256"]
        assert role_counts["train"]==700 and role_counts["val_known"]==350 and role_counts["val_unknown"]==150
        assert role_counts==timing["sample_counts"] and unique_counts==timing["unique_content_counts"]
        assert all(not role_hashes[a]&role_hashes[b] for i,a in enumerate(role_hashes) for b in list(role_hashes)[i+1:])
        with np.load(run/"logits.npz",allow_pickle=False) as z:a={k:z[k] for k in z.files}
        for key,role in [("yk","val_known"),("yu","val_unknown"),("ty","test")]:np.testing.assert_array_equal(a[key],labels[role])
        for key,role in [("ka","val_known"),("kz","val_known"),("ua","val_unknown"),("uz","val_unknown"),("ta","test"),("tz","test")]:
            assert a[key].shape==(role_counts[role],35) and np.isfinite(a[key]).all(),(uid,key,a[key].shape)
        saved=read(evaluated/"results.json")
        assert saved["raw_logits_sha256"]==hashes["logits.npz"] and saved["raw_training_archive_modified"] is False
        choices=read(evaluated/"validation_choices_frozen.json")
        with np.load(evaluated/"stable_scores.npz",allow_pickle=False) as z:scores={k:z[k] for k in z.files}
        assert set(scores)==set(spec["expected_methods"])
        target_known=a["ty"]>=0;y=(~target_known).astype(int);pred=a["ta"].argmax(1)
        vy=np.r_[np.zeros(len(a["ka"]),dtype=int),np.ones(len(a["ua"]),dtype=int)]
        for name,route,mode,tune in VARIANTS:
            row=next(r for r in saved["results"] if r["method"]==name)
            assert row==next(r for r in timing["results"] if r["method"]==name)
            assert dict(unit=uid,**row)==next(r for r in parent["records"] if r["unit"]==uid and r["method"]==name)
            selection=select(a,route,mode,tune,[float(t) for t in config["temp_candidates"].split(",")],[float(t) for t in config["mix_alphas"].split(",")])
            frozen=next(r["selection"] for r in choices["choices"] if r["method"]==name)
            for key in ["score_source","alpha","T_score"]:assert selection[key]==frozen[key]==row["selection"][key],(uid,name,key,selection,frozen)
            for key in ["val_fpr95","val_auroc"]:numeric_equal(selection[key],frozen[key],(uid,name,key))
            values=np.r_[score(mix(a["kz"],a["ka"],selection["score_source"],selection["alpha"]),selection["T_score"],mode),
                score(mix(a["uz"],a["ua"],selection["score_source"],selection["alpha"]),selection["T_score"],mode)]
            test=score(mix(a["tz"],a["ta"],selection["score_source"],selection["alpha"]),selection["T_score"],mode)
            error=float(np.max(np.abs(test-scores[name])));assert error<=1e-10,(uid,name,error);max_error=max(max_error,error)
            fpr,_=roc_details(test,y);_,threshold=roc_details(values,vy)
            numeric_equal(threshold,row["frozen_val_tpr95_threshold"],(uid,name,"threshold"),1e-10)
            f1=maxf1_threshold(values,vy);numeric_equal(f1,row["maxf1_validation_threshold"],(uid,name,"maxF1threshold"),1e-10)
            reject=test>=threshold;classification=pred.copy();classification[test>=f1]=-1
            computed=dict(auroc=float(roc_auc_score(y,test)),fpr95=fpr,known_acc=float((pred[target_known]==a["ty"][target_known]).mean()),
                osr_acc=float((classification==a["ty"]).mean()),frozen_threshold_test_known_fpr=float(reject[target_known].mean()),
                frozen_threshold_test_unknown_tpr=float(reject[~target_known].mean()))
            for key,value in computed.items():numeric_equal(value,row[key],(uid,name,key))
            assert row["checkpoint_sha256"]==hashes["best_adapter.pt"] and row["validation_choices_sha256"]==sha(evaluated/"validation_choices_frozen.json")
            records.append(dict(unit=uid,target=unit["target"],rotation=unit["rotation"],method=name,**computed,selection=row["selection"],
                frozen_val_tpr95_threshold=row["frozen_val_tpr95_threshold"],maxf1_validation_threshold=row["maxf1_validation_threshold"],
                known_files=int(target_known.sum()),unknown_files=int(y.sum())))
        np.savez_compressed(export/(uid+".npz"),target_labels=a["ty"],adapter_predictions=pred,**scores)
        raw_hashes[uid]["portable_scores_and_labels_sha256"]=sha(export/(uid+".npz"))
        units_audit.append(dict(unit=uid,target=unit["target"],epochs=timing["epochs"],nominal=role_counts,unique_content=unique_counts,
            measured_pipeline_seconds=timing["measured_unit_pipeline_seconds"],archive_files_verified=len(hashes),all_methods_verified=True))
    # Raw image bytes are checked once per path, including repeated role appearances.
    for relative,digest in image_hashes.items():assert sha(Path(plan["data_root"])/relative)==digest,relative
    fields=["auroc","fpr95","known_acc","osr_acc","frozen_threshold_test_known_fpr","frozen_threshold_test_unknown_tpr"]
    summary=[];domains=[]
    for method in spec["expected_methods"]:
        rows=[r for r in records if r["method"]==method];assert len(rows)==20
        result=dict(method=method,n=len(rows),**{k:float(np.mean([r[k] for r in rows])) for k in fields});summary.append(result)
        archived=next(r for r in parent["summary"] if r["method"]==method)
        for key in fields:numeric_equal(result[key],archived[key],(method,"summary",key))
        for domain in plan["domains"]:
            rr=[r for r in rows if r["target"]==domain];assert len(rr)==5
            domains.append(dict(target=domain,method=method,n=len(rr),**{k:float(np.mean([r[k] for r in rr])) for k in fields}))
    paired=[]
    for uid in spec["expected_units"]:
        auto=next(r for r in records if r["unit"]==uid and r["method"]=="autoMixTemp")
        for comparator in ["MSP","Temp-MSP"]:
            ref=next(r for r in records if r["unit"]==uid and r["method"]==comparator)
            paired.append(dict(unit=uid,target=auto["target"],comparator=comparator,
                delta_auroc=auto["auroc"]-ref["auroc"],delta_fpr95=auto["fpr95"]-ref["fpr95"]))
    pair_summary=[]
    for comparator in ["MSP","Temp-MSP"]:
        rows=[r for r in paired if r["comparator"]==comparator]
        pair_summary.append(dict(comparator=comparator,n=len(rows),mean_delta_auroc=float(np.mean([r["delta_auroc"] for r in rows])),
            mean_delta_fpr95=float(np.mean([r["delta_fpr95"] for r in rows])),
            lower=sum(r["delta_fpr95"]<0 for r in rows),higher=sum(r["delta_fpr95"]>0 for r in rows),tied=sum(r["delta_fpr95"]==0 for r in rows)))
    auto=[r for r in records if r["method"]=="autoMixTemp"]
    source_counts=Counter("interior" if r["selection"]["score_source"]=="mix" and 0<r["selection"]["alpha"]<1 else r["selection"]["score_source"] for r in auto)
    output=dict(task=spec["task"],all_checks_pass=True,n=20,seed=0,methods_verified=7,method_unit_records_verified=140,
        input_hashes=inputs,raw_archives=raw_hashes,records=records,summary=summary,domain_summary=domains,
        paired_records=paired,paired_summary=pair_summary,selection_source_counts=dict(source_counts),units=units_audit,
        unique_raw_image_paths_verified=len(image_hashes),max_saved_score_absolute_error=max_error,
        nominal_training_files=700,nominal_known_validation_files=350,nominal_unknown_validation_files=150,
        unique_unknown_validation_min=min(r["unique_content"]["val_unknown"] for r in units_audit),
        unique_unknown_validation_max=max(r["unique_content"]["val_unknown"] for r in units_audit),
        measured_pipeline_seconds_sum=sum(r["measured_pipeline_seconds"] for r in units_audit),
        no_new_training=True,no_target_retuning=True,no_IID_inference=True,not_pooled_with_other_datasets=True,
        stage2_started=False,stage1_original_json_sha256=sha(result_path))
    dump(ROOT/"evidence/C1_complete_panel_audit.json",output)
    dump(ROOT/"evidence/C1_stage1_v3_eval64.json",parent)
    for name,data in [("C1_complete_units.csv",records),("C1_complete_domain_summary.csv",domains),("C1_complete_paired.csv",paired)]:
        with (ROOT/"evidence"/name).open("w",encoding="utf-8-sig",newline="") as f:
            keys=[k for k in data[0] if k!="selection"];writer=csv.DictWriter(f,fieldnames=keys,extrasaction="ignore");writer.writeheader();writer.writerows(data)
    print(json.dumps({k:output[k] for k in ["all_checks_pass","n","methods_verified","method_unit_records_verified","max_saved_score_absolute_error","summary","paired_summary","selection_source_counts"]},indent=2))

if __name__=="__main__":main()
