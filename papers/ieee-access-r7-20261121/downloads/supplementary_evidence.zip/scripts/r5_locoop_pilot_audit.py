"""Verify both official pilots and produce timing facts, not acceptance claims."""
from collections import defaultdict
from pathlib import Path
import numpy as np
from gap_closure_core import ROOT,BASE,read,sha,write
from r5_independent_audit_helpers import roc,check,fixtures


def main():
    fixture=fixtures();audit_path=ROOT/"prespec/E6_independent_audit.json";audit=read(audit_path)
    assert sha(audit_path)==read(ROOT/"prespec/E6_independent_audit_seal.json")["sha256"]
    for name,digest in audit["code_hashes"].items():assert sha(name)==digest,name
    import sys
    if "--fixtures" in sys.argv:
        write(ROOT/"evidence/E6_audit_fixtures.json",dict(**fixture,script_sha256=sha(__file__)),exclusive=True)
        print("E6 independent audit synthetic fixtures passed; no pilot outcomes read.");return
    assert read(ROOT/"evidence/E6_audit_fixtures.json")["script_sha256"]==sha(__file__)
    spec=read(ROOT/"prespec/E6_locoop_pilot.json")
    assert sha(ROOT/"prespec/E6_locoop_pilot.json")==audit["pilot_prespec_sha256"]
    assert sha(ROOT/"prespec/E6_locoop_pilot.json")==read(ROOT/"prespec/E6_locoop_pilot_seal.json")["sha256"]
    parent=read(ROOT/"evidence/E6_pilot_results.json")
    assert len(parent["records"])==2
    for path,digest in spec["code_hashes"].items():assert sha(path)==digest,path
    verified=[];times=[]
    for ds,unit in spec["pilot_ids"]:
        output=ROOT/"new_runs/locoop_pilot"/ds/unit;original=BASE/"05_new_runs"/ds/unit
        record=read(output/"results.json");choice=read(output/"checkpoint_choice_frozen.json")
        frozen=read(output/"validation_thresholds_frozen.json")
        assert record==next(r for r in parent["records"] if r["dataset"]==ds and r["unit"]==unit)
        assert record["prespec_sha256"]==sha(ROOT/"prespec/E6_locoop_pilot.json")
        assert len(record["epochs"])==50 and [r["epoch"] for r in record["epochs"]]==list(range(1,51))
        best=min(record["epochs"],key=lambda r:(r["known_validation_nll"],r["epoch"]))
        assert choice["epoch"]==best["epoch"]==record["best_epoch"]
        assert choice["known_validation_nll"]==best["known_validation_nll"]
        assert sha(choice["checkpoint_file"])==choice["checkpoint_sha256"]
        assert frozen["checkpoint_choice_sha256"]==sha(output/"checkpoint_choice_frozen.json")
        for epoch in range(1,51):assert (output/"prompt_learner"/("model.pth.tar-"+str(epoch))).is_file()
        path=output/"saved_logits_and_scores.npz";assert sha(path)==record["saved_arrays_sha256"]
        with np.load(path,allow_pickle=False) as z:a={k:z[k] for k in z.files}
        for role in ["val_known","val_unknown","test"]:
            np.testing.assert_array_equal(a[role+"_labels"],[s["label"] for s in read(original/(role+"_samples.json"))])
            g=a[role+"_global_logits"].astype(np.float64)/100.
            l=a[role+"_local_logits"].astype(np.float64)/100.
            maximum=g.max(1);nonmax=g.copy();nonmax[np.arange(len(g)),g.argmax(1)]=-np.inf
            mcm=np.logaddexp.reduce(nonmax,axis=1)-maximum
            gp=maximum-np.logaddexp.reduce(g,axis=1)
            lp=(l-np.logaddexp.reduce(l,axis=2)[...,None]).max(axis=(1,2))
            gl=-(np.exp(gp)+np.exp(lp))
            assert np.max(np.abs(mcm-a[role+"_MCM64"]))<1e-12
            assert np.max(np.abs(gl-a[role+"_GLMCM64"]))<1e-12
            gf=a[role+"_global_logits"].astype(np.float32)/np.float32(100.)
            lf=a[role+"_local_logits"].astype(np.float32)/np.float32(100.)
            gp=np.exp(gf-gf.max(1,keepdims=True));gp/=gp.sum(1,keepdims=True)
            lp=np.exp(lf-lf.max(2,keepdims=True));lp/=lp.sum(2,keepdims=True)
            official_mcm=-gp.max(1);official_gl=official_mcm-lp.max(axis=(1,2))
            assert np.max(np.abs(official_mcm-a[role+"_MCM_official"]))<=1e-6
            assert np.max(np.abs(official_gl-a[role+"_GLMCM_official"]))<=1e-6
        vy=np.r_[np.zeros(len(a["val_known_labels"]),dtype=int),np.ones(len(a["val_unknown_labels"]),dtype=int)]
        ty=a["test_labels"];y=(ty<0).astype(int);known=y==0;pred=a["test_global_logits"].argmax(1)
        for r in record["results"]:
            m=r["method"];sv=np.r_[a["val_known_"+m],a["val_unknown_"+m]];st=a["test_"+m]
            threshold=roc(sv,vy)["threshold"]
            check(threshold,frozen["thresholds"][m],(unit,m,"threshold"))
            value=roc(st,y)
            for field in ["auroc","fpr95"]:check(value[field],r[field],(unit,m,field))
            reject=st>=threshold
            check(float(reject[~known].mean()),r["frozen_unknown_recall"],(unit,m,"recall"))
            check(float(reject[known].mean()),r["frozen_known_rejection"],(unit,m,"rejection"))
            check(float((pred[known]==ty[known]).mean()),r["known_accuracy"],(unit,m,"known_accuracy"))
            verified.append(dict(dataset=ds,unit=unit,**r))
        times.append(dict(dataset=ds,unit=unit,epochs=50,measured_processing_seconds=record["measured_pipeline_seconds"],
            train_files=len(read(original/"train_samples.json")),known_validation_files=len(a["val_known_labels"]),target_files=len(ty)))
    write(ROOT/"evidence/E6_pilot_audit.json",dict(all_checks_pass=True,fixtures=fixture,records=verified,timings=times,
        official_source_unmodified=True,prespec_sha256=sha(ROOT/"prespec/E6_locoop_pilot.json"),audit_prespec_sha256=sha(audit_path),
        scope="Checks recorded50epoch validation selection and selected checkpoint hash, all saved labels/scores/thresholds/target metrics and both64-bit scoring formulas. Does not rerun neural training or claim to reproduce published benchmarks. Official float32 scores are preserved, not silently replaced.",
        batch_authorization_required=True,no_acceptance_guarantee=True),exclusive=True)
    pacs=next(r["measured_processing_seconds"] for r in times if r["dataset"]=="pacs")
    cifar=next(r["measured_processing_seconds"] for r in times if r["dataset"]=="cifar10")
    write(ROOT/"evidence/E6_batch_planning_projection.json",dict(measured_pilots=times,
        proposed_unit_scope=dict(pacs=28,cifar10=5,seeds=[0],lambda_candidates=[.1,.25]),
        total_fits=66,reused_pilots=2,new_fits=64,new_pacs_fits=55,new_cifar_fits=9,
        projected_processing_seconds=55*pacs+9*cifar,
        derivation="55 additional PACS fits times the actual PACS pilot plus9 CIFAR fits times the actual CIFAR pilot. Planning projection only; unit sizes, I/O and CPU contention differ. Excludes environment installation, Python startup and unmeasured final auditing costs.",
        not_a_measured_future_runtime=True,not_a_scientific_outcome=True,batch_started=False),exclusive=True)
    print("Official LoCoOp two-pilot audit passed; actual timings and explicit batch-planning projection saved.")


if __name__=="__main__":main()
