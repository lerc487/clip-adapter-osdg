"""Official prompt training and official scoring on a fixed custom-role pilot."""
import argparse
from datetime import datetime,timezone
import hashlib
import json
import os
from pathlib import Path
import sys
import time

import numpy as np
import torch
import torch.nn.functional as F
from torch.utils.data import DataLoader
from scipy.special import logsumexp
from sklearn.metrics import roc_auc_score
from dassl.utils import set_random_seed
from r5_locoop_bridge import ROOT,BASE,OFFICIAL,config_for,read

sys.path.insert(0,str(ROOT/"new_runs/c3b/code"))
from train_disjoint import MultiDomainFolder
from verified_metrics import fpr_at_recall
sys.path.insert(0,str(OFFICIAL))
from trainers.locoop import LoCoOp
from clip_w_local import clip


def sha(p):return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def write(p,x):
    with Path(p).open("x",encoding="utf-8") as f:json.dump(x,f,indent=2,allow_nan=False)


@torch.no_grad()
def known_nll(trainer):
    trainer.set_model_mode("eval")
    total=0.;count=0
    for batch in trainer.val_loader:
        output,_=trainer.model(batch["img"].cuda())
        labels=batch["label"].cuda()
        total+=F.cross_entropy(output,labels,reduction="sum").item();count+=len(labels)
    return total/count


def stable_scores(global_logits,local_logits):
    g=np.asarray(global_logits,dtype=np.float64)/100.
    l=np.asarray(local_logits,dtype=np.float64)/100.
    maximum=g.max(1);other=g.copy();other[np.arange(len(g)),g.argmax(1)]=-np.inf
    mcm_logodds=logsumexp(other,axis=1)-maximum
    global_logp=maximum-logsumexp(g,axis=1)
    local_logp=(l-logsumexp(l,axis=2,keepdims=True)).max(axis=(1,2))
    gl=-(np.exp(global_logp)+np.exp(local_logp))
    return dict(MCM64=mcm_logodds,GLMCM64=gl)


def main():
    parser=argparse.ArgumentParser();parser.add_argument("--dataset",required=True);parser.add_argument("--unit",required=True);args=parser.parse_args()
    spec_path=ROOT/"prespec/E6_locoop_pilot.json";spec=read(spec_path)
    owner=os.environ.get("R5_LOCOOP_QUEUE_PID")
    lock=BASE/"revision2_20261118/new_runs/GPU_QUEUE.lock"
    # Windows virtualenv launchers can interpose between the queue and worker.
    assert owner and lock.read_text().strip()==owner,"An owning exclusive serial pilot queue is required"
    assert sha(spec_path)==read(ROOT/"prespec/E6_locoop_pilot_seal.json")["sha256"]
    assert [args.dataset,args.unit] in spec["pilot_ids"]
    for path,digest in spec["code_hashes"].items():assert sha(path)==digest,path
    assert read(ROOT/"evidence/E6_cpu_fixture_checks.json")["passed"]
    assert read(ROOT/"evidence/R5_authorization_20261119.json")["locoop_official_environment_and_two_unit_pilot"]
    output=ROOT/"new_runs/locoop_pilot"/args.dataset/args.unit
    output.mkdir(parents=True,exist_ok=False)
    cfg=config_for(args.dataset,args.unit,output,use_cuda=True)
    write(output/"config.json",dict(yaml=cfg.dump(),prespec_sha256=sha(spec_path),no_target_based_hyperparameters=True,
        queue_lock_owner=owner,observed_parent_pid=os.getppid(),windows_launcher_interposition_allowed=True))
    set_random_seed(0)
    torch.backends.cudnn.benchmark=False
    started=time.perf_counter();trainer=LoCoOp(cfg)
    trainable=[name for name,p in trainer.model.named_parameters() if p.requires_grad]
    assert trainable and all(name.startswith("prompt_learner.") for name in trainable)
    trainer.before_train();assert trainer.start_epoch==0
    records=[];best=(float("inf"),None)
    for epoch in range(cfg.OPTIM.MAX_EPOCH):
        trainer.epoch=epoch;trainer.before_epoch();trainer.run_epoch()
        nll=known_nll(trainer)
        assert np.isfinite(nll)
        records.append(dict(epoch=epoch+1,known_validation_nll=nll))
        if nll<best[0]:best=(nll,epoch+1)
        trainer.after_epoch()
        with (output/"epochs.jsonl").open("a",encoding="utf-8") as f:f.write(json.dumps(records[-1])+"\n")
    trainer.after_train()
    chosen_file=output/"prompt_learner"/("model.pth.tar-"+str(best[1]))
    assert chosen_file.is_file()
    choice=dict(epoch=best[1],known_validation_nll=best[0],checkpoint_file=str(chosen_file),checkpoint_sha256=sha(chosen_file),
        policy="Earliest minimum known-validation NLL across all50epochs; no target or validation-unknown checkpoint selection",prespec_sha256=sha(spec_path))
    write(output/"checkpoint_choice_frozen.json",choice)
    trainer.load_model(str(output),epoch=best[1])
    source=BASE/"05_new_runs"/args.dataset/args.unit
    original=read(source/"config.json")["arguments"]
    transform=clip._transform(224)
    arrays={};official_alignment=[]
    for role in ["val_known","val_unknown","test"]:
        samples=read(source/(role+"_samples.json"))
        loader=DataLoader(MultiDomainFolder([(str(Path(original["data_root"])/s["path"]),s["label"]) for s in samples],transform),batch_size=64,num_workers=0,shuffle=False)
        captured=[]
        def hook(module,inputs,out):
            captured.append((out[0].detach().cpu().numpy().copy(),out[1].detach().cpu().numpy().copy()))
        handle=trainer.model.register_forward_hook(hook)
        raw_mcm,raw_gl=trainer.test_ood(loader,1.0)
        handle.remove()
        g=np.concatenate([x[0] for x in captured]);l=np.concatenate([x[1] for x in captured])
        assert len(g)==len(samples)
        with torch.no_grad():
            pg=torch.softmax(torch.from_numpy(g)/100.,dim=-1).numpy()
            pl=torch.softmax(torch.from_numpy(l)/100.,dim=-1).numpy()
        expected_mcm=-pg.max(1);expected_gl=expected_mcm-pl.max(axis=(1,2))
        # Exact official GPU scores are retained; CPU softmax is an independent same-input check.
        err=max(float(np.max(np.abs(raw_mcm-expected_mcm))),float(np.max(np.abs(raw_gl-expected_gl))))
        assert err<=1e-6
        official_alignment.append(dict(role=role,max_cpu_gpu_score_difference=err,passed=True))
        arrays[role+"_global_logits"]=g;arrays[role+"_local_logits"]=l
        arrays[role+"_labels"]=np.array([s["label"] for s in samples])
        arrays[role+"_MCM_official"]=raw_mcm;arrays[role+"_GLMCM_official"]=raw_gl
        for method,values in stable_scores(g,l).items():arrays[role+"_"+method]=values
        if role=="val_unknown":
            vy=np.r_[np.zeros(len(arrays["val_known_labels"]),dtype=int),np.ones(len(samples),dtype=int)]
            thresholds={m:fpr_at_recall(np.r_[arrays["val_known_"+m],arrays["val_unknown_"+m]],vy)["threshold"] for m in ["MCM_official","GLMCM_official","MCM64","GLMCM64"]}
            write(output/"validation_thresholds_frozen.json",dict(thresholds=thresholds,checkpoint_choice_sha256=sha(output/"checkpoint_choice_frozen.json"),score_temperature=1.,no_target_selection=True))
    results=[];ty=arrays["test_labels"];y=ty<0;known=~y;pred=arrays["test_global_logits"].argmax(1)
    for method,threshold in thresholds.items():
        st=arrays["test_"+method];reject=st>=threshold
        results.append(dict(method=method,auroc=float(roc_auc_score(y,st)),fpr95=fpr_at_recall(st,y)["fpr95"],
            frozen_unknown_recall=float(reject[y].mean()),frozen_known_rejection=float(reject[known].mean()),
            known_accuracy=float((pred[known]==ty[known]).mean()),validation95_threshold=threshold))
    np.savez_compressed(output/"saved_logits_and_scores.npz",**arrays)
    write(output/"results.json",dict(dataset=args.dataset,unit=args.unit,results=results,epochs=records,best_epoch=best[1],
        measured_pipeline_seconds=time.perf_counter()-started,official_score_alignment=official_alignment,
        saved_arrays_sha256=sha(output/"saved_logits_and_scores.npz"),prespec_sha256=sha(spec_path),
        official_trainer_unchanged=True,metrics_use_unknown_positive_complete_tie_ROC=True,
        not_reproduction_of_published_benchmark_numbers=True,pilot_only_requires_batch_decision=True))
    print("LoCoOp official pilot completed "+args.dataset+" "+args.unit,flush=True)


if __name__=="__main__":main()
