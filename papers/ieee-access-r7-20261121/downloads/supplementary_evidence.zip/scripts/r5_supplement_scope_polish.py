"""Remove superseded seed0 diagnostic rows and tabulate already measured timings."""
from pathlib import Path
import sys
from gap_closure_core import ROOT, read, write
import integrate_results as I

src = ROOT / "source"
path = src / "locoop_complete_supplement.tex"
text = path.read_text()
lines = text.splitlines()
office = [i for i, line in enumerate(lines) if line.startswith("ViT-B32 & officehome &")]
assert len(office) == 4
lines = [line for i, line in enumerate(lines) if i not in office[:2]]
text = "\n".join(lines) + "\n"
text = text.replace("Training/validation reuse and pretraining exposure remain; no IID population inference.",
    "Office-Home uses all three seeds averaged within 20 clusters; its superseded seed0-only diagnostic is not pooled here. Training/validation reuse and pretraining exposure remain; no IID population inference.")
I.ROOT = ROOT
I.SRC = src
I.DATA = {}
I.REG = read(ROOT / "evidence/number_registry.json")
I.MACROS = []
data = read(ROOT / "evidence/E1_search_utility.json")
rows = []
for i, row in enumerate(data["timing_summary"]):
    label = row["unit"].replace("art_painting", "art painting").replace("_", r"\_")
    rows.append([row["dataset"], label] + [I.n("E1_search_utility", ("timing_summary", i, key), 3) for key in
        ["temp_median_seconds", "auto_median_seconds", "auto_to_temp_ratio"]])
text += "\n".join([r"\begin{table}[htbp]\centering\small",
    r"\caption{Measured CPU validation-search overhead on nine fixed units. Values are medians of three repeats after one warmup. Image encoding, I/O and training are excluded; this is not end-to-end deployment latency.}",
    r"\begin{tabular}{llrrr}\toprule", r"Data & Unit & Temp seconds & Auto seconds & Auto/Temp\\\midrule"] +
    [" & ".join(row) + r"\\" for row in rows] + [r"\bottomrule\end{tabular}\end{table}"]) + "\n"
path.write_text(text, encoding="ascii")
with (src / "numbers_revision2.tex").open("a", encoding="ascii") as f:
    f.write("\n".join(I.MACROS) + "\n")
write(ROOT / "evidence/number_registry.json", I.REG)
print("Supplement scoped to full60 Office-Home only, with nine actual CPU timing fixtures.")
