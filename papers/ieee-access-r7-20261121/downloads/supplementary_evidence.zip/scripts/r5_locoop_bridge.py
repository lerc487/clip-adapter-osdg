"""Literal data-role integration; the official LoCoOp trainer is not patched."""
import importlib.util
import json
from pathlib import Path
import sys

ROOT=Path(__file__).resolve().parents[1]
BASE=ROOT.parent
versions=json.loads((ROOT/"evidence/E6_official_source_versions.json").read_text(encoding="utf-8-sig"))
OFFICIAL=Path(versions["sources"][0]["code_root"])
sys.path.insert(0,str(OFFICIAL))

from dassl.config import get_cfg_default
from dassl.data.datasets import DATASET_REGISTRY,Datum,DatasetBase
from yacs.config import CfgNode as CN


def read(p):return json.loads(Path(p).read_text(encoding="utf-8-sig"))


@DATASET_REGISTRY.register()
class R5FrozenRoles(DatasetBase):
    def __init__(self,cfg):
        run=Path(cfg.R5.RUN_INPUT)
        config=read(run/"config.json")["arguments"]
        root=Path(config["data_root"])
        def entries(name):
            result=[]
            for s in read(run/(name+"_samples.json")):
                path=s["path"].replace("\\","/")
                result.append(Datum(impath=str(root/path),label=int(s["label"]),domain=0,classname=path.split("/")[-2]))
            return result
        train=entries("train");val=entries("val_known")
        assert all(s.label>=0 for s in train+val)
        # The official training loop never receives target or validation-unknown data.
        # Its disabled test slot holds the known validation list, not the target set.
        super().__init__(train_x=train,val=val,test=val)


def config_for(dataset,unit,output,use_cuda=True):
    cfg=get_cfg_default()
    module_spec=importlib.util.spec_from_file_location("r5_official_locoop_config",OFFICIAL/"train.py")
    module=importlib.util.module_from_spec(module_spec);module_spec.loader.exec_module(module)
    module.extend_cfg(cfg)
    cfg.merge_from_file(str(OFFICIAL/"configs/trainers/LoCoOp/vit_b16_ep50.yaml"))
    cfg.R5=CN();cfg.R5.RUN_INPUT=str(BASE/"05_new_runs"/dataset/unit)
    cfg.DATASET.NAME="R5FrozenRoles"
    cfg.DATASET.ROOT=read(Path(cfg.R5.RUN_INPUT)/"config.json")["arguments"]["data_root"]
    cfg.DATASET.NUM_SHOTS=-1
    cfg.MODEL.BACKBONE.NAME="ViT-B/32"
    cfg.TRAINER.NAME="LoCoOp"
    cfg.TRAINER.LOCOOP.PREC="amp"
    cfg.TRAINER.LOCOOP.N_CTX=16
    cfg.TRAINER.LOCOOP.CSC=False
    cfg.TRAINER.LOCOOP.CTX_INIT=""
    cfg.TRAINER.LOCOOP.CLASS_TOKEN_POSITION="end"
    cfg.DATALOADER.NUM_WORKERS=0
    cfg.DATALOADER.TRAIN_X.BATCH_SIZE=32
    cfg.DATALOADER.TEST.BATCH_SIZE=64
    cfg.OPTIM.MAX_EPOCH=50
    cfg.TRAIN.CHECKPOINT_FREQ=1
    cfg.TRAIN.PRINT_FREQ=100
    cfg.TEST.NO_TEST=True
    cfg.SEED=0
    cfg.USE_CUDA=use_cuda
    cfg.OUTPUT_DIR=str(output)
    cfg.RESUME=""
    cfg.lambda_value=.1
    labels={r["label"] for r in read(Path(cfg.R5.RUN_INPUT)/"train_samples.json")}
    cfg.topk=max(1,int(len(labels)*.2))
    cfg.freeze()
    return cfg
