"""Yield only at an Office-Home unit boundary, pilot, then resume that queue."""
from datetime import datetime,timezone
import os
from pathlib import Path
import subprocess
import sys
import time
from gap_closure_core import ROOT,R2,read,sha,write


def state(stage,**kw):
    write(ROOT/"evidence/E6_priority_schedule_progress.json",dict(stage=stage,pid=os.getpid(),
        updated_utc=datetime.now(timezone.utc).isoformat(),**kw))


def main():
    spec=read(ROOT/"prespec/E6_priority_schedule.json")
    assert sha(ROOT/"prespec/E6_priority_schedule.json")==read(ROOT/"prespec/E6_priority_schedule_seal.json")["sha256"]
    marker=ROOT/"new_runs/PAUSE_REQUESTED"
    assert read(marker)["scheduler_token"]==spec["scheduler_token"]
    state("waiting_for_officehome_unit_boundary")
    while True:
        p=read(ROOT/"evidence/E5_officehome_stage2_progress.json")
        if p["stage"]=="failed_requires_inspection":raise RuntimeError("Office-Home failed; inspect before changing GPU work")
        if p["stage"] in ["paused_at_unit_boundary","training_complete_requires_independent_audit"] and not (R2/"new_runs/GPU_QUEUE.lock").exists():break
        time.sleep(5)
    assert read(marker)["scheduler_token"]==spec["scheduler_token"]
    marker.unlink()
    result=None
    try:
        state("running_two_official_locoop_pilots",officehome_completed=p["completed"])
        with (ROOT/"logs/E6_priority_pilots_stdout.log").open("a",encoding="utf-8") as out,(ROOT/"logs/E6_priority_pilots_stderr.log").open("a",encoding="utf-8") as err:
            result=subprocess.run([sys.executable,"-B","-s","-u",str(ROOT/"scripts/r5_locoop_pilot_queue.py")],cwd=ROOT,stdout=out,stderr=err).returncode
    finally:
        if not any((r/"new_runs/PAUSE_REQUESTED").exists() for r in [ROOT,R2]) and p["completed"]<40:
            with (ROOT/"logs/E5_stage2_stdout.log").open("a",encoding="utf-8") as out,(ROOT/"logs/E5_stage2_stderr.log").open("a",encoding="utf-8") as err:
                process=subprocess.Popen([sys.executable,"-B","-s","-u",str(ROOT/"scripts/r5_officehome_stage2.py")],cwd=ROOT,stdout=out,stderr=err,
                    creationflags=subprocess.CREATE_NO_WINDOW)
            (ROOT/"logs/E5_stage2.pid").write_text(str(process.pid),encoding="ascii")
            state("officehome_resumed_after_pilots",officehome_queue_pid=process.pid,pilot_exit_code=result,
                next_gate="Independent pilot audit and explicit user decision before any LoCoOp batch")
        else:
            state("user_pause_respected_or_officehome_already_complete",pilot_exit_code=result)
    if result:raise RuntimeError("An official pilot failed; no substitute or automatic retry was run")


if __name__=="__main__":main()
