"""Portable evidence/source checks; full local archival checks use --release."""
import argparse
from functools import lru_cache
import hashlib
import json
from pathlib import Path
import re
import subprocess

ROOT = Path(__file__).resolve().parents[1]


@lru_cache(None)
def read(path):
    return json.loads(Path(path).read_text(encoding="utf-8-sig"))


def sha(path):
    return hashlib.sha256(Path(path).read_bytes()).hexdigest()


def words(text):
    text = re.sub(r"(?m)(?<!\\)%.*$", "", text)
    text = re.sub(r"(?s)\\begin\{(?:table\*?|equation\*?|align\*?|Verbatim)\}.*?\\end\{(?:table\*?|equation\*?|align\*?|Verbatim)\}", " ", text)
    text = re.sub(r"(?m)^\\caption.*$", "", text)
    text = re.sub(r"\$[^$]*\$", " ", text)
    text = re.sub(r"\\(?:label|ref|cite|input|includegraphics)(?:\[[^]]*\])?\{[^}]*\}", " ", text)
    text = re.sub(r"\\(?:begin|end)\{[^}]*\}", " ", text)
    text = re.sub(r"\\[A-Za-z]+", " ", text)
    return len(re.findall(r"[A-Za-z]+(?:[-'][A-Za-z]+)*", text))


def abstract_text():
    src = ROOT / "source"
    text = (src / "manuscript.tex").read_text().split(r"\begin{abstract}")[1].split(r"\end{abstract}")[0]
    aliases = dict(re.findall(r"\\newcommand\{\\([^}]+)\}\{([^\n]*)\}", (src / "numbers_revision2.tex").read_text()))
    for _ in range(8):
        text = re.sub(r"\\([A-Za-z]+)\{\}", lambda m: aliases.get(m[1], m[0]), text)
    return text


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--release", action="store_true")
    args = parser.parse_args()
    src = ROOT / "source"
    registry = read(ROOT / "evidence/number_registry.json")
    numeric = (src / "numbers_revision2.tex").read_text()
    defined = re.findall(r"\\newcommand\{\\([^}]+)\}", numeric)
    assert len(defined) == len(set(defined))
    for row in registry:
        value = read(ROOT / "evidence" / row["file"])
        for key in row["pointer"]:
            value = value[key]
        assert value == row["value"]
        display = format(value * row["scale"], ("+" if row["signed"] else "") + "." + str(row["decimals"]) + "f")
        assert display == row["display"]
        assert "\\newcommand{\\" + row["macro"] + "}{" + display + "}" in numeric
    used = set()
    for p in src.rglob("*.tex"):
        used.update(re.findall(r"\\(Num[a-z]+)\b", p.read_text()))
    assert used <= set(defined)
    seals = []
    for path in (ROOT / "prespec").glob("*_seal.json"):
        seal = read(path)
        candidates = [path.with_name(path.name.removesuffix("_seal.json") + ".json")]
        if "task" in seal:
            candidates.append(path.parent / (seal["task"] + ".json"))
        spec = next((p for p in candidates if p.is_file() and sha(p) == seal["sha256"]), None)
        assert spec, path
        seals.append(spec.name)
    fig = read(ROOT / "evidence/E9_final_figure_registry.json")
    for name, digest in fig["figure_hashes"].items():
        assert sha(src / "figures" / name) == digest, name
    for row in fig["loco_op_records"]:
        value = read(ROOT / "evidence" / row["file"])
        for key in row["pointer"]:
            value = value[key]
        assert value == row["value"] and format(value * 100, ".3f") == row["display_percent"]
    for row in fig["policy_risk_records"]:
        risk = row["figure"] == "risk_coverage"
        data = read(ROOT / "evidence" / ("E0_probability.json" if risk else "E2_transfer_tradeoffs.json"))
        keys = ["model", "dataset", "method", "coverage"] if risk else ["model", "dataset", "method", "rho", "policy"]
        candidates = [r for r in data["risk_coverage" if risk else "summary"] if all(r[k] == row[k] for k in keys)]
        assert len(candidates) == 1 and all(row[k] == v for k, v in candidates[0].items())
    for filename, counts in [("E5_officehome_full_audit.json", ("n", 60)), ("E4_independent_audit.json", ("method_selector_rows_verified", 264)), ("E6_locoop_batch_audit.json", ("fits", 66))]:
        data = read(ROOT / "evidence" / filename)
        assert data["all_checks_pass"] and data[counts[0]] == counts[1]
    e7 = read(ROOT / "evidence/E7_final_numeric_evidence.json")
    assert e7["both_interpolation_operands_float64"] and e7["original_archives_modified"] is False
    current = "\n".join((src / p).read_text() for p in ["body_revision.tex", "architecture_results.tex"])
    assert "two audited timing pilots only" not in current and "LoCoOp remains unevaluated" not in current
    abstract = abstract_text()
    assert len(abstract.split()) <= 180
    result = dict(evidence_checks_pass=True, macro_bindings_verified=len(registry), sealed_designs_verified=len(seals),
        figure_files_verified=len(fig["figure_hashes"]), abstract_words_including_numbers=len(abstract.split()),
        abstract_english_words=words(abstract), current_body_words=words(current),
        word_count_rule="Same English-prose rule before/after; equations/tables/captions/commands/numerals excluded; escaped percent signs are not treated as comments.",
        all_authorized_experiments_audited=True, no_target_selected_lambda=True,
        editorial_acceptance_or_population_guarantee=False, author_approval=False, upload_ready=False)
    if args.release:
        for name in ["manuscript", "supplement"]:
            log = (src / (name + ".log")).read_text(errors="replace")
            assert not any(x in log for x in ["undefined references", "undefined citations", "! LaTeX Error"]), name
        text = subprocess.check_output(["pdftotext", str(src / "manuscript.pdf"), "-"], text=True, encoding="utf-8")
        assert not any(x in text for x in ["TBD", "AUTHOR REVIEW DRAFT", "Not submitted", "+ 本文"])
        bbl = (src / "manuscript.bbl").read_text()
        refs = len(re.findall(r"\\bibitem", bbl))
        cites = list(map(int, re.findall(r"(?<![A-Za-z0-9])\[(\d+)\](?![A-Za-z0-9])", text)))
        assert cites and max(cites) <= refs
        prior_root = ROOT.parent / "06_manuscript/revision_20261118/source"
        previous = "\n".join((prior_root / p).read_text() for p in ["body_revision.tex", "architecture_results.tex"])
        before = words(previous)
        ratio = words(current) / before
        assert ratio <= .85
        info = subprocess.check_output(["pdfinfo", str(src / "manuscript.pdf")], text=True)
        pages = int(re.search(r"Pages:\s+(\d+)", info)[1])
        assert pages <= 14
        protected = read(ROOT / "evidence/R4_protected_manifest.json")
        if isinstance(protected, dict):
            protected = protected.get("files", protected.get("records"))
        assert protected and all(sha(r["path"]) == r["sha256"] for r in protected)
        baseline = ROOT.parent / "00_submitted_baseline/IEEE_Access_n80_20260930.zip"
        assert sha(baseline) == "55750070ad2f04219c2ed15059a69905537c1e4ad7742f9421121f59750dfd3d"
        result.update(reference_count=refs, maximum_body_citation=max(cites), no_undefined_references=True,
            before_body_words=before, body_ratio=ratio, protected_R4_files_verified=len(protected),
            actual_submitted_baseline_unchanged=True, clean_pdf_sha256=sha(src / "manuscript.pdf"),
            supplement_pdf_sha256=sha(src / "supplement.pdf"), main_pages=pages,
            previous_85_percent_prose_target_met=ratio <= .85,
            current_editorial_limits="14 manuscript pages and 180 abstract words")
    path = ROOT / "evidence/E10_final_consistency_checks.json"
    path.write_text(json.dumps(result, indent=2), encoding="utf-8")
    print(json.dumps(result, indent=2))


if __name__ == "__main__":
    main()
