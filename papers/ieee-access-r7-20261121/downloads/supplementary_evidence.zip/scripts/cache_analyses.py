"""Read-only cache analyses; all new outputs stay under this revision."""
from collections import defaultdict
import csv
import hashlib
import json
from pathlib import Path
import sys
import time

import numpy as np
from scipy.optimize import minimize_scalar
from scipy.special import logsumexp, softmax
from scipy.stats import spearmanr, kendalltau
from sklearn.metrics import roc_auc_score

ROOT = Path(__file__).resolve().parents[1]
BASE = ROOT.parent
sys.path.insert(0, str(BASE / "tools"))
from stable_score_audit import stable_msp, stable_energy, branch, choose
from audit_and_analyze import probability_metrics
sys.path.insert(0, str(BASE / "05_new_runs/code"))
from verified_metrics import fpr_at_recall


def read(p):
    return json.loads(p.read_text(encoding="utf-8-sig"))


def sha(p):
    return hashlib.sha256(p.read_bytes()).hexdigest()


def dump(task, obj):
    spec = ROOT / "prespec" / (task + ".json")
    assert sha(spec) == read(ROOT / "prespec/sealed_hashes.json")[task]
    obj.update(task=task, prespec_sha256=sha(spec), script_sha256=sha(Path(__file__)),
               interpretation="Conditional descriptive cache analysis; no IID significance, causal interpretation or deployment guarantee.")
    (ROOT / "evidence" / (task + ".json")).write_text(json.dumps(obj,indent=2,allow_nan=False),encoding="utf-8")
    for name, rows in obj.items():
        if isinstance(rows,list) and rows and isinstance(rows[0],dict):
            if any(any(isinstance(v,(dict,list)) for v in r.values()) for r in rows):
                continue
            keys = list(dict.fromkeys(k for r in rows for k in r))
            with (ROOT / "evidence" / (task + "_" + name + ".csv")).open("w",newline="",encoding="utf-8-sig") as f:
                w=csv.DictWriter(f,keys);w.writeheader();w.writerows(rows)
    print(task+" saved",flush=True)


def panels():
    principal = read(BASE / "04_analysis/stable_score_audit_20261118.json")["records"]
    extra = read(BASE / "04_analysis/additional_validation_summary_20261118.json")["records"]
    for model, rows in [("ViT-B32", principal), ("RN50", [r for r in extra if r["family"] == "rn50"])]:
        for ds in ["pacs","cifar10"]:
            selected = [r for r in rows if r["dataset"] == ds]
            byunit = defaultdict(dict)
            for r in selected:
                byunit[r["unit"]][r["method"]] = r
            for unit, methods in sorted(byunit.items()):
                directory = BASE / "05_new_runs" / ds / unit if model == "ViT-B32" else BASE / "05_new_runs/rn50" / ds / unit
                with np.load(directory / "logits.npz",allow_pickle=False) as z:
                    arrays={k:z[k] for k in z.files}
                yield model, ds, unit, directory, arrays, methods


def meta(model, ds, unit):
    return dict(model=model,dataset=ds,unit=unit)


def corr(x,y,kind="spearman"):
    if len(x)<2 or len(set(x))<2 or len(set(y))<2:
        return None
    return float((spearmanr if kind=="spearman" else kendalltau)(x,y).statistic)


def means(rows, keys):
    return {k:float(np.mean([r[k] for r in rows if r[k] is not None])) if any(r[k] is not None for r in rows) else None for k in keys}


def detection(a,sel,energy=False):
    fn=stable_energy if energy else stable_msp
    st=fn(branch(a,"t",sel),sel["T_score"])
    sv=np.r_[fn(branch(a,"k",sel),sel["T_score"]),fn(branch(a,"u",sel),sel["T_score"])]
    return st,sv


def B1():
    rows=[];policies=[]
    for model,ds,unit,d,a,m in panels():
        auto,temp=m["autoMixTemp"],m["Temp-MSP"]
        s=auto["selection"]; kind=s["score_source"]
        if kind=="mix" and s["alpha"] in [0,1]:kind="adapter" if s["alpha"]==1 else "zeroshot"
        gain=temp["selection"]["val_fpr95"]-s["val_fpr95"]
        row=dict(**meta(model,ds,unit),choice=kind,alpha=s["alpha"],temperature=s["T_score"],validation_fpr_gain=gain,
            delta_fpr95=auto["fpr95"]-temp["fpr95"],delta_auroc=auto["auroc"]-temp["auroc"],target_fpr_gain=temp["fpr95"]-auto["fpr95"])
        rows.append(row)
        for delta in [0,.01]:
            for gate in ["any_selected_source","interior_only"]:
                enabled=gain>delta and (gate!="interior_only" or kind=="mix")
                choice=auto if enabled else temp
                policies.append(dict(**meta(model,ds,unit),delta=delta,gate=gate,enabled=enabled,
                    auroc=choice["auroc"],fpr95=choice["fpr95"],delta_fpr95=choice["fpr95"]-temp["fpr95"],delta_auroc=choice["auroc"]-temp["auroc"]))
    summary=[];associations=[];ps=[]
    for model,ds in sorted({(r["model"],r["dataset"]) for r in rows}):
        group=[r for r in rows if r["model"]==model and r["dataset"]==ds]
        associations.append(dict(model=model,dataset=ds,n=len(group),spearman=corr([r["validation_fpr_gain"] for r in group],[r["target_fpr_gain"] for r in group])))
        for kind in ["adapter","zeroshot","mix"]:
            rr=[r for r in group if r["choice"]==kind]
            summary.append(dict(model=model,dataset=ds,choice=kind,n=len(rr),
                **means(rr,["validation_fpr_gain","delta_fpr95","delta_auroc"]),
                lower=sum(r["delta_fpr95"]<0 for r in rr),higher=sum(r["delta_fpr95"]>0 for r in rr),tied=sum(r["delta_fpr95"]==0 for r in rr)))
        for delta in [0,.01]:
            for gate in ["any_selected_source","interior_only"]:
                rr=[r for r in policies if r["model"]==model and r["dataset"]==ds and r["delta"]==delta and r["gate"]==gate]
                ps.append(dict(model=model,dataset=ds,delta=delta,gate=gate,n=len(rr),enabled=sum(r["enabled"] for r in rr),**means(rr,["auroc","fpr95","delta_fpr95","delta_auroc"])))
    dump("B1",dict(records=rows,strata=summary,associations=associations,policy_records=policies,policy_summary=ps))


def B2():
    rows=[]
    for model,ds,unit,d,a,m in panels():
        ty=a["ty"];y=(ty<0).astype(int);pred=a["ta"].argmax(1)
        vy=np.r_[np.zeros(len(a["yk"]),dtype=int),np.ones(len(a["yu"]),dtype=int)]
        vu=read(d/"val_unknown_samples.json")
        names=np.array([s["path"].replace("\\","/").split("/")[-2] for s in vu])
        for method in ["MSP","Temp-MSP","autoMixTemp","Energy-T-tuned"]:
            st,sv=detection(a,m[method]["selection"],method=="Energy-T-tuned")
            for rho in [.9,.95,.975,.99]:
                pooled=fpr_at_recall(sv,vy,rho)["threshold"]
                byclass=[]
                for name in sorted(set(names)):
                    mask=np.r_[np.ones(len(a["yk"]),dtype=bool),names==name]
                    byclass.append(fpr_at_recall(sv[mask],vy[mask],rho)["threshold"])
                for policy,threshold in [("pooled",pooled),("worst_class",min(byclass))]:
                    reject=st>=threshold;known=y==0;acc=known&~reject;accepted=~reject
                    recall=float(reject[~known].mean())
                    rows.append(dict(**meta(model,ds,unit),method=method,rho=rho,policy=policy,threshold=threshold,
                        unknown_recall=recall,known_rejection=float(reject[known].mean()),
                        accepted_known_accuracy=float((pred[acc]==ty[acc]).mean()) if acc.any() else None,
                        unknown_contamination=float((accepted&~known).sum()/accepted.sum()) if accepted.any() else None,
                        recall_gap=recall-rho))
        print("B2 "+model+" "+unit,flush=True)
    summary=[];gaps=[]
    keys=["unknown_recall","known_rejection","accepted_known_accuracy","unknown_contamination","recall_gap"]
    for model,ds,method,rho,policy in sorted({tuple(r[k] for k in ["model","dataset","method","rho","policy"]) for r in rows}):
        rr=[r for r in rows if (r["model"],r["dataset"],r["method"],r["rho"],r["policy"])==(model,ds,method,rho,policy)]
        base=dict(model=model,dataset=ds,method=method,rho=rho,policy=policy,n=len(rr))
        summary.append(dict(**base,**means(rr,keys)))
        values=[r["recall_gap"] for r in rr]
        gaps.append(dict(**base,**{f"q{q}":float(np.quantile(values,q/100)) for q in [0,25,50,75,100]},negative_fraction=float(np.mean(np.array(values)<0))))
    dump("B2",dict(records=rows,summary=summary,gap_summary=gaps,score_choices="Existing validation-FPR95-selected parameters are fixed across rho; only the validation threshold policy changes."))


def risk_curve(scores,errors):
    order=np.argsort(scores,kind="stable");s=scores[order];e=errors[order]
    ends=np.r_[np.flatnonzero(s[1:]!=s[:-1]),len(s)-1]
    coverage=(ends+1)/len(s);risk=np.cumsum(e)[ends]/(ends+1)
    aurc=float(np.sum(np.diff(np.r_[0.,coverage])*risk))
    grid=np.linspace(.01,1,100)
    rows=[dict(coverage=float(c),realized_coverage=float(coverage[min(np.searchsorted(coverage,c),len(ends)-1)]),risk=float(risk[min(np.searchsorted(coverage,c),len(ends)-1)])) for c in grid]
    return aurc,rows


def B3():
    rows=[];curves=[]
    for model,ds,unit,d,a,m in panels():
        z=a["ka"].astype(np.float64); labels=a["yk"]
        def objective(logt):
            x=z/np.exp(logt)
            return float(np.mean(logsumexp(x,axis=1)-x[np.arange(len(labels)),labels]))
        opt=minimize_scalar(objective,bounds=(np.log(.01),np.log(1000)),method="bounded",options=dict(xatol=1e-8,maxiter=500))
        if not opt.success:raise RuntimeError("Known-NLL temperature fit failed: "+unit)
        temperature=float(np.exp(opt.x));known=a["ty"]>=0
        for method in ["MSP","Temp-MSP","autoMixTemp","Known-NLL-TS"]:
            selection=dict(score_source="adapter",alpha=None,T_score=temperature) if method=="Known-NLL-TS" else m[method]["selection"]
            prob,_=probability_metrics(branch(a,"t",selection)[known],a["ty"][known],selection["T_score"])
            st,_=detection(a,selection)
            aurc,curve=risk_curve(st[known],a["ta"][known].argmax(1)!=a["ty"][known])
            rows.append(dict(**meta(model,ds,unit),method=method,temperature=selection["T_score"],ece15=prob["ece15"],nll=prob["nll"],brier=prob["brier_sum_classes"],aurc=aurc,
                optimizer_nfev=int(opt.nfev) if method=="Known-NLL-TS" else None))
            if method!="Known-NLL-TS":curves.extend(dict(**meta(model,ds,unit),method=method,**r) for r in curve)
    summary=[];curve_summary=[]
    for model,ds,method in sorted({(r["model"],r["dataset"],r["method"]) for r in rows}):
        rr=[r for r in rows if (r["model"],r["dataset"],r["method"])==(model,ds,method)]
        summary.append(dict(model=model,dataset=ds,method=method,n=len(rr),**means(rr,["ece15","nll","brier","aurc"])))
        for coverage in sorted({r["coverage"] for r in curves}):
            cc=[r for r in curves if (r["model"],r["dataset"],r["method"],r["coverage"])==(model,ds,method,coverage)]
            if cc:curve_summary.append(dict(model=model,dataset=ds,method=method,coverage=coverage,**means(cc,["risk","realized_coverage"])))
    dump("B3",dict(records=rows,summary=summary,risk_coverage=curve_summary,optimizer="Bounded continuous log-temperature known-validation NLL fit, T in [0.01,1000]; no unknown/target objective."))


def B4():
    rows=[];dense=[]
    grid=np.logspace(-1,4,61)
    for model,ds,unit,d,a,m in panels():
        ty=(a["ty"]<0).astype(int);ref=stable_msp(a["ta"],1000.)
        for t in [100.,1000.,10000.,1000000.,None]:
            score=stable_msp(a["ta"],t) if t is not None else a["ta"].astype(np.float64).mean(1)-a["ta"].astype(np.float64).max(1)
            rows.append(dict(**meta(model,ds,unit),temperature=t,variant="limit" if t is None else "finite",auroc=float(roc_auc_score(ty,score)),fpr95=fpr_at_recall(score,ty)["fpr95"],spearman_to_T1000=corr(score.tolist(),ref.tolist()),kendall_to_T1000=corr(score.tolist(),ref.tolist(),"kendall")))
        for method,route in [("Temp-MSP","adapter"),("autoMixTemp","auto")]:
            selection=choose(a,route,"msp",grid,"fpr95");s=stable_msp(branch(a,"t",selection),selection["T_score"])
            old=m[method];expanded=m.get("autoMixTemp-expanded") if route=="auto" else None
            if route=="adapter":
                oldgrid=[float(v) for v in read(d/"config.json")["arguments"]["temp_candidates"].split(",")]
                expanded_sel=choose(a,"adapter","msp",oldgrid+[10.,20.,50.,100.,1000.],"fpr95")
                expanded_score=stable_msp(branch(a,"t",expanded_sel),expanded_sel["T_score"])
                expanded=dict(auroc=float(roc_auc_score(ty,expanded_score)),fpr95=fpr_at_recall(expanded_score,ty)["fpr95"])
            fpr=fpr_at_recall(s,ty)["fpr95"]
            dense.append(dict(**meta(model,ds,unit),method=method,selection=selection,auroc=float(roc_auc_score(ty,s)),fpr95=fpr,
                at_lower=selection["T_score"]==float(grid[0]),at_upper=selection["T_score"]==float(grid[-1]),
                delta_fpr_original=fpr-old["fpr95"],delta_fpr_expanded=fpr-expanded["fpr95"]))
        print("B4 "+model+" "+unit,flush=True)
    summary=[];dsum=[]
    for model,ds,var,t in sorted({(r["model"],r["dataset"],r["variant"],r["temperature"]) for r in rows},key=str):
        rr=[r for r in rows if (r["model"],r["dataset"],r["variant"],r["temperature"])==(model,ds,var,t)]
        summary.append(dict(model=model,dataset=ds,variant=var,temperature=t,n=len(rr),**means(rr,["auroc","fpr95","spearman_to_T1000","kendall_to_T1000"])))
    for model,ds,method in sorted({(r["model"],r["dataset"],r["method"]) for r in dense}):
        rr=[r for r in dense if (r["model"],r["dataset"],r["method"])==(model,ds,method)]
        dsum.append(dict(model=model,dataset=ds,method=method,n=len(rr),lower_count=sum(r["at_lower"] for r in rr),upper_count=sum(r["at_upper"] for r in rr),**means(rr,["auroc","fpr95","delta_fpr_original","delta_fpr_expanded"])))
    dump("B4",dict(records=rows,summary=summary,dense_records=dense,dense_summary=dsum,grid=grid.tolist()))


def B5():
    rows=[];ties=[]
    for model,ds,unit,d,a,m in panels():
        if model!="ViT-B32" or ds!="pacs":continue
        base=m["MSP"];auto=m["autoMixTemp"];z=a["ta"].astype(np.float64);known=a["ty"]>=0
        p=softmax(z[known],axis=1);prob,_=probability_metrics(z[known],a["ty"][known],1.)
        domain=unit.split("_rotation")[0];rotation=unit.split("rotation")[1].split("_")[0]
        rows.append(dict(**meta(model,ds,unit),domain=domain,rotation=rotation,
            delta_fpr95=auto["fpr95"]-base["fpr95"],baseline_fpr95=base["fpr95"],known_confidence=float(p.max(1).mean()),
            validation_target_auc_gap=base["selection"]["val_auroc"]-base["auroc"],known_nll=prob["nll"]))
        if rotation=="04" and domain in ["art_painting","sketch"]:
            original={r["method"]:r for r in read(d/"results.json")}["autoMixTemp"]
            old=np.load(d/"scores_autoMixTemp.npy",allow_pickle=False);y=(a["ty"]<0).astype(int)
            det=fpr_at_recall(old,y);sel=original["selection"]
            stable=stable_msp(branch(a,"t",sel),sel["T_score"])
            ties.append(dict(**meta(model,ds,unit),domain=domain,temperature=sel["T_score"],source=sel["score_source"],alpha=sel["alpha"],
                zero_scores=int((old==0).sum()),zero_known=int(((old==0)&(y==0)).sum()),zero_unknown=int(((old==0)&(y==1)).sum()),
                boundary_tie_size=det["boundary_tie_size"],boundary_known=det["boundary_known"],boundary_unknown=det["boundary_unknown"],threshold=det["threshold"],
                original_fpr95=det["fpr95"],stable_same_parameter_fpr95=fpr_at_recall(stable,y)["fpr95"]))
    cells=[];assoc=[]
    features=["baseline_fpr95","known_confidence","validation_target_auc_gap","known_nll"]
    for domain,rot in sorted({(r["domain"],r["rotation"]) for r in rows}):
        rr=[r for r in rows if (r["domain"],r["rotation"])==(domain,rot)]
        cells.append(dict(domain=domain,rotation=rot,n=len(rr),**means(rr,["delta_fpr95"]+features)))
    for group in ["all"]+sorted({r["domain"] for r in cells}):
        cc=cells if group=="all" else [r for r in cells if r["domain"]==group]
        for feature in features:
            assoc.append(dict(group=group,feature=feature,clusters=len(cc),spearman=corr([r[feature] for r in cc],[r["delta_fpr95"] for r in cc])))
    v=[100*r["delta_fpr95"] for r in cells]
    domains=[dict(domain=d,**means([r for r in rows if r["domain"]==d],["delta_fpr95"])) for d in sorted({r["domain"] for r in rows})]
    dump("B5",dict(records=rows,cells=cells,domain_summary=domains,associations=assoc,saturation_records=ties,minimum_cell_pp=min(v),maximum_cell_pp=max(v),all_rounded_cells_within_stated_range=all(-3.8<=round(x,1)<=.8 for x in v)))


def B7():
    hist=BASE/"02_historical/pacs_same_checkpoint_20260919";rows=[]
    for u in read(hist/"protocol.json")["units"]:
        d=hist/"runs"/u["unit_id"]
        with np.load(d/"logits.npz",allow_pickle=False) as z:a={k:z[k] for k in z.files}
        old={r["method"]:r for r in read(d/"all_methods_results.json")};config=read(d/"config.json")
        args=config.get("arguments",config);grid=[float(v) for v in args["temp_candidates"].split(",")]
        y=(a["ty"]<0).astype(int)
        for method,route in [("MSP","adapter"),("Temp-MSP","adapter"),("autoMixTemp","auto")]:
            original=old[method];oldsel=original["selection"]
            for variant,sel in [("original_float32",oldsel),("stable_original_parameters",oldsel),("stable_validation_reselected",choose(a,route,"msp",[1.] if method=="MSP" else grid,"fpr95"))]:
                s=np.load(d/("scores_"+method+".npy"),allow_pickle=False) if variant=="original_float32" else stable_msp(branch(a,"t",sel),sel["T_score"])
                detail=fpr_at_recall(s,y)
                rows.append(dict(unit=u["unit_id"],method=method,variant=variant,selection=sel,
                    auroc=float(roc_auc_score(y,s)),fpr95=detail["fpr95"],boundary_tie_size=detail["boundary_tie_size"],recorded_auroc=original["auroc"],recorded_fpr95=original["fpr95"]))
        print("B7 "+u["unit_id"],flush=True)
    summary=[]
    for method,variant in sorted({(r["method"],r["variant"]) for r in rows}):
        rr=[r for r in rows if (r["method"],r["variant"])==(method,variant)]
        summary.append(dict(method=method,variant=variant,n=len(rr),**means(rr,["auroc","fpr95","boundary_tie_size"])))
    dump("B7",dict(records=rows,summary=summary,main_manuscript_permitted=False))


def C3a():
    extra=read(BASE/"04_analysis/additional_validation_summary_20261118.json")
    selected=[]
    for model,ds,unit,d,a,m in panels():
        if model=="ViT-B32" and ds=="pacs" and "rotation00_seed0" in unit:
            for method in ["autoMixTemp","Energy-T-tuned","Energy-only-T1"]:
                selected.append(dict(unit=unit,budget="primary_NLL_early_stop",selector="known_NLL",method=method,auroc=m[method]["auroc"],fpr95=m[method]["fpr95"]))
    for r in extra["fullbudget_records"]:
        if r["dataset"]=="pacs" and r["method"] in ["autoMixTemp","Energy-T-tuned"]:
            selected.append(dict(unit=r["unit"],budget="full20",selector=r["selector"],method=r["method"],auroc=r["auroc"],fpr95=r["fpr95"]))
    summary=[]
    for budget,selector,method in sorted({(r["budget"],r["selector"],r["method"]) for r in selected}):
        rr=[r for r in selected if (r["budget"],r["selector"],r["method"])==(budget,selector,method)]
        summary.append(dict(budget=budget,selector=selector,method=method,n=len(rr),**means(rr,["auroc","fpr95"])))
    dump("C3a",dict(records=selected,summary=summary,training_performed=False))


if __name__=="__main__":
    task=sys.argv[1];assert task in ["B1","B2","B3","B4","B5","B7","C3a"]
    spec=ROOT/"prespec"/(task+".json");assert sha(spec)==read(ROOT/"prespec/sealed_hashes.json")[task]
    globals()[task]()
