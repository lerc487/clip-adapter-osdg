Supply genuine author portrait photographs only, using the exact filenames below. IEEE biography layout reserves a 1 inch by 1.25 inch image area when a file exists; without a photo the no-photo biography is used. No blank frames or invented photographs are inserted.
author_photos/hongyi_yang.jpg
author_photos/cheng_fang.jpg
author_photos/yuanyu_liang.jpg
author_photos/jin_zhang.jpg
author_photos/songhai_shi.jpg
author_photos/ke_jiang.jpg
author_photos/taoze_liu.jpg
author_photos/zhanghong_wang.jpg
author_photos/jiegang_liu.jpg
